# Byte-credit recycle observer implementation checkpoint 4

Runtime source is byte-identical to accepted checkpoint 2. Relative to checkpoint 3, focused tests only add failure-path ownership:

- every public Stream.Write worker has a pre-registered cleanup that closes its synthetic Session and joins the goroutine within one second;
- synthetic control consumers select Session shutdown, close a done channel, and are joined explicitly on success and cleanup;
- normal successful paths also prove the owned goroutine has exited rather than relying on a buffered send/receive boundary.

This prevents a failing assertion or timeout from racing a leaked worker with the process-global observer reset in a later test. The outer driver must still apply an explicit Go test timeout and treat any process-group cleanup as an invalid attempt. No build or test was executed.
