# Byte-credit recycle observer implementation checkpoint 2

Checkpoint 2 preserves checkpoint 1 and applies only the bounded review corrections:

- all three record fields encode as empty JSON arrays rather than null;
- ambiguity, overflow, orphan overflow, or any dropped record makes the destructive interval incomplete and prevents reset, so a rejected interval cannot be drained again as healthy;
- a no-advance zero-credit wake is classified only as `stale`; peer records still report the actual delivered/coalesced notify result without claiming it caused a later wake;
- receiver controls require one exact header, and an observed positive control without bounded publication ownership sets global orphan-overflow rejection;
- receiver eligibility time is captured at observer hook entry before its mutex and fixed-slot scan;
- peer handler-entry time is captured before `processFlags`, so it includes peer-local flag/state work before the exact successful credit CAS;
- a positive FIN/RST still applies credit and notifies under unchanged protocol semantics, but marks the selected observer ledger sticky-ambiguous because terminal credit is outside the accepted cross-end update domain;
- actual `Stream.write` controls cover zero-credit wait through real peer apply, notify, retry, DATA completion, shutdown, deadline, and positive-FIN rejection;
- actual `waitForSendErrCommitOn` controls cover accepted completion timeout/shutdown, pre-enqueue timeout, accepted send error, repeat-drain stickiness, and unknown ownership.

The observer uses fixed process-global arrays: 4096 receiver records, 4096 peer records, 4096 wait records, and 4096 session/stream ledgers. A session drain clears only that exact session after a fully healthy interval. Other sessions' active handles and ordinal/cumulative state are preserved. Slot exhaustion invalidates rather than allocating or evicting.

The 2048 ordinary plus at most 28 forced-growth estimate applies only to positive updates for one selected 256 MiB transfer. It does not bound wait attempts or all conditioning transfers before the first selected pre-drain. Any real prehistory exceeding the fixed arrays is rejected through overflow/drop state; this checkpoint adds no activation API and claims no worst-case prehistory guarantee.

Receiver/writer hook sites follow existing Yamux-lock-to-observer ordering. Observer drain/export code never enters Yamux, TLS, raw connection, I/O, or blocking channel operations. The peer notify performed under the observer lock is nonblocking. Unix timestamps remain labels; durations use monotonic `time.Time.Sub`.

Ordinary bodies for `waitForSendErrCommitOn`, `sendWindowUpdateMode`, and `incrSendWindow` remain exact accepted-base copies. The existing ordinary `Stream.write` file remains unchanged. No Stream, Session, or sendReady fields were added.

No build or test was executed for this source checkpoint.
