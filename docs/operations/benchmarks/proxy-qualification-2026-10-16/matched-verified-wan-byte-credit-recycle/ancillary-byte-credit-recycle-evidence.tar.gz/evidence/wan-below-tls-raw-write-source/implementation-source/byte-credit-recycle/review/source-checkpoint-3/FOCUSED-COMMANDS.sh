#!/bin/sh
set -eu
regex='^(TestQualificationByteCreditActualReceiverThresholdForcedAndSessionIsolation|TestQualificationByteCreditActualPeerApplyAndWaitRange|TestQualificationByteCreditActualStreamWriteApplyWakeRetryAndDataCompletion|TestQualificationByteCreditActualStreamWriteTerminalWaitsJoin|TestQualificationByteCreditPositiveFINWakeFailsClosed|TestQualificationByteCreditPreEntryBufferedAndPermanentCompletionTimeout|TestQualificationByteCreditRejectedIntervalsRemainSticky|TestQualificationByteCreditFixedRingOverflowFailsClosed|TestQualificationByteCreditTwoAppliedUpdatesCoalesceIntoOneRetryRange|TestQualificationByteCreditStaleWakeAndRetryZeroDefect)$'
: "${GO:?set pinned Go binary}"
: "${SOURCE:?set fresh audited materialized source root}"
cd "$SOURCE/third_party/yamux"
"$GO" test -tags=p2pstream_qualification . -run "$regex" -count=1
"$GO" test -race -tags=p2pstream_qualification . -run "$regex" -count=1
