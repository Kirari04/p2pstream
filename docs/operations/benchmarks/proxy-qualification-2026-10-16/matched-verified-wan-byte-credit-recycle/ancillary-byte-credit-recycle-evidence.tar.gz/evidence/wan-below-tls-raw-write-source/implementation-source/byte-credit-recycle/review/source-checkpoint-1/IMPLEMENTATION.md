# Byte-credit recycle observer implementation checkpoint 1

This checkpoint implements the frozen schema and amendment 2 only in `third_party/yamux`. It adds qualification-tagged, fixed-capacity process-global receiver-publication, peer-apply, and byte-zero-wait records. Session-scoped destructive drain removes only the exact session after active receiver publications and peer waits reach zero; other sessions and fixed slot indexes remain untouched.

The peer observer mutex covers the successful byte-credit CAS, per-stream ordinal/cumulative update, record publication, and nonblocking notify attempt. Writer entry, wake, and retry samples load credit with those counters under the same mutex. Receiver and writer call sites enter the observer only in the existing one-way Yamux-lock-to-observer direction. Observer drain/export code never acquires Yamux, TLS, raw connection, channel-wait, or I/O locks.

Receiver timestamps are caller observations. An accepted enqueue followed by completion timeout or shutdown remains active and ambiguous permanently. No send-loop or physical-write hook was added. Unix timestamps are labels; every duration is computed from retained monotonic `time.Time` values with `Sub`.

The observer uses three independent 4096-record arrays and one 4096-entry session/stream ledger. Slot exhaustion and dropped records invalidate the snapshot while runtime flow control continues. The 2076 positive-update bound does not bound wait records.

Ordinary bodies for `waitForSendErrCommitOn`, `sendWindowUpdateMode`, and `incrSendWindow` are exact text copies of the accepted base functions. The existing ordinary `Stream.write` file is unchanged. No Stream, Session, or sendReady fields were added.

No build or test was executed for this source checkpoint.
