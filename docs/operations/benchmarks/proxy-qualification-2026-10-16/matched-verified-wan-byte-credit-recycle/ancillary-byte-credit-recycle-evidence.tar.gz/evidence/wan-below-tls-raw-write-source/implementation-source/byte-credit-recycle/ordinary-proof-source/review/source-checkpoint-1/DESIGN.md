# Ordinary byte-credit split proof

This bounded proof compares the audited combined-source Yamux package with the untagged byte-credit overlay. It covers exactly the three moved parent methods and every text symbol emitted beneath their symbol namespaces. Baseline and candidate must expose the same bounded symbol set, including nested closures/wrappers.

The proof requires exact nm type/size/cardinality; machine bytes and assembly with only whole-function addresses/in-function targets normalized; compiler frame, PCDATA/FUNCDATA and referenced stack-map bytes; all `-m=2` diagnostics inside each complete parent source span with only source positions normalized; and exact Stream, Session, aggregateWindow and sendReady layouts. The baseline and candidate compile separately with pinned Go 1.26.6, fresh caches, offline modules, and an identical ordinary-only layout probe. It does not run tagged runtime tests, endpoints, or traffic.

Literal generated-symbol names are part of the strict proof. A mismatch is preserved as failure and cannot be normalized by this driver. Any later bounded referent-bijection supplement requires separate review. The accepted receipt is flat, outside the records ledger, and binds the records ledger and strict report hashes.
