# Focused verification plan (not executed)

Use a fresh audited source/overlay, pinned Go and offline module cache, owned bounded process groups, exact JSON test-name auditing, and source/tool pre/post hashes. The exact normal and race commands are frozen in `FOCUSED-COMMANDS.sh`; they run the ten qualification controls from the nested Yamux module directory. Ordinary/tagged layout and compiler proof remains a separate gate. No execution is authorized by this checkpoint.
