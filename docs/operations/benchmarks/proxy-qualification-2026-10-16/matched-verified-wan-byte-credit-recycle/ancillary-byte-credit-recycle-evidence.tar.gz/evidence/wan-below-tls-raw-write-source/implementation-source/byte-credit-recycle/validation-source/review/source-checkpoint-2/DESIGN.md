# Byte-credit focused verification driver checkpoint 2

This driver binds source checkpoint 5 and preserves focused attempt 1. It runs the same exact normal then race contract in a fresh output using the nested Yamux module, pinned tools, fixed Go overlay, offline module cache, explicit timeouts, and owned process groups.

The result now records each stage's started state, exact direct status, whether the JSON audit ran, and its verdict. `normal_and_race` is true only when both commands ran, returned zero, and passed the exact JSON audit. This corrects attempt 1's misleading static `normal_and_race:true`; it does not alter test execution.
