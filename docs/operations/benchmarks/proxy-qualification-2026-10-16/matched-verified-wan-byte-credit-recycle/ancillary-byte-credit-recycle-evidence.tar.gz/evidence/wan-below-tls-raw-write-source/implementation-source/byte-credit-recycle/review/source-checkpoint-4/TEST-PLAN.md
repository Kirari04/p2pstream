# Focused verification plan (not executed)

Run the ten exact tests in `FOCUSED-COMMANDS.sh` once normal and once race from the nested Yamux module. The reviewed driver must add `-json`, `-timeout=300s`, exact expected test/action auditing, an outer timeout below its owned TERM/KILL bounds, source/tool pre/post hashes, and natural process-group joins. No execution is authorized by this checkpoint.
