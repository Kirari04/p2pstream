#!/usr/bin/python3.14
"""Prove ordinary Yamux code/layout equivalence for the three moved methods."""
from __future__ import annotations
import hashlib,importlib.util,json,os,re,shutil,stat,sys,time,traceback
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
REPO=Path('/home/user/.codex/worktrees/astra-proxy-performance/p2pstream')
CONT=REPO/'tmp/continuation-20261016'
COMP=CONT/'wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle'
RUNS=COMP/'runs'; SOURCE_CP=COMP/'review/source-checkpoint-5'; SOURCE_CP_SHA='d315f2e4f49c3b00d714346d5ff38a797c52e7b1874e7d21e7d89679a46d4287'
OVERLAY=COMP/'source/third_party/yamux'; FOCUSED=COMP/'runs/focused-attempt-2/records';FOCUSED_LEDGER_SHA='2ebacd83ac4102b008185ed173910c467bc271ca87ada6c4c831f1357fb0ea2e'
BASE_RUN=CONT/'wan-below-tls-raw-write-source/implementation-source/combined-build/runs/audited-build-attempt-1';BASE=BASE_RUN/'source';BASE_INV=BASE_RUN/'records/source-pre.json';BASE_INV_SHA='2bf3c0201892b5da5af984874f93bbdfa8c59dd92c04886fbeaf545f4437816c'
GO=Path('/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go');GO_SHA='29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45';GO_VERSION='go version go1.26.6 linux/amd64'
PYTHON=Path('/usr/bin/python3.14');PYTHON_SHA='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41';TASKSET=Path('/usr/bin/taskset');TASKSET_SHA='42acb8e233943873f3bf9eeb1e15bd3281498b5603a5b10d0f9bc37067a12d57'
HELPER=CONT/'wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py';HELPER_SHA='8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440'
PATTERN=r'github.com/hashicorp/yamux\.\(\*Session\)\.waitForSendErrCommitOn($|\.)|github.com/hashicorp/yamux\.\(\*Stream\)\.(sendWindowUpdateMode($|\.)|incrSendWindow($|\.))'
MAX_FILE=64<<20;MAX_LINE=1<<20

def sha(p):
 p=Path(p);s=p.lstat()
 if not stat.S_ISREG(s.st_mode) or s.st_size>MAX_FILE:raise ValueError(f'unsafe file: {p}')
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def inv(root):
 root=Path(root)
 if root.is_symlink() or not root.is_dir():raise ValueError(f'unsafe root: {root}')
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink():raise ValueError(f'symlink: {p}')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def safe_dot(n):
 if not n.startswith('./') or n.startswith('././'):raise ValueError('unsafe ledger name')
 q=PurePosixPath(n[2:])
 if not q.parts or q.is_absolute() or any(x in ('','.','..') for x in q.parts):raise ValueError('unsafe ledger name')
 return q.as_posix()
def verify_dot_ledger(root,expected_sha):
 root=Path(root);manifest=root/'SHA256SUMS.txt'
 if sha(manifest)!=expected_sha:raise ValueError(f'ledger hash changed: {root}')
 want={}
 for line in manifest.read_text().splitlines():
  d,n=line.split('  ',1);n=safe_dot(n)
  if n in want or re.fullmatch('[0-9a-f]{64}',d) is None:raise ValueError(f'malformed ledger: {root}')
  want[n]=d
 got={k:v for k,v in inv(root).items() if k!='SHA256SUMS.txt'}
 if got!=want:raise ValueError(f'ledger coverage mismatch: {root}')
 return got
def verify_cp():
 if sha(SOURCE_CP/'SHA256SUMS.txt')!=SOURCE_CP_SHA:raise ValueError('source checkpoint changed')
 want={}
 for line in (SOURCE_CP/'SHA256SUMS.txt').read_text().splitlines():
  d,n=line.split('  ',1);n=safe_dot(n)
  if n in want or re.fullmatch('[0-9a-f]{64}',d) is None:raise ValueError('source ledger')
  want[n]=d
 got={k:v for k,v in inv(SOURCE_CP).items() if k!='SHA256SUMS.txt'}
 if got!=want:raise ValueError('source checkpoint coverage')
 return got
def write_json(p,v):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def write_text(p,v):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:f.write(v)
def load_helper():
 if sha(HELPER)!=HELPER_SHA:raise ValueError('helper changed')
 spec=importlib.util.spec_from_file_location('ordinary_owned',HELPER)
 if spec is None or spec.loader is None:raise ValueError('helper import')
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def copy_regular(src,dst):
 if Path(dst).exists():raise ValueError('fresh copy output required')
 data=Path(src).read_bytes()
 if len(data)>MAX_FILE:raise ValueError('copy input too large')
 fd=os.open(dst,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:f.write(data)
def extract_archive(stdout,dst):
 lines=Path(stdout).read_text().splitlines()
 if len(lines)!=1:raise ValueError('export path cardinality')
 src=Path(lines[0]);copy_regular(src,dst)
def extract_layout(stream,out):
 actions=[];encoded=[];package_pass=0
 with Path(stream).open('rb') as f:
  total=0
  for number,line in enumerate(f,1):
   total+=len(line)
   if total>MAX_FILE or len(line)>MAX_LINE or not line.endswith(b'\n'):raise ValueError('layout JSON bound')
   event=json.loads(line)
   if event.get('Package')!='github.com/hashicorp/yamux':continue
   if event.get('Test')=='TestQualificationBaselineCandidateTypeLayoutProbe' and event.get('Action') in ('run','pass','fail','skip'):actions.append(event['Action'])
   if event.get('Test')=='TestQualificationBaselineCandidateTypeLayoutProbe' and event.get('Action')=='output':
    text=event.get('Output','');mark='QUALIFICATION_LAYOUT_JSON='
    if mark in text:encoded.append(text.split(mark,1)[1].strip())
   if event.get('Test') is None and event.get('Action')=='pass':package_pass+=1
 if actions!=['run','pass'] or package_pass!=1 or len(encoded)!=1:raise ValueError('layout exact audit')
 value=json.loads(encoded[0]);write_json(out,value)
def main():
 if len(sys.argv)!=3:raise SystemExit('usage: run-proof.py FRESH_OUTPUT EXPECTED_CHECKPOINT_SHA256')
 output=Path(sys.argv[1]).resolve();expected=sys.argv[2];cp=Path(__file__).resolve().parent
 if output.exists() or output.parent!=RUNS.resolve():raise SystemExit('fresh direct output required')
 output.mkdir(mode=0o700);records=output/'records';records.mkdir(mode=0o700);write_text(records/'start-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
 accepted=False;issue=None;helper=None;cp_pre=source_pre=focused_pre=base_pre=overlay_pre=None;configs={}
 try:
  cp_pre=verify_dot_ledger(cp,expected);source_pre=verify_cp();focused_pre=verify_dot_ledger(FOCUSED,FOCUSED_LEDGER_SHA)
  if json.loads((FOCUSED/'RESULT.json').read_text()).get('accepted') is not True or (FOCUSED/'final.status').read_text()!='0\n':raise ValueError('focused prerequisite')
  if sha(BASE_INV)!=BASE_INV_SHA:raise ValueError('base inventory changed')
  base_pre=json.loads(BASE_INV.read_text()).get('files')
  if not isinstance(base_pre,dict) or inv(BASE)!=base_pre:raise ValueError('base source changed')
  expected_overlay={n:v['sha256'] for n,v in json.loads((SOURCE_CP/'INPUTS.json').read_text()).get('overlay_files',{}).items()};overlay_pre=inv(OVERLAY)
  if overlay_pre!=expected_overlay or len(overlay_pre)!=11:raise ValueError('overlay changed')
  if sha(GO)!=GO_SHA or sha(PYTHON)!=PYTHON_SHA or sha(TASKSET)!=TASKSET_SHA:raise ValueError('tool changed')
  helper=load_helper();probe=cp/'ordinary_layout_probe_test.go';compare=cp/'compare_ordinary.py'
  virtual_root=BASE/'third_party/yamux';probe_virtual=virtual_root/'qualification_byte_credit_ordinary_layout_probe_test.go'
  baseline_replace={str(probe_virtual):str(probe)}
  candidate_replace={str(virtual_root/name):str(OVERLAY/name) for name in overlay_pre};candidate_replace[str(probe_virtual)]=str(probe)
  for side,repl in (('baseline',baseline_replace),('candidate',candidate_replace)):
   path=output/f'{side}-overlay.json';write_json(path,{'Replace':repl});configs[side]=repl
  write_json(records/'inputs-pre.json',{'schema_version':1,'proof_checkpoint_sha256':expected,'proof_files':cp_pre,'source_checkpoint_sha256':SOURCE_CP_SHA,'source_files':source_pre,'focused_ledger_sha256':FOCUSED_LEDGER_SHA,'base_inventory_sha256':BASE_INV_SHA,'overlay_files':overlay_pre,'go':{'path':str(GO),'sha256':GO_SHA,'version':GO_VERSION},'python_sha256':PYTHON_SHA,'taskset_sha256':TASKSET_SHA,'helper_sha256':HELPER_SHA,'symbol_pattern':PATTERN})
  common={'HOME':'/home/user','PATH':'/usr/bin:/bin','GOENV':'off','GOTOOLCHAIN':'local','GOWORK':'off','GOFLAGS':'','CGO_ENABLED':'1','GOMAXPROCS':'16','GOPATH':str(output/'gopath'),'GOMODCACHE':'/home/user/go/pkg/mod','GOPROXY':'off','GOSUMDB':'off','LC_ALL':'C','TZ':'Europe/Zurich'}
  if helper.run(records,'comparator-contract',[str(PYTHON),'-I','-B',str(cp/'test-comparator.py'),str(compare),str(records/'comparator-contract.json')],REPO,common,30)!=0:raise ValueError('comparator contract')
  contract_result=json.loads((records/'comparator-contract.json').read_text())
  if contract_result.get('accepted') is not True or contract_result.get('case_count')!=3 or not all(x.get('accepted') is True for x in contract_result.get('cases',[])):raise ValueError('comparator contract result')
  for p in (output/'gopath',output/'tmp',output/'cache-baseline-export',output/'cache-candidate-export',output/'cache-baseline-asm',output/'cache-candidate-asm',output/'cache-baseline-escape',output/'cache-candidate-escape',output/'cache-baseline-layout',output/'cache-candidate-layout'):p.mkdir(mode=0o700)
  env0=dict(common,TMPDIR=str(output/'tmp'),GOTMPDIR=str(output/'tmp'),GOCACHE=str(output/'cache-baseline-export'))
  if helper.run(records,'go-version',[str(GO),'version'],BASE,env0,30)!=0 or (records/'go-version.stdout.log').read_text().strip()!=GO_VERSION:raise ValueError('Go version')
  if helper.run(records,'go-env',[str(GO),'env','-json','GOMOD','GOWORK','GOENV','GOTOOLCHAIN','GOMODCACHE','GOPATH','GOPROXY','GOSUMDB'],virtual_root,env0,30)!=0:raise ValueError('Go env')
  want={'GOMOD':str(virtual_root/'go.mod'),'GOWORK':'off','GOENV':'','GOTOOLCHAIN':'local','GOMODCACHE':'/home/user/go/pkg/mod','GOPATH':str(output/'gopath'),'GOPROXY':'off','GOSUMDB':'off'}
  if json.loads((records/'go-env.stdout.log').read_text())!=want:raise ValueError('effective Go env')
  for side in ('baseline','candidate'):
   overlay=output/f'{side}-overlay.json';base_cmd=[str(TASKSET),'-c','0-15',str(GO)]
   def run(name,args,cache,timeout=360):
    env=dict(common,TMPDIR=str(output/'tmp'),GOTMPDIR=str(output/'tmp'),GOCACHE=str(output/cache))
    status=helper.run(records,name,args,virtual_root,env,timeout)
    if status!=0:raise ValueError(f'{name} failed')
   run(f'{side}-export',base_cmd+['list','-a','-export','-overlay='+str(overlay),'-f','{{.Export}}','.'],f'cache-{side}-export')
   extract_archive(records/f'{side}-export.stdout.log',records/f'{side}-yamux.a')
   run(f'{side}-asm',base_cmd+['build','-a','-trimpath','-overlay='+str(overlay),'-gcflags=github.com/hashicorp/yamux=-S','.'],f'cache-{side}-asm')
   run(f'{side}-escape',base_cmd+['build','-a','-trimpath','-overlay='+str(overlay),'-gcflags=github.com/hashicorp/yamux=-m=2','.'],f'cache-{side}-escape')
   run(f'{side}-layout',base_cmd+['test','-json','-count=1','-timeout=300s','-overlay='+str(overlay),'.','-run','^TestQualificationBaselineCandidateTypeLayoutProbe$'],f'cache-{side}-layout')
   extract_layout(records/f'{side}-layout.stdout.log',records/f'{side}-layout.json')
   if helper.run(records,f'{side}-nm',[str(GO),'tool','nm','-size',str(records/f'{side}-yamux.a')],REPO,common,60)!=0:raise ValueError(f'{side} nm')
   if helper.run(records,f'{side}-objdump',[str(GO),'tool','objdump','-s',PATTERN,str(records/f'{side}-yamux.a')],REPO,common,60)!=0:raise ValueError(f'{side} objdump')
  proof=records/'proof'
  command=[str(PYTHON),'-I','-B',str(compare),'--baseline-objdump',str(records/'baseline-objdump.stdout.log'),'--baseline-nm',str(records/'baseline-nm.stdout.log'),'--baseline-asm',str(records/'baseline-asm.stderr.log'),'--baseline-escape',str(records/'baseline-escape.stderr.log'),'--baseline-layout',str(records/'baseline-layout.json'),'--baseline-source-root',str(virtual_root),'--candidate-objdump',str(records/'candidate-objdump.stdout.log'),'--candidate-nm',str(records/'candidate-nm.stdout.log'),'--candidate-asm',str(records/'candidate-asm.stderr.log'),'--candidate-escape',str(records/'candidate-escape.stderr.log'),'--candidate-layout',str(records/'candidate-layout.json'),'--candidate-source-root',str(OVERLAY),'--output',str(proof)]
  if helper.run(records,'compare',command,REPO,common,60)!=0:raise ValueError('strict ordinary comparison failed')
  report=json.loads((proof/'report.json').read_text())
  if report.get('accepted') is not True or set(report.get('gates',{}))!={'nm','code','compiler','compiler_data','escape','layout'} or not all(report['gates'].values()):raise ValueError('proof report rejected')
  accepted=True
 except BaseException as e:
  issue=f'{type(e).__name__}: {e}';traceback.print_exc()
 finally:
  checks={};errors={}
  def check(name,fn):
   try:checks[name]=bool(fn())
   except BaseException as e:checks[name]=False;errors[name]=f'{type(e).__name__}: {e}'
  check('proof_checkpoint_unchanged',lambda:cp_pre is not None and verify_dot_ledger(cp,expected)==cp_pre)
  check('source_checkpoint_unchanged',lambda:source_pre is not None and verify_cp()==source_pre)
  check('focused_prerequisite_unchanged',lambda:focused_pre is not None and verify_dot_ledger(FOCUSED,FOCUSED_LEDGER_SHA)==focused_pre and json.loads((FOCUSED/'RESULT.json').read_text()).get('accepted') is True and (FOCUSED/'final.status').read_text()=='0\n')
  check('base_unchanged',lambda:base_pre is not None and sha(BASE_INV)==BASE_INV_SHA and json.loads(BASE_INV.read_text()).get('files')==base_pre and inv(BASE)==base_pre)
  check('overlay_unchanged',lambda:overlay_pre is not None and inv(OVERLAY)==overlay_pre)
  check('overlay_configs_unchanged',lambda:configs and all(json.loads((output/f'{s}-overlay.json').read_text())=={'Replace':configs[s]} for s in configs))
  check('tools_unchanged',lambda:sha(GO)==GO_SHA and sha(PYTHON)==PYTHON_SHA and sha(TASKSET)==TASKSET_SHA and sha(HELPER)==HELPER_SHA)
  check('all_groups_joined_without_force',lambda:helper is not None and all(json.loads(p.read_text()).get('group_joined') is True and json.loads(p.read_text()).get('forced_cleanup') is False for p in records.glob('*.lifecycle.json')))
  accepted=accepted and all(checks.values())
  write_json(records/'RESULT.json',{'schema_version':1,'accepted':accepted,'issue':issue,'gates':json.loads((records/'proof/report.json').read_text()).get('gates') if (records/'proof/report.json').is_file() else None,'post_checks':checks,'post_errors':errors,'endpoint_or_traffic':False})
  write_text(records/'final.status','0\n' if accepted else '1\n');write_text(records/'end-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
  with (records/'SHA256SUMS.txt').open('x') as f:
   for p in sorted(records.rglob('*')):
    if p.is_file() and p.name!='SHA256SUMS.txt':f.write(f'{sha(p)}  ./{p.relative_to(records).as_posix()}\n')
  report_path=records/'proof/report.json';report=json.loads(report_path.read_text()) if report_path.is_file() else {}
  write_json(output/'RECEIPT.json',{'schema_version':1,'diagnostic':'wan-byte-credit-recycle','accepted':accepted,'ordinary_untagged_exact':accepted and report.get('accepted') is True,'strict_generated_symbol_names_equal':accepted and report.get('accepted') is True,'strict_proof_accepted':accepted and report.get('accepted') is True,'endpoint_or_traffic':False,'source_checkpoint_sha256':SOURCE_CP_SHA,'focused_records_ledger_sha256':FOCUSED_LEDGER_SHA,'proof_checkpoint_sha256':expected,'base_source_inventory_sha256':BASE_INV_SHA,'records_ledger_sha256':sha(records/'SHA256SUMS.txt'),'result_sha256':sha(records/'RESULT.json'),'ordinary_report_sha256':sha(report_path) if report_path.is_file() else None})
  write_text(output/'FINAL','complete\n')
 return 0 if accepted else 1
if __name__=='__main__':raise SystemExit(main())
