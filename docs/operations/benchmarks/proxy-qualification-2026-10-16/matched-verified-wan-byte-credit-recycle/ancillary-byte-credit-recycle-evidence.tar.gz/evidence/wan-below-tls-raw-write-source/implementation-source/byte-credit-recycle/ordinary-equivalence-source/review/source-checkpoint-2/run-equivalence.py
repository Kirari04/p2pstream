#!/usr/bin/env python3
"""Owned offline driver over immutable byte-credit ordinary proof artifacts."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import stat
import sys
import time
from pathlib import Path, PurePosixPath

sys.dont_write_bytecode = True
REPO = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
ROOT = REPO / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle"
STRICT = ROOT / "runs/ordinary-proof-attempt-2/records"
STRICT_LEDGER = "b44462efcda19a1a8cd4357effe7fdb590b2c565a034c29ddf747264ea44b13b"
FAILED = ROOT / "runs/ordinary-proof-attempt-1/records"
FAILED_LEDGER = "9366180252ad6af8f4ae14f8212aa629e62581e5c0e90ad25b7a08a8f1da6927"
FOCUSED = ROOT / "runs/focused-attempt-2/records"
FOCUSED_LEDGER = "2ebacd83ac4102b008185ed173910c467bc271ca87ada6c4c831f1357fb0ea2e"
SOURCE_CP = ROOT / "review/source-checkpoint-5"
SOURCE_CP_SHA = "d315f2e4f49c3b00d714346d5ff38a797c52e7b1874e7d21e7d89679a46d4287"
PROOF_CP = ROOT / "ordinary-proof-source/review/source-checkpoint-4"
PROOF_CP_SHA = "6ce6b7a39f74be0e04bf653cc533b7bc5258d628f88bb776a8d869485585bace"
BASE_INVENTORY = REPO / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/combined-build/runs/audited-build-attempt-1/records/source-pre.json"
BASE_INVENTORY_SHA = "2bf3c0201892b5da5af984874f93bbdfa8c59dd92c04886fbeaf545f4437816c"
HELPER = REPO / "tmp/continuation-20261016/wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
HELPER_SHA = "8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
PYTHON = Path("/usr/bin/python3.14")
PYTHON_SHA = "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
MAX = 8 << 20


def sha(path: Path) -> str:
    st = path.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_size > MAX:
        raise ValueError(f"unsafe file: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def inventory(root: Path, exclude=()) -> dict[str, str]:
    excluded = set(exclude)
    result = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"symlink: {path}")
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            if relative not in excluded:
                result[relative] = sha(path)
    return result


def manifest(root: Path, expected_sha: str) -> dict[str, str]:
    ledger = root / "SHA256SUMS.txt"
    if sha(ledger) != expected_sha:
        raise ValueError(f"manifest hash: {root}")
    expected = {}
    for line in ledger.read_text().splitlines():
        digest, raw = line.split("  ", 1)
        name = raw[2:] if raw.startswith("./") else raw
        pure = PurePosixPath(name)
        if not name or raw not in (name, "./" + name) or name != pure.as_posix() or pure.is_absolute() or ".." in pure.parts or name in expected:
            raise ValueError(f"manifest path: {raw}")
        expected[name] = digest
    if inventory(root, {"SHA256SUMS.txt"}) != expected:
        raise ValueError(f"manifest coverage: {root}")
    return expected


def evidence(root: Path, expected_sha: str) -> dict[str, str]:
    ledger = root / "SHA256SUMS.txt"
    if sha(ledger) != expected_sha:
        raise ValueError(f"evidence ledger hash: {root}")
    expected = {}
    for line in ledger.read_text().splitlines():
        digest, raw = line.split("  ", 1)
        name = raw[2:] if raw.startswith("./") else raw
        pure = PurePosixPath(name)
        if not name or raw not in (name, "./" + name) or pure.is_absolute() or ".." in pure.parts or name in expected:
            raise ValueError(f"evidence path: {raw}")
        expected[name] = digest
    if inventory(root, {"SHA256SUMS.txt"}) != expected:
        raise ValueError(f"evidence coverage: {root}")
    return expected


def write_json(path: Path, value) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def write_text(path: Path, value: str) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as handle:
        handle.write(value)


def publish(path: Path, value) -> None:
    temporary = path.with_name("." + path.name + ".tmp")
    write_json(temporary, value)
    os.rename(temporary, path)


def load_helper():
    if sha(HELPER) != HELPER_SHA:
        raise ValueError("owned helper")
    spec = importlib.util.spec_from_file_location("owned", HELPER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    if len(sys.argv) != 3:
        raise ValueError("usage: run-equivalence.py FRESH_OUTPUT EXPECTED_CHECKPOINT_SHA256")
    output = Path(sys.argv[1]).resolve()
    checkpoint = Path(__file__).resolve().parent
    expected_checkpoint = sys.argv[2]
    if output.exists() or output.parent != (ROOT / "runs").resolve():
        raise ValueError("fresh bounded output")
    output.mkdir(mode=0o700)
    records = output / "records"
    records.mkdir(mode=0o700)
    write_text(records / "start-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))
    accepted, issue, receipt = False, None, None
    snapshots = {}
    try:
        snapshots["checkpoint"] = manifest(checkpoint, expected_checkpoint)
        snapshots["source"] = manifest(SOURCE_CP, SOURCE_CP_SHA)
        snapshots["proof"] = manifest(PROOF_CP, PROOF_CP_SHA)
        snapshots["strict"] = evidence(STRICT, STRICT_LEDGER)
        snapshots["failed"] = evidence(FAILED, FAILED_LEDGER)
        snapshots["focused"] = evidence(FOCUSED, FOCUSED_LEDGER)
        helper = load_helper()
        if sha(PYTHON) != PYTHON_SHA or sha(BASE_INVENTORY) != BASE_INVENTORY_SHA:
            raise ValueError("Python/base inventory")
        strict_result = json.loads((STRICT / "RESULT.json").read_text())
        strict_report = json.loads((STRICT / "proof/report.json").read_text())
        failed_result = json.loads((FAILED / "RESULT.json").read_text())
        focused_result = json.loads((FOCUSED / "RESULT.json").read_text())
        if strict_result.get("accepted") is not False or strict_report.get("accepted") is not False:
            raise ValueError("strict disposition")
        if failed_result.get("accepted") is not False or focused_result.get("accepted") is not True:
            raise ValueError("prerequisite dispositions")
        environment = {"PATH": "/usr/bin:/bin", "LC_ALL": "C", "TZ": "Europe/Zurich"}
        status = helper.run(
            records,
            "contracts",
            [str(PYTHON), "-I", "-B", str(checkpoint / "test_equivalence.py"), "--analyzer", str(checkpoint / "prove_equivalence.py"), "--input-root", str(STRICT), "--output", str(records / "contracts")],
            REPO,
            environment,
            60,
        )
        if status != 0 or json.loads((records / "contracts/result.json").read_text()).get("accepted") is not True:
            raise ValueError("contracts")
        status = helper.run(
            records,
            "equivalence",
            [str(PYTHON), "-I", "-B", str(checkpoint / "prove_equivalence.py"), "--baseline-asm", str(STRICT / "baseline-asm.stderr.log"), "--candidate-asm", str(STRICT / "candidate-asm.stderr.log"), "--baseline-canonical", str(STRICT / "proof/baseline-canonical.json"), "--candidate-canonical", str(STRICT / "proof/candidate-canonical.json"), "--strict-report", str(STRICT / "proof/report.json"), "--output", str(records / "equivalence")],
            REPO,
            environment,
            60,
        )
        result = json.loads((records / "equivalence/result.json").read_text())
        if status != 0 or result.get("accepted") is not True or result.get("instruction_difference_count") != 1:
            raise ValueError("equivalence")
        receipt = {
            "schema_version": 1,
            "diagnostic": "wan-byte-credit-recycle",
            "accepted": True,
            "ordinary_untagged_code_and_referents_equivalent": True,
            "strict_generated_symbol_names_equal": False,
            "strict_proof_accepted": False,
            "supplemental_reference_equivalence_accepted": True,
            "endpoint_execution": False,
            "endpoint_or_traffic": False,
            "wan_traffic": False,
            "source_checkpoint_sha256": SOURCE_CP_SHA,
            "focused_records_ledger_sha256": FOCUSED_LEDGER,
            "reused_failed_records_ledger_sha256": FAILED_LEDGER,
            "strict_attempt_records_ledger_sha256": STRICT_LEDGER,
            "strict_report_sha256": sha(STRICT / "proof/report.json"),
            "strict_proof_checkpoint_sha256": PROOF_CP_SHA,
            "base_source_inventory_sha256": BASE_INVENTORY_SHA,
            "supplement_checkpoint_sha256": expected_checkpoint,
            "supplement_result_sha256": sha(records / "equivalence/result.json"),
            "supplement_contract_result_sha256": sha(records / "contracts/result.json"),
        }
        accepted = True
    except BaseException as error:
        issue = f"{type(error).__name__}: {error}"
    finally:
        checks = {}

        def check(name, fn):
            try:
                checks[name] = bool(fn())
            except BaseException:
                checks[name] = False

        check("checkpoint_unchanged", lambda: snapshots.get("checkpoint") == manifest(checkpoint, expected_checkpoint))
        check("source_checkpoint_unchanged", lambda: snapshots.get("source") == manifest(SOURCE_CP, SOURCE_CP_SHA))
        check("strict_attempt_unchanged", lambda: snapshots.get("strict") == evidence(STRICT, STRICT_LEDGER))
        check("failed_attempt_unchanged", lambda: snapshots.get("failed") == evidence(FAILED, FAILED_LEDGER))
        check("focused_prerequisite_unchanged", lambda: snapshots.get("focused") == evidence(FOCUSED, FOCUSED_LEDGER))
        check("proof_checkpoint_unchanged", lambda: snapshots.get("proof") == manifest(PROOF_CP, PROOF_CP_SHA))
        check("python_unchanged", lambda: sha(PYTHON) == PYTHON_SHA)
        check("base_source_inventory_unchanged", lambda: sha(BASE_INVENTORY) == BASE_INVENTORY_SHA)
        check("helper_unchanged", lambda: sha(HELPER) == HELPER_SHA)
        check(
            "groups_joined_without_force",
            lambda: {path.name for path in records.glob("*.lifecycle.json")} == {"contracts.lifecycle.json", "equivalence.lifecycle.json"}
            and all(
                (lambda value: value.get("direct_status") == 0 and value.get("direct_child_joined") is True and value.get("group_joined") is True and value.get("timed_out") is False and not value.get("forced_cleanup"))(json.loads(path.read_text()))
                for path in records.glob("*.lifecycle.json")
            ),
        )
        accepted = accepted and all(checks.values())
        write_json(records / "FINAL.json", {"schema_version": 1, "accepted": accepted, "issue": issue, "post_checks": checks, "endpoint_or_traffic": False})
        write_text(records / "FINAL.status", "0\n" if accepted else "1\n")
        write_text(records / "end-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))
        lines = []
        for path in sorted(records.rglob("*")):
            if path.is_file() and path.name != "SHA256SUMS.txt":
                lines.append(f"{sha(path)}  ./{path.relative_to(records).as_posix()}\n")
        write_text(records / "SHA256SUMS.txt", "".join(lines))
        if accepted:
            receipt["final_sha256"] = sha(records / "FINAL.json")
            receipt["records_ledger_sha256"] = sha(records / "SHA256SUMS.txt")
            publish(output / "RECEIPT.json", receipt)
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
