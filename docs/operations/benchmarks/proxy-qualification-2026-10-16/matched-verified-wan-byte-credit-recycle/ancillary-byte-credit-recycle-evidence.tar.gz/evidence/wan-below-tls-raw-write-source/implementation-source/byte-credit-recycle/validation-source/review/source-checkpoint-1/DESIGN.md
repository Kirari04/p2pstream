# Byte-credit focused execution driver

This driver runs only the ten frozen checkpoint-4 Yamux controls, once normal and once race, through the reviewed owned-process helper. It uses a Go overlay over the immutable audited combined source, so it neither copies nor mutates the 98 MiB source tree. The overlay maps exactly eleven reviewed files, including new tagged files.

The child working directory is the nested `third_party/yamux` module. Go has a 300-second test timeout inside a 360-second owned process-group bound. Any TERM/KILL cleanup invalidates the attempt. The Go JSON auditor requires exactly ten roots, two expected subtests, one package pass, and no additional/failing/skipped tests. Base source, overlay source, source/driver checkpoints, tools, helper, overlay configuration, and natural joins are checked on every exit path.

No command has been executed from this checkpoint.
