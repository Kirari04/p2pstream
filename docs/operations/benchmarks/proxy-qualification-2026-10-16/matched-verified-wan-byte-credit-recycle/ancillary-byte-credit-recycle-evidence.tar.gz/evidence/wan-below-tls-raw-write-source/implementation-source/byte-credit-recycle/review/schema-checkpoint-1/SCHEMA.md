# Qualification byte-credit trace schema 1

This is the frozen adapter boundary for the qualification-only Yamux observer. The implementation owns only files under third_party/yamux. Server/agent adapters and arm validators are a disjoint overlay.

## API and limits

Tagged Yamux exports:

- const QualificationByteCreditTraceSchemaVersion = 1
- const QualificationByteCreditTraceRecordLimit = 4096
- func (*Session) DrainQualificationByteCreditTrace() QualificationByteCreditTraceSnapshot

The receiver-publication ring, peer-apply ring, and peer-wait ring each have an independent fixed capacity of 4096. The 2048 ordinary plus at most 28 forced-growth calculation bounds only positive update records; it does not bound wait attempts. Wait overflow is rejected, not truncated silently.

Drain is scoped to the exact Session receiver. It never resolves Session/Stream/TLS/raw state while holding the observer mutex. Complete state is reset only when active_receiver_publications and active_peer_waits are zero. An accepted enqueue followed by caller timeout or shutdown stays active and ambiguous permanently, so drain remains incomplete and never resets it healthy.

## Snapshot

QualificationByteCreditTraceSnapshot has JSON fields:

- schema_version exact 1
- enabled true
- complete, reset_performed
- ambiguous, overflow
- orphan_overflow (a bounded-state failure that could not be assigned to a session slot)
- active_receiver_publications, active_peer_waits
- dropped_receiver_records, dropped_peer_records, dropped_wait_records
- receiver_records: array of QualificationByteCreditReceiverRecord
- peer_records: array of QualificationByteCreditPeerRecord
- wait_records: array of QualificationByteCreditWaitRecord

Accepted pre/post requires enabled, complete, reset_performed, no ambiguity/overflow/orphan overflow, zero active and dropped counts. Arrays may be nonempty on a complete post drain; prior counts are not required to be zero.

## Receiver record

QualificationByteCreditReceiverRecord fields:

- relative_ordinal uint64, positive and contiguous within one destructive interval and stream
- stream_id uint32 positive
- flags uint16
- kind exact normal_read or forced_growth
- delta uint32 positive
- cumulative uint64 positive, exact sum through relative_ordinal
- receive_window_after uint32
- eligibility_observed_unix_ns int64 positive
- enqueue_observed_unix_ns int64, positive only when enqueue_observed true
- completion_result_observed_unix_ns int64, positive only when completion_result_observed true
- eligibility_to_enqueue_observed_ns uint64
- enqueue_to_completion_result_observed_ns uint64
- eligibility_to_completion_result_observed_ns uint64
- enqueue_observed bool
- completion_result_observed bool
- active bool
- ambiguous bool
- outcome exact pending, enqueue_shutdown, enqueue_timeout, success, error, completion_shutdown, or completion_timeout

The observed durations include caller scheduling. No field claims physical queue/write duration. Accepted success chronology is eligibility <= enqueue <= completion; failed pre-enqueue records have no enqueue timestamp. A post-enqueue shutdown/timeout is permanently active and ambiguous.

## Peer record

QualificationByteCreditPeerRecord fields:

- relative_ordinal uint64, positive and contiguous within interval and stream
- stream_id uint32 positive
- flags uint16
- delta uint32 positive
- cumulative uint64 positive, exact sum through relative_ordinal
- byte_credit_before, byte_credit_after uint32 with after = before + delta and no overflow
- handler_entry_unix_ns, credit_applied_unix_ns, notify_observed_unix_ns int64 positive
- handler_to_credit_applied_ns, credit_applied_to_notify_observed_ns, handler_to_notify_observed_ns uint64
- notify_result exact delivered or coalesced
- active_wait_token uint64, zero means none at apply time

The peer observer mutex covers the byte-credit CAS, ordinal/cumulative update, record, and nonblocking notify attempt. These local timestamps include observer-lock acquisition and scheduling. They do not measure cross-process transit.

## Wait record

QualificationByteCreditWaitRecord fields:

- token uint64 positive
- stream_id uint32 positive
- decision_credit uint32, exactly zero for an actual byte-zero wait
- entry/wake/retry ordinal uint64
- entry/wake/retry cumulative uint64
- entry/wake/retry byte_credit uint32
- entry_observed_unix_ns, wake_observed_unix_ns, retry_observed_unix_ns int64
- entry_to_wake_observed_ns, wake_to_retry_observed_ns, entry_to_retry_observed_ns uint64
- outcome exact pending, retry, shutdown, or timeout
- classification exact pending, applied_range, pre_entry_buffered, stale, coalesced, shutdown, or timeout
- range_first_ordinal, range_last_ordinal uint64; both zero unless retry ordinal advanced beyond entry
- active, ambiguous, terminal, advanced, retry_zero_after_advance bool

Entry, wake, and immediate retry snapshots load byte credit plus ordinal/cumulative under the same observer lock used by peer apply. A legal zero-decision to positive-entry race is pre_entry_buffered. No-advance wakes are descriptive stale/coalesced/pre_entry_buffered. One wake can cover multiple applied frames; no record claims an individual frame caused it. retry_zero_after_advance is an integrity defect only for a nonterminal trace-consistent retry whose ordinal/cumulative advanced and whose same locked retry credit is zero.

## Endpoint join and ownership exclusions

Adapters select records only after the existing lane/session-generation/stream/tuple ownership join. Cross-end equality is exact ordered (relative_ordinal, flags, delta, cumulative). Receiver kind supplies normal_read versus forced_growth after that equality join. No timestamp is subtracted across processes.

The adapter overlay owns authenticated server/agent composition, record selection, and selected-arm validation. It must not edit third_party/yamux observer/hook/test files. The Yamux overlay must not edit adapter or validator files. Integration rejects overlap.
