#!/usr/bin/env python3
"""Bounded semantic controls for the exact one-pair equivalence proof."""
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
import os
from pathlib import Path


def load(path: Path):
    spec = importlib.util.spec_from_file_location("equivalence", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path: Path, value) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--analyzer", type=Path, required=True)
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("fresh output required")
    args.output.mkdir(mode=0o700)
    module = load(args.analyzer)
    proof = args.input_root / "proof"
    btext = (args.input_root / "baseline-asm.stderr.log").read_text()
    ctext = (args.input_root / "candidate-asm.stderr.log").read_text()
    baseline = json.loads((proof / "baseline-canonical.json").read_text())
    candidate = json.loads((proof / "candidate-canonical.json").read_text())
    strict = json.loads((proof / "report.json").read_text())
    cases = []

    def check(name, accepted, fn):
        actual, issue = True, None
        try:
            fn()
        except BaseException as error:
            actual, issue = False, f"{type(error).__name__}: {error}"
        cases.append({"case": name, "expected": accepted, "actual": actual, "issue": issue})
        if actual is not accepted:
            raise ValueError(f"unexpected case outcome: {name}")

    call = lambda bt=btext, ct=ctext, b=baseline, c=candidate, s=strict: module.analyze(bt, ct, b, c, s)
    target_block = "\n".join(
        [module.CANDIDATE_TARGET + " SRODATA static size=16"]
        + module.sections(ctext)[module.CANDIDATE_TARGET]["body"]
    )
    string_block = "\n".join(
        [module.STRING_TARGET + " SRODATA dupok size=40"]
        + module.sections(ctext)[module.STRING_TARGET]["body"]
    )
    check("accepted_exact_pair", True, call)
    changed = copy.deepcopy(candidate); changed["code"][module.FUNCTION][28]["bytes"] = "00"
    check("reject_instruction_bytes", False, lambda: module.analyze(btext, ctext, baseline, changed, strict))
    changed = copy.deepcopy(candidate); changed["code"][module.FUNCTION][0]["bytes"] = "00"
    check("reject_additional_code_difference", False, lambda: module.analyze(btext, ctext, baseline, changed, strict))
    check("reject_target_bytes", False, lambda: module.analyze(btext, ctext.replace(target_block, target_block.replace("........(.......", "................"), 1), baseline, candidate, strict))
    check("reject_target_relocation", False, lambda: module.analyze(btext, ctext.replace(target_block, target_block.replace(module.STRING_TARGET + "+0", module.STRING_TARGET + "+1"), 1), baseline, candidate, strict))
    check("reject_target_section_type", False, lambda: module.analyze(btext, ctext.replace(target_block, target_block.replace("SRODATA static", "SDATA static"), 1), baseline, candidate, strict))
    check("reject_target_section_size", False, lambda: module.analyze(btext, ctext.replace(target_block, target_block.replace("size=16", "size=17"), 1), baseline, candidate, strict))
    check("reject_referenced_string_bytes", False, lambda: module.analyze(btext, ctext.replace(string_block, string_block.replace("74 69 6d 65", "00 69 6d 65", 1), 1), baseline, candidate, strict))
    check("reject_extra_incoming_reference", False, lambda: module.analyze(btext, ctext + f"\n\trel 0+8 t=R_ADDR {module.CANDIDATE_TARGET}+0\n", baseline, candidate, strict))
    changed = copy.deepcopy(candidate); changed["code"][module.FUNCTION][28]["offset"] = 105
    check("reject_unexpected_instruction_site", False, lambda: module.analyze(btext, ctext, baseline, changed, strict))
    changed = copy.deepcopy(candidate); changed["code"][module.FUNCTION][28]["assembly"] = changed["code"][module.FUNCTION][28]["assembly"].replace(module.CANDIDATE_TARGET, module.BASE_TARGET)
    check("reject_target_alias_collapse", False, lambda: module.analyze(btext, ctext, baseline, changed, strict))
    changed = copy.deepcopy(strict); changed["accepted"] = True
    check("reject_strict_disposition", False, lambda: module.analyze(btext, ctext, baseline, candidate, changed))
    summary = {"schema_version": 1, "accepted": True, "case_count": len(cases), "cases": cases}
    write_json(args.output / "result.json", summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
