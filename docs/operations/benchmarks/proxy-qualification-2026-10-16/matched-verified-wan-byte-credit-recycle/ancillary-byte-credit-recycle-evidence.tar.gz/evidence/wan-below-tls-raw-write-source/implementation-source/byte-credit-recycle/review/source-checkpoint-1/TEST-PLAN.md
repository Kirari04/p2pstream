# Focused verification plan (not executed)

Run only after source review, from a fresh audited materialization or Go overlay over the accepted combined source, with pinned Go, module cache, `GOPROXY=off`, `GOSUMDB=off`, bounded owned process groups, and source/tool pre/post hashes.

Normal and race commands are limited to these six tagged Yamux controls:

```text
go test -tags=p2pstream_qualification ./third_party/yamux -run '^(TestQualificationByteCreditActualReceiverThresholdForcedAndSessionIsolation|TestQualificationByteCreditActualPeerApplyAndWaitRange|TestQualificationByteCreditPreEntryBufferedAndPermanentCompletionTimeout|TestQualificationByteCreditFixedRingOverflowFailsClosed|TestQualificationByteCreditTwoAppliedUpdatesCoalesceIntoOneRetryRange|TestQualificationByteCreditStaleWakeAndRetryZeroDefect)$' -count=1
go test -race -tags=p2pstream_qualification ./third_party/yamux -run '^(TestQualificationByteCreditActualReceiverThresholdForcedAndSessionIsolation|TestQualificationByteCreditActualPeerApplyAndWaitRange|TestQualificationByteCreditPreEntryBufferedAndPermanentCompletionTimeout|TestQualificationByteCreditFixedRingOverflowFailsClosed|TestQualificationByteCreditTwoAppliedUpdatesCoalesceIntoOneRetryRange|TestQualificationByteCreditStaleWakeAndRetryZeroDefect)$' -count=1
```

A separate ordinary/tagged source and compiler proof must verify that ordinary layouts and executable bodies remain unchanged. This checkpoint does not authorize either command.
