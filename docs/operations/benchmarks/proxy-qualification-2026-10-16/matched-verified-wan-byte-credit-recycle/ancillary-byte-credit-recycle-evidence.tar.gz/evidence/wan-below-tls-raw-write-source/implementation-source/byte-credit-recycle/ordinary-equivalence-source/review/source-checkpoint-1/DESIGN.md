# Byte-credit ordinary referent supplement

The saved strict ordinary proof remains rejected because one instruction names `github.com/hashicorp/yamux..stmp_10` in the baseline and `github.com/hashicorp/yamux..stmp_12` in the candidate. This supplement accepts only that one saved instruction at offset 104 of `waitForSendErrCommitOn.func1`. It requires identical instruction bytes, one-to-one target mapping, exact target SRODATA type, initialized bytes and relocation graph, exact referenced string SRODATA, and the complete incoming target graph. Any other code difference rejects.

The composite receipt therefore states `strict_proof_accepted:false` and `strict_generated_symbol_names_equal:false` while separately stating `ordinary_untagged_code_and_referents_equivalent:true` and `supplemental_reference_equivalence_accepted:true`. No Go command, build, endpoint, or traffic is part of this offline supplement.
