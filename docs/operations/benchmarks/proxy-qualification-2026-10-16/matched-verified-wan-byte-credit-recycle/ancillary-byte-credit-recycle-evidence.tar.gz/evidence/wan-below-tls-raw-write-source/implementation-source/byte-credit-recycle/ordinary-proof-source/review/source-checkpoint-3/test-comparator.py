#!/usr/bin/python3.14
"""Require the actual comparator to reject duplicate proof records."""
from __future__ import annotations
import importlib.util,json,os,sys
from pathlib import Path

def main():
 if len(sys.argv)!=3:raise SystemExit('usage: test-comparator.py COMPARATOR FRESH_RESULT')
 source=Path(sys.argv[1]);out=Path(sys.argv[2])
 if out.exists():raise ValueError('fresh result required')
 spec=importlib.util.spec_from_file_location('byte_credit_comparator',source)
 if spec is None or spec.loader is None:raise ValueError('comparator import')
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 module.EXPECTED=('x',)
 cases=[
  ('duplicate_text',lambda:module.parse_objdump('TEXT x(SB)\n f.go:1 0x1000 90 NOP\n\nTEXT x(SB)\n f.go:1 0x1000 90 NOP\n'),'duplicate objdump TEXT symbol: x'),
  ('duplicate_stext',lambda:module.compiler_functions('x STEXT size=1 args=0x0 locals=0x0 funcid=0x0 align=0x0\n\t0x0000 00000\tTEXT\tx(SB), ABIInternal, $0-0\nx STEXT size=1 args=0x0 locals=0x0 funcid=0x0 align=0x0\n\t0x0000 00000\tTEXT\tx(SB), ABIInternal, $0-0\n'),'duplicate compiler STEXT symbol: x'),
  ('duplicate_aux',lambda:module.data_blocks(['g SRODATA dup','g SRODATA dup']),'duplicate compiler data block: g'),
 ]
 records=[]
 for name,call,want in cases:
  actual=None
  try:call()
  except ValueError as e:actual=str(e)
  accepted=actual==want;records.append({'case':name,'expected':want,'actual':actual,'accepted':accepted})
  if not accepted:raise ValueError(f'{name}: {actual!r}')
 fd=os.open(out,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump({'schema_version':1,'accepted':True,'case_count':len(records),'cases':records},f,indent=2,sort_keys=True);f.write('\n')
 return 0
if __name__=='__main__':raise SystemExit(main())
