# Byte-credit recycle observer implementation checkpoint 3

Runtime source is byte-identical to checkpoint 2. This checkpoint changes focused controls only:

- public `Stream.Write` replaces direct internal `write`, exercising the actual `sendLock -> observer` direction;
- draining one Session while another Session owns an active wait proves the second handle, receiver record, and per-stream ordinal survive without compaction or reset;
- queue-consumer goroutines for accepted shutdown/error/unknown-ownership controls have explicit completion joins.

The focused command source now runs from the nested Yamux module directory and targets package `.`. No build or test was executed.
