# Focused verification delta

Run the same exact ten-root/twelve-test normal and race contract once in a fresh output. The corrected retry-zero test must prove the first and repeated drain are both incomplete, not reset, ambiguous, and retain the defect. Preserve focused attempt 1 and report stage execution explicitly; race must not be claimed when normal fails.
