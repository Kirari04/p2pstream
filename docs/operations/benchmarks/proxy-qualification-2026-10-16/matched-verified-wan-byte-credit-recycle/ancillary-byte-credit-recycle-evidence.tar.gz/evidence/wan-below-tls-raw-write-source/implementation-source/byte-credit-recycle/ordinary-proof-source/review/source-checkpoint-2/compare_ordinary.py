#!/usr/bin/env python3
"""Fail-closed baseline/candidate ordinary-code proof."""
from __future__ import annotations
import argparse, hashlib, json, re, stat
from pathlib import Path

MAX_INPUT = 64 * 1024 * 1024
PARENT_SYMBOLS = (
    "github.com/hashicorp/yamux.(*Session).waitForSendErrCommitOn",
    "github.com/hashicorp/yamux.(*Stream).sendWindowUpdateMode",
    "github.com/hashicorp/yamux.(*Stream).incrSendWindow",
)
EXPECTED = ()
PARENTS = {
    "(*Session).waitForSendErrCommitOn": "func (s *Session) waitForSendErrCommitOn(",
    "(*Stream).sendWindowUpdateMode": "func (s *Stream) sendWindowUpdateMode(",
    "(*Stream).incrSendWindow": "func (s *Stream) incrSendWindow(",
}
TEXT_LINE = re.compile(r"^TEXT (?P<name>\S+)\(SB\)(?: .*)?$")
OBJ_LINE = re.compile(r"^\s+(?P<source>\S+:\d+)\s+(?P<addr>0x[0-9a-f]+)\s+(?P<bytes>[0-9a-f]+)\s+(?P<asm>.*?)\s*$")
HEX_ADDR = re.compile(r"0x[0-9a-f]+")
STEXT_LINE = re.compile(r"^(?P<name>\S+) STEXT size=(?P<size>\d+) args=(?P<args>0x[0-9a-f]+) locals=(?P<locals>0x[0-9a-f]+) funcid=(?P<funcid>0x[0-9a-f]+) align=(?P<align>0x[0-9a-f]+)$")
AUX_LINE = re.compile(r"^(?P<name>\S+) SRODATA (?P<header>.*)$")
SOURCE_PARENS = re.compile(r"\s+\(github\.com/hashicorp/yamux/[^:]+:\d+\)")
DIAG_PREFIX = re.compile(r"^github\.com/hashicorp/yamux/(?P<file>[^:]+):(?P<line>\d+):(?P<column>\d+): (?P<text>.*)$")
SOURCE_ANY = re.compile(r"github\.com/hashicorp/yamux/[^:]+:\d+:\d+")
SYMBOL_REFERENCE = re.compile(r"(?P<name>(?:gclocals·[^\s,]+|github\.com/hashicorp/yamux\.[^\s,]+))\(SB\)")
LAYOUT_NAMES = ("Stream", "Session", "aggregateWindow", "sendReady")


def discover_expected(*nm_texts: str):
    sets = []
    for text in nm_texts:
        found = set()
        for line in text.splitlines():
            fields = line.split(None, 3)
            if len(fields) != 4 or fields[2] != "T":
                continue
            name = fields[3]
            if any(name == parent or name.startswith(parent + ".") for parent in PARENT_SYMBOLS):
                found.add(name)
        sets.append(found)
    if any(parent not in item for item in sets for parent in PARENT_SYMBOLS):
        raise ValueError(f"missing parent symbol: {[sorted(item) for item in sets]}")
    if sets[0] != sets[1]:
        raise ValueError(f"emitted symbol families differ: baseline={sorted(sets[0])} candidate={sorted(sets[1])}")
    if len(sets[0]) > 16:
        raise ValueError(f"unexpected emitted symbol cardinality: {len(sets[0])}")
    return tuple(sorted(sets[0]))


def read_regular(path: Path) -> tuple[str, str]:
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_INPUT:
        raise ValueError(f"input is not a bounded regular file: {path} size={info.st_size}")
    raw = path.read_bytes()
    return raw.decode("utf-8", errors="strict"), hashlib.sha256(raw).hexdigest()


def parse_objdump(text: str):
    raw, current = {}, None
    for line in text.splitlines():
        header = TEXT_LINE.match(line)
        if header:
            current = header.group("name")
            if current in raw: raise ValueError(f"duplicate objdump TEXT symbol: {current}")
            raw[current] = []; continue
        if current is None: continue
        if not line: current = None; continue
        item = OBJ_LINE.match(line)
        if not item: raise ValueError(f"unparsed objdump line in {current}: {line!r}")
        raw[current].append((item.group("source"), int(item.group("addr"), 16), item.group("bytes"), item.group("asm")))
    if set(raw) != set(EXPECTED): raise ValueError(f"objdump symbols differ: {sorted(raw)}")
    code, positions = {}, {}
    for name, rows in raw.items():
        if not rows: raise ValueError(f"empty function: {name}")
        base = rows[0][1]; end = max(address + len(encoded) // 2 for _, address, encoded, _ in rows)
        def target(match):
            value = int(match.group(0), 16)
            return f"<FUNC+0x{value-base:x}>" if base <= value <= end else match.group(0)
        code[name] = [{"offset": address-base, "bytes": encoded, "assembly": HEX_ADDR.sub(target, assembly)} for _, address, encoded, assembly in rows]
        positions[name] = [source for source, _, _, _ in rows]
    return code, positions


def data_blocks(lines: list[str]) -> dict[str, list[str]]:
    blocks = {}
    for index, line in enumerate(lines):
        header = AUX_LINE.match(line)
        if not header: continue
        if header.group("name") in blocks: raise ValueError(f"duplicate compiler data block: {header.group('name')}")
        block = [line]; cursor = index + 1
        while cursor < len(lines) and (not lines[cursor] or lines[cursor].startswith("\t")):
            block.append(lines[cursor]); cursor += 1
        blocks[header.group("name")] = block
    return blocks


def compiler_functions(text: str):
    lines = text.splitlines(); blocks = data_blocks(lines)
    records, positions, referenced = {}, {}, set()
    for index, line in enumerate(lines):
        header = STEXT_LINE.match(line)
        if not header or header.group("name") not in EXPECTED: continue
        name = header.group("name"); metadata, source_positions, frame = [], [], None
        if name in records: raise ValueError(f"duplicate compiler STEXT symbol: {name}")
        cursor = index + 1
        while cursor < len(lines):
            candidate = lines[cursor]
            if STEXT_LINE.match(candidate) or (candidate and not candidate.startswith("\t")): break
            stripped = SOURCE_PARENS.sub("", candidate)
            if "\tTEXT\t" in stripped: frame = stripped.split("\tTEXT\t", 1)[1]
            if "\tFUNCDATA\t" in stripped or "\tPCDATA\t" in stripped:
                metadata.append(stripped.strip())
                referenced.update(match.group("name") for match in SYMBOL_REFERENCE.finditer(stripped))
            position = SOURCE_PARENS.search(candidate)
            if position: source_positions.append(position.group(0).strip())
            cursor += 1
        if frame is None: raise ValueError(f"missing compiler TEXT frame for {name}")
        records[name] = {"size": int(header.group("size")), "args": header.group("args"), "locals": header.group("locals"), "funcid": header.group("funcid"), "align": header.group("align"), "frame": frame, "stack_metadata": metadata}
        positions[name] = source_positions
    if set(records) != set(EXPECTED): raise ValueError(f"compiler function symbols differ: {sorted(records)}")
    missing = referenced - set(blocks)
    if missing: raise ValueError(f"missing referenced stack-map data blocks: {sorted(missing)}")
    referenced_blocks = {name: blocks[name] for name in sorted(referenced)}
    return records, positions, referenced_blocks


def parse_nm(text: str) -> dict[str, dict]:
    found = {}
    for line in text.splitlines():
        fields = line.split(None, 3)
        if len(fields) != 4: continue
        address, size, kind, name = fields
        if name not in EXPECTED: continue
        if name in found: raise ValueError(f"duplicate nm symbol: {name}")
        if kind != "T": raise ValueError(f"non-text relevant nm symbol: {line}")
        found[name] = {"size": int(size), "kind": kind}
    if set(found) != set(EXPECTED): raise ValueError(f"nm symbol cardinality differs: {sorted(found)}")
    return found


def function_end_line(text: str, start_offset: int) -> int:
    line = text.count("\n", 0, start_offset) + 1; depth = 0; seen = False
    state = "normal"; escape = False; index = start_offset
    while index < len(text):
        char = text[index]; nxt = text[index+1] if index+1 < len(text) else ""
        if char == "\n": line += 1
        if state == "line_comment":
            if char == "\n": state = "normal"
        elif state == "block_comment":
            if char == "*" and nxt == "/": state = "normal"; index += 1
        elif state in ("string", "rune"):
            if escape: escape = False
            elif char == "\\": escape = True
            elif (state == "string" and char == '"') or (state == "rune" and char == "'"): state = "normal"
        elif state == "raw":
            if char == "`": state = "normal"
        else:
            if char == "/" and nxt == "/": state = "line_comment"; index += 1
            elif char == "/" and nxt == "*": state = "block_comment"; index += 1
            elif char == '"': state = "string"
            elif char == "'": state = "rune"
            elif char == "`": state = "raw"
            elif char == "{": depth += 1; seen = True
            elif char == "}":
                depth -= 1
                if seen and depth == 0: return line
        index += 1
    raise ValueError("unterminated Go function")


def source_spans(root: Path):
    if not root.is_dir(): raise ValueError(f"source root is not a directory: {root}")
    spans, provenance = {}, {}
    files = [path for path in root.glob("*.go") if not path.name.endswith("_test.go")]
    for logical, marker in PARENTS.items():
        matches = []
        for path in files:
            text, digest = read_regular(path)
            offset = text.find(marker)
            if offset >= 0: matches.append((path, text, digest, offset))
        if len(matches) > 1:
            matches = [item for item in matches if item[1].startswith("//go:build !p2pstream_qualification\n")]
        if len(matches) != 1: raise ValueError(f"source declaration cardinality for {logical}: {[m[0].name for m in matches]}")
        path, text, digest, offset = matches[0]
        start = text.count("\n", 0, offset) + 1; end = function_end_line(text, offset)
        spans[(path.name, start, end)] = logical
        provenance[logical] = {"file": path.name, "start_line": start, "end_line": end, "sha256": digest}
    return spans, provenance


def escape_records(text: str, spans):
    normalized = {name: [] for name in PARENTS}; raw = {name: [] for name in PARENTS}
    current_norm = current_raw = None
    for original in text.splitlines():
        match = DIAG_PREFIX.match(original)
        if not match:
            current_norm = current_raw = None; continue
        body = match.group("text")
        if not body[:1].isspace():
            line = int(match.group("line")); owner = next((logical for (file, start, end), logical in spans.items() if file == match.group("file") and start <= line <= end), None)
            if owner is None:
                current_norm = current_raw = None; continue
            current_norm = [SOURCE_ANY.sub("<SOURCE-POSITION>", body)]; current_raw = [original]
            normalized[owner].append(current_norm); raw[owner].append(current_raw)
        elif current_norm is not None:
            current_norm.append(SOURCE_ANY.sub("<SOURCE-POSITION>", body)); current_raw.append(original)
    for name in PARENTS:
        if not normalized[name]: raise ValueError(f"no escape diagnostics in source span for {name}")
        normalized[name].sort(key=lambda record: "\n".join(record))
    return normalized, raw


def parse_layout(text: str):
    value = json.loads(text)
    if not isinstance(value, list) or [row.get("name") for row in value] != list(LAYOUT_NAMES): raise ValueError("layout JSON lacks exact ordered four-type set")
    for row in value:
        fields = row.get("fields")
        if not isinstance(fields, list) or row.get("field_count") != len(fields): raise ValueError(f"invalid field count for {row.get('name')}")
        if [field.get("index") for field in fields] != list(range(len(fields))): raise ValueError(f"invalid field order for {row.get('name')}")
        required = {"index", "name", "type", "offset", "size", "align", "anonymous"}
        if any(set(field) != required for field in fields): raise ValueError(f"invalid field schema for {row.get('name')}")
    return value


def write_json(path, value): path.write_text(json.dumps(value, indent=2, sort_keys=True)+"\n")


def main():
    global EXPECTED
    parser = argparse.ArgumentParser()
    for side in ("baseline", "candidate"):
        for kind in ("objdump", "nm", "asm", "escape", "layout"): parser.add_argument(f"--{side}-{kind}", required=True, type=Path)
        parser.add_argument(f"--{side}-source-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path); args = parser.parse_args()
    if args.output.exists(): raise ValueError(f"fresh output required: {args.output}")
    args.output.mkdir(parents=False)
    parsed, input_hashes = {}, {}
    baseline_nm, _ = read_regular(args.baseline_nm)
    candidate_nm, _ = read_regular(args.candidate_nm)
    EXPECTED = discover_expected(baseline_nm, candidate_nm)
    for side in ("baseline", "candidate"):
        values = {}
        for kind in ("objdump", "nm", "asm", "escape", "layout"):
            values[kind], input_hashes[f"{side}_{kind}"] = read_regular(getattr(args, f"{side}_{kind}"))
        spans, source_provenance = source_spans(getattr(args, f"{side}_source_root"))
        code, code_positions = parse_objdump(values["objdump"])
        compiler, compiler_positions, compiler_data = compiler_functions(values["asm"])
        escape, escape_raw = escape_records(values["escape"], spans)
        parsed[side] = {"nm": parse_nm(values["nm"]), "code": code, "compiler": compiler, "compiler_data": compiler_data, "escape": escape, "layout": parse_layout(values["layout"])}
        write_json(args.output/f"{side}-source-provenance.json", {"spans": source_provenance, "objdump": code_positions, "compiler": compiler_positions})
        write_json(args.output/f"{side}-escape-raw.json", escape_raw)
        write_json(args.output/f"{side}-canonical.json", parsed[side])
    keys = ("nm", "code", "compiler", "compiler_data", "escape", "layout")
    gates = {key: parsed["baseline"][key] == parsed["candidate"][key] for key in keys}
    report = {"accepted": all(gates.values()), "gates": gates, "expected_symbols": list(EXPECTED), "input_sha256": input_hashes, "normalization": {"code": "whole-function load addresses and in-function targets only", "escape": "all diagnostics whose primary source location is within each parent function span; source positions only normalized; records sorted per function", "compiler": "source positions excluded; frames, PCDATA/FUNCDATA, and all referenced data blocks preserved", "nm": "addresses excluded; exact relevant parent and emitted nested text-symbol cardinality and sizes preserved", "layout": "none"}}
    write_json(args.output/"report.json", report)
    return 0 if report["accepted"] else 1

if __name__ == "__main__": raise SystemExit(main())
