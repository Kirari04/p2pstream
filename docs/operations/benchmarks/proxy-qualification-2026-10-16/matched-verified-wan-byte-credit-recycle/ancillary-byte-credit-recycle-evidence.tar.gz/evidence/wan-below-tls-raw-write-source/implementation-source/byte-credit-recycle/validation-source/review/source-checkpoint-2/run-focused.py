#!/usr/bin/python3.14
"""Run the frozen byte-credit Yamux controls once normal and once race."""
from __future__ import annotations
import hashlib,importlib.util,json,os,re,sys,time,traceback
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
REPO=Path('/home/user/.codex/worktrees/astra-proxy-performance/p2pstream')
CONT=REPO/'tmp/continuation-20261016'
COMP=CONT/'wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle'
RUNS=COMP/'runs'
SOURCE_CHECKPOINT=COMP/'review/source-checkpoint-5';SOURCE_CHECKPOINT_SHA='d315f2e4f49c3b00d714346d5ff38a797c52e7b1874e7d21e7d89679a46d4287'
OVERLAY_SOURCE=COMP/'source/third_party/yamux'
BASE_RUN=CONT/'wan-below-tls-raw-write-source/implementation-source/combined-build/runs/audited-build-attempt-1'
BASE=BASE_RUN/'source';BASE_INVENTORY=BASE_RUN/'records/source-pre.json';BASE_INVENTORY_SHA='2bf3c0201892b5da5af984874f93bbdfa8c59dd92c04886fbeaf545f4437816c'
GO=Path('/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go');GO_SHA='29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45';GO_VERSION='go version go1.26.6 linux/amd64'
PYTHON=Path('/usr/bin/python3.14');PYTHON_SHA='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'
TASKSET=Path('/usr/bin/taskset');TASKSET_SHA='42acb8e233943873f3bf9eeb1e15bd3281498b5603a5b10d0f9bc37067a12d57'
HELPER=CONT/'wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py';HELPER_SHA='8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440'
MAX_STREAM=64<<20;MAX_LINE=1<<20

def sha(p):
 p=Path(p);st=p.lstat()
 if p.is_symlink() or not p.is_file():raise ValueError(f'unsafe file: {p}')
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def inventory(root):
 root=Path(root);out={}
 if root.is_symlink() or not root.is_dir():raise ValueError(f'unsafe inventory root: {root}')
 for p in sorted(root.rglob('*')):
  if p.is_symlink():raise ValueError(f'symlink in inventory: {p}')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def write_json(p,v):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def write_text(p,v):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:f.write(v)
def safe_dot(n):
 if not n.startswith('./') or n.startswith('././'):raise ValueError(f'unsafe ledger name: {n}')
 q=PurePosixPath(n[2:])
 if not q.as_posix() or q.is_absolute() or any(x in ('','.','..') for x in q.parts):raise ValueError(f'unsafe ledger name: {n}')
 return q.as_posix()
def verify_checkpoint():
 manifest=SOURCE_CHECKPOINT/'SHA256SUMS.txt'
 if sha(manifest)!=SOURCE_CHECKPOINT_SHA:raise ValueError('source checkpoint manifest changed')
 ledger={}
 for line in manifest.read_text().splitlines():
  d,n=line.split('  ',1);n=safe_dot(n)
  if re.fullmatch(r'[0-9a-f]{64}',d) is None or n in ledger:raise ValueError('malformed source checkpoint ledger')
  ledger[n]=d
 actual={k:v for k,v in inventory(SOURCE_CHECKPOINT).items() if k!='SHA256SUMS.txt'}
 if ledger!=actual:raise ValueError('source checkpoint coverage mismatch')
 return actual
def load_helper():
 if sha(HELPER)!=HELPER_SHA:raise ValueError('owned helper changed')
 spec=importlib.util.spec_from_file_location('owned_process',HELPER)
 if spec is None or spec.loader is None:raise ValueError('owned helper import')
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def expected_contract(p):
 x=json.loads(p.read_text());package=x.get('package');roots=x.get('roots');tests=x.get('all_tests')
 if x.get('schema_version')!=1 or package!='github.com/hashicorp/yamux' or not isinstance(roots,list) or not isinstance(tests,list) or len(roots)!=10 or len(tests)!=12 or len(set(roots))!=10 or len(set(tests))!=12:raise ValueError('expected test contract shape')
 if set(roots)!={n for n in tests if '/' not in n}:raise ValueError('expected test roots mismatch')
 if any(not isinstance(n,str) or re.fullmatch(r'Test[A-Za-z0-9_]+',n) is None for n in roots):raise ValueError('invalid root')
 if any(not isinstance(n,str) or n.split('/',1)[0] not in roots for n in tests):raise ValueError('invalid subtest')
 return package,roots,tests,'^('+'|'.join(re.escape(n) for n in roots)+')$'
def audit_go_json(stream_path,contract_path,report_path):
 package,roots,tests,pattern=expected_contract(contract_path);expected=set(tests);actions={n:[] for n in tests};unexpected=[];rejected=[];total=0;package_passes=0;overflow=False
 with stream_path.open('rb') as f:
  for number,line in enumerate(f,1):
   total+=len(line)
   if total>MAX_STREAM or len(line)>MAX_LINE or not line.endswith(b'\n'):raise ValueError(f'bounded JSON violation line {number}')
   try:event=json.loads(line)
   except Exception as e:raise ValueError(f'invalid JSON line {number}: {e}') from e
   if event.get('Package')!=package:
    if len(rejected)<128:rejected.append({'line':number,'reason':'package','package':event.get('Package'),'action':event.get('Action'),'test':event.get('Test')})
    else:overflow=True
    continue
   action=event.get('Action');test=event.get('Test')
   if test is None:
    if action=='pass':package_passes+=1
    elif action in ('fail','skip'):
     if len(rejected)<128:rejected.append({'line':number,'reason':'package_terminal','action':action})
     else:overflow=True
    continue
   if test not in expected:
    if len(unexpected)<128:unexpected.append({'line':number,'test':test,'action':action})
    else:overflow=True
    continue
   if action in ('run','pass','fail','skip'):
    actions[test].append(action)
    if action in ('fail','skip'):
     if len(rejected)<128:rejected.append({'line':number,'reason':'test_terminal','test':test,'action':action})
     else:overflow=True
 accepted=package_passes==1 and not unexpected and not rejected and not overflow and all(actions[n]==['run','pass'] for n in tests)
 write_json(report_path,{'schema_version':1,'accepted':accepted,'package':package,'pattern':pattern,'roots':roots,'expected_tests':tests,'actions':actions,'package_passes':package_passes,'unexpected':unexpected,'rejected':rejected,'audit_overflow':overflow,'stream_bytes':total})
 return accepted
def main():
 if len(sys.argv)!=3:raise SystemExit('usage: run-focused.py FRESH_OUTPUT EXPECTED_DRIVER_CHECKPOINT_SHA256')
 output=Path(sys.argv[1]).resolve();expected_driver_sha=sys.argv[2];driver_cp=Path(__file__).resolve().parent
 if output.exists() or output.parent!=RUNS.resolve() or not RUNS.is_dir() or RUNS.is_symlink():raise SystemExit('fresh direct output required')
 output.mkdir(mode=0o700);records=output/'records';records.mkdir(mode=0o700);write_text(records/'start-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
 accepted=False;issue=None;source_cp_pre=None;base_pre=None;overlay_pre=None;overlay_replace=None;driver_pre=None;helper=None
 stages={mode:{'started':False,'direct_status':None,'audit_run':False,'audit_accepted':None} for mode in ('normal','race')}
 try:
  if sha(driver_cp/'SHA256SUMS.txt')!=expected_driver_sha:raise ValueError('unapproved driver checkpoint')
  driver_pre=inventory(driver_cp);source_cp_pre=verify_checkpoint()
  if sha(BASE_INVENTORY)!=BASE_INVENTORY_SHA:raise ValueError('base inventory record changed')
  base_record=json.loads(BASE_INVENTORY.read_text());base_pre=base_record.get('files')
  if not isinstance(base_pre,dict) or inventory(BASE)!=base_pre:raise ValueError('audited combined source changed')
  cp_inputs=json.loads((SOURCE_CHECKPOINT/'INPUTS.json').read_text());overlay_expected={n:v['sha256'] for n,v in cp_inputs.get('overlay_files',{}).items()}
  overlay_pre=inventory(OVERLAY_SOURCE)
  if overlay_pre!=overlay_expected or len(overlay_pre)!=11:raise ValueError('byte-credit overlay changed')
  ordinary=json.loads((SOURCE_CHECKPOINT/'ORDINARY-BODY-CHECK.json').read_text())
  if ordinary.get('all_exact') is not True or len(ordinary.get('checks',[]))!=3 or not all(x.get('exact') is True for x in ordinary['checks']):raise ValueError('ordinary body proof rejected')
  if sha(GO)!=GO_SHA or sha(PYTHON)!=PYTHON_SHA or sha(TASKSET)!=TASKSET_SHA:raise ValueError('pinned tool changed')
  helper=load_helper();contract=driver_cp/'EXPECTED-TESTS.json';package,roots,tests,pattern=expected_contract(contract)
  replace={}
  for name,digest in sorted(overlay_pre.items()):
   backing=OVERLAY_SOURCE/name;virtual=BASE/'third_party/yamux'/name
   if sha(backing)!=digest:raise ValueError(f'overlay backing changed: {name}')
   replace[str(virtual)]=str(backing)
  overlay_replace=replace
  overlay_config=output/'overlay.json';write_json(overlay_config,{'Replace':replace})
  write_json(records/'inputs-pre.json',{'schema_version':1,'source_checkpoint_manifest_sha256':SOURCE_CHECKPOINT_SHA,'source_checkpoint_files':source_cp_pre,'driver_checkpoint_sha256':expected_driver_sha,'driver_files':driver_pre,'base_inventory_sha256':BASE_INVENTORY_SHA,'base_file_count':len(base_pre),'overlay_files':overlay_pre,'overlay_config_sha256':sha(overlay_config),'go':{'path':str(GO),'sha256':GO_SHA,'version':GO_VERSION},'python':{'path':str(PYTHON),'sha256':PYTHON_SHA},'taskset':{'path':str(TASKSET),'sha256':TASKSET_SHA},'owned_helper':{'path':str(HELPER),'sha256':HELPER_SHA},'test_contract_sha256':sha(contract),'package':package,'roots':roots,'all_tests':tests})
  common={'HOME':'/home/user','PATH':'/usr/bin:/bin','GOENV':'off','GOTOOLCHAIN':'local','GOWORK':'off','GOFLAGS':'','CGO_ENABLED':'1','GOMAXPROCS':'16','GOPATH':str(output/'gopath'),'GOMODCACHE':'/home/user/go/pkg/mod','GOPROXY':'off','GOSUMDB':'off','LC_ALL':'C','TZ':'Europe/Zurich'}
  for p in (output/'gopath',output/'tmp-normal',output/'tmp-race',output/'gocache-normal',output/'gocache-race'):p.mkdir(mode=0o700)
  normal_env=dict(common,TMPDIR=str(output/'tmp-normal'),GOTMPDIR=str(output/'tmp-normal'),GOCACHE=str(output/'gocache-normal'))
  if helper.run(records,'go-version',[str(GO),'version'],BASE,normal_env,30)!=0 or (records/'go-version.stdout.log').read_text().strip()!=GO_VERSION:raise ValueError('Go version')
  if helper.run(records,'go-env',[str(GO),'env','-json','GOMOD','GOWORK','GOENV','GOTOOLCHAIN','GOMODCACHE','GOPATH','GOPROXY','GOSUMDB'],BASE/'third_party/yamux',normal_env,30)!=0:raise ValueError('Go env')
  effective=json.loads((records/'go-env.stdout.log').read_text());want={'GOMOD':str(BASE/'third_party/yamux/go.mod'),'GOWORK':'off','GOENV':'','GOTOOLCHAIN':'local','GOMODCACHE':'/home/user/go/pkg/mod','GOPATH':str(output/'gopath'),'GOPROXY':'off','GOSUMDB':'off'}
  if effective!=want:raise ValueError('effective Go environment')
  for mode in ('normal','race'):
   env=dict(common,TMPDIR=str(output/f'tmp-{mode}'),GOTMPDIR=str(output/f'tmp-{mode}'),GOCACHE=str(output/f'gocache-{mode}'))
   command=[str(TASKSET),'-c','0-15',str(GO),'test','-json','-count=1','-timeout=300s','-tags=p2pstream_qualification',f'-overlay={overlay_config}']
   if mode=='race':command.append('-race')
   command.extend(['.','-run',pattern])
   stages[mode]['started']=True
   status=helper.run(records,f'yamux-{mode}',command,BASE/'third_party/yamux',env,360)
   stages[mode]['direct_status']=status
   if status!=0:raise ValueError(f'{mode} focused test failed')
   stages[mode]['audit_run']=True
   stages[mode]['audit_accepted']=audit_go_json(records/f'yamux-{mode}.stdout.log',contract,records/f'yamux-{mode}.audit.json')
   if not stages[mode]['audit_accepted']:raise ValueError(f'{mode} exact test audit failed')
  accepted=True
 except BaseException as e:
  issue=f'{type(e).__name__}: {e}';traceback.print_exc()
 finally:
  checks={};post_errors={}
  def check(name,fn):
   try:checks[name]=bool(fn())
   except BaseException as e:checks[name]=False;post_errors[name]=f'{type(e).__name__}: {e}'
  def source_cp_check():return source_cp_pre is not None and verify_checkpoint()==source_cp_pre
  def base_check():return base_pre is not None and sha(BASE_INVENTORY)==BASE_INVENTORY_SHA and json.loads(BASE_INVENTORY.read_text()).get('files')==base_pre and inventory(BASE)==base_pre
  check('driver_checkpoint_unchanged',lambda:driver_pre is not None and sha(driver_cp/'SHA256SUMS.txt')==expected_driver_sha and inventory(driver_cp)==driver_pre)
  check('source_checkpoint_unchanged',source_cp_check)
  check('audited_base_unchanged',base_check)
  check('overlay_source_unchanged',lambda:overlay_pre is not None and inventory(OVERLAY_SOURCE)==overlay_pre)
  check('overlay_config_unchanged',lambda:overlay_replace is not None and (output/'overlay.json').is_file() and not (output/'overlay.json').is_symlink() and json.loads((output/'overlay.json').read_text())=={'Replace':overlay_replace})
  check('tools_unchanged',lambda:sha(GO)==GO_SHA and sha(PYTHON)==PYTHON_SHA and sha(TASKSET)==TASKSET_SHA)
  check('owned_helper_unchanged',lambda:sha(HELPER)==HELPER_SHA)
  check('all_groups_joined_without_force',lambda:helper is not None and all(json.loads(p.read_text()).get('group_joined') is True and json.loads(p.read_text()).get('forced_cleanup') is False for p in records.glob('*.lifecycle.json')))
  accepted=accepted and all(checks.values())
  normal_and_race=all(x['started'] and x['direct_status']==0 and x['audit_run'] and x['audit_accepted'] is True for x in stages.values())
  write_json(records/'RESULT.json',{'schema_version':1,'accepted':accepted,'issue':issue,'post_checks':checks,'post_errors':post_errors,'stages':stages,'normal_and_race':normal_and_race,'ordinary_proof_run':False,'endpoint_or_traffic':False})
  write_text(records/'final.status','0\n' if accepted else '1\n');write_text(records/'end-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
  with (records/'SHA256SUMS.txt').open('x') as f:
   for p in sorted(records.rglob('*')):
    if p.is_file() and p.name!='SHA256SUMS.txt':f.write(f'{sha(p)}  ./{p.relative_to(records).as_posix()}\n')
  write_text(output/'FINAL','complete\n')
 return 0 if accepted else 1
if __name__=='__main__':raise SystemExit(main())
