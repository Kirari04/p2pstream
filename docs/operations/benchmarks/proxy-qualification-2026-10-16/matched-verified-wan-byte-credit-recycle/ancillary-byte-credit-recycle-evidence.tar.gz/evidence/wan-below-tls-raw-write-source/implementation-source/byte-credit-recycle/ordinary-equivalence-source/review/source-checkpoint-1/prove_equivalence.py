#!/usr/bin/env python3
"""Prove the one saved generated-referent difference; never relax strict proof."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
from pathlib import Path

MAX_INPUT = 8 << 20
FUNCTION = "github.com/hashicorp/yamux.(*Session).waitForSendErrCommitOn.func1"
BASE_TARGET = "github.com/hashicorp/yamux..stmp_10"
CANDIDATE_TARGET = "github.com/hashicorp/yamux..stmp_12"
STRING_TARGET = 'go:string."time: Stop called on uninitialized Timer"'
EXPECTED_GATES = {
    "code": False,
    "compiler": True,
    "compiler_data": True,
    "escape": True,
    "layout": True,
    "nm": True,
}
HEADER = re.compile(r"^(?P<name>\S+) (?P<meta>(?:STEXT|SRODATA|SDATA)(?: .*)?)$")
SOURCE = re.compile(r"\s+\([^():]+(?:/[^():]+)*:\d+\)")


def read(path: Path) -> tuple[str, str]:
    st = path.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_size <= 0 or st.st_size > MAX_INPUT:
        raise ValueError(f"input bounds: {path}")
    raw = path.read_bytes()
    return raw.decode(), hashlib.sha256(raw).hexdigest()


def sections(text: str) -> dict[str, dict]:
    lines = text.splitlines()
    result: dict[str, dict] = {}
    for index, line in enumerate(lines):
        match = HEADER.match(line)
        if not match:
            continue
        name = match.group("name")
        if name in result:
            raise ValueError(f"duplicate section: {name}")
        body = []
        cursor = index + 1
        while cursor < len(lines) and (not lines[cursor] or lines[cursor].startswith("\t")):
            body.append(lines[cursor])
            cursor += 1
        result[name] = {"meta": match.group("meta"), "body": body}
    return result


def incoming(text: str, target: str) -> list[dict]:
    pattern = re.compile(r"(?<![A-Za-z0-9_.])" + re.escape(target) + r"(?![A-Za-z0-9_.])")
    owner = None
    found = []
    for number, line in enumerate(text.splitlines(), 1):
        header = HEADER.match(line)
        if header:
            owner = header.group("name")
            if header.group("name") == target:
                continue
        if pattern.search(line):
            found.append(
                {
                    "line": number,
                    "owner": owner,
                    "text": SOURCE.sub("", line).replace(target, "<TARGET>"),
                }
            )
    return found


def analyze(baseline_asm: str, candidate_asm: str, baseline: dict, candidate: dict, strict: dict) -> dict:
    if strict.get("accepted") is not False or strict.get("gates") != EXPECTED_GATES:
        raise ValueError("strict proof disposition")
    bcode, ccode = baseline.get("code"), candidate.get("code")
    if not isinstance(bcode, dict) or not isinstance(ccode, dict) or set(bcode) != set(ccode):
        raise ValueError("code symbol set")
    differences = []
    for symbol in sorted(bcode):
        if len(bcode[symbol]) != len(ccode[symbol]):
            raise ValueError("instruction cardinality")
        for index, (left, right) in enumerate(zip(bcode[symbol], ccode[symbol])):
            if left != right:
                differences.append((symbol, index, left, right))
    if len(differences) != 1:
        raise ValueError("exactly one instruction difference required")
    symbol, index, left, right = differences[0]
    if symbol != FUNCTION or index != 28:
        raise ValueError("unexpected instruction site")
    expected_left = f"R_PCREL:{BASE_TARGET}<1>"
    expected_right = f"R_PCREL:{CANDIDATE_TARGET}<1>"
    if (
        left.get("offset") != 104
        or right.get("offset") != 104
        or left.get("bytes") != "488d1d00000000"
        or right.get("bytes") != left.get("bytes")
        or expected_left not in left.get("assembly", "")
        or expected_right not in right.get("assembly", "")
        or left["assembly"].replace(expected_left, "<TARGET>")
        != right["assembly"].replace(expected_right, "<TARGET>")
    ):
        raise ValueError("instruction mismatch beyond exact referent")

    bsections, csections = sections(baseline_asm), sections(candidate_asm)
    btarget, ctarget = bsections.get(BASE_TARGET), csections.get(CANDIDATE_TARGET)
    expected_target = {
        "meta": "SRODATA static size=16",
        "body": [
            "\t0x0000 00 00 00 00 00 00 00 00 28 00 00 00 00 00 00 00  ........(.......",
            f"\trel 0+8 t=R_ADDR {STRING_TARGET}+0",
        ],
    }
    if btarget != expected_target or ctarget != expected_target:
        raise ValueError("generated referent section/bytes/relocation graph")
    bstring, cstring = bsections.get(STRING_TARGET), csections.get(STRING_TARGET)
    if bstring is None or cstring is None or bstring != cstring:
        raise ValueError("referenced string section mismatch")
    if bstring.get("meta") != "SRODATA dupok size=40":
        raise ValueError("referenced string type/size")

    bincoming, cincoming = incoming(baseline_asm, BASE_TARGET), incoming(candidate_asm, CANDIDATE_TARGET)
    if len(bincoming) != 2 or len(cincoming) != 2:
        raise ValueError("incoming reference cardinality")
    if {item["owner"] for item in bincoming} != {FUNCTION} or {item["owner"] for item in cincoming} != {FUNCTION}:
        raise ValueError("incoming reference owner")
    if [item["text"] for item in bincoming] != [item["text"] for item in cincoming]:
        raise ValueError("incoming relocation graph")

    return {
        "schema_version": 1,
        "accepted": True,
        "ordinary_untagged_code_and_referents_equivalent": True,
        "strict_generated_symbol_names_equal": False,
        "strict_proof_accepted": False,
        "supplemental_reference_equivalence_accepted": True,
        "instruction_difference_count": 1,
        "instruction_site": {
            "symbol": symbol,
            "index": index,
            "offset": 104,
            "bytes": "488d1d00000000",
            "baseline_target": BASE_TARGET,
            "candidate_target": CANDIDATE_TARGET,
        },
        "target_mapping": {BASE_TARGET: CANDIDATE_TARGET},
        "target_mapping_bijective": True,
        "target_section": expected_target,
        "referenced_string_section": bstring,
        "incoming_references": {"baseline": bincoming, "candidate": cincoming},
        "other_instruction_differences": [],
        "normalization": "Only the exact one evidence-bound generated target at the exact saved instruction; bytes, section type/data/relocations, referenced string section, and complete incoming graph remain exact.",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    for side in ("baseline", "candidate"):
        parser.add_argument(f"--{side}-asm", type=Path, required=True)
        parser.add_argument(f"--{side}-canonical", type=Path, required=True)
    parser.add_argument("--strict-report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("fresh output required")
    values, hashes = {}, {}
    for key, path in (
        ("baseline_asm", args.baseline_asm),
        ("candidate_asm", args.candidate_asm),
        ("baseline_canonical", args.baseline_canonical),
        ("candidate_canonical", args.candidate_canonical),
        ("strict_report", args.strict_report),
    ):
        values[key], hashes[key] = read(path)
    result = analyze(
        values["baseline_asm"],
        values["candidate_asm"],
        json.loads(values["baseline_canonical"]),
        json.loads(values["candidate_canonical"]),
        json.loads(values["strict_report"]),
    )
    result["input_sha256"] = hashes
    args.output.mkdir(mode=0o700)
    fd = os.open(args.output / "result.json", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
