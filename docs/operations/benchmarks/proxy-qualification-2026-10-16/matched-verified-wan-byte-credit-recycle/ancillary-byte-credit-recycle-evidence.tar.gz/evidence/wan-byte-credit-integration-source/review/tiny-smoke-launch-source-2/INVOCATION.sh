#!/usr/bin/env bash
set -Eeuo pipefail
exec /usr/bin/env \
  -u P2PSTREAM_QUALIFICATION_PROFILE_DIR \
  -u P2PSTREAM_QUALIFICATION_PROFILE_MODE \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_DIR \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_SEQUENCES \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_BEARER \
  /usr/bin/taskset -c 0-15 \
  /usr/bin/bash \
  /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/integration-source-4/integration/run-wan-below-tls-diagnostic.sh \
  --server-binary /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/combined-build-source/runs/audited-build-attempt-2/bin/current-server-wan-byte-credit-audited.test \
  --aggregate-agent-binary /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/combined-build-source/runs/audited-build-attempt-2/bin/current-agent-wan-byte-credit-audited.test \
  --server-source-ref 8ac4c8df8237e37777ba2fac0da6f949da17bdea+byte-credit-corpus-c30fac66848fed1bf15a9b46bd7da5b8e6657ab373e6bdcd497259260a463298 \
  --aggregate-agent-source-ref 8ac4c8df8237e37777ba2fac0da6f949da17bdea+byte-credit-corpus-c30fac66848fed1bf15a9b46bd7da5b8e6657ab373e6bdcd497259260a463298 \
  --output-dir /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/integration-source-4/integration/runs/tiny-byte-credit-smoke-1 \
  --small-diagnostic
