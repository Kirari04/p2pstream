#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, pathlib, stat, sys
root=pathlib.Path(__file__).resolve().parent
integration=root/'integration'
continuation=integration.parents[2]
if continuation.name!='continuation-20261016': raise SystemExit('unexpected continuation root')
paths={
 'mature_sender_root':continuation/'wan-sender-wait-integration-source',
 'capacity_root':continuation/'wan-read-wait-capacity-source',
 'base_runner':continuation/'wan-read-wait-stack-intern-source/integration-source/runs/sustained-matched-protocol-1/preflight/runner-rebuilt.sh',
 'sender_observer_checkpoint':continuation/'wan-sender-wait-source/review/source-checkpoint-11/SHA256SUMS.txt',
 'combined_checkpoint_manifest':continuation/'wan-below-tls-raw-write-source/implementation-source/server-growth/review/combined-integration-source-checkpoint-5/SHA256SUMS.txt',
 'combined_contract_ledger':continuation/'wan-below-tls-raw-write-source/implementation-source/server-growth/runs/combined-contract-attempt-1/records/SHA256SUMS.txt',
 'server_growth_checkpoint':continuation/'wan-below-tls-raw-write-source/implementation-source/server-growth/review/source-checkpoint-3/SHA256SUMS.txt',
 'server_growth_overlay_patch':continuation/'wan-below-tls-raw-write-source/implementation-source/server-growth/review/source-checkpoint-3/SERVER-GROWTH-GO.patch',
 'server_growth_runner_patch':continuation/'wan-below-tls-raw-write-source/implementation-source/server-growth/review/source-checkpoint-3/SERVER-GROWTH-RUNNER.patch',
 'server_growth_focused_receipt':continuation/'wan-below-tls-raw-write-source/runs/server-growth-focused-attempt-1/records/SHA256SUMS.txt',
 'raw_ordinary_proof_receipt':root/'provenance/raw-ordinary-proof-receipt.json',
 'byte_credit_ordinary_proof_receipt':root/'provenance/byte-credit-ordinary-proof-receipt.json',
 'combined_build_receipt':root/'provenance/audited-combined-build-receipt.json',
 'adapter_checkpoint':continuation/'wan-byte-credit-integration-source/implementation-source/review/source-checkpoint-11/SHA256SUMS.txt',
 'adapter_contract_ledger':continuation/'wan-byte-credit-integration-source/runs/focused-contract-attempt-2/SHA256SUMS.txt',
 'adapter_contract_outer':continuation/'wan-byte-credit-integration-source/provenance/focused-contract-attempt-2-main-tool-envelope/SHA256SUMS.txt',
 'protocol_checkpoint':continuation/'wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle/review/source-checkpoint-5/SHA256SUMS.txt',
 'protocol_focused_ledger':continuation/'wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle/runs/focused-attempt-2/records/SHA256SUMS.txt',
 'protocol_focused_outer':continuation/'wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle/provenance/focused-attempt-2-worker-tool-envelope/SHA256SUMS.txt',
 'runner':integration/'generated/qualify-proxy-agent-growth-wan-below-tls.sh',
 'arm_validator':integration/'validate-wan-below-tls-arm.py',
 'arm_outcome_validator':integration/'validate-arm-outcome.py',
 'copy_validator':integration/'validate-copy-record.py',
 'sender_validator':integration/'validate-sender-wait-snapshot.py',
 'raw_validator':integration/'validate-raw-write-activity.py',
 'growth_validator':integration/'validate-server-receive-growth.py',
 'byte_credit_validator':integration/'validate-byte-credit-recycle.py',
 'closure_validator':integration/'validate-post-join-raw-closure.py',
 'continuation_validator':integration/'validate-h1-continuation.py',
}
expected={
 'base_runner':'e9e453206cd479e1d29b78c05cf4d0eaf0cbaefe3c6ff13f0ba9594235c3bea0',
 'sender_observer_checkpoint':'9f96e06bfd571fdf3550d095e6818b949bff0e3cdd733394e7ce93299e965e30',
 'combined_checkpoint_manifest':'7a5aa90f45d588fc05e58f1968772b7a0accbad295bfecc7470bcb980022aab5',
 'combined_contract_ledger':'d63e8212ba90000f5067c20546a7f9084ae65f0073aa3cb9690c3c0c8615ef37',
 'server_growth_checkpoint':'29e33466c5f79928b4d3805fcf957fb0d49b1eeb1f0c8fba720ff001c7193856',
 'server_growth_overlay_patch':'da47ac7179f6113a6c3a918a19db6ea0a8fd116feff7c893c2123b5fa9779644',
 'server_growth_runner_patch':'f08461837990894b693157a45510b8694749f882ccae8e0b01ce8c818e2e69a3',
 'server_growth_focused_receipt':'2109895c1d9d0d4824f49b9823b034a44693dfa1d8ca05c5340491024fa726ff',
 'raw_ordinary_proof_receipt':'b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d',
 'byte_credit_ordinary_proof_receipt':'6562b975ba8f25d1b7a1a83c323c4c289f62f97b5508421e9e0f2e244c940460',
 'combined_build_receipt':'93c91824df93bdfd78efc50dbc22b3c028b2e87ac4c88b77600c30207df0daff',
 'adapter_checkpoint':'4b91d78895462b0280ac0915bbf9580e49c864b747a6f231c3065d227f994062',
 'adapter_contract_ledger':'b4253d5b10bbbec2ea1d94b679ded5dea805081c62b2d31c36b3798ea726125a',
 'adapter_contract_outer':'b54598e556246b568ae8fe9bdadac91feda31d9f2a29d44a9e7d9f3a1bebfdc0',
 'protocol_checkpoint':'d315f2e4f49c3b00d714346d5ff38a797c52e7b1874e7d21e7d89679a46d4287',
 'protocol_focused_ledger':'2ebacd83ac4102b008185ed173910c467bc271ca87ada6c4c831f1357fb0ea2e',
 'protocol_focused_outer':'ffcd04d875bcc1d533bd93d2045e113f68a2e9f072643f1eaf96f5270db8126d',
 'runner':'a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad',
 'arm_validator':'4dc9a0b6610df33fb0351da0a03c3c4be33bff16d5ce895dc7c053c9a191a406',
 'arm_outcome_validator':'4c4f1c8119aac278b732fadabb72fa08f9249ee9ed003d0b881c5220b74f1eb1',
 'copy_validator':'f1c70a2f347a77975a00330d4d37929700b1a38bac5fa195c3dff02b3f773c26',
 'sender_validator':'cf813b4863a087eb4b944a60aaa745bddbceb65c185f839ccc78a0690b4a89fc',
 'raw_validator':'e4d1c7fd76773f136a54bfb1dae35a5664258e88e95f1c3706a5fd290d62c90c',
 'growth_validator':'bab8a8def06fc4347b5cfd8e7547c40ca85013fe28892da43c0e365c32dd7477',
 'byte_credit_validator':'e53f911e0362eeae728a55386cce5ebb0eb60a52163df14f8a95d0135aa0c3eb',
 'closure_validator':'7b5b7962f603ebd7c160fabcdb9d4a78b7699e9866b4ed4172480be25b847eae',
 'continuation_validator':'24f85dbfc5ad165b17416f63772466f790202d1d7194dc4c2e6630e2161dbb9b',
}
expected_modes={
 'raw_ordinary_proof_receipt':0o600,
 'byte_credit_ordinary_proof_receipt':0o600,
 'combined_build_receipt':0o600,
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows={}
for name,path in paths.items():
 if not path.exists():raise SystemExit(f'missing {name}: {path}')
 digest=sha(path) if path.is_file() else None
 if name in expected and digest!=expected[name]:raise SystemExit(f'hash mismatch {name}')
 if name in expected_modes and stat.S_IMODE(path.lstat().st_mode)!=expected_modes[name]:raise SystemExit(f'mode mismatch {name}')
 rows[name]={'path':str(path),'kind':'directory' if path.is_dir() else 'file','sha256':digest}
out=pathlib.Path(sys.argv[1])
if out.exists():raise SystemExit('fresh output required')
out.mkdir(parents=True)
(out/'result.json').write_text(json.dumps({'schema_version':1,'accepted':True,'materialized_integration_dir':str(integration),'continuation_root':str(continuation),'resolved':rows,'endpoint_or_traffic':False},indent=2,sort_keys=True)+'\n')
