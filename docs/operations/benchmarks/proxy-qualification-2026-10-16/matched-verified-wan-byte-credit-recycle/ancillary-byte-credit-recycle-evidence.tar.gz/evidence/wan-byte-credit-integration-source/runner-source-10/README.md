# Byte-credit runner checkpoint 10

Status: source-only, ready for independent review and fresh materialization. No
contract, materialization, receipt publication, endpoint, or traffic command ran
from this checkpoint.

This checkpoint is a binding-only successor to accepted runner checkpoint 9.
It preserves the generated runner, exact 7,350-byte timed transfer body, H1/H2
schedules, validators, proof gates, TLS/resource/lifecycle protections, 86-key
producer/validator equality, and all 17 self-gates. The executable changes are:

- bind immutable adapter checkpoint 11 (`4b91d788...`), whose Go source/test
  bytes equal checkpoint 10 and whose metadata binds the frozen-input incident;
- bind accepted audited build attempt 5 receipt (`93c91824...`), records ledger,
  source inventory and binary tuple;
- retain the old raw proof and byte-credit supplemental proof as distinct gates;
  the strict byte-credit proof remains rejected and is not normalized;
- retain rejected tiny smoke 1 and provenance-invalid build attempt 4 only as
  immutable lineage. Neither output nor binary is reused.

The source corpus has 34 files. `RUNNER9-TO-RUNNER10-TERMINAL-FIX-BINDING.diff`
contains the exact active binding delta. Historical diffs and every superseded
runner checkpoint remain separately preserved. A fresh materialized root is
required before a new tiny run so the rejected tiny-1 subtree is never reused.
