# Byte-credit discriminator adapter plan

Status: source-only plan. Adapter source remains blocked on the protocol-owned frozen schema and amendment. No compilation, tests, endpoint work or traffic is authorized.

## Bound inputs

- Approved design manifest: `6e0d86cb902f47b27731000408a23920eb93bedd8ed2a3c406f7bdea06f81f75`.
- Design bytes: `97626b97f5feb096a134586021c4f221d382300b758c1d5356e4de9ead841c01`.
- Current source binding: `byte-credit-current-head-binding-8bad77a.json`, SHA-256 `2eb54d550e2cdf60347198d4f00b64c3f7f78a08324eccc3773096850dec1877` (`8bad77a` docs-only over production runtime base `8ac4c8d`).
- Mature final integration source remains a read-only template. The frozen prior evidence package is immutable.

## Owned files

The adapter checkpoint will contain only derivatives of:

1. `internal/server/proxy_qualification_wan_sender_wait_growth_enabled_test.go` for receiver trace export through the existing exact-auth, exact-query, globally ordered pre/post server action.
2. `internal/agent/proxy_qualification_credit_snapshot_enabled_test.go` for peer trace and extended byte-wait range export through the existing authenticated destructive drain.
3. A narrow `validate-byte-credit-recycle.py` imported by a derivative of `validate-wan-below-tls-arm.py`.
4. Focused adapter and validator contracts covering the new schema and ordered join.

The protocol worker owns Yamux recorders, hooks, wait-token changes and their tests. This checkpoint will not own the runner, coordinator, supervisor, timed transfer, raw-write validator, server-growth validator, binaries or workload source.

## Adapter invariants

- No new query, polling path, runtime service, goroutine, timer or payload retention.
- Preserve bearer authentication, exact query cardinality, fixed sequences `9,11,14,15`, one global active sequence and irreversible invalid state.
- Pre is destructive and accepted only when capacity is 4096, drops are zero, no record is active or ambiguous, no selected interval remains outstanding and all required ownership fields are complete.
- Post retains the complete interval and selects exactly one lane/session generation/stream. Late or in-flight boundary mismatch is invalid; there is no synthetic wait or reconciliation.
- A post-enqueue error, timeout, short write, shutdown or other ambiguity terminally invalidates the owner. It must not be cleared to admit another interval.
- Preserve existing raw-write, sender-duration and server-growth response fields byte-for-byte in shape and meaning.

## Validator invariants

- Validate receiver and peer schema independently before joining.
- Accept only successful positive per-stream byte-window updates. Treat terminal/RST, allocation/session, DATA, ping, zero and below-threshold events as outside the accepted ordered ledger while preserving invalid outcomes as evidence.
- Join inverse physical tuple, lane, positive generation, nonempty session identity and positive stream ID. Require exact ordered equality of `(relative ordinal, flags, delta, cumulative positive delta)`.
- Define initial/open positive frame handling consistently at both endpoints before computing relative ordinals and cumulative conservation.
- Require uint bounds, strictly ordered unique ordinals, positive deltas, exact cumulative sums, capacity 4096, zero drops, zero overflow, zero ambiguity, zero active records and complete ownership.
- Learn `normal_read` versus `forced_growth` from the receiver only after the ordered cross-endpoint join.
- Validate receiver eligibility-to-queue and queue-to-local-completion durations on the receiver clock. Validate handler-to-apply/notify and byte-wait entry/wake/retry ranges on the peer clock. Never subtract timestamps across endpoints.
- For each selected byte-zero wait, require entry/wake/retry ordinal and cumulative ranges to be monotone and trace-consistent. A positive selected-stream advance followed by a nonterminal retry with zero usable byte credit is invalid. A stale/coalesced wake with no advance remains descriptive.
- Preserve the established transfer, payload, TLS, source/binary, raw-write, sender, server-growth, resource, lifecycle, reuse and floor gates unchanged.

## Focused contracts

Use bounded synthetic records only for the new adapter/validator layer: valid ordinary and forced updates; initial/open frame convention; two peer updates coalesced into one retry; stale wake without advance; missing/extra/reordered frame; flags/delta/cumulative mismatch; wrong tuple/lane/generation/stream; overflow/drop/active/ambiguity; late event after post boundary; positive advance followed by zero-credit retry; and receiver/peer local duration ordering. Existing accepted raw/growth contracts are not rerun or duplicated.
