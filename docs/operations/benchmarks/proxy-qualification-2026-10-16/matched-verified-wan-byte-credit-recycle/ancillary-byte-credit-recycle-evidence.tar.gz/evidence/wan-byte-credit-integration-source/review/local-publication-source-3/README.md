# Local receipt publication source 1

This offline publisher copies the accepted mature raw proof receipt, the accepted byte-credit supplemental proof receipt, and the accepted audited byte-credit build receipt into the fresh 34-file materialization attempt 4 corpus. It does not copy the audited binaries and does not execute endpoints or WAN traffic. Earlier publication attempts remain unchanged.
