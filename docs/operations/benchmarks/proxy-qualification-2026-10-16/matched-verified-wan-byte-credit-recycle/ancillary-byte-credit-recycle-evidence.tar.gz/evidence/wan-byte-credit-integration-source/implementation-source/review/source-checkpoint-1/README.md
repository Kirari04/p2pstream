# WAN byte-credit adapter source checkpoint 1

Status: source-only and unexecuted. This checkpoint is ready for source review. It does not establish compilation, focused-contract acceptance, endpoint behavior, performance, cause, a runtime fix, or WAN gate clearance.

The checkpoint binds the frozen schema manifest `174aa8409dde7a3b56a8144297366b4141f54dbff2e09bf1c5ab33465c6c101b`, protocol source checkpoint `99a82c6e6dafad9d7b1bd7c4e2611fd98b3be96aaffbc5619172efed2ffc7050`, and current source binding `2eb54d550e2cdf60347198d4f00b64c3f7f78a08324eccc3773096850dec1877`. `SOURCE-MAP.json` identifies every base file, derivative, patch and digest. The protocol worker owns the separately frozen Yamux implementation; this checkpoint owns only the authenticated adapters and validator composition.

The authenticated agent action now owns one global alternating pre/post epoch over fixed sequences 9, 11, 14 and 15. The server retains its existing explicit pre/post global epoch. Both reject malformed queries and out-of-order requests before any drain, drain the complete ordered five-lane session set once, and terminally invalidate an epoch after a destructive trace-health, serialization, or response-size failure. The older generic agent growth route keeps its prior JSON shape and does not drain byte-credit traces.

Both adapters preserve the controller's existing 4 MiB response ceiling. They serialize and check the complete response before advancing their epoch. There is no truncation and no limit increase. The existing file-backed server-capacity serialization path is unchanged.

The selected-arm validator preserves all existing sender, raw-write, server-growth, TLS, transfer, resource, lifecycle, reuse and performance gates. Its additive join requires:

- exactly five stable lane/session records at pre and post on both endpoints;
- healthy, complete, reset drains with independent 4096-record receiver, peer and wait bounds and zero active, drop, overflow or ambiguity state;
- the existing positive raw-owner generation, agent/server session identities, server agent identity, selected lane and stream, and inverse actual TCP tuple;
- exact ordered equality of `(relative_ordinal, flags, delta, cumulative)` for the server receiver-publication and agent peer-apply ledgers of the selected public download;
- local monotonic duration conservation from the observer's `time.Time.Sub` fields, with Unix nanoseconds used only for same-endpoint ordering;
- trace-consistent peer wait ordinal and cumulative ranges, with no cross-endpoint clock subtraction and no causal credit claim.

Positive initial/open updates use the same per-stream relative ordinal and cumulative convention at both endpoints, so they remain in the joined ledger. Session-scoped traces are kept as five separate wrappers; one lane cannot replace or reindex another lane. A late or in-flight record leaves the snapshot active or ambiguous and cannot be cleared into a healthy next interval.

`integration/contracts/test-byte-credit-recycle-validator.py` contains source-only positive and negative cases for ordinary and forced updates, initial/open records, coalesced and stale waits, compound identity, ring health, ordered ledgers, mismatch and duration failures. `integration/run-byte-credit-focused-contracts.sh` is a prepared bounded invocation with source pre/post checks and fresh output ownership. It has not run. The embedded Go source tests add only query cardinality, order, irreversible invalid-state checks around the mature owners; they have not run.

One earlier routine Python bytecode syntax-compilation action exited 0, but its exact invocation envelope was not preserved and it is not a focused-contract result. `review/source-actions/ATTEMPTS.md` records that limitation and the excluded cache digest.
