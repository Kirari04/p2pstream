# Final source contract invocation 4

Narrow derivative of accepted invocation source 3 for runner12, fresh integration-source-6, and audited build attempt 5. It executes only the existing offline source/dispatch contracts in an owned process group. It does not start endpoints or traffic.
