#!/usr/bin/python3.14
"""Run focused adapter controls and build the reviewed byte-credit corpus."""
from __future__ import annotations

import hashlib, importlib.util, json, os, re, shutil, stat, sys, time, traceback
from pathlib import Path, PurePosixPath

sys.dont_write_bytecode = True
REPO = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
CONT = REPO / "tmp/continuation-20261016"
ROOT = CONT / "wan-byte-credit-integration-source"
BUILD = ROOT / "combined-build-source"
RUNS = BUILD / "runs"
BASE_RUN = CONT / "wan-below-tls-raw-write-source/implementation-source/combined-build/runs/audited-build-attempt-1"
BASE_SOURCE = BASE_RUN / "source"
BASE_INVENTORY = BASE_RUN / "records/source-pre.json"
BASE_INVENTORY_SHA = "2bf3c0201892b5da5af984874f93bbdfa8c59dd92c04886fbeaf545f4437816c"
BASE_LEDGER_SHA = "9d89e974120f0a2b28c03dac1d1d5ed7031999b7b69dbcf875fabdc53a2cd96f"
BASE_RECEIPT_SHA = "472d8abcbb2c36d866e201f32f3c8aab25f8ff478670859fbea57cc174a435c6"
PROTOCOL_CP = CONT / "wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle/review/source-checkpoint-5"
PROTOCOL_CP_SHA = "d315f2e4f49c3b00d714346d5ff38a797c52e7b1874e7d21e7d89679a46d4287"
PROTOCOL_OVERLAY = PROTOCOL_CP.parents[1] / "source/third_party/yamux"
PROTOCOL_FOCUSED = PROTOCOL_CP.parents[1] / "runs/focused-attempt-2/records"
PROTOCOL_FOCUSED_SHA = "2ebacd83ac4102b008185ed173910c467bc271ca87ada6c4c831f1357fb0ea2e"
PROTOCOL_OUTER = PROTOCOL_CP.parents[1] / "provenance/focused-attempt-2-worker-tool-envelope"
PROTOCOL_OUTER_SHA = "ffcd04d875bcc1d533bd93d2045e113f68a2e9f072643f1eaf96f5270db8126d"
PROOF_ROOT_EXPECTED = PROTOCOL_CP.parents[1] / "runs/ordinary-proof-equivalence-attempt-1"
PROOF_REUSED_FAILED_LEDGER_SHA = "9366180252ad6af8f4ae14f8212aa629e62581e5c0e90ad25b7a08a8f1da6927"
PROOF_STRICT_CHECKPOINT_SHA = "6ce6b7a39f74be0e04bf653cc533b7bc5258d628f88bb776a8d869485585bace"
PROOF_STRICT_LEDGER_SHA = "b44462efcda19a1a8cd4357effe7fdb590b2c565a034c29ddf747264ea44b13b"
PROOF_STRICT_REPORT_SHA = "e6a8aaa14b0682470cd944445498a0a1b9fc9250d79d7f99dd20e3b14440a581"
ADAPTER_ROOT = ROOT / "implementation-source"
ADAPTER_CP = ADAPTER_ROOT / "review/source-checkpoint-11"
ADAPTER_CP_SHA = "4b91d78895462b0280ac0915bbf9580e49c864b747a6f231c3065d227f994062"
ADAPTER_OVERLAY = ADAPTER_ROOT / "overlay"
ADAPTER_CONTRACT = ROOT / "runs/focused-contract-attempt-2"
ADAPTER_CONTRACT_SHA = "b4253d5b10bbbec2ea1d94b679ded5dea805081c62b2d31c36b3798ea726125a"
ADAPTER_OUTER = ROOT / "provenance/focused-contract-attempt-2-main-tool-envelope"
ADAPTER_OUTER_SHA = "b54598e556246b568ae8fe9bdadac91feda31d9f2a29d44a9e7d9f3a1bebfdc0"
FAILED_BUILD = BUILD / "runs/audited-build-attempt-1"
FAILED_BUILD_LEDGER_SHA = "0c9713822fe3e5c35a2cb4d232668df17aab76a93472897b13d0aa157b5744db"
FAILED_BUILD_FINAL_SHA = "65613ea221492e529aba23e4070da8f538aab07eef08c6226b7520a58e6d662b"
FAILED_BUILD_LIFECYCLE_SHA = "cac8fabcd9486aa7fa968bc574b755008062b7b86789a8fdd429de1a2e6cedea"
FAILED_BUILD_TOOL = BUILD / "provenance/audited-build-attempt-1-tool-envelope"
FAILED_BUILD_TOOL_LEDGER_SHA = "1d61f3f52522bcc924fdf2bc492b78dde62122b3afc2962a8431775b8cc72ea6"
PRIOR_BYTE_BUILD = BUILD / "runs/audited-build-attempt-2"
PRIOR_BYTE_BUILD_LEDGER_SHA = "067f96474bf4c11c7a757dbc5e0a797607699d5bbe3fadeb86f37ae8c25af78d"
PRIOR_BYTE_BUILD_FINAL_SHA = "3022ba603df1842272e223942023cc39fb529949799902f4b76a742464825649"
PRIOR_BYTE_BUILD_RECEIPT_SHA = "2d501b866385543fcac01ac305f6a2e9db22abd7b5d41b42c5bbcb7d01cdaaeb"
PRIOR_BYTE_BUILD_OUTER = BUILD / "provenance/audited-build-attempt-2-tool-envelope"
PRIOR_BYTE_BUILD_OUTER_SHA = "3093dfd8af077822c5431abb0d12d716f6e4ee8a53ee8f40c7bd37d6f69c18df"
TINY1_RUN = ROOT / "integration-source-4/integration/runs/tiny-byte-credit-smoke-1"
TINY1_REVIEW = ROOT / "provenance/tiny-byte-credit-smoke-1-result-review"
TINY1_REVIEW_LEDGER_SHA = "a46152dc319fb38bffb928b319381cecf8071c76c3d10bbe7400c7b009abf019"
TINY1_RUN_LEDGER_SHA = "b0fe4d75bf64eb320cfd65e86717df4cb0e9fc5a85a1ea27a148b3cd1eec8b1a"
TINY1_LAUNCH = ROOT / "provenance/tiny-byte-credit-smoke-1-launch/records"
TINY1_LAUNCH_LEDGER_SHA = "c9a41d84f7f2d5440d87e3e713f9c217cfab2a15be9308d896a048dfa1108769"
TINY1_OUTER = ROOT / "provenance/tiny-byte-credit-smoke-1-main-tool-envelope"
TINY1_OUTER_LEDGER_SHA = "e7708d032d31a84c5fcb9112d6cb72012a59e9284994bf6a471abaf157bb6b17"
FAILED_BUILD3 = BUILD / "runs/audited-build-attempt-3"
FAILED_BUILD3_LEDGER_SHA = "43844c6dc6177a7769dd26ade4fe65e9d8e545f32f41b07bd8752175cd2e3dec"
FAILED_BUILD3_FINAL_SHA = "74238ed65b0b1fc2e43de77da7be999efe67b36b6d32aa50d52ae5fbf29c8600"
FAILED_BUILD3_OUTER = BUILD / "provenance/audited-build-attempt-3-tool-envelope"
FAILED_BUILD3_OUTER_SHA = "1a2196c9c3462100069a08e36b0ba0352eb7cd6a329673ab0a404e59cd17866a"
INVALID_BUILD4 = BUILD / "runs/audited-build-attempt-4"
INVALID_BUILD4_LEDGER_SHA = "ecca3c702611faee341761b939e0f2e0d40ed1ae9a538987cabf40d352ffd994"
INVALID_BUILD4_FINAL_SHA = "3022ba603df1842272e223942023cc39fb529949799902f4b76a742464825649"
INVALID_BUILD4_RECEIPT_SHA = "2b3284e45e405dd68a49059be80b5b7c768d86f7a3aef417bf20a3bc1f861eee"
INVALID_BUILD4_AGENT_SHA = "8713cc04708f1f3e0cf0751a8873bf1dfb990d2332f44f20069c97ff1bd6d8ab"
INVALID_BUILD4_SERVER_SHA = "1d594d9711964c7cfa5aff84b624af4be83bb7ad2f2ce6e7c5dc0379021e617f"
INVALID_BUILD4_OUTER = BUILD / "provenance/audited-build-attempt-4-tool-envelope"
INVALID_BUILD4_OUTER_SHA = "ab30b2763938b56de30c239d7ee7ef99927b0fdac82873f3dcd536f231322a5e"
INVALID_BUILD4_TOOL_SHA = "9d1d0621821e5deba0eb7a98f263a4a4e4f8b28563e88ed3924f1efb0d4b3336"
CP10_INCIDENT = CONT / "wan-byte-credit-evidence-export/incidents/frozen-cp10-in-place-mutation-1"
CP10_INCIDENT_SHA = "7c174ec70b10531f5f80db2cfebdcc24f3851295e63d8e3d7a19aab182ef332e"
CURRENT_BINDING = CONT / "byte-credit-current-head-binding-8bad77a.json"
HELPER = CONT / "wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
HELPER_SHA = "8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
GO = Path("/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go")
GO_SHA = "29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45"
GO_VERSION = "go version go1.26.6 linux/amd64"
PYTHON = Path("/usr/bin/python3.14")
PYTHON_SHA = "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
TASKSET = Path("/usr/bin/taskset")
TASKSET_SHA = "42acb8e233943873f3bf9eeb1e15bd3281498b5603a5b10d0f9bc37067a12d57"
SOURCE_REF = "8ac4c8df8237e37777ba2fac0da6f949da17bdea"
CURRENT_HEAD = "8bad77a456876fac0ee4b76673890a2243951d5f"
GO_MOD_SHA = "165d373cd30192573bfd30e0f0997b393c433368d3ac01df8b178aaf4bdb5d65"
GO_SUM_SHA = "7e451e21339534258c770d5d4669cffd5c126d38e91026e09f35fa93c89173f2"
MAX_FILE = 1 << 30
MAX_STREAM = 64 << 20
MAX_LINE = 1 << 20
APPROVED_FIELDS = {
    "schema_version", "accepted", "build_checkpoint_manifest_sha256", "build_driver_sha256",
    "ordinary_proof_checkpoint_sha256", "ordinary_proof_receipt_sha256", "current_source_binding_sha256",
}
ADAPTER_FILES = {
    "internal/agent/proxy_qualification_credit_snapshot_disabled_test.go": "57efb203f043684546e3c0450f2877e9c68bc3af5af774dc2890356233fd948d",
    "internal/agent/proxy_qualification_credit_snapshot_enabled_test.go": "1f5f15bb92878edb6dd18161c559a35365e817adf2dfc58735b9d934320c7637",
    "internal/agent/proxy_qualification_wan_sender_wait_test.go": "d2161f69b60920c1a29ef813832b1912c8d34a54dde027292b27c403ab2b092b",
    "internal/server/proxy_qualification_wan_sender_wait_growth_enabled_test.go": "6787b8eceaec82cdd0c8345da9d0b57801e4dd075924b0c4ec9e56f670033cc7",
}
MATURE_RECEIPT_FIELDS = {
    "raw_ordinary_proof_receipt_sha256": "b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d",
    "raw_runtime_checkpoint_sha256": "4474770be44e933572b79ece0d5db970f3a27f8792a41c27adc31269230b6bab",
    "raw_isolation_checkpoint_sha256": "85afe09e358fd3b9f9277ec6bc8de42ea4fae59a646f5810b0d5dfa3d3cc6d6c",
    "server_growth_checkpoint_sha256": "29e33466c5f79928b4d3805fcf957fb0d49b1eeb1f0c8fba720ff001c7193856",
}
MATURE_EVIDENCE_FIELDS = {
    "raw_focused_evidence_ledger_sha256": "26b6e59c6a4911328b1684221ba41779c7f4aa7aafbf516c253628916d70a656",
    "server_focused_evidence_ledger_sha256": "2109895c1d9d0d4824f49b9823b034a44693dfa1d8ca05c5340491024fa726ff",
    "combined_contract_evidence_ledger_sha256": "d63e8212ba90000f5067c20546a7f9084ae65f0073aa3cb9690c3c0c8615ef37",
}


def sha(path: Path) -> str:
    path = Path(path)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_FILE:
        raise ValueError(f"unsafe file: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path):
    return json.loads(path.read_text())


def write_json(path: Path, value) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def write_text(path: Path, value: str) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w") as stream:
        stream.write(value)


def safe_name(value: str) -> str:
    if value.startswith("./") and not value.startswith("././"):
        value = value[2:]
    item = PurePosixPath(value)
    if not value or value != item.as_posix() or item.is_absolute() or any(part in ("", ".", "..") for part in item.parts):
        raise ValueError(f"unsafe ledger path: {value!r}")
    return value


def inventory(root: Path) -> dict[str, str]:
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError(f"unsafe inventory root: {root}")
    result = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"symlink in inventory: {path}")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha(path)
    return result


def parse_ledger(path: Path) -> dict[str, str]:
    result = {}
    for line in path.read_text().splitlines():
        digest, name = line.split("  ", 1)
        name = safe_name(name)
        if re.fullmatch(r"[0-9a-f]{64}", digest) is None or name in result:
            raise ValueError(f"malformed ledger: {path}")
        result[name] = digest
    if not result:
        raise ValueError(f"empty ledger: {path}")
    return result


def verify_exact_ledger(root: Path, expected_sha: str, exclude: tuple[str, ...] = ("SHA256SUMS.txt",)) -> dict[str, str]:
    manifest = root / "SHA256SUMS.txt"
    if sha(manifest) != expected_sha:
        raise ValueError(f"ledger digest mismatch: {root}")
    expected = parse_ledger(manifest)
    actual = {name: digest for name, digest in inventory(root).items() if name not in set(exclude)}
    if actual != expected:
        raise ValueError(f"ledger coverage mismatch: {root}")
    return expected


def verify_component(checkpoint: Path, expected_sha: str) -> dict[str, str]:
    return verify_exact_ledger(checkpoint, expected_sha)


def verify_adapter_checkpoint() -> dict[str, str]:
    expected = verify_component(ADAPTER_CP, ADAPTER_CP_SHA)
    source_map = load_json(ADAPTER_CP / "SOURCE-MAP.json")
    entries = source_map.get("files")
    if source_map.get("schema_version") != 1 or not isinstance(entries, list):
        raise ValueError("adapter source map schema")
    expected_map = {f"overlay/{name}": digest for name, digest in ADAPTER_FILES.items()}
    mapped = {}
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("adapter source map entry")
        name, digest = entry.get("path"), entry.get("sha256")
        if name in expected_map:
            if name in mapped or re.fullmatch(r"[0-9a-f]{64}", str(digest)) is None:
                raise ValueError("adapter source map duplicate or digest")
            mapped[name] = digest
    if mapped != expected_map:
        raise ValueError("adapter source map build corpus changed")
    for name, digest in ADAPTER_FILES.items():
        path = ADAPTER_OVERLAY.joinpath(*PurePosixPath(name).parts)
        if not path.resolve().is_relative_to(ADAPTER_OVERLAY.resolve()) or sha(path) != digest:
            raise ValueError(f"adapter active overlay changed: {name}")
    return expected


def verify_result(root: Path, ledger_sha: str, final_name: str) -> dict:
    verify_exact_ledger(root, ledger_sha)
    result = load_json(root / final_name)
    if result.get("accepted") is not True:
        raise ValueError(f"unaccepted result: {root}")
    if "post_checks" in result and not all(result["post_checks"].values()):
        raise ValueError(f"failed postcheck: {root}")
    for lifecycle in root.glob("*.lifecycle.json"):
        value = load_json(lifecycle)
        if value.get("direct_status") != 0 or value.get("group_joined") is not True or value.get("forced_cleanup") is not False:
            raise ValueError(f"non-natural lifecycle: {lifecycle}")
    return result


def verify_prior_build() -> dict:
    result = verify_result(BASE_RUN / "records", BASE_LEDGER_SHA, "FINAL.json")
    receipt_path = BASE_RUN / "audited-combined-build-receipt.json"
    if sha(receipt_path) != BASE_RECEIPT_SHA:
        raise ValueError("prior build receipt changed")
    receipt = load_json(receipt_path)
    if receipt.get("accepted") is not True or receipt.get("records_ledger_sha256") != BASE_LEDGER_SHA:
        raise ValueError("prior build receipt rejected")
    if any(receipt.get(key) != value for key, value in {**MATURE_RECEIPT_FIELDS, **MATURE_EVIDENCE_FIELDS}.items()):
        raise ValueError("prior mature diagnostic binding changed")
    return result


def verify_protocol_focused() -> None:
    result = verify_result(PROTOCOL_FOCUSED, PROTOCOL_FOCUSED_SHA, "RESULT.json")
    if result.get("normal_and_race") is not True or set(result.get("stages", {})) != {"normal", "race"}:
        raise ValueError("protocol focused stages rejected")
    verify_exact_ledger(PROTOCOL_OUTER, PROTOCOL_OUTER_SHA)
    envelope = load_json(PROTOCOL_OUTER / "tool-envelope.json")
    if envelope.get("final", {}).get("exit_code") != 0:
        raise ValueError("protocol focused outer status")


def verify_adapter_contract() -> None:
    result = verify_result(ADAPTER_CONTRACT, ADAPTER_CONTRACT_SHA, "RESULT.json")
    summary = result.get("contract_summary", {})
    if result.get("contract_status") != 0 or summary.get("accepted") is not True or summary.get("case_count") != 37:
        raise ValueError("adapter contract rejected")
    verify_exact_ledger(ADAPTER_OUTER, ADAPTER_OUTER_SHA)
    if load_json(ADAPTER_OUTER / "outer-tool-envelope.json").get("exit_code") != 0:
        raise ValueError("adapter contract outer status")


def verify_failed_build_attempt() -> None:
    records = FAILED_BUILD / "records"
    verify_exact_ledger(records, FAILED_BUILD_LEDGER_SHA)
    if sha(records / "FINAL.json") != FAILED_BUILD_FINAL_SHA:
        raise ValueError("failed build FINAL changed")
    result = load_json(records / "FINAL.json")
    expected_checks = {
        "all_groups_joined_without_force": False,
        "base_source_unchanged": True,
        "binaries_unchanged_and_executable": False,
        "checkpoint_unchanged": True,
        "component_evidence_unchanged": True,
        "materialized_source_unchanged": True,
        "module_unchanged": True,
        "static_inputs_unchanged": True,
        "tools_and_helper_unchanged": True,
    }
    if result.get("accepted") is not False or result.get("issue") != "ValueError: command failed: ordinary-agent" or result.get("post_checks") != expected_checks or (records / "FINAL.status").read_text() != "1\n":
        raise ValueError("failed build disposition changed")
    lifecycle = records / "ordinary-agent.lifecycle.json"
    if sha(lifecycle) != FAILED_BUILD_LIFECYCLE_SHA:
        raise ValueError("failed build lifecycle changed")
    value = load_json(lifecycle)
    if value.get("direct_status") != 1 or value.get("wait_returncode") != 1 or value.get("direct_child_joined") is not True or value.get("group_joined") is not True or value.get("timed_out") is not False or value.get("term_attempted") is not False or value.get("kill_attempted") is not False or value.get("forced_cleanup") is not False:
        raise ValueError("failed build lifecycle disposition changed")
    verify_exact_ledger(FAILED_BUILD_TOOL, FAILED_BUILD_TOOL_LEDGER_SHA)
    envelope = load_json(FAILED_BUILD_TOOL / "tool-envelope.json")
    if envelope.get("exit_code") != 1 or envelope.get("endpoint_execution") is not False or envelope.get("wan_traffic") is not False:
        raise ValueError("failed build tool envelope changed")


def verify_prior_byte_build() -> None:
    records = PRIOR_BYTE_BUILD / "records"
    result = verify_result(records, PRIOR_BYTE_BUILD_LEDGER_SHA, "FINAL.json")
    if sha(records / "FINAL.json") != PRIOR_BYTE_BUILD_FINAL_SHA or result.get("accepted") is not True:
        raise ValueError("prior byte-credit build result changed")
    receipt_path = PRIOR_BYTE_BUILD / "audited-byte-credit-build-receipt.json"
    if sha(receipt_path) != PRIOR_BYTE_BUILD_RECEIPT_SHA:
        raise ValueError("prior byte-credit build receipt changed")
    receipt = load_json(receipt_path)
    if receipt.get("accepted") is not True or receipt.get("records_ledger_sha256") != PRIOR_BYTE_BUILD_LEDGER_SHA or receipt.get("final_sha256") != PRIOR_BYTE_BUILD_FINAL_SHA:
        raise ValueError("prior byte-credit build receipt rejected")
    verify_exact_ledger(PRIOR_BYTE_BUILD_OUTER, PRIOR_BYTE_BUILD_OUTER_SHA)
    envelope = load_json(PRIOR_BYTE_BUILD_OUTER / "tool-envelope.json")
    if envelope.get("accepted") is not True or envelope.get("exit_code") != 0 or envelope.get("endpoint_execution") is not False or envelope.get("wan_traffic") is not False or envelope.get("receipt_sha256") != PRIOR_BYTE_BUILD_RECEIPT_SHA:
        raise ValueError("prior byte-credit build outer envelope rejected")


def verify_tiny1_failure() -> None:
    verify_exact_ledger(TINY1_REVIEW, TINY1_REVIEW_LEDGER_SHA)
    run_manifest = TINY1_REVIEW / "RUN-SHA256SUMS.txt"
    if sha(run_manifest) != TINY1_RUN_LEDGER_SHA:
        raise ValueError("tiny1 run ledger changed")
    expected = parse_ledger(run_manifest)
    if inventory(TINY1_RUN) != expected:
        raise ValueError("tiny1 closed run changed")
    review = load_json(TINY1_REVIEW / "REVIEW.json")
    required = {
        "schema_version": 1,
        "classification": "failed_tiny_h1_terminal_phase_mismatch_h2_withheld",
        "entry_count": 145,
        "regular_file_count": 145,
        "symlink_count": 0,
        "total_regular_bytes": 3051794,
        "h1_rows": 16,
        "h1_runner_status": 0,
        "h1_validation_status": 1,
        "h2_status": 125,
    }
    if any(review.get(key) != value for key, value in required.items()):
        raise ValueError("tiny1 review disposition changed")
    verify_exact_ledger(TINY1_LAUNCH, TINY1_LAUNCH_LEDGER_SHA)
    launch = load_json(TINY1_LAUNCH / "RESULT.json")
    if launch.get("coordinator_direct_status") != 1 or launch.get("coordinator_succeeded") is not False or launch.get("evidence_complete") is not True or launch.get("natural_group_join") is not True or launch.get("source_pre_post_accepted") is not True:
        raise ValueError("tiny1 launcher disposition changed")
    verify_exact_ledger(TINY1_OUTER, TINY1_OUTER_LEDGER_SHA)
    envelope = load_json(TINY1_OUTER / "TOOL-ENVELOPE.json")
    if envelope.get("final", {}).get("exit_code") != 1 or envelope.get("command_stdout_complete") is not True:
        raise ValueError("tiny1 outer envelope changed")


def verify_failed_build3() -> None:
    records = FAILED_BUILD3 / "records"
    verify_exact_ledger(records, FAILED_BUILD3_LEDGER_SHA)
    if sha(records / "FINAL.json") != FAILED_BUILD3_FINAL_SHA:
        raise ValueError("failed build3 FINAL changed")
    result = load_json(records / "FINAL.json")
    if result.get("accepted") is not False or result.get("issue") != "ValueError: command failed: tagged-agent-normal" or result.get("natural_groups_joined") is not True or result.get("expected_stages_complete") is not False or result.get("status_success") is not False or result.get("endpoint_execution") is not False or result.get("wan_traffic") is not False:
        raise ValueError("failed build3 disposition changed")
    lifecycle = load_json(records / "tagged-agent-normal.lifecycle.json")
    if lifecycle.get("direct_status") != 1 or lifecycle.get("direct_child_joined") is not True or lifecycle.get("group_joined") is not True or lifecycle.get("forced_cleanup") is not False or lifecycle.get("timed_out") is not False or lifecycle.get("term_attempted") is not False or lifecycle.get("kill_attempted") is not False:
        raise ValueError("failed build3 lifecycle changed")
    verify_exact_ledger(FAILED_BUILD3_OUTER, FAILED_BUILD3_OUTER_SHA)
    envelope = load_json(FAILED_BUILD3_OUTER / "tool-envelope.json")
    if envelope.get("final", {}).get("exit_code") != 1 or envelope.get("records_ledger_sha256") != FAILED_BUILD3_LEDGER_SHA or envelope.get("final_sha256") != FAILED_BUILD3_FINAL_SHA or envelope.get("endpoint_execution") is not False or envelope.get("wan_traffic") is not False:
        raise ValueError("failed build3 outer envelope changed")


def verify_invalid_build4() -> None:
    records = INVALID_BUILD4 / "records"
    result = verify_result(records, INVALID_BUILD4_LEDGER_SHA, "FINAL.json")
    if sha(records / "FINAL.json") != INVALID_BUILD4_FINAL_SHA or result.get("accepted") is not True:
        raise ValueError("invalid build4 raw result changed")
    receipt = INVALID_BUILD4 / "audited-byte-credit-build-receipt.json"
    if sha(receipt) != INVALID_BUILD4_RECEIPT_SHA:
        raise ValueError("invalid build4 raw receipt changed")
    if sha(INVALID_BUILD4 / "bin/current-agent-wan-byte-credit-audited.test") != INVALID_BUILD4_AGENT_SHA or sha(INVALID_BUILD4 / "bin/current-server-wan-byte-credit-audited.test") != INVALID_BUILD4_SERVER_SHA:
        raise ValueError("invalid build4 raw binaries changed")
    verify_exact_ledger(INVALID_BUILD4_OUTER, INVALID_BUILD4_OUTER_SHA)
    envelope_path = INVALID_BUILD4_OUTER / "tool-envelope.json"
    if sha(envelope_path) != INVALID_BUILD4_TOOL_SHA:
        raise ValueError("invalid build4 disposition changed")
    envelope = load_json(envelope_path)
    if envelope.get("acceptance_disposition") != "provenance_invalid_checkpoint_mutated_and_restored_during_run" or envelope.get("final", {}).get("exit_code") != 0 or envelope.get("records_ledger_sha256") != INVALID_BUILD4_LEDGER_SHA or envelope.get("receipt_sha256") != INVALID_BUILD4_RECEIPT_SHA:
        raise ValueError("invalid build4 disposition rejected")
    verify_exact_ledger(CP10_INCIDENT, CP10_INCIDENT_SHA, ("SHA256SUMS.txt", "intermediate-e7182/SHA256SUMS.txt", "original-restored-cp10/SHA256SUMS.txt"))
    verify_exact_ledger(CP10_INCIDENT / "original-restored-cp10", "34ed296a37112ce876873b0a7d04ef41ae0f5e4caa3a76416c8119fea742f9f0")
    transient_manifest = CP10_INCIDENT / "intermediate-e7182/SHA256SUMS.txt"
    if sha(transient_manifest) != "e7182d2aa8711355550cce662b471f7ece1e56bd4863a2b36e01738ee3b6a942":
        raise ValueError("cp10 transient manifest changed")
    transient = parse_ledger(transient_manifest)
    restored = parse_ledger(CP10_INCIDENT / "original-restored-cp10/SHA256SUMS.txt")
    if set(transient) != set(restored):
        raise ValueError("cp10 transient manifest path set changed")
    for name, digest in transient.items():
        backing = CP10_INCIDENT / "intermediate-e7182/CHECKPOINT.json" if name == "CHECKPOINT.json" else CP10_INCIDENT / "original-restored-cp10" / name
        if sha(backing) != digest:
            raise ValueError(f"cp10 transient byte reconstruction changed: {name}")


def verify_proof(receipt_path: Path, approved: dict) -> dict:
    receipt_path = Path(receipt_path)
    if receipt_path != PROOF_ROOT_EXPECTED / "RECEIPT.json":
        raise ValueError("unexpected ordinary proof receipt path")
    if sha(receipt_path) != approved["ordinary_proof_receipt_sha256"]:
        raise ValueError("ordinary proof receipt changed")
    receipt = load_json(receipt_path)
    required = {
        "schema_version": 1, "diagnostic": "wan-byte-credit-recycle", "accepted": True,
        "ordinary_untagged_code_and_referents_equivalent": True,
        "strict_generated_symbol_names_equal": False, "strict_proof_accepted": False,
        "supplemental_reference_equivalence_accepted": True,
        "endpoint_execution": False, "endpoint_or_traffic": False, "wan_traffic": False,
        "source_checkpoint_sha256": PROTOCOL_CP_SHA,
        "focused_records_ledger_sha256": PROTOCOL_FOCUSED_SHA,
        "strict_proof_checkpoint_sha256": PROOF_STRICT_CHECKPOINT_SHA,
        "strict_attempt_records_ledger_sha256": PROOF_STRICT_LEDGER_SHA,
        "strict_report_sha256": PROOF_STRICT_REPORT_SHA,
        "supplement_checkpoint_sha256": approved["ordinary_proof_checkpoint_sha256"],
        "base_source_inventory_sha256": BASE_INVENTORY_SHA,
        "reused_failed_records_ledger_sha256": PROOF_REUSED_FAILED_LEDGER_SHA,
    }
    if any(receipt.get(key) != value for key, value in required.items()):
        raise ValueError("ordinary proof receipt rejected")
    records = receipt_path.parent / "records"
    ledger_sha = receipt.get("records_ledger_sha256")
    if re.fullmatch(r"[0-9a-f]{64}", str(ledger_sha)) is None:
        raise ValueError("ordinary proof ledger field")
    verify_exact_ledger(records, ledger_sha)
    result = load_json(records / "FINAL.json")
    if result.get("accepted") is not True or not all(result.get("post_checks", {}).values()):
        raise ValueError("ordinary proof result rejected")
    lifecycles = {path.name.removesuffix(".lifecycle.json"): load_json(path) for path in records.glob("*.lifecycle.json")}
    if set(lifecycles) != {"contracts", "equivalence"} or any(value.get("direct_status") != 0 or value.get("direct_child_joined") is not True or value.get("group_joined") is not True or value.get("forced_cleanup") is not False or value.get("timed_out") is not False for value in lifecycles.values()):
        raise ValueError("ordinary proof lifecycle rejected")
    if receipt.get("final_sha256") != sha(records / "FINAL.json") or receipt.get("supplement_result_sha256") != sha(records / "equivalence/result.json") or receipt.get("supplement_contract_result_sha256") != sha(records / "contracts/result.json"):
        raise ValueError("ordinary proof output binding")
    return receipt


def verify_current_binding(approved: dict, schema: dict) -> dict:
    if sha(CURRENT_BINDING) != approved["current_source_binding_sha256"]:
        raise ValueError("current source binding changed")
    value = load_json(CURRENT_BINDING)
    if set(value) != set(schema) or any(value.get(key) != expected for key, expected in schema.items()):
        raise ValueError("current source binding rejected")
    return value


def load_helper():
    if sha(HELPER) != HELPER_SHA:
        raise ValueError("owned helper changed")
    spec = importlib.util.spec_from_file_location("byte_credit_owned", HELPER)
    if spec is None or spec.loader is None:
        raise ValueError("owned helper import")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def expected_contract(path: Path) -> dict:
    value = load_json(path)
    packages = value.get("packages")
    if value.get("schema_version") != 1 or not isinstance(packages, dict) or set(packages) != {"p2pstream/internal/agent", "p2pstream/internal/server"}:
        raise ValueError("test contract schema")
    for package, contract in packages.items():
        roots, tests = contract.get("roots"), contract.get("all_tests")
        if not isinstance(roots, list) or not isinstance(tests, list) or len(roots) != len(set(roots)) or len(tests) != len(set(tests)):
            raise ValueError(f"test contract cardinality: {package}")
        if set(roots) != {name for name in tests if "/" not in name}:
            raise ValueError(f"test root mismatch: {package}")
        if any(re.fullmatch(r"Test[A-Za-z0-9_]+", name) is None for name in roots) or any(name.split("/", 1)[0] not in roots for name in tests):
            raise ValueError(f"invalid test name: {package}")
    return packages


def audit_go_json(stream_path: Path, package: str, expected_tests: list[str], report_path: Path) -> bool:
    expected = set(expected_tests)
    actions = {name: [] for name in expected_tests}
    unexpected, rejected = [], []
    package_passes = total = 0
    with stream_path.open("rb") as stream:
        for number, line in enumerate(stream, 1):
            total += len(line)
            if total > MAX_STREAM or len(line) > MAX_LINE or not line.endswith(b"\n"):
                raise ValueError(f"bounded Go JSON violation line {number}")
            event = json.loads(line)
            if event.get("Package") != package:
                rejected.append({"line": number, "reason": "package", "package": event.get("Package")})
                continue
            action, test = event.get("Action"), event.get("Test")
            if test is None:
                if action == "pass":
                    package_passes += 1
                elif action in ("fail", "skip"):
                    rejected.append({"line": number, "reason": "package_terminal", "action": action})
                continue
            if test not in expected:
                unexpected.append({"line": number, "test": test, "action": action})
                continue
            if action in ("run", "pass", "fail", "skip"):
                actions[test].append(action)
                if action in ("fail", "skip"):
                    rejected.append({"line": number, "reason": "test_terminal", "test": test, "action": action})
    accepted = package_passes == 1 and not unexpected and not rejected and all(actions[name] == ["run", "pass"] for name in expected_tests)
    write_json(report_path, {"schema_version": 1, "accepted": accepted, "package": package, "expected_tests": expected_tests, "actions": actions, "package_passes": package_passes, "unexpected": unexpected, "rejected": rejected, "stream_bytes": total})
    return accepted


def audit_ordinary_json(stream_path: Path, package: str, report_path: Path) -> bool:
    return audit_go_json(stream_path, package, [], report_path)


def publish_last(path: Path, value: dict) -> None:
    encoded = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    temporary = path.with_name("." + path.name + ".tmp")
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    os.link(temporary, path, follow_symlinks=False)
    os.unlink(temporary)


def main() -> int:
    if len(sys.argv) != 4:
        raise SystemExit("usage: run-audited-byte-credit-build.py FRESH_OUTPUT APPROVED-INPUTS.json ORDINARY-PROOF-RECEIPT.json")
    output = Path(sys.argv[1]).resolve()
    approved_path = Path(sys.argv[2]).resolve(strict=True)
    proof_receipt_path = Path(sys.argv[3]).resolve(strict=True)
    checkpoint = Path(__file__).resolve().parent
    if output.exists() or output.parent != RUNS.resolve() or not RUNS.is_dir() or RUNS.is_symlink():
        raise SystemExit("fresh direct output required")
    approved = load_json(approved_path)
    if set(approved) != APPROVED_FIELDS or approved.get("schema_version") != 1 or approved.get("accepted") is not True:
        raise SystemExit("approved input schema")
    for key in APPROVED_FIELDS - {"schema_version", "accepted"}:
        if re.fullmatch(r"[0-9a-f]{64}", str(approved.get(key, ""))) is None:
            raise SystemExit(f"approved digest: {key}")
    if sha(checkpoint / "SHA256SUMS.txt") != approved["build_checkpoint_manifest_sha256"] or sha(Path(__file__).resolve()) != approved["build_driver_sha256"]:
        raise SystemExit("unapproved build driver")
    verify_component(checkpoint, approved["build_checkpoint_manifest_sha256"])
    output.mkdir(mode=0o700)
    records, source, binaries = output / "records", output / "source", output / "bin"
    records.mkdir(); binaries.mkdir()
    write_text(records / "start-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))
    write_json(records / "approved-inputs.json", approved)
    accepted = False; issue = None; helper = None; source_pre = None; static_pre = None; outputs = {}
    try:
        contract_path = checkpoint / "EXPECTED-TESTS.json"
        binding_schema = load_json(checkpoint / "CURRENT-SOURCE-BINDING-SCHEMA.json")
        components = {
            "protocol_checkpoint": PROTOCOL_CP / "SHA256SUMS.txt", "adapter_checkpoint": ADAPTER_CP / "SHA256SUMS.txt",
            "protocol_focused": PROTOCOL_FOCUSED / "SHA256SUMS.txt", "protocol_outer": PROTOCOL_OUTER / "SHA256SUMS.txt",
            "adapter_contract": ADAPTER_CONTRACT / "SHA256SUMS.txt", "adapter_outer": ADAPTER_OUTER / "SHA256SUMS.txt",
            "base_ledger": BASE_RUN / "records/SHA256SUMS.txt", "base_receipt": BASE_RUN / "audited-combined-build-receipt.json",
            "base_inventory": BASE_INVENTORY, "proof_receipt": proof_receipt_path, "current_binding": CURRENT_BINDING,
            "failed_build_ledger": FAILED_BUILD / "records/SHA256SUMS.txt", "failed_build_tool_ledger": FAILED_BUILD_TOOL / "SHA256SUMS.txt",
            "prior_byte_build_ledger": PRIOR_BYTE_BUILD / "records/SHA256SUMS.txt", "prior_byte_build_receipt": PRIOR_BYTE_BUILD / "audited-byte-credit-build-receipt.json", "prior_byte_build_outer": PRIOR_BYTE_BUILD_OUTER / "SHA256SUMS.txt",
            "tiny1_review_ledger": TINY1_REVIEW / "SHA256SUMS.txt", "tiny1_run_ledger": TINY1_REVIEW / "RUN-SHA256SUMS.txt", "tiny1_launch_ledger": TINY1_LAUNCH / "SHA256SUMS.txt", "tiny1_outer_ledger": TINY1_OUTER / "SHA256SUMS.txt",
            "failed_build3_ledger": FAILED_BUILD3 / "records/SHA256SUMS.txt", "failed_build3_outer": FAILED_BUILD3_OUTER / "SHA256SUMS.txt",
            "invalid_build4_ledger": INVALID_BUILD4 / "records/SHA256SUMS.txt", "invalid_build4_receipt": INVALID_BUILD4 / "audited-byte-credit-build-receipt.json", "invalid_build4_outer": INVALID_BUILD4_OUTER / "SHA256SUMS.txt", "cp10_mutation_incident": CP10_INCIDENT / "SHA256SUMS.txt",
            "go": GO, "python": PYTHON, "taskset": TASKSET, "helper": HELPER, "test_contract": contract_path,
        }
        static_pre = {name: sha(path) for name, path in components.items()}
        verify_prior_build(); verify_component(PROTOCOL_CP, PROTOCOL_CP_SHA); verify_adapter_checkpoint()
        verify_protocol_focused(); verify_adapter_contract(); verify_failed_build_attempt(); verify_prior_byte_build(); verify_tiny1_failure(); verify_failed_build3(); verify_invalid_build4(); proof = verify_proof(proof_receipt_path, approved)
        current_binding = verify_current_binding(approved, binding_schema)
        if sha(GO) != GO_SHA or sha(PYTHON) != PYTHON_SHA or sha(TASKSET) != TASKSET_SHA:
            raise ValueError("pinned tool changed")
        helper = load_helper()
        base_files = load_json(BASE_INVENTORY).get("files")
        if not isinstance(base_files, dict) or inventory(BASE_SOURCE) != base_files:
            raise ValueError("audited combined base changed")
        shutil.copytree(BASE_SOURCE, source, copy_function=shutil.copy2)
        if inventory(source) != base_files:
            raise ValueError("base materialization changed")
        protocol_inputs = load_json(PROTOCOL_CP / "INPUTS.json")
        protocol_overlay_values = protocol_inputs.get("overlay_files", {})
        if not isinstance(protocol_overlay_values, dict):
            raise ValueError("protocol overlay input schema")
        protocol_backing = {}
        for name, value in protocol_overlay_values.items():
            pure = PurePosixPath(name) if isinstance(name, str) else None
            if pure is None or name != pure.as_posix() or len(pure.parts) != 1 or not isinstance(value, dict) or set(value) != {"bytes", "sha256"} or type(value["bytes"]) is not int or value["bytes"] <= 0 or re.fullmatch(r"[0-9a-f]{64}", str(value["sha256"])) is None:
                raise ValueError("protocol overlay entry schema")
            path = PROTOCOL_OVERLAY / name
            if path.stat().st_size != value["bytes"]:
                raise ValueError(f"protocol overlay byte count: {name}")
            protocol_backing[name] = value["sha256"]
        if inventory(PROTOCOL_OVERLAY) != protocol_backing or len(protocol_backing) != 11:
            raise ValueError("protocol overlay changed")
        protocol_files = {f"third_party/yamux/{name}": digest for name, digest in protocol_backing.items()}
        adapter_files = {name: sha(ADAPTER_OVERLAY / name) for name in ADAPTER_FILES}
        if adapter_files != ADAPTER_FILES or set(protocol_files) & set(adapter_files):
            raise ValueError("adapter overlay changed or overlaps protocol")
        for name, digest in sorted(protocol_backing.items()):
            source_path = PROTOCOL_OVERLAY / name
            target = source / "third_party/yamux" / name
            shutil.copy2(source_path, target)
            if sha(target) != digest:
                raise ValueError(f"protocol overlay copy changed: {name}")
        for name, digest in sorted(adapter_files.items()):
            source_path = ADAPTER_OVERLAY.joinpath(*PurePosixPath(name).parts)
            target = source.joinpath(*PurePosixPath(name).parts)
            shutil.copy2(source_path, target)
            if sha(target) != digest:
                raise ValueError(f"adapter overlay copy changed: {name}")
        expected_source = dict(base_files); expected_source.update(protocol_files); expected_source.update(adapter_files)
        source_pre = inventory(source)
        if source_pre != expected_source:
            raise ValueError("combined byte-credit corpus mismatch")
        write_json(records / "source-pre.json", {"schema_version": 1, "base_source_ref": SOURCE_REF, "current_head": CURRENT_HEAD, "files": source_pre})
        write_json(records / "corpus.json", {"schema_version": 1, "accepted": True, "base_file_count": len(base_files), "protocol_overlay_file_count": len(protocol_files), "adapter_overlay_file_count": len(adapter_files), "final_file_count": len(source_pre), "protocol_overlay": protocol_files, "adapter_overlay": adapter_files})
        if sha(source / "go.mod") != GO_MOD_SHA or sha(source / "go.sum") != GO_SUM_SHA:
            raise ValueError("module files changed")
        packages = expected_contract(contract_path)
        common = {"HOME": "/home/user", "PATH": "/usr/bin:/bin", "GOENV": "off", "GOTOOLCHAIN": "local", "GOWORK": "off", "GOFLAGS": "", "CGO_ENABLED": "1", "GOMAXPROCS": "16", "GOPATH": str(output / "gopath"), "GOMODCACHE": "/home/user/go/pkg/mod", "GOPROXY": "off", "GOSUMDB": "off", "LC_ALL": "C", "TZ": "Europe/Zurich"}
        for directory in (output / "gopath", output / "tmp-normal", output / "tmp-race", output / "gocache-normal", output / "gocache-race"):
            directory.mkdir(mode=0o700)
        normal_env = dict(common, TMPDIR=str(output / "tmp-normal"), GOTMPDIR=str(output / "tmp-normal"), GOCACHE=str(output / "gocache-normal"))
        race_env = dict(common, TMPDIR=str(output / "tmp-race"), GOTMPDIR=str(output / "tmp-race"), GOCACHE=str(output / "gocache-race"))
        write_json(records / "go-environment.json", {"normal": normal_env, "race": race_env})
        def run(name: str, command: list[str], cwd: Path, env: dict, timeout: int) -> None:
            if helper.run(records, name, command, cwd, env, timeout) != 0:
                raise ValueError(f"command failed: {name}")
        run("toolchain-version-pre", [str(GO), "version"], REPO, {"HOME": "/home/user", "PATH": "/usr/bin:/bin", "LC_ALL": "C", "TZ": "Europe/Zurich"}, 30)
        if (records / "toolchain-version-pre.stdout.log").read_text().strip() != GO_VERSION:
            raise ValueError("Go version pre")
        run("go-env", [str(GO), "env", "-json", "GOMOD", "GOWORK", "GOENV", "GOTOOLCHAIN", "GOMODCACHE", "GOPATH", "GOPROXY", "GOSUMDB"], source, normal_env, 30)
        effective = load_json(records / "go-env.stdout.log")
        wanted = {"GOMOD": str(source / "go.mod"), "GOWORK": "off", "GOENV": "", "GOTOOLCHAIN": "local", "GOMODCACHE": "/home/user/go/pkg/mod", "GOPATH": str(output / "gopath"), "GOPROXY": "off", "GOSUMDB": "off"}
        if effective != wanted:
            raise ValueError("effective Go environment")
        for short, package in (("agent", "p2pstream/internal/agent"), ("server", "p2pstream/internal/server")):
            package_path = "./internal/" + short
            run(f"ordinary-{short}", [str(TASKSET), "-c", "0-15", str(GO), "test", "-json", "-count=1", "-timeout=300s", package_path, "-run", "^$"], source, normal_env, 360)
            if not audit_ordinary_json(records / f"ordinary-{short}.stdout.log", package, records / f"ordinary-{short}.audit.json"):
                raise ValueError(f"ordinary {short} audit")
            contract = packages[package]
            pattern = "^(" + "|".join(re.escape(name) for name in contract["roots"]) + ")$"
            for mode, env in (("normal", normal_env), ("race", race_env)):
                command = [str(TASKSET), "-c", "0-15", str(GO), "test", "-json", "-count=1", "-timeout=300s", "-tags=p2pstream_qualification"]
                if mode == "race": command.append("-race")
                command.extend([package_path, "-run", pattern])
                name = f"tagged-{short}-{mode}"
                run(name, command, source, env, 360)
                if not audit_go_json(records / f"{name}.stdout.log", package, contract["all_tests"], records / f"{name}.audit.json"):
                    raise ValueError(f"tagged {short} {mode} audit")
        for short in ("agent", "server"):
            package_path = "./internal/" + short
            binary = binaries / f"current-{short}-wan-byte-credit-audited.test"
            run(f"build-{short}", [str(TASKSET), "-c", "0-15", str(GO), "test", "-tags=p2pstream_qualification", "-c", "-o", str(binary), package_path], source, normal_env, 600)
            run(f"build-{short}-version", [str(GO), "version", "-m", str(binary)], source, normal_env, 30)
            metadata = (records / f"build-{short}-version.stdout.log").read_text()
            if f": go1.26.6\n\tpath\tp2pstream/internal/{short}.test\n" not in metadata or "\n\tbuild\t-tags=p2pstream_qualification\n" not in metadata:
                raise ValueError(f"binary metadata: {short}")
            if binary.stat().st_size <= 0 or binary.stat().st_mode & 0o111 == 0:
                raise ValueError(f"non-executable binary: {short}")
            outputs[short] = {"path": str(binary.relative_to(output)), "sha256": sha(binary), "mode": oct(binary.stat().st_mode & 0o777), "go_version_m_sha256": sha(records / f"build-{short}-version.stdout.log")}
        run("toolchain-version-post", [str(GO), "version"], REPO, {"HOME": "/home/user", "PATH": "/usr/bin:/bin", "LC_ALL": "C", "TZ": "Europe/Zurich"}, 30)
        if (records / "toolchain-version-post.stdout.log").read_text().strip() != GO_VERSION:
            raise ValueError("Go version post")
        write_json(records / "source-post.json", {"schema_version": 1, "base_source_ref": SOURCE_REF, "current_head": CURRENT_HEAD, "files": inventory(source)})
        statuses = {path.name.removesuffix(".direct.status"): int(path.read_text()) for path in records.glob("*.direct.status")}
        expected_statuses = {"toolchain-version-pre", "go-env", "ordinary-agent", "ordinary-server", "tagged-agent-normal", "tagged-agent-race", "tagged-server-normal", "tagged-server-race", "build-agent", "build-agent-version", "build-server", "build-server-version", "toolchain-version-post"}
        if set(statuses) != expected_statuses or any(statuses.values()):
            raise ValueError("command status set")
        for name in expected_statuses:
            lifecycle = load_json(records / f"{name}.lifecycle.json")
            if lifecycle.get("direct_status") != 0 or lifecycle.get("direct_child_joined") is not True or lifecycle.get("group_joined") is not True or lifecycle.get("forced_cleanup") is not False or lifecycle.get("timed_out") is not False:
                raise ValueError(f"command lifecycle: {name}")
        write_json(records / "command-results.json", {"schema_version": 1, "accepted": True, "statuses": statuses, "all_groups_joined_without_force": True})
        write_json(records / "input-receipts.json", {"schema_version": 1, "prior_build_receipt_sha256": BASE_RECEIPT_SHA, "protocol_checkpoint_sha256": PROTOCOL_CP_SHA, "protocol_focused_ledger_sha256": PROTOCOL_FOCUSED_SHA, "adapter_checkpoint_sha256": ADAPTER_CP_SHA, "adapter_contract_ledger_sha256": ADAPTER_CONTRACT_SHA, "failed_build_attempt_records_ledger_sha256": FAILED_BUILD_LEDGER_SHA, "failed_build_attempt_tool_envelope_ledger_sha256": FAILED_BUILD_TOOL_LEDGER_SHA, "prior_byte_credit_build_receipt_sha256": PRIOR_BYTE_BUILD_RECEIPT_SHA, "prior_byte_credit_build_records_ledger_sha256": PRIOR_BYTE_BUILD_LEDGER_SHA, "prior_byte_credit_build_outer_ledger_sha256": PRIOR_BYTE_BUILD_OUTER_SHA, "rejected_tiny1_run_ledger_sha256": TINY1_RUN_LEDGER_SHA, "rejected_tiny1_review_ledger_sha256": TINY1_REVIEW_LEDGER_SHA, "rejected_tiny1_launcher_ledger_sha256": TINY1_LAUNCH_LEDGER_SHA, "rejected_tiny1_outer_ledger_sha256": TINY1_OUTER_LEDGER_SHA, "failed_build_attempt_3_records_ledger_sha256": FAILED_BUILD3_LEDGER_SHA, "failed_build_attempt_3_outer_ledger_sha256": FAILED_BUILD3_OUTER_SHA, "provenance_invalid_build_4_records_ledger_sha256": INVALID_BUILD4_LEDGER_SHA, "provenance_invalid_build_4_receipt_sha256": INVALID_BUILD4_RECEIPT_SHA, "provenance_invalid_build_4_disposition_ledger_sha256": INVALID_BUILD4_OUTER_SHA, "cp10_mutation_incident_ledger_sha256": CP10_INCIDENT_SHA, "ordinary_proof_receipt_sha256": approved["ordinary_proof_receipt_sha256"], "ordinary_proof_checkpoint_sha256": approved["ordinary_proof_checkpoint_sha256"], "current_source_binding_sha256": approved["current_source_binding_sha256"], "proof_receipt": proof, "current_source_binding": current_binding})
        accepted = True
    except BaseException as error:
        issue = f"{type(error).__name__}: {error}"
        traceback.print_exc()
    finally:
        checks, post_errors = {}, {}
        def check(name, function):
            try: checks[name] = bool(function())
            except BaseException as error: checks[name] = False; post_errors[name] = f"{type(error).__name__}: {error}"
        check("checkpoint_unchanged", lambda: verify_component(checkpoint, approved["build_checkpoint_manifest_sha256"]) is not None)
        check("static_inputs_unchanged", lambda: static_pre is not None and all(sha(components[name]) == digest for name, digest in static_pre.items()))
        check("component_evidence_unchanged", lambda: verify_prior_build() is not None and verify_component(PROTOCOL_CP, PROTOCOL_CP_SHA) is not None and verify_adapter_checkpoint() is not None and verify_protocol_focused() is None and verify_adapter_contract() is None and verify_failed_build_attempt() is None and verify_prior_byte_build() is None and verify_tiny1_failure() is None and verify_failed_build3() is None and verify_invalid_build4() is None and verify_proof(proof_receipt_path, approved) is not None and verify_current_binding(approved, load_json(checkpoint / "CURRENT-SOURCE-BINDING-SCHEMA.json")) is not None)
        check("tools_and_helper_unchanged", lambda: sha(GO) == GO_SHA and sha(PYTHON) == PYTHON_SHA and sha(TASKSET) == TASKSET_SHA and sha(HELPER) == HELPER_SHA)
        check("base_source_unchanged", lambda: sha(BASE_INVENTORY) == BASE_INVENTORY_SHA and inventory(BASE_SOURCE) == load_json(BASE_INVENTORY).get("files"))
        check("materialized_source_unchanged", lambda: source_pre is not None and inventory(source) == source_pre)
        check("module_unchanged", lambda: source_pre is not None and sha(source / "go.mod") == GO_MOD_SHA and sha(source / "go.sum") == GO_SUM_SHA)
        check("binaries_unchanged_and_executable", lambda: accepted and set(outputs) == {"agent", "server"} and all(sha(output / value["path"]) == value["sha256"] and oct((output / value["path"]).stat().st_mode & 0o777) == value["mode"] and (output / value["path"]).stat().st_mode & 0o111 != 0 for value in outputs.values()))
        expected_lifecycles = {"toolchain-version-pre", "go-env", "ordinary-agent", "ordinary-server", "tagged-agent-normal", "tagged-agent-race", "tagged-server-normal", "tagged-server-race", "build-agent", "build-agent-version", "build-server", "build-server-version", "toolchain-version-post"}
        lifecycle_paths = list(records.glob("*.lifecycle.json"))
        observed_lifecycles = {path.name.removesuffix(".lifecycle.json") for path in lifecycle_paths}
        natural_groups_joined = bool(lifecycle_paths) and all(load_json(path).get("direct_child_joined") is True and load_json(path).get("group_joined") is True and load_json(path).get("forced_cleanup") is False and load_json(path).get("timed_out") is False for path in lifecycle_paths)
        expected_stages_complete = observed_lifecycles == expected_lifecycles
        status_success = expected_stages_complete and all(load_json(path).get("direct_status") == 0 for path in lifecycle_paths)
        check("all_groups_joined_without_force", lambda: helper is not None and natural_groups_joined and expected_stages_complete and status_success)
        accepted = accepted and all(checks.values())
        write_json(records / "FINAL.json", {"schema_version": 1, "accepted": accepted, "issue": issue, "post_checks": checks, "post_errors": post_errors, "natural_groups_joined": natural_groups_joined, "expected_stages_complete": expected_stages_complete, "status_success": status_success, "endpoint_execution": False, "wan_traffic": False})
        write_text(records / "FINAL.status", "0\n" if accepted else "1\n")
        write_text(records / "end-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))
        lines = []
        for path in sorted(records.rglob("*")):
            if path.is_file() and path.name != "SHA256SUMS.txt":
                lines.append(f"{sha(path)}  {path.relative_to(records).as_posix()}\n")
        write_text(records / "SHA256SUMS.txt", "".join(lines))
        if accepted:
            source_ref = f"{SOURCE_REF}+byte-credit-corpus-{sha(records / 'source-post.json')}"
        write_text(output / "FINAL", "complete\n")
        if accepted:
            receipt = {"schema_version": 1, "diagnostic": "wan-below-tls-server-growth", "accepted": True, "diagnostic_only": True, "endpoint_execution": False, "wan_traffic": False, "traffic_run": False, "test_rerun": True, "server_binary_sha256": outputs["server"]["sha256"], "agent_binary_sha256": outputs["agent"]["sha256"], "server_source_ref": source_ref, "agent_source_ref": source_ref, **MATURE_RECEIPT_FIELDS, **MATURE_EVIDENCE_FIELDS, "byte_credit_runtime_checkpoint_sha256": PROTOCOL_CP_SHA, "byte_credit_adapter_checkpoint_sha256": ADAPTER_CP_SHA, "byte_credit_ordinary_proof_receipt_sha256": approved["ordinary_proof_receipt_sha256"], "byte_credit_ordinary_proof_checkpoint_sha256": approved["ordinary_proof_checkpoint_sha256"], "byte_credit_strict_proof_checkpoint_sha256": PROOF_STRICT_CHECKPOINT_SHA, "byte_credit_strict_attempt_records_ledger_sha256": PROOF_STRICT_LEDGER_SHA, "byte_credit_strict_report_sha256": PROOF_STRICT_REPORT_SHA, "byte_credit_protocol_focused_records_ledger_sha256": PROTOCOL_FOCUSED_SHA, "byte_credit_protocol_focused_outer_ledger_sha256": PROTOCOL_OUTER_SHA, "byte_credit_adapter_contract_records_ledger_sha256": ADAPTER_CONTRACT_SHA, "byte_credit_adapter_contract_outer_ledger_sha256": ADAPTER_OUTER_SHA, "failed_build_attempt_records_ledger_sha256": FAILED_BUILD_LEDGER_SHA, "failed_build_attempt_tool_envelope_ledger_sha256": FAILED_BUILD_TOOL_LEDGER_SHA, "prior_byte_credit_build_receipt_sha256": PRIOR_BYTE_BUILD_RECEIPT_SHA, "prior_byte_credit_build_records_ledger_sha256": PRIOR_BYTE_BUILD_LEDGER_SHA, "prior_byte_credit_build_outer_ledger_sha256": PRIOR_BYTE_BUILD_OUTER_SHA, "rejected_tiny1_run_ledger_sha256": TINY1_RUN_LEDGER_SHA, "rejected_tiny1_review_ledger_sha256": TINY1_REVIEW_LEDGER_SHA, "rejected_tiny1_launcher_ledger_sha256": TINY1_LAUNCH_LEDGER_SHA, "rejected_tiny1_outer_ledger_sha256": TINY1_OUTER_LEDGER_SHA, "failed_build_attempt_3_records_ledger_sha256": FAILED_BUILD3_LEDGER_SHA, "failed_build_attempt_3_outer_ledger_sha256": FAILED_BUILD3_OUTER_SHA, "provenance_invalid_build_4_records_ledger_sha256": INVALID_BUILD4_LEDGER_SHA, "provenance_invalid_build_4_receipt_sha256": INVALID_BUILD4_RECEIPT_SHA, "provenance_invalid_build_4_disposition_ledger_sha256": INVALID_BUILD4_OUTER_SHA, "cp10_mutation_incident_ledger_sha256": CP10_INCIDENT_SHA, "current_source_binding_sha256": approved["current_source_binding_sha256"], "base_source_ref": SOURCE_REF, "current_head": CURRENT_HEAD, "base_combined_build_receipt_sha256": BASE_RECEIPT_SHA, "base_source_inventory_sha256": BASE_INVENTORY_SHA, "final_source_inventory_sha256": sha(records / "source-post.json"), "build_tags": ["p2pstream_qualification"], "toolchain_sha256": GO_SHA, "toolchain_version": GO_VERSION, "python_sha256": PYTHON_SHA, "taskset_sha256": TASKSET_SHA, "build_checkpoint_manifest_sha256": approved["build_checkpoint_manifest_sha256"], "build_driver_sha256": approved["build_driver_sha256"], "approved_inputs_sha256": sha(records / "approved-inputs.json"), "server_binary": outputs["server"], "agent_binary": outputs["agent"], "final_sha256": sha(records / "FINAL.json"), "records_ledger_sha256": sha(records / "SHA256SUMS.txt")}
            publish_last(output / "audited-byte-credit-build-receipt.json", receipt)
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
