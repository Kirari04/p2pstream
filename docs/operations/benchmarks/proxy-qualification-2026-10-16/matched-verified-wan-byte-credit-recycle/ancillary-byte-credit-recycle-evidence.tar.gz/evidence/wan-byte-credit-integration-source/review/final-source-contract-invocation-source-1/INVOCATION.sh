#!/usr/bin/env bash
set -Eeuo pipefail
exec /usr/bin/python3.14 -I -B \
  /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/review/final-source-contract-invocation-source-1/run-final-contracts.py \
  /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/runs/final-source-contract-attempt-1
