# WAN byte-credit adapter source checkpoint 8

Checkpoint 8 preserves checkpoint 7 and corrects only the route fixture configuration to match the actual five-lane negotiated topology. Lane 0 uses `NewNegotiatedControlYamuxConfig`; lanes 1 through 4 use `NewAggregateYamuxConfig`; registry ownership remains aggregate for all five lanes. Runtime source is unchanged from checkpoint 7. The authenticated nine-drain path, exact schema/cardinality checks, cleanup, and replay rejection remain.

No Go command, build, endpoint, or traffic was executed for this checkpoint.
