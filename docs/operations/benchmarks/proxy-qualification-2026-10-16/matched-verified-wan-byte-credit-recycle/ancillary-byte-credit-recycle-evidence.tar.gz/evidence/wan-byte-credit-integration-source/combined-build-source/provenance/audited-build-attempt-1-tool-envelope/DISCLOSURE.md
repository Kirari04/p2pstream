# Build attempt 1 tool envelope

The native execution returned status 1 after the driver stopped at the first failed Go command (`ordinary-agent`). The original run records are unchanged. The command's owned process group exited naturally with direct status 1; no TERM or KILL was attempted. The result-wide `all_groups_joined_without_force:false` also encodes that the complete expected 13-stage set did not run, so it is not evidence of forced cleanup.
