# WAN byte-credit adapter source checkpoint 3

Status: the checkpoint 2 Python validator contracts are accepted; the additive Go payload assertions are source-only and unexecuted. No Go test, compile, build, endpoint or traffic command ran.

The first contract launch failed before source verification because its parent output directory did not exist. That exact nonzero attempt is preserved. After creating only the parent directory, the unchanged checkpoint 2 driver verified its source before and after execution and accepted all 37 declared cases. The copied result and native tool-envelope evidence under `inputs/focused-contract-evidence/` are byte-identical to the authoritative run and provenance roots.

The agent and server adapters retain checkpoint 2 behavior. Two Go tests now compare the embedded rejected snapshot with the exact marshalled complete snapshot and compare omitted byte count and SHA-256 with the exact complete marshalled snapshot. `CP2-TO-CP3-TESTS.diff` is the complete test-only delta. The authenticated routes, destructive-drain ordering, permanent invalidation, 4 MiB response ceiling, file-backed capacity handling, timed transfer, protocol source, Python validators and 37-case contract source are unchanged.

The selected public download remains joined directionally: server receiver-publication records to agent peer-apply and byte-zero wait records. Exact schema, SYN/ACK-only flags, ordinal/cumulative prefixes, positive active-token interval membership, mature byte-zero count binding, checkpoint-3 no-advance semantics and five-lane compound identity remain fail-closed. Four complete saved sustained2 artifacts exercise the same selected-lane and mature-counter extraction used by the arm.

Rejected checkpoint 1, accepted-source checkpoint 2, the pre-execution contract failure and the accepted contract run remain separate and immutable. This checkpoint establishes neither Go compilation nor runtime behavior, performance, cause, a fix, or WAN gate clearance.
