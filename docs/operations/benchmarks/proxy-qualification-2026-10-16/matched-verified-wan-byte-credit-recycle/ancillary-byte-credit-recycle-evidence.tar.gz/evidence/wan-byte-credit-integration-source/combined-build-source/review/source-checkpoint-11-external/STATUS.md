# Build checkpoint 11 external binding

Source-only approved-input binding for the adapter checkpoint 9 terminal fix. Execution remains contingent on the recorded no-Go preflight and independent review.
