# Combined byte-credit terminal-fix build source

This source-only checkpoint supersedes build checkpoint 11 with reviewed adapter checkpoint 10. It binds the preserved natural attempt-3 failure and changes no runtime logic; the only adapter delta corrects the replay phase assertion from terminal to pre. Planned output is the fresh `audited-build-attempt-4`. No endpoint or WAN traffic is authorized here.
