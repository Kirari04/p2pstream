# WAN byte-credit adapter source checkpoint 6

Checkpoint 6 preserves checkpoint 5 and adds the missing end-to-end regression control. Runtime source is byte-identical to checkpoint 5. The new tagged test builds five real aggregate Yamux session pairs, registers the exact five client sessions, and sends all eight ordered authenticated pre/post requests plus the one terminal request through `serveDrainHTTP`. Every response must be HTTP 200, schema 2, and contain exactly five legacy sender rows and five byte-credit trace rows. A tenth request must receive HTTP 409. The existing helper-level state checks and real empty-registry terminal failure/sticky-retry checks remain.

No Go command, build, endpoint, or traffic was executed for this checkpoint.
