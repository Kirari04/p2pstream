# Review map

- `CP2-TO-CP3-TESTS.diff`: only the two rejected-snapshot payload tests changed after checkpoint 2.
- `overlay/internal/agent/proxy_qualification_credit_snapshot_enabled_test.go`: full embedded snapshot byte equality and exact omitted byte-count/SHA-256 assertions.
- `overlay/internal/server/proxy_qualification_wan_sender_wait_growth_enabled_test.go`: the same full payload assertions for the server response.
- `inputs/focused-contract-evidence/attempt-1-preexec/`: original pre-execution failure; no contract ran.
- `inputs/focused-contract-evidence/attempt-2-run/`: accepted 37-case result with source pre/post status 0.
- `inputs/focused-contract-evidence/attempt-2-outer/`: exact native tool metadata and binding to the immutable run ledger.
- `integration/validate-byte-credit-recycle.py`, `integration/validate-wan-byte-credit-arm.py` and `integration/contracts/`: unchanged checkpoint 2 validator, composition and complete saved-cohort fixtures.
- `inputs/protocol-source-checkpoint-3/`: immutable protocol source/test checkpoint; runtime source equals protocol checkpoint 2.

No Go test/build or endpoint workload is represented by this checkpoint.
