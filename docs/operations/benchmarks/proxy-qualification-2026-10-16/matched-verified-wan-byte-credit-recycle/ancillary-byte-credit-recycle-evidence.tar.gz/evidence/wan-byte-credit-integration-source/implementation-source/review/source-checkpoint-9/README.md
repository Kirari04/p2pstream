# WAN byte-credit adapter source checkpoint 9

Checkpoint 9 preserves checkpoint 8 and fixes only its test-fixture cleanup. Each net.Pipe endpoint is registered for cleanup immediately, Yamux server and client constructors run synchronously, and each successfully constructed session is registered for cleanup before the next fallible step. There is no helper goroutine or unbounded wait. Runtime source and terminal semantics remain byte-identical to checkpoint 8.

No Go command, build, endpoint, or traffic was executed for this checkpoint.
