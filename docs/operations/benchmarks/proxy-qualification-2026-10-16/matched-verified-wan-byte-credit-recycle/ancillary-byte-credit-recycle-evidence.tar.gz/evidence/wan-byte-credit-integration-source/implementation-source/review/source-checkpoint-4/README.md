# WAN byte-credit adapter source checkpoint 4

Status: source-only build-tag boundary correction; unexecuted. No checkpoint-4 Go test, compile, build, endpoint, or traffic command ran.

The first audited combined build stopped at the ordinary agent compile before producing binaries. Its immutable records ledger is `0c971382...`, `FINAL.status` is 1, and the ordinary-agent lifecycle is `cac8fabc...`. The failure exposed an inherited fixture boundary: the Linux-common WAN sender-wait fixture referenced response and snapshot types that exist only with `p2pstream_qualification`. This checkpoint preserves that failed attempt and changes no production runtime source.

The common Linux fixture retains only environment/configuration, bearer authentication, sequence state, and owner construction. The tagged fixture receives the checkpoint-3 response bound, sequence order, `serveDrainHTTP`, `drain`, error, and `TestExternalQualificationWANSenderWaitControl` declarations byte-for-byte. The untagged fixture adds only the mature authenticated, exact-query, configured-sequence route adapter and delegates to the established disabled growth writer, which returns 404 and emits no synthetic trace.

The checkpoint-3 reconstruction from its base files and patches matched all three recorded source hashes. The moved tagged function declarations are byte-identical, and the exact four-test name multiset is unchanged. `CP3-TO-CP4-BUILD-TAG-BOUNDARY.diff` is the complete three-file boundary delta. The four selected overlay hashes are recorded in `CHECKPOINT.json` and `SOURCE-MAP.json`.

The previously accepted 37 Python validator contracts and their outer evidence remain unchanged and are not rerun. Protocol focused evidence and the accepted composite ordinary proof are separate inputs to the later build; this checkpoint makes no compilation, behavior, performance, causal, fix, or WAN-gate claim.
