#!/usr/bin/env bash
set -Eeuo pipefail
exec /usr/bin/env \
  -u P2PSTREAM_QUALIFICATION_PROFILE_DIR \
  -u P2PSTREAM_QUALIFICATION_PROFILE_MODE \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_DIR \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_SEQUENCES \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_BEARER \
  /usr/bin/taskset -c 0-15 \
  /usr/bin/bash \
  /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/integration-source-6/integration/run-wan-below-tls-diagnostic.sh \
  --server-binary /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/combined-build-source/runs/audited-build-attempt-5/bin/current-server-wan-byte-credit-audited.test \
  --aggregate-agent-binary /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/combined-build-source/runs/audited-build-attempt-5/bin/current-agent-wan-byte-credit-audited.test \
  --server-source-ref 8ac4c8df8237e37777ba2fac0da6f949da17bdea+byte-credit-corpus-dab62af9a09f23fee6bedf57ed014cc63655fcd5f0f91a32e0f8bee23c297b72 \
  --aggregate-agent-source-ref 8ac4c8df8237e37777ba2fac0da6f949da17bdea+byte-credit-corpus-dab62af9a09f23fee6bedf57ed014cc63655fcd5f0f91a32e0f8bee23c297b72 \
  --output-dir /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/integration-source-6/integration/runs/sustained-byte-credit-1
