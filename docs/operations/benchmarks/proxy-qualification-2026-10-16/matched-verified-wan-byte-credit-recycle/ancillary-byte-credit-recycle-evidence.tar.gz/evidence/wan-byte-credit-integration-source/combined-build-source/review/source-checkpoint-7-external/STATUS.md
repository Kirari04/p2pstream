# External approved inputs

Checkpoint 7 supersedes checkpoint 6. It binds the reviewed four-file adapter tag-boundary correction and the complete failed attempt-1 evidence, while retaining the same thirteen-stage build/test gate and accepted proof/runtime inputs. Source-only and unexecuted.
