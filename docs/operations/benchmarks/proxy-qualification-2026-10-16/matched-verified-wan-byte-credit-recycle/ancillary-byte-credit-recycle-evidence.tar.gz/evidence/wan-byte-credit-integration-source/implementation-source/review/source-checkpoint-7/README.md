# WAN byte-credit adapter source checkpoint 7

Checkpoint 7 preserves checkpoint 6 and narrows its end-to-end route fixture to the actual five-lane configuration: lane 0 uses the default Yamux config and lanes 1 through 4 use the aggregate config. Runtime source remains byte-identical to checkpoint 6. All five live net.Pipe client sessions are registered as the negotiated aggregate topology and both ends are closed by test cleanup. The test drives eight pre/post drains and the ninth terminal drain through the authenticated HTTP route, requires schema 2 with exact five sender and byte-credit rows, then requires replay status 409.

No Go command, build, endpoint, or traffic was executed for this checkpoint.
