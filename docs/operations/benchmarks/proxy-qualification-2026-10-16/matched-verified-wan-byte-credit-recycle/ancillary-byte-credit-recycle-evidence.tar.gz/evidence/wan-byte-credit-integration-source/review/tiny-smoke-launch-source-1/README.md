# Byte-credit tiny smoke launch source 1

Status: source-only and deliberately nonlaunchable. It contains explicit
non-hash placeholders for the final runner source, materialization result,
receipt publication, final source contract, combined-build receipt, binaries,
source reference, and invocation hash. No endpoint or traffic command has run.

This is a narrow derivative of the accepted mature tiny launcher source 5. It
retains the resolved Python 3.14 gate, validated existing user bus/runtime
environment, `/usr/sbin:/usr/bin:/sbin:/bin`, exact tool resolution, owned
coordinator lifecycle, source pre/post inventories, and fresh output rule. It
uses the mature `--small-diagnostic` schedule: 4 MiB payloads and the 2 MiB pool
threshold are observational controls and do not qualify performance.

The launcher binds the prior launcher and its two pre-endpoint failures by
ledger. The future active corpus must come from the reviewed byte-credit
materializer; three receipt copies must be published without overwrite under
its `provenance/` directory. The binary tuple remains at the closed audited
build paths and is passed explicitly. Placeholder removal requires a new source
checkpoint and independent review before any launch.
