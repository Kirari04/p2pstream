# Review map

- `overlay/internal/agent/proxy_qualification_credit_snapshot_enabled_test.go`: adds the five session-scoped traces to the authenticated snapshot while leaving the generic route unchanged; validates full trace health before return.
- `overlay/internal/agent/proxy_qualification_wan_sender_wait_test.go`: exact two-key query, global alternating pre/post owner, irreversible invalidation, and complete-response 4 MiB check before epoch advance.
- `overlay/internal/server/proxy_qualification_wan_sender_wait_growth_enabled_test.go`: appends five server traces inside the existing explicit pre/post owner, preserves server growth/capacity fields, and applies the same irreversible health and response-size gates.
- `integration/validate-sender-wait-snapshot.py` and `integration/validate-server-receive-growth.py`: preserve prior strict schemas while admitting exactly five new wrappers.
- `integration/validate-byte-credit-recycle.py`: strict trace schema, unsigned bounds, per-stream ordinal/cumulative conservation, local monotonic duration conservation, stable pre/post identity, exact compound ownership, server-receiver to agent-peer ordered ledger, and agent peer-wait range validation.
- `integration/validate-wan-byte-credit-arm.py`: adds the byte-credit result to the mature selected-arm gate without changing the timed transfer or existing gates.
- `integration/contracts/test-byte-credit-recycle-validator.py`: 24 prepared positive/negative cases. It is source-only and unexecuted.
- `integration/run-byte-credit-focused-contracts.sh`: prepared fresh-output invocation with checkpoint pre/post verification. It is source-only and unexecuted.

The adapter health checks drain all five exact sessions once before deciding whether the set is valid. An invalid trace set is never published as healthy and the owner cannot admit another interval. The protocol-owned tests remain responsible for proving that each `Session.DrainQualificationByteCreditTrace` leaves other sessions' outstanding state untouched; the adapter and Python contracts separately reject lane loss, duplicate/reindexed lanes, or pre/post session replacement.
