# WAN byte-credit adapter source checkpoint 5

This source-only checkpoint preserves checkpoint 4 and adds the one-shot terminal drain required by the unchanged mature runner after all four selected pre/post intervals complete. The authenticated query shape, response bound, destructive full snapshot, timed transfers, validators, server adapter, protocol observer, and production source remain unchanged.

The terminal transition is eligible only for sequence 15 when sequences 9, 11, 14, and 15 are all complete, no interval is active, the ordered cursor is exhausted, and no terminal drain succeeded before. A successful bounded healthy drain marks the transition consumed. Any drain or encoding failure marks sequence 15 invalid, retains the bounded failure response when available, and makes retry ineligible. Premature, active, other-sequence, invalid, and replay requests remain rejected.

The two added focused roots exercise the exact shared transition helpers across all four pre/post intervals, premature and active rejection, one terminal success and replay rejection, plus a real failed terminal snapshot through the authenticated HTTP adapter followed by sticky retry rejection. No Go command, build, endpoint, or traffic was executed for this checkpoint.
