# Byte-credit tiny smoke launch source 2

Status: source-only and fully bound for independent review. It binds runner
checkpoint 9, materialization attempt 4, publication attempt 3, accepted final
source-contract attempt 3, build attempt 2, its two audited binaries, the exact
source reference, and invocation hash. No endpoint or traffic command has run
from this launcher.

This is a narrow derivative of the accepted mature tiny launcher source 5. It
retains the resolved Python 3.14 gate, validated existing user bus/runtime
environment, `/usr/sbin:/usr/bin:/sbin:/bin`, exact tool resolution, owned
coordinator lifecycle, source pre/post inventories, and fresh output rule. It
uses the mature `--small-diagnostic` schedule: 4 MiB payloads and the 2 MiB pool
threshold are observational controls and do not qualify performance.

The launcher binds the prior launcher and its two pre-endpoint failures by
ledger. The active corpus comes from the reviewed byte-credit materializer;
three exact receipt copies are published mode 0600 under its `provenance/`
directory. The binary tuple remains at the closed audited build paths and is
passed explicitly. Earlier materialization and contract failures remain
preserved separately.
