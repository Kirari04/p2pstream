# Build checkpoint 13 external binding

Binds immutable adapter checkpoint 11, the cp10 mutation incident, and rejected build attempt 4. Conditional fresh attempt 5 only.
