# Review map

- `overlay/internal/agent/proxy_qualification_credit_snapshot_enabled_test.go`: validates five owned sessions before destructive drains; preserves all drained counters, raw-write activity, growth events and byte-credit snapshots on health rejection; emits bounded full-snapshot or exact size/hash failure JSON.
- `overlay/internal/agent/proxy_qualification_wan_sender_wait_test.go`: retains exact authentication and global ordering, writes structured HTTP 503 evidence for a captured invalid interval, and permanently rejects retries.
- `overlay/internal/server/proxy_qualification_wan_sender_wait_growth_enabled_test.go`: validates five server-side session/agent identities before capacity/growth/trace drains, drains all five traces even when one is unhealthy, and applies the same bounded rejected-snapshot response.
- `integration/validate-byte-credit-recycle.py`: exact schema and accepted flags, directional endpoint join, independently bound zero/nonzero wait count, exact wait-to-peer prefix cumulatives, active-token/local-interval binding, and checkpoint-3 no-advance semantics.
- `integration/validate-wan-byte-credit-arm.py`: uses the same selected-sender evidence helper to bind actual raw generation and the existing byte-zero counter/cause fields before the new endpoint join.
- `integration/contracts/test-byte-credit-recycle-validator.py`: 37 prepared synthetic cases plus exact saved-cohort selection/composition. It is unexecuted.
- `integration/contracts/sustained2-actual/`: four complete byte-identical saved H1 artifacts and an origin/digest map. They contain no bearer value, private key, readiness document, endpoint log, or mutable state.
- `integration/validate-sender-wait-snapshot.py` and `integration/validate-server-receive-growth.py`: retain all mature strict gates while admitting exactly the five additive trace wrappers.
- `inputs/protocol-source-checkpoint-3/`: immutable protocol source/test checkpoint; runtime source equals checkpoint 2 and its test-only correction is retained.

Rejected checkpoint 1 is preserved separately under `wan-byte-credit-integration-source/rejected/source-checkpoint-1/implementation-source` with its original root ledger `2f2f6143067335fd5d6450864ac98f3db6586b9b541d4279bf6aa1c7e16af375`.
