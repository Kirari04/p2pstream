# Combined byte-credit terminal-fix build source

This source-only checkpoint binds immutable adapter checkpoint 11, the cp10 mutation incident, and the separately rejected provenance-invalid build attempt 4. It plans fresh `audited-build-attempt-5` with unchanged 10-agent/5-server/13-command gates. No endpoint or WAN traffic is authorized here.
