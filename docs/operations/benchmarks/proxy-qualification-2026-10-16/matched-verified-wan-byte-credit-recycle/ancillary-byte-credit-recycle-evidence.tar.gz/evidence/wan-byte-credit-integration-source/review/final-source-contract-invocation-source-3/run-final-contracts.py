#!/usr/bin/env python3
"""Run the reviewed byte-credit final-source contracts in an owned process group."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import traceback


REPO = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
BASE = REPO / "tmp/continuation-20261016/wan-byte-credit-integration-source"
ACTIVE = BASE / "integration-source-4"
CHECKPOINT = BASE / "runner-source-9"
CHECKPOINT_SHA = "70d9872d2d85624e42c08b8fa64ed53c09871f28b80888349f17b80d352745e4"
CORPUS_SHA = "7b3db886bc9703037bba9b7fa7be059e32d3d09715627d8be118908b3dd2b553"
CONTRACT = ACTIVE / "integration/contracts/run-final-source-contracts.sh"
CONTRACT_SHA = "aac533fbd2222e8e8c6d8398c027070a2c2c68492d1990397cd590dd29fd818b"
OWNED_HELPER = REPO / "tmp/continuation-20261016/wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
OWNED_HELPER_SHA = "8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
PYTHON = Path("/usr/bin/python3")
PYTHON_SHA = "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
PROVENANCE = {
    "raw-ordinary-proof-receipt.json": "b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d",
    "byte-credit-ordinary-proof-receipt.json": "6562b975ba8f25d1b7a1a83c323c4c289f62f97b5508421e9e0f2e244c940460",
    "audited-combined-build-receipt.json": "2d501b866385543fcac01ac305f6a2e9db22abd7b5d41b42c5bbcb7d01cdaaeb",
}
BINARIES = {
    "agent": (
        BASE / "combined-build-source/runs/audited-build-attempt-2/bin/current-agent-wan-byte-credit-audited.test",
        "f589f7cc585e878c12d672ffbd3b9f8814c4234918b6660f225d021714ec6f68",
    ),
    "server": (
        BASE / "combined-build-source/runs/audited-build-attempt-2/bin/current-server-wan-byte-credit-audited.test",
        "664a970bdb7cec589a3683105db9965684bd283cfd8b888766fa9f5219181bf5",
    ),
}


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def write_text(path: Path, value: str) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        stream.write(value)


def inventory(root: Path, *, exclude_provenance: bool = False) -> dict[str, str]:
    if not root.is_dir() or root.is_symlink():
        raise ValueError(f"unsafe inventory root: {root}")
    result: dict[str, str] = {}
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root).as_posix()
        if exclude_provenance and (relative == "provenance" or relative.startswith("provenance/")):
            continue
        if path.is_symlink():
            raise ValueError(f"symlink in immutable input: {path}")
        if path.is_file():
            result[relative] = sha(path)
    return result


def parse_checkpoint() -> dict[str, str]:
    manifest = CHECKPOINT / "SHA256SUMS.txt"
    if sha(manifest) != CHECKPOINT_SHA:
        raise ValueError("runner checkpoint 9 manifest changed")
    corpus_path = CHECKPOINT / "SOURCE-CORPUS.json"
    if sha(corpus_path) != CORPUS_SHA:
        raise ValueError("runner checkpoint 9 source corpus changed")
    corpus = json.loads(corpus_path.read_text(encoding="utf-8"))
    if corpus.get("status") != "ready_for_materialization":
        raise ValueError("runner checkpoint 9 is not ready")
    expected: dict[str, str] = {}
    files = corpus.get("files")
    if not isinstance(files, dict) or len(files) != 34:
        raise ValueError("runner checkpoint 9 source corpus count differs")
    for name, item in files.items():
        relative = Path(name)
        if (relative.is_absolute() or ".." in relative.parts or name in expected
                or not isinstance(item, dict) or item.get("mode") not in (0o644, 0o755)):
            raise ValueError("unsafe source corpus entry")
        expected[name] = item.get("sha256")
        source = CHECKPOINT / name
        if sha(source) != expected[name]:
            raise ValueError(f"checkpoint source differs: {name}")
    return expected


def verify_active(expected: dict[str, str]) -> dict[str, str]:
    actual = inventory(ACTIVE, exclude_provenance=True)
    if actual != expected:
        raise ValueError("active executable corpus differs from runner checkpoint 9")
    files = json.loads((CHECKPOINT / "SOURCE-CORPUS.json").read_text(encoding="utf-8"))["files"]
    for name, item in files.items():
        info = (ACTIVE / name).lstat()
        if (not stat.S_ISREG(info.st_mode) or (ACTIVE / name).is_symlink()
                or stat.S_IMODE(info.st_mode) != item["mode"]):
            raise ValueError(f"active package mode differs: {name}")
    provenance = inventory(ACTIVE / "provenance")
    if provenance != PROVENANCE:
        raise ValueError("published receipt inventory differs")
    for path, expected_mode in ((ACTIVE / "provenance", 0o700),):
        info = path.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != expected_mode:
            raise ValueError("published receipt directory ownership or mode differs")
    for name in PROVENANCE:
        info = (ACTIVE / "provenance" / name).lstat()
        if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o600:
            raise ValueError(f"published receipt mode differs: {name}")
    for name, (path, digest) in BINARIES.items():
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or path.is_symlink() or sha(path) != digest:
            raise ValueError(f"audited {name} binary differs")
        if stat.S_IMODE(info.st_mode) != 0o775:
            raise ValueError(f"audited {name} binary mode differs")
    return actual


def load_owned_helper():
    if sha(OWNED_HELPER) != OWNED_HELPER_SHA:
        raise ValueError("reviewed owned-process helper changed")
    spec = importlib.util.spec_from_file_location("reviewed_owned_process", OWNED_HELPER)
    if spec is None or spec.loader is None:
        raise ValueError("owned-process helper import failed")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require_lifecycle(records: Path) -> None:
    lifecycle = json.loads((records / "final-source-contracts.lifecycle.json").read_text(encoding="utf-8"))
    expected = {
        "owned_group_identity_valid": True,
        "direct_child_joined": True,
        "timed_out": False,
        "term_attempted": False,
        "kill_attempted": False,
        "forced_cleanup": False,
        "group_joined": True,
        "direct_status": 0,
        "wait_returncode": 0,
    }
    for key, wanted in expected.items():
        if lifecycle.get(key) != wanted:
            raise ValueError(f"contract lifecycle {key} differs: {lifecycle.get(key)!r}")
    if (records / "final-source-contracts.direct.status").read_text(encoding="utf-8") != "0\n":
        raise ValueError("contract direct status differs")


def require_contract_work(work: Path) -> dict[str, str]:
    required_names = {
        "FINAL",
        "arm-outcome-cases.json",
        "h1-continuation-cases.json",
        "path-resolution/result.json",
        "source-bindings.json",
    }
    actual = inventory(work)
    if not required_names.issubset(actual):
        raise ValueError(f"required contract artifacts are missing: {sorted(required_names - set(actual))}")
    if len(actual) > 128:
        raise ValueError("contract artifact count exceeded 128")
    total = 0
    for relative in actual:
        size = (work / relative).stat().st_size
        if size > 4 * 1024 * 1024:
            raise ValueError(f"contract artifact exceeded 4 MiB: {relative}")
        total += size
    if total > 8 * 1024 * 1024:
        raise ValueError("contract artifacts exceeded 8 MiB total")
    if (work / "FINAL").read_text(encoding="utf-8") != "complete\n":
        raise ValueError("contract FINAL marker differs")
    for relative in sorted(required_names - {"FINAL"}):
        value = json.loads((work / relative).read_text(encoding="utf-8"))
        if value.get("accepted") is not True:
            raise ValueError(f"contract output is not accepted: {relative}")
    return actual


def main() -> int:
    if len(sys.argv) != 2:
        raise ValueError("usage: run-final-contracts.py FRESH_OUTPUT")
    output = Path(sys.argv[1]).resolve()
    if output.exists() or output.is_symlink() or not output.parent.is_dir():
        raise ValueError("output must be fresh below an existing parent")
    output.mkdir(mode=0o700)
    info = output.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o700:
        raise ValueError("output must be an euid-owned mode-0700 directory")
    records = output / "records"
    records.mkdir(mode=0o700)
    work = records / "contract-work"
    accepted = False
    issue = None
    checkpoint_expected = None
    active_pre = None
    try:
        if sys.flags.isolated != 1 or not sys.dont_write_bytecode:
            raise ValueError("driver requires Python -I -B")
        if sha(PYTHON) != PYTHON_SHA:
            raise ValueError("reviewed Python interpreter changed")
        checkpoint_expected = parse_checkpoint()
        active_pre = verify_active(checkpoint_expected)
        if sha(CONTRACT) != CONTRACT_SHA:
            raise ValueError("final-source contract driver changed")
        write_json(records / "fixed-inputs-pre.json", {
            "schema_version": 1,
            "checkpoint_manifest_sha256": CHECKPOINT_SHA,
            "contract_sha256": CONTRACT_SHA,
            "owned_process_helper_sha256": OWNED_HELPER_SHA,
            "python_sha256": PYTHON_SHA,
            "published_receipts": PROVENANCE,
            "audited_binaries": {name: digest for name, (_, digest) in BINARIES.items()},
        })
        write_json(records / "active-corpus-pre.json", {"schema_version": 1, "files": active_pre})
        owned = load_owned_helper()
        environment = {
            "HOME": "/home/user",
            "PATH": "/usr/bin:/bin",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONHASHSEED": "0",
            "LC_ALL": "C",
            "TZ": "Europe/Zurich",
        }
        write_json(records / "environment.json", environment)
        status = owned.run(
            records,
            "final-source-contracts",
            ["/usr/bin/bash", str(CONTRACT), str(work)],
            ACTIVE,
            environment,
            120,
        )
        if status != 0:
            raise ValueError(f"final-source contracts returned {status}")
        require_lifecycle(records)
        contract_inventory = require_contract_work(work)
        write_json(records / "contract-work-inventory.json", {
            "schema_version": 1,
            "files": contract_inventory,
        })
        accepted = True
    except BaseException as error:
        issue = f"{type(error).__name__}: {error}"
        traceback.print_exc()
    finally:
        checks: dict[str, object] = {}
        try:
            checkpoint_post = parse_checkpoint()
            checks["checkpoint_unchanged"] = checkpoint_expected is not None and checkpoint_post == checkpoint_expected
            active_post = verify_active(checkpoint_post)
            checks["active_corpus_unchanged"] = active_pre is not None and active_post == active_pre
            checks["contract_unchanged"] = sha(CONTRACT) == CONTRACT_SHA
            checks["owned_process_helper_unchanged"] = sha(OWNED_HELPER) == OWNED_HELPER_SHA
            checks["python_unchanged"] = sha(PYTHON) == PYTHON_SHA
            write_json(records / "active-corpus-post.json", {"schema_version": 1, "files": active_post})
            write_json(records / "fixed-inputs-post.json", {
                "schema_version": 1,
                "checkpoint_manifest_sha256": sha(CHECKPOINT / "SHA256SUMS.txt"),
                "contract_sha256": sha(CONTRACT),
                "owned_process_helper_sha256": sha(OWNED_HELPER),
                "python_sha256": sha(PYTHON),
                "published_receipts": inventory(ACTIVE / "provenance"),
                "audited_binaries": {name: sha(path) for name, (path, _) in BINARIES.items()},
            })
            accepted = accepted and all(value is True for value in checks.values())
        except BaseException as final_error:
            accepted = False
            checks["finalization_error"] = f"{type(final_error).__name__}: {final_error}"
        write_json(records / "RESULT.json", {
            "schema_version": 1,
            "accepted": accepted,
            "issue": issue,
            "post_checks": checks,
            "endpoint_execution": False,
            "wan_traffic": False,
        })
        write_text(records / "final.status", "0\n" if accepted else "1\n")
        with (records / "SHA256SUMS.txt").open("x", encoding="utf-8") as stream:
            for path in sorted(records.rglob("*")):
                if path.is_file() and path.name != "SHA256SUMS.txt":
                    stream.write(f"{sha(path)}  ./{path.relative_to(records).as_posix()}\n")
        write_text(output / "FINAL", "complete\n")
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
