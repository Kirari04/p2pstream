# Combined byte-credit audited build source

This checkpoint is source-only and has not built binaries, run Go tests, opened endpoints, or generated traffic. It supersedes preserved checkpoint 8 after its no-Go preflight exposed two deterministic adapter-input assumptions: five nested input ledgers are intentionally outside checkpoint 4's signed 46-file ledger, and `SOURCE-MAP.json` names active sources beneath `overlay/`. This checkpoint requires that exact five-path exclusion, verifies every signed entry, joins the exact four `overlay/` map entries to the active four-file overlay, and rejects any other missing or extra path.

The driver requires a separate approved-input file that binds this checkpoint and driver, the accepted composite ordinary-code/referent receipt, and the current-source binding. It retains the rejected strict generated-symbol-name result as evidence and requires the accepted exact referent supplement; it does not reinterpret the strict result as passing.

On an accepted run, the driver materializes the audited `8ac4c8d` source, applies exactly the eleven byte-credit Yamux files and three adapter files, runs the declared focused package controls in normal and race modes, builds fresh tagged agent/server test binaries, verifies all owned process groups and immutable inputs, closes the records ledger, writes `FINAL`, and publishes the build receipt last.
