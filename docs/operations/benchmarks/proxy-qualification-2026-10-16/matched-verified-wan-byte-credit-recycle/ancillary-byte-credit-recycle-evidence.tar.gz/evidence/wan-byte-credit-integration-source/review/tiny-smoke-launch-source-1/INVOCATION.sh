#!/usr/bin/env bash
set -Eeuo pipefail
exec /usr/bin/env \
  -u P2PSTREAM_QUALIFICATION_PROFILE_DIR \
  -u P2PSTREAM_QUALIFICATION_PROFILE_MODE \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_DIR \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_SEQUENCES \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_BEARER \
  /usr/bin/taskset -c 0-15 \
  /usr/bin/bash \
  /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/integration-source/integration/run-wan-below-tls-diagnostic.sh \
  --server-binary /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/combined-build-source/runs/audited-build-attempt-1/bin/current-server-wan-byte-credit-audited.test \
  --aggregate-agent-binary /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/combined-build-source/runs/audited-build-attempt-1/bin/current-agent-wan-byte-credit-audited.test \
  --server-source-ref PENDING_BYTE_CREDIT_SOURCE_REF \
  --aggregate-agent-source-ref PENDING_BYTE_CREDIT_SOURCE_REF \
  --output-dir /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-byte-credit-integration-source/integration-source/integration/runs/tiny-byte-credit-smoke-1 \
  --small-diagnostic
