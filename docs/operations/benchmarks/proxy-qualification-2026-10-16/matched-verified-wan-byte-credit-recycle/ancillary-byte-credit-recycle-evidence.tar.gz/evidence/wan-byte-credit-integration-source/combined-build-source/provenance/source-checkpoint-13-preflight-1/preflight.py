import importlib.util, json, hashlib
from pathlib import Path
root = Path('/home/user/.codex/worktrees/astra-proxy-performance/p2pstream')
checkpoint = root/'tmp/continuation-20261016/wan-byte-credit-integration-source/combined-build-source/review/source-checkpoint-13'
external = root/'tmp/continuation-20261016/wan-byte-credit-integration-source/combined-build-source/review/source-checkpoint-13-external'
approved_path = external/'APPROVED-INPUTS.json'
proof_path = root/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle/runs/ordinary-proof-equivalence-attempt-1/RECEIPT.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('byte_credit_terminal_build',checkpoint/'run-audited-byte-credit-build.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
approved=json.loads(approved_path.read_text())
module.verify_component(checkpoint,approved['build_checkpoint_manifest_sha256'])
module.verify_component(external,'d5d47f6a27d42a1fda8be7de2352ad08c4040f0d0bb5d3741f19843b38983526')
module.verify_prior_build(); module.verify_component(module.PROTOCOL_CP,module.PROTOCOL_CP_SHA)
adapter_entries=module.verify_adapter_checkpoint(); module.verify_protocol_focused(); module.verify_adapter_contract(); module.verify_failed_build_attempt(); module.verify_prior_byte_build(); module.verify_tiny1_failure(); module.verify_failed_build3(); module.verify_invalid_build4(); module.verify_proof(proof_path,approved); module.verify_current_binding(approved,module.load_json(checkpoint/'CURRENT-SOURCE-BINDING-SCHEMA.json')); module.load_helper()
packages=module.expected_contract(checkpoint/'EXPECTED-TESTS.json')
counts={name:{'roots':len(value['roots']),'all_tests':len(value['all_tests'])} for name,value in packages.items()}
if counts != {'p2pstream/internal/agent':{'roots':7,'all_tests':10},'p2pstream/internal/server':{'roots':2,'all_tests':5}}: raise ValueError('test counts changed')
print(json.dumps({'accepted':True,'adapter_signed_entries':len(adapter_entries),'adapter_overlay_entries':len(module.ADAPTER_FILES),'test_counts':counts,'tiny1_run_ledger_sha256':module.TINY1_RUN_LEDGER_SHA,'prior_byte_build_receipt_sha256':module.PRIOR_BYTE_BUILD_RECEIPT_SHA},sort_keys=True))
