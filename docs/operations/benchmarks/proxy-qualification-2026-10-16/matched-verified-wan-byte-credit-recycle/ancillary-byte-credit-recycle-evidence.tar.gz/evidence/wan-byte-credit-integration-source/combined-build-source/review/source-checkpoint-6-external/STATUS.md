# External approved inputs

Checkpoint 6 supersedes checkpoints 2–5. It uses the authoritative pre-existing `8bad77a` current-source binding and retains checkpoint 4's corrected composite-proof validation and exact runner-compatible receipt field names. Checkpoint 5 was a documentation-only clarification. Source-only and unexecuted.
