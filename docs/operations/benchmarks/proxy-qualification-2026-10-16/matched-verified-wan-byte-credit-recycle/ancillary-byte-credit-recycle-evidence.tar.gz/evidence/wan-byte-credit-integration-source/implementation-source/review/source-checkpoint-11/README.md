# Adapter source checkpoint 11

Checkpoint 11 is a metadata-only successor to the restored checkpoint 10.
Every Go overlay, reconstruction patch, focused test root, and the terminal
replay source correction is byte-identical to checkpoint 10.

It records the checkpoint-10 in-place metadata mutation incident separately and
binds audited build attempt 4 as provenance-invalid even though its commands and
checks completed successfully. Neither its receipt nor its binaries may be used.
The attempt-3 `records/FINAL.json` and top-level `FINAL` hashes are named
separately here; this clarification caused the earlier incident and is now made
only in this new checkpoint.

No test, build, endpoint, or traffic command ran from checkpoint 11. All external hashes are bound. This checkpoint is frozen and must not be edited
again.
