#!/usr/bin/env python3
from __future__ import annotations

import ast
import hashlib
import json
import pathlib
import re
import sys


if len(sys.argv) != 5:
    raise SystemExit("usage: test-final-source-bindings.py ARM COORDINATOR VALIDATOR OUTPUT")
arm_path, coordinator_path, validator_path, output_path = map(pathlib.Path, sys.argv[1:])
if output_path.exists():
    raise SystemExit("fresh output required")
arm = arm_path.read_text()
coordinator = coordinator_path.read_text()
validator_source = validator_path.read_text()
validator_tree = ast.parse(validator_source, filename=str(validator_path))


def sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bound_self_gate(source: str, variable: str, path: pathlib.Path) -> bool:
    found = re.findall(
        rf'''sha256sum "\${re.escape(variable)}"[^\n]*== ([0-9a-f]{{64}})''',
        source,
    )
    return bool(found) and all(value == sha(path) for value in found)
required = None
for node in ast.walk(validator_tree):
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "required_hashes"
                                            for target in node.targets):
        required = ast.literal_eval(node.value)
        break
if not isinstance(required, set):
    raise SystemExit("validator required_hashes set not found")

write_start = arm.find("write_hashes() {")
python_start = arm.find("<<'PY'\n", write_start)
python_end = arm.find("\nPY\n}", python_start)
if min(write_start, python_start, python_end) < 0:
    raise SystemExit("arm write_hashes embedded Python not found")
embedded = arm[python_start + len("<<'PY'\n"):python_end]
tree = ast.parse(embedded, filename=f"{arm_path}:write_hashes")
emitted = None
for node in ast.walk(tree):
    if isinstance(node, ast.Dict):
        keys = [key.value for key in node.keys if isinstance(key, ast.Constant) and isinstance(key.value, str)]
        if "supervisor" in keys and "server_binary" in keys:
            emitted = set(keys)
            break
if not isinstance(emitted, set):
    raise SystemExit("arm emitted hash dictionary not found")

integration = validator_path.parent
self_gates = {
    "arm_validator": bound_self_gate(arm, "validator", integration / "validate-wan-below-tls-arm.py"),
    "arm_outcome_validator": bound_self_gate(arm, "arm_outcome_validator", integration / "validate-arm-outcome.py"),
    "arm_copy_validator": bound_self_gate(arm, "copy_record_validator", integration / "validate-copy-record.py"),
    "arm_sender_validator": bound_self_gate(arm, "sender_snapshot_validator", integration / "validate-sender-wait-snapshot.py"),
    "arm_raw_validator": bound_self_gate(arm, "raw_write_validator", integration / "validate-raw-write-activity.py"),
    "arm_growth_validator": bound_self_gate(arm, "server_growth_validator", integration / "validate-server-receive-growth.py"),
    "arm_byte_credit_validator": bound_self_gate(arm, "byte_credit_validator", integration / "validate-byte-credit-recycle.py"),
    "arm_closure_validator": bound_self_gate(arm, "raw_closure_validator", integration / "validate-post-join-raw-closure.py"),
    "coordinator_arm_validator": bound_self_gate(coordinator, "validator", integration / "validate-wan-below-tls-arm.py"),
    "coordinator_outcome_validator": bound_self_gate(coordinator, "arm_outcome_validator", integration / "validate-arm-outcome.py"),
    "coordinator_copy_validator": bound_self_gate(coordinator, "copy_record_validator", integration / "validate-copy-record.py"),
    "coordinator_sender_validator": bound_self_gate(coordinator, "snapshot_validator", integration / "validate-sender-wait-snapshot.py"),
    "coordinator_raw_validator": bound_self_gate(coordinator, "raw_write_validator", integration / "validate-raw-write-activity.py"),
    "coordinator_growth_validator": bound_self_gate(coordinator, "server_growth_validator", integration / "validate-server-receive-growth.py"),
    "coordinator_byte_credit_validator": bound_self_gate(coordinator, "byte_credit_validator", integration / "validate-byte-credit-recycle.py"),
    "coordinator_closure_validator": bound_self_gate(coordinator, "raw_closure_validator", integration / "validate-post-join-raw-closure.py"),
    "coordinator_continuation_validator": bound_self_gate(coordinator, "continuation_validator", integration / "validate-h1-continuation.py"),
}
pending_byte_credit = "PENDING_" + "BYTE_CREDIT_"

checks = {
    "all_runtime_self_gates_match_materialized_files": all(self_gates.values()),
    "arm_hash_keys_equal_validator_keys": emitted == required,
    "accepted_proof_receipt_exactly_bound": arm.count("b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d") == 1
                                              and coordinator.count("b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d") == 1
                                              and "PENDING_RAW_ORDINARY_PROOF_RECEIPT_SHA256" not in arm + coordinator,
    "accepted_byte_credit_proof_receipt_exactly_bound": arm.count("6562b975ba8f25d1b7a1a83c323c4c289f62f97b5508421e9e0f2e244c940460") == 1
                                              and coordinator.count("6562b975ba8f25d1b7a1a83c323c4c289f62f97b5508421e9e0f2e244c940460") == 1
                                              and pending_byte_credit + "ORDINARY_PROOF_RECEIPT_SHA256" not in arm + coordinator,
    "accepted_build_receipt_exactly_bound": arm.count("93c91824df93bdfd78efc50dbc22b3c028b2e87ac4c88b77600c30207df0daff") == 1
                                              and coordinator.count("93c91824df93bdfd78efc50dbc22b3c028b2e87ac4c88b77600c30207df0daff") == 1
                                              and "PENDING_COMBINED_BUILD_RECEIPT_SHA256" not in arm + coordinator,
    "base_build_ancestry_exactly_bound": arm.count("472d8abcbb2c36d866e201f32f3c8aab25f8ff478670859fbea57cc174a435c6") == 1
                                              and coordinator.count("472d8abcbb2c36d866e201f32f3c8aab25f8ff478670859fbea57cc174a435c6") == 1
                                              and '.base_combined_build_receipt_sha256 == "472d8abcbb2c36d866e201f32f3c8aab25f8ff478670859fbea57cc174a435c6"' in arm
                                              and '.base_combined_build_receipt_sha256 == "472d8abcbb2c36d866e201f32f3c8aab25f8ff478670859fbea57cc174a435c6"' in coordinator,
    "receipts_use_canonical_published_paths": 'raw_ordinary_proof_receipt="$combined_root/provenance/raw-ordinary-proof-receipt.json"' in arm
                                              and 'byte_credit_ordinary_proof_receipt="$combined_root/provenance/byte-credit-ordinary-proof-receipt.json"' in arm
                                              and 'combined_build_receipt="$combined_root/provenance/audited-combined-build-receipt.json"' in arm
                                              and 'raw_ordinary_proof_receipt="$combined_root/provenance/raw-ordinary-proof-receipt.json"' in coordinator
                                              and 'byte_credit_ordinary_proof_receipt="$combined_root/provenance/byte-credit-ordinary-proof-receipt.json"' in coordinator
                                              and 'combined_build_receipt="$combined_root/provenance/audited-combined-build-receipt.json"' in coordinator,
    "no_internal_final_manifest_cycle": "expected_final_reviewed_manifest" not in arm + coordinator
                                         and "final_reviewed_manifest" not in arm + coordinator,
    "coordinator_executes_continuation_validator": bool(re.search(
        r'python3 -I -B "\$continuation_validator"[\s\\]+"\$output_dir/h1/supervisor-lifecycle.json"', coordinator)),
    "coordinator_does_not_gate_h2_on_arm_accepted": ".accepted == true and .raw_write_final_closure_valid" not in coordinator,
    "historical_cp10_verifier_scoped_to_mature_root": bool(re.search(
        r'"\$reviewed_integration_verifier" "\$reviewed_integration_manifest" "\$mature_sender_root"', coordinator)),
    "timed_runner_hash_bound": "a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad" in arm
                               and "a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad" in coordinator,
}
result = {
    "schema_version": 1,
    "accepted": all(checks.values()),
    "checks": checks,
    "required_hash_key_count": len(required),
    "emitted_hash_key_count": len(emitted),
    "missing_from_arm": sorted(required - emitted),
    "unexpected_from_arm": sorted(emitted - required),
    "check_count": len(checks),
    "self_gates": self_gates,
}
output_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
if not result["accepted"]:
    raise SystemExit("final source binding contract failed")
