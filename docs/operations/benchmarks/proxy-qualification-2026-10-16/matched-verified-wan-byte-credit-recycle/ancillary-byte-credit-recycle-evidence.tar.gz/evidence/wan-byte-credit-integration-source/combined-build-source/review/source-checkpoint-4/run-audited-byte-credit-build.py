#!/usr/bin/python3.14
"""Run focused adapter controls and build the reviewed byte-credit corpus."""
from __future__ import annotations

import hashlib, importlib.util, json, os, re, shutil, stat, sys, time, traceback
from pathlib import Path, PurePosixPath

sys.dont_write_bytecode = True
REPO = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
CONT = REPO / "tmp/continuation-20261016"
ROOT = CONT / "wan-byte-credit-integration-source"
BUILD = ROOT / "combined-build-source"
RUNS = BUILD / "runs"
BASE_RUN = CONT / "wan-below-tls-raw-write-source/implementation-source/combined-build/runs/audited-build-attempt-1"
BASE_SOURCE = BASE_RUN / "source"
BASE_INVENTORY = BASE_RUN / "records/source-pre.json"
BASE_INVENTORY_SHA = "2bf3c0201892b5da5af984874f93bbdfa8c59dd92c04886fbeaf545f4437816c"
BASE_LEDGER_SHA = "9d89e974120f0a2b28c03dac1d1d5ed7031999b7b69dbcf875fabdc53a2cd96f"
BASE_RECEIPT_SHA = "472d8abcbb2c36d866e201f32f3c8aab25f8ff478670859fbea57cc174a435c6"
PROTOCOL_CP = CONT / "wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle/review/source-checkpoint-5"
PROTOCOL_CP_SHA = "d315f2e4f49c3b00d714346d5ff38a797c52e7b1874e7d21e7d89679a46d4287"
PROTOCOL_OVERLAY = PROTOCOL_CP.parents[1] / "source/third_party/yamux"
PROTOCOL_FOCUSED = PROTOCOL_CP.parents[1] / "runs/focused-attempt-2/records"
PROTOCOL_FOCUSED_SHA = "2ebacd83ac4102b008185ed173910c467bc271ca87ada6c4c831f1357fb0ea2e"
PROTOCOL_OUTER = PROTOCOL_CP.parents[1] / "provenance/focused-attempt-2-worker-tool-envelope"
PROTOCOL_OUTER_SHA = "ffcd04d875bcc1d533bd93d2045e113f68a2e9f072643f1eaf96f5270db8126d"
PROOF_ROOT_EXPECTED = PROTOCOL_CP.parents[1] / "runs/ordinary-proof-equivalence-attempt-1"
PROOF_REUSED_FAILED_LEDGER_SHA = "9366180252ad6af8f4ae14f8212aa629e62581e5c0e90ad25b7a08a8f1da6927"
PROOF_STRICT_CHECKPOINT_SHA = "6ce6b7a39f74be0e04bf653cc533b7bc5258d628f88bb776a8d869485585bace"
PROOF_STRICT_LEDGER_SHA = "b44462efcda19a1a8cd4357effe7fdb590b2c565a034c29ddf747264ea44b13b"
PROOF_STRICT_REPORT_SHA = "e6a8aaa14b0682470cd944445498a0a1b9fc9250d79d7f99dd20e3b14440a581"
ADAPTER_ROOT = ROOT / "implementation-source"
ADAPTER_CP = ADAPTER_ROOT / "review/source-checkpoint-3"
ADAPTER_CP_SHA = "ecaed82ce87ad3e5d5409f786b3a397d2f4322f3de78d39baec24c137646ac2c"
ADAPTER_OVERLAY = ADAPTER_ROOT / "overlay"
ADAPTER_CONTRACT = ROOT / "runs/focused-contract-attempt-2"
ADAPTER_CONTRACT_SHA = "b4253d5b10bbbec2ea1d94b679ded5dea805081c62b2d31c36b3798ea726125a"
ADAPTER_OUTER = ROOT / "provenance/focused-contract-attempt-2-main-tool-envelope"
ADAPTER_OUTER_SHA = "b54598e556246b568ae8fe9bdadac91feda31d9f2a29d44a9e7d9f3a1bebfdc0"
CURRENT_BINDING = BUILD / "provenance/main-current-source-binding/binding.json"
HELPER = CONT / "wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
HELPER_SHA = "8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
GO = Path("/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go")
GO_SHA = "29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45"
GO_VERSION = "go version go1.26.6 linux/amd64"
PYTHON = Path("/usr/bin/python3.14")
PYTHON_SHA = "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
TASKSET = Path("/usr/bin/taskset")
TASKSET_SHA = "42acb8e233943873f3bf9eeb1e15bd3281498b5603a5b10d0f9bc37067a12d57"
SOURCE_REF = "8ac4c8df8237e37777ba2fac0da6f949da17bdea"
CURRENT_HEAD = "8bad77a456876fac0ee4b76673890a2243951d5f"
GO_MOD_SHA = "165d373cd30192573bfd30e0f0997b393c433368d3ac01df8b178aaf4bdb5d65"
GO_SUM_SHA = "7e451e21339534258c770d5d4669cffd5c126d38e91026e09f35fa93c89173f2"
MAX_FILE = 1 << 30
MAX_STREAM = 64 << 20
MAX_LINE = 1 << 20
APPROVED_FIELDS = {
    "schema_version", "accepted", "build_checkpoint_manifest_sha256", "build_driver_sha256",
    "ordinary_proof_checkpoint_sha256", "ordinary_proof_receipt_sha256", "current_source_binding_sha256",
}
ADAPTER_FILES = {
    "internal/agent/proxy_qualification_credit_snapshot_enabled_test.go": "29520cfdf2b7f3ff0d7c687c82adfe90c03ca1b26c85366a1d10caad771244f1",
    "internal/agent/proxy_qualification_wan_sender_wait_test.go": "b8356ff63ab4213276721b4d1e7b3b566e1e7f07d3b4d82ddab48ef9e780536c",
    "internal/server/proxy_qualification_wan_sender_wait_growth_enabled_test.go": "6787b8eceaec82cdd0c8345da9d0b57801e4dd075924b0c4ec9e56f670033cc7",
}
MATURE_RECEIPT_FIELDS = {
    "raw_ordinary_proof_receipt_sha256": "b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d",
    "raw_runtime_checkpoint_sha256": "4474770be44e933572b79ece0d5db970f3a27f8792a41c27adc31269230b6bab",
    "raw_isolation_checkpoint_sha256": "85afe09e358fd3b9f9277ec6bc8de42ea4fae59a646f5810b0d5dfa3d3cc6d6c",
    "server_growth_checkpoint_sha256": "29e33466c5f79928b4d3805fcf957fb0d49b1eeb1f0c8fba720ff001c7193856",
}
MATURE_EVIDENCE_FIELDS = {
    "raw_focused_evidence_ledger_sha256": "26b6e59c6a4911328b1684221ba41779c7f4aa7aafbf516c253628916d70a656",
    "server_focused_evidence_ledger_sha256": "2109895c1d9d0d4824f49b9823b034a44693dfa1d8ca05c5340491024fa726ff",
    "combined_contract_evidence_ledger_sha256": "d63e8212ba90000f5067c20546a7f9084ae65f0073aa3cb9690c3c0c8615ef37",
}


def sha(path: Path) -> str:
    path = Path(path)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_FILE:
        raise ValueError(f"unsafe file: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path):
    return json.loads(path.read_text())


def write_json(path: Path, value) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def write_text(path: Path, value: str) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w") as stream:
        stream.write(value)


def safe_name(value: str) -> str:
    if value.startswith("./") and not value.startswith("././"):
        value = value[2:]
    item = PurePosixPath(value)
    if not value or value != item.as_posix() or item.is_absolute() or any(part in ("", ".", "..") for part in item.parts):
        raise ValueError(f"unsafe ledger path: {value!r}")
    return value


def inventory(root: Path) -> dict[str, str]:
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError(f"unsafe inventory root: {root}")
    result = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"symlink in inventory: {path}")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha(path)
    return result


def parse_ledger(path: Path) -> dict[str, str]:
    result = {}
    for line in path.read_text().splitlines():
        digest, name = line.split("  ", 1)
        name = safe_name(name)
        if re.fullmatch(r"[0-9a-f]{64}", digest) is None or name in result:
            raise ValueError(f"malformed ledger: {path}")
        result[name] = digest
    if not result:
        raise ValueError(f"empty ledger: {path}")
    return result


def verify_exact_ledger(root: Path, expected_sha: str, exclude: tuple[str, ...] = ("SHA256SUMS.txt",)) -> dict[str, str]:
    manifest = root / "SHA256SUMS.txt"
    if sha(manifest) != expected_sha:
        raise ValueError(f"ledger digest mismatch: {root}")
    expected = parse_ledger(manifest)
    actual = {name: digest for name, digest in inventory(root).items() if name not in set(exclude)}
    if actual != expected:
        raise ValueError(f"ledger coverage mismatch: {root}")
    return expected


def verify_component(checkpoint: Path, expected_sha: str) -> dict[str, str]:
    return verify_exact_ledger(checkpoint, expected_sha)


def verify_adapter_checkpoint() -> dict[str, str]:
    manifest = ADAPTER_CP / "SHA256SUMS.txt"
    if sha(manifest) != ADAPTER_CP_SHA:
        raise ValueError("adapter checkpoint manifest changed")
    expected = parse_ledger(manifest)
    for name, digest in expected.items():
        path = ADAPTER_ROOT.joinpath(*PurePosixPath(name).parts)
        if not path.resolve().is_relative_to(ADAPTER_ROOT.resolve()) or sha(path) != digest:
            raise ValueError(f"adapter checkpoint input changed: {name}")
    return expected


def verify_result(root: Path, ledger_sha: str, final_name: str) -> dict:
    verify_exact_ledger(root, ledger_sha)
    result = load_json(root / final_name)
    if result.get("accepted") is not True:
        raise ValueError(f"unaccepted result: {root}")
    if "post_checks" in result and not all(result["post_checks"].values()):
        raise ValueError(f"failed postcheck: {root}")
    for lifecycle in root.glob("*.lifecycle.json"):
        value = load_json(lifecycle)
        if value.get("direct_status") != 0 or value.get("group_joined") is not True or value.get("forced_cleanup") is not False:
            raise ValueError(f"non-natural lifecycle: {lifecycle}")
    return result


def verify_prior_build() -> dict:
    result = verify_result(BASE_RUN / "records", BASE_LEDGER_SHA, "FINAL.json")
    receipt_path = BASE_RUN / "audited-combined-build-receipt.json"
    if sha(receipt_path) != BASE_RECEIPT_SHA:
        raise ValueError("prior build receipt changed")
    receipt = load_json(receipt_path)
    if receipt.get("accepted") is not True or receipt.get("records_ledger_sha256") != BASE_LEDGER_SHA:
        raise ValueError("prior build receipt rejected")
    if any(receipt.get(key) != value for key, value in {**MATURE_RECEIPT_FIELDS, **MATURE_EVIDENCE_FIELDS}.items()):
        raise ValueError("prior mature diagnostic binding changed")
    return result


def verify_protocol_focused() -> None:
    result = verify_result(PROTOCOL_FOCUSED, PROTOCOL_FOCUSED_SHA, "RESULT.json")
    if result.get("normal_and_race") is not True or set(result.get("stages", {})) != {"normal", "race"}:
        raise ValueError("protocol focused stages rejected")
    verify_exact_ledger(PROTOCOL_OUTER, PROTOCOL_OUTER_SHA)
    envelope = load_json(PROTOCOL_OUTER / "tool-envelope.json")
    if envelope.get("final", {}).get("exit_code") != 0:
        raise ValueError("protocol focused outer status")


def verify_adapter_contract() -> None:
    result = verify_result(ADAPTER_CONTRACT, ADAPTER_CONTRACT_SHA, "RESULT.json")
    summary = result.get("contract_summary", {})
    if result.get("contract_status") != 0 or summary.get("accepted") is not True or summary.get("case_count") != 37:
        raise ValueError("adapter contract rejected")
    verify_exact_ledger(ADAPTER_OUTER, ADAPTER_OUTER_SHA)
    if load_json(ADAPTER_OUTER / "outer-tool-envelope.json").get("exit_code") != 0:
        raise ValueError("adapter contract outer status")


def verify_proof(receipt_path: Path, approved: dict) -> dict:
    receipt_path = Path(receipt_path)
    if receipt_path != PROOF_ROOT_EXPECTED / "RECEIPT.json":
        raise ValueError("unexpected ordinary proof receipt path")
    if sha(receipt_path) != approved["ordinary_proof_receipt_sha256"]:
        raise ValueError("ordinary proof receipt changed")
    receipt = load_json(receipt_path)
    required = {
        "schema_version": 1, "diagnostic": "wan-byte-credit-recycle", "accepted": True,
        "ordinary_untagged_code_and_referents_equivalent": True,
        "strict_generated_symbol_names_equal": False, "strict_proof_accepted": False,
        "supplemental_reference_equivalence_accepted": True,
        "endpoint_execution": False, "endpoint_or_traffic": False, "wan_traffic": False,
        "source_checkpoint_sha256": PROTOCOL_CP_SHA,
        "focused_records_ledger_sha256": PROTOCOL_FOCUSED_SHA,
        "strict_proof_checkpoint_sha256": PROOF_STRICT_CHECKPOINT_SHA,
        "strict_attempt_records_ledger_sha256": PROOF_STRICT_LEDGER_SHA,
        "strict_report_sha256": PROOF_STRICT_REPORT_SHA,
        "supplement_checkpoint_sha256": approved["ordinary_proof_checkpoint_sha256"],
        "base_source_inventory_sha256": BASE_INVENTORY_SHA,
        "reused_failed_records_ledger_sha256": PROOF_REUSED_FAILED_LEDGER_SHA,
    }
    if any(receipt.get(key) != value for key, value in required.items()):
        raise ValueError("ordinary proof receipt rejected")
    records = receipt_path.parent / "records"
    ledger_sha = receipt.get("records_ledger_sha256")
    if re.fullmatch(r"[0-9a-f]{64}", str(ledger_sha)) is None:
        raise ValueError("ordinary proof ledger field")
    verify_exact_ledger(records, ledger_sha)
    result = load_json(records / "FINAL.json")
    if result.get("accepted") is not True or not all(result.get("post_checks", {}).values()):
        raise ValueError("ordinary proof result rejected")
    lifecycles = {path.name.removesuffix(".lifecycle.json"): load_json(path) for path in records.glob("*.lifecycle.json")}
    if set(lifecycles) != {"contracts", "equivalence"} or any(value.get("direct_status") != 0 or value.get("direct_child_joined") is not True or value.get("group_joined") is not True or value.get("forced_cleanup") is not False or value.get("timed_out") is not False for value in lifecycles.values()):
        raise ValueError("ordinary proof lifecycle rejected")
    if receipt.get("final_sha256") != sha(records / "FINAL.json") or receipt.get("supplement_result_sha256") != sha(records / "equivalence/result.json") or receipt.get("supplement_contract_result_sha256") != sha(records / "contracts/result.json"):
        raise ValueError("ordinary proof output binding")
    return receipt


def verify_current_binding(approved: dict, schema: dict) -> dict:
    if sha(CURRENT_BINDING) != approved["current_source_binding_sha256"]:
        raise ValueError("current source binding changed")
    value = load_json(CURRENT_BINDING)
    if set(value) != set(schema) or any(value.get(key) != expected for key, expected in schema.items()):
        raise ValueError("current source binding rejected")
    return value


def load_helper():
    if sha(HELPER) != HELPER_SHA:
        raise ValueError("owned helper changed")
    spec = importlib.util.spec_from_file_location("byte_credit_owned", HELPER)
    if spec is None or spec.loader is None:
        raise ValueError("owned helper import")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def expected_contract(path: Path) -> dict:
    value = load_json(path)
    packages = value.get("packages")
    if value.get("schema_version") != 1 or not isinstance(packages, dict) or set(packages) != {"p2pstream/internal/agent", "p2pstream/internal/server"}:
        raise ValueError("test contract schema")
    for package, contract in packages.items():
        roots, tests = contract.get("roots"), contract.get("all_tests")
        if not isinstance(roots, list) or not isinstance(tests, list) or len(roots) != len(set(roots)) or len(tests) != len(set(tests)):
            raise ValueError(f"test contract cardinality: {package}")
        if set(roots) != {name for name in tests if "/" not in name}:
            raise ValueError(f"test root mismatch: {package}")
        if any(re.fullmatch(r"Test[A-Za-z0-9_]+", name) is None for name in roots) or any(name.split("/", 1)[0] not in roots for name in tests):
            raise ValueError(f"invalid test name: {package}")
    return packages


def audit_go_json(stream_path: Path, package: str, expected_tests: list[str], report_path: Path) -> bool:
    expected = set(expected_tests)
    actions = {name: [] for name in expected_tests}
    unexpected, rejected = [], []
    package_passes = total = 0
    with stream_path.open("rb") as stream:
        for number, line in enumerate(stream, 1):
            total += len(line)
            if total > MAX_STREAM or len(line) > MAX_LINE or not line.endswith(b"\n"):
                raise ValueError(f"bounded Go JSON violation line {number}")
            event = json.loads(line)
            if event.get("Package") != package:
                rejected.append({"line": number, "reason": "package", "package": event.get("Package")})
                continue
            action, test = event.get("Action"), event.get("Test")
            if test is None:
                if action == "pass":
                    package_passes += 1
                elif action in ("fail", "skip"):
                    rejected.append({"line": number, "reason": "package_terminal", "action": action})
                continue
            if test not in expected:
                unexpected.append({"line": number, "test": test, "action": action})
                continue
            if action in ("run", "pass", "fail", "skip"):
                actions[test].append(action)
                if action in ("fail", "skip"):
                    rejected.append({"line": number, "reason": "test_terminal", "test": test, "action": action})
    accepted = package_passes == 1 and not unexpected and not rejected and all(actions[name] == ["run", "pass"] for name in expected_tests)
    write_json(report_path, {"schema_version": 1, "accepted": accepted, "package": package, "expected_tests": expected_tests, "actions": actions, "package_passes": package_passes, "unexpected": unexpected, "rejected": rejected, "stream_bytes": total})
    return accepted


def audit_ordinary_json(stream_path: Path, package: str, report_path: Path) -> bool:
    return audit_go_json(stream_path, package, [], report_path)


def publish_last(path: Path, value: dict) -> None:
    encoded = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    temporary = path.with_name("." + path.name + ".tmp")
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    os.link(temporary, path, follow_symlinks=False)
    os.unlink(temporary)


def main() -> int:
    if len(sys.argv) != 4:
        raise SystemExit("usage: run-audited-byte-credit-build.py FRESH_OUTPUT APPROVED-INPUTS.json ORDINARY-PROOF-RECEIPT.json")
    output = Path(sys.argv[1]).resolve()
    approved_path = Path(sys.argv[2]).resolve(strict=True)
    proof_receipt_path = Path(sys.argv[3]).resolve(strict=True)
    checkpoint = Path(__file__).resolve().parent
    if output.exists() or output.parent != RUNS.resolve() or not RUNS.is_dir() or RUNS.is_symlink():
        raise SystemExit("fresh direct output required")
    approved = load_json(approved_path)
    if set(approved) != APPROVED_FIELDS or approved.get("schema_version") != 1 or approved.get("accepted") is not True:
        raise SystemExit("approved input schema")
    for key in APPROVED_FIELDS - {"schema_version", "accepted"}:
        if re.fullmatch(r"[0-9a-f]{64}", str(approved.get(key, ""))) is None:
            raise SystemExit(f"approved digest: {key}")
    if sha(checkpoint / "SHA256SUMS.txt") != approved["build_checkpoint_manifest_sha256"] or sha(Path(__file__).resolve()) != approved["build_driver_sha256"]:
        raise SystemExit("unapproved build driver")
    verify_component(checkpoint, approved["build_checkpoint_manifest_sha256"])
    output.mkdir(mode=0o700)
    records, source, binaries = output / "records", output / "source", output / "bin"
    records.mkdir(); binaries.mkdir()
    write_text(records / "start-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))
    write_json(records / "approved-inputs.json", approved)
    accepted = False; issue = None; helper = None; source_pre = None; static_pre = None; outputs = {}
    try:
        contract_path = checkpoint / "EXPECTED-TESTS.json"
        binding_schema = load_json(checkpoint / "CURRENT-SOURCE-BINDING-SCHEMA.json")
        components = {
            "protocol_checkpoint": PROTOCOL_CP / "SHA256SUMS.txt", "adapter_checkpoint": ADAPTER_CP / "SHA256SUMS.txt",
            "protocol_focused": PROTOCOL_FOCUSED / "SHA256SUMS.txt", "protocol_outer": PROTOCOL_OUTER / "SHA256SUMS.txt",
            "adapter_contract": ADAPTER_CONTRACT / "SHA256SUMS.txt", "adapter_outer": ADAPTER_OUTER / "SHA256SUMS.txt",
            "base_ledger": BASE_RUN / "records/SHA256SUMS.txt", "base_receipt": BASE_RUN / "audited-combined-build-receipt.json",
            "base_inventory": BASE_INVENTORY, "proof_receipt": proof_receipt_path, "current_binding": CURRENT_BINDING,
            "go": GO, "python": PYTHON, "taskset": TASKSET, "helper": HELPER, "test_contract": contract_path,
        }
        static_pre = {name: sha(path) for name, path in components.items()}
        verify_prior_build(); verify_component(PROTOCOL_CP, PROTOCOL_CP_SHA); verify_adapter_checkpoint()
        verify_protocol_focused(); verify_adapter_contract(); proof = verify_proof(proof_receipt_path, approved)
        current_binding = verify_current_binding(approved, binding_schema)
        if sha(GO) != GO_SHA or sha(PYTHON) != PYTHON_SHA or sha(TASKSET) != TASKSET_SHA:
            raise ValueError("pinned tool changed")
        helper = load_helper()
        base_files = load_json(BASE_INVENTORY).get("files")
        if not isinstance(base_files, dict) or inventory(BASE_SOURCE) != base_files:
            raise ValueError("audited combined base changed")
        shutil.copytree(BASE_SOURCE, source, copy_function=shutil.copy2)
        if inventory(source) != base_files:
            raise ValueError("base materialization changed")
        protocol_inputs = load_json(PROTOCOL_CP / "INPUTS.json")
        protocol_overlay_values = protocol_inputs.get("overlay_files", {})
        if not isinstance(protocol_overlay_values, dict):
            raise ValueError("protocol overlay input schema")
        protocol_backing = {}
        for name, value in protocol_overlay_values.items():
            pure = PurePosixPath(name) if isinstance(name, str) else None
            if pure is None or name != pure.as_posix() or len(pure.parts) != 1 or not isinstance(value, dict) or set(value) != {"bytes", "sha256"} or type(value["bytes"]) is not int or value["bytes"] <= 0 or re.fullmatch(r"[0-9a-f]{64}", str(value["sha256"])) is None:
                raise ValueError("protocol overlay entry schema")
            path = PROTOCOL_OVERLAY / name
            if path.stat().st_size != value["bytes"]:
                raise ValueError(f"protocol overlay byte count: {name}")
            protocol_backing[name] = value["sha256"]
        if inventory(PROTOCOL_OVERLAY) != protocol_backing or len(protocol_backing) != 11:
            raise ValueError("protocol overlay changed")
        protocol_files = {f"third_party/yamux/{name}": digest for name, digest in protocol_backing.items()}
        adapter_files = {name: sha(ADAPTER_OVERLAY / name) for name in ADAPTER_FILES}
        if adapter_files != ADAPTER_FILES or set(protocol_files) & set(adapter_files):
            raise ValueError("adapter overlay changed or overlaps protocol")
        for name, digest in sorted(protocol_backing.items()):
            source_path = PROTOCOL_OVERLAY / name
            target = source / "third_party/yamux" / name
            shutil.copy2(source_path, target)
            if sha(target) != digest:
                raise ValueError(f"protocol overlay copy changed: {name}")
        for name, digest in sorted(adapter_files.items()):
            source_path = ADAPTER_OVERLAY.joinpath(*PurePosixPath(name).parts)
            target = source.joinpath(*PurePosixPath(name).parts)
            shutil.copy2(source_path, target)
            if sha(target) != digest:
                raise ValueError(f"adapter overlay copy changed: {name}")
        expected_source = dict(base_files); expected_source.update(protocol_files); expected_source.update(adapter_files)
        source_pre = inventory(source)
        if source_pre != expected_source:
            raise ValueError("combined byte-credit corpus mismatch")
        write_json(records / "source-pre.json", {"schema_version": 1, "base_source_ref": SOURCE_REF, "current_head": CURRENT_HEAD, "files": source_pre})
        write_json(records / "corpus.json", {"schema_version": 1, "accepted": True, "base_file_count": len(base_files), "protocol_overlay_file_count": len(protocol_files), "adapter_overlay_file_count": len(adapter_files), "final_file_count": len(source_pre), "protocol_overlay": protocol_files, "adapter_overlay": adapter_files})
        if sha(source / "go.mod") != GO_MOD_SHA or sha(source / "go.sum") != GO_SUM_SHA:
            raise ValueError("module files changed")
        packages = expected_contract(contract_path)
        common = {"HOME": "/home/user", "PATH": "/usr/bin:/bin", "GOENV": "off", "GOTOOLCHAIN": "local", "GOWORK": "off", "GOFLAGS": "", "CGO_ENABLED": "1", "GOMAXPROCS": "16", "GOPATH": str(output / "gopath"), "GOMODCACHE": "/home/user/go/pkg/mod", "GOPROXY": "off", "GOSUMDB": "off", "LC_ALL": "C", "TZ": "Europe/Zurich"}
        for directory in (output / "gopath", output / "tmp-normal", output / "tmp-race", output / "gocache-normal", output / "gocache-race"):
            directory.mkdir(mode=0o700)
        normal_env = dict(common, TMPDIR=str(output / "tmp-normal"), GOTMPDIR=str(output / "tmp-normal"), GOCACHE=str(output / "gocache-normal"))
        race_env = dict(common, TMPDIR=str(output / "tmp-race"), GOTMPDIR=str(output / "tmp-race"), GOCACHE=str(output / "gocache-race"))
        write_json(records / "go-environment.json", {"normal": normal_env, "race": race_env})
        def run(name: str, command: list[str], cwd: Path, env: dict, timeout: int) -> None:
            if helper.run(records, name, command, cwd, env, timeout) != 0:
                raise ValueError(f"command failed: {name}")
        run("toolchain-version-pre", [str(GO), "version"], REPO, {"HOME": "/home/user", "PATH": "/usr/bin:/bin", "LC_ALL": "C", "TZ": "Europe/Zurich"}, 30)
        if (records / "toolchain-version-pre.stdout.log").read_text().strip() != GO_VERSION:
            raise ValueError("Go version pre")
        run("go-env", [str(GO), "env", "-json", "GOMOD", "GOWORK", "GOENV", "GOTOOLCHAIN", "GOMODCACHE", "GOPATH", "GOPROXY", "GOSUMDB"], source, normal_env, 30)
        effective = load_json(records / "go-env.stdout.log")
        wanted = {"GOMOD": str(source / "go.mod"), "GOWORK": "off", "GOENV": "", "GOTOOLCHAIN": "local", "GOMODCACHE": "/home/user/go/pkg/mod", "GOPATH": str(output / "gopath"), "GOPROXY": "off", "GOSUMDB": "off"}
        if effective != wanted:
            raise ValueError("effective Go environment")
        for short, package in (("agent", "p2pstream/internal/agent"), ("server", "p2pstream/internal/server")):
            package_path = "./internal/" + short
            run(f"ordinary-{short}", [str(TASKSET), "-c", "0-15", str(GO), "test", "-json", "-count=1", "-timeout=300s", package_path, "-run", "^$"], source, normal_env, 360)
            if not audit_ordinary_json(records / f"ordinary-{short}.stdout.log", package, records / f"ordinary-{short}.audit.json"):
                raise ValueError(f"ordinary {short} audit")
            contract = packages[package]
            pattern = "^(" + "|".join(re.escape(name) for name in contract["roots"]) + ")$"
            for mode, env in (("normal", normal_env), ("race", race_env)):
                command = [str(TASKSET), "-c", "0-15", str(GO), "test", "-json", "-count=1", "-timeout=300s", "-tags=p2pstream_qualification"]
                if mode == "race": command.append("-race")
                command.extend([package_path, "-run", pattern])
                name = f"tagged-{short}-{mode}"
                run(name, command, source, env, 360)
                if not audit_go_json(records / f"{name}.stdout.log", package, contract["all_tests"], records / f"{name}.audit.json"):
                    raise ValueError(f"tagged {short} {mode} audit")
        for short in ("agent", "server"):
            package_path = "./internal/" + short
            binary = binaries / f"current-{short}-wan-byte-credit-audited.test"
            run(f"build-{short}", [str(TASKSET), "-c", "0-15", str(GO), "test", "-tags=p2pstream_qualification", "-c", "-o", str(binary), package_path], source, normal_env, 600)
            run(f"build-{short}-version", [str(GO), "version", "-m", str(binary)], source, normal_env, 30)
            metadata = (records / f"build-{short}-version.stdout.log").read_text()
            if f": go1.26.6\n\tpath\tp2pstream/internal/{short}.test\n" not in metadata or "\n\tbuild\t-tags=p2pstream_qualification\n" not in metadata:
                raise ValueError(f"binary metadata: {short}")
            if binary.stat().st_size <= 0 or binary.stat().st_mode & 0o111 == 0:
                raise ValueError(f"non-executable binary: {short}")
            outputs[short] = {"path": str(binary.relative_to(output)), "sha256": sha(binary), "mode": oct(binary.stat().st_mode & 0o777), "go_version_m_sha256": sha(records / f"build-{short}-version.stdout.log")}
        run("toolchain-version-post", [str(GO), "version"], REPO, {"HOME": "/home/user", "PATH": "/usr/bin:/bin", "LC_ALL": "C", "TZ": "Europe/Zurich"}, 30)
        if (records / "toolchain-version-post.stdout.log").read_text().strip() != GO_VERSION:
            raise ValueError("Go version post")
        write_json(records / "source-post.json", {"schema_version": 1, "base_source_ref": SOURCE_REF, "current_head": CURRENT_HEAD, "files": inventory(source)})
        statuses = {path.name.removesuffix(".direct.status"): int(path.read_text()) for path in records.glob("*.direct.status")}
        expected_statuses = {"toolchain-version-pre", "go-env", "ordinary-agent", "ordinary-server", "tagged-agent-normal", "tagged-agent-race", "tagged-server-normal", "tagged-server-race", "build-agent", "build-agent-version", "build-server", "build-server-version", "toolchain-version-post"}
        if set(statuses) != expected_statuses or any(statuses.values()):
            raise ValueError("command status set")
        for name in expected_statuses:
            lifecycle = load_json(records / f"{name}.lifecycle.json")
            if lifecycle.get("direct_status") != 0 or lifecycle.get("direct_child_joined") is not True or lifecycle.get("group_joined") is not True or lifecycle.get("forced_cleanup") is not False or lifecycle.get("timed_out") is not False:
                raise ValueError(f"command lifecycle: {name}")
        write_json(records / "command-results.json", {"schema_version": 1, "accepted": True, "statuses": statuses, "all_groups_joined_without_force": True})
        write_json(records / "input-receipts.json", {"schema_version": 1, "prior_build_receipt_sha256": BASE_RECEIPT_SHA, "protocol_checkpoint_sha256": PROTOCOL_CP_SHA, "protocol_focused_ledger_sha256": PROTOCOL_FOCUSED_SHA, "adapter_checkpoint_sha256": ADAPTER_CP_SHA, "adapter_contract_ledger_sha256": ADAPTER_CONTRACT_SHA, "ordinary_proof_receipt_sha256": approved["ordinary_proof_receipt_sha256"], "ordinary_proof_checkpoint_sha256": approved["ordinary_proof_checkpoint_sha256"], "current_source_binding_sha256": approved["current_source_binding_sha256"], "proof_receipt": proof, "current_source_binding": current_binding})
        accepted = True
    except BaseException as error:
        issue = f"{type(error).__name__}: {error}"
        traceback.print_exc()
    finally:
        checks, post_errors = {}, {}
        def check(name, function):
            try: checks[name] = bool(function())
            except BaseException as error: checks[name] = False; post_errors[name] = f"{type(error).__name__}: {error}"
        check("checkpoint_unchanged", lambda: verify_component(checkpoint, approved["build_checkpoint_manifest_sha256"]) is not None)
        check("static_inputs_unchanged", lambda: static_pre is not None and all(sha(components[name]) == digest for name, digest in static_pre.items()))
        check("component_evidence_unchanged", lambda: verify_prior_build() is not None and verify_component(PROTOCOL_CP, PROTOCOL_CP_SHA) is not None and verify_adapter_checkpoint() is not None and verify_protocol_focused() is None and verify_adapter_contract() is None and verify_proof(proof_receipt_path, approved) is not None and verify_current_binding(approved, load_json(checkpoint / "CURRENT-SOURCE-BINDING-SCHEMA.json")) is not None)
        check("tools_and_helper_unchanged", lambda: sha(GO) == GO_SHA and sha(PYTHON) == PYTHON_SHA and sha(TASKSET) == TASKSET_SHA and sha(HELPER) == HELPER_SHA)
        check("base_source_unchanged", lambda: sha(BASE_INVENTORY) == BASE_INVENTORY_SHA and inventory(BASE_SOURCE) == load_json(BASE_INVENTORY).get("files"))
        check("materialized_source_unchanged", lambda: source_pre is not None and inventory(source) == source_pre)
        check("module_unchanged", lambda: source_pre is not None and sha(source / "go.mod") == GO_MOD_SHA and sha(source / "go.sum") == GO_SUM_SHA)
        check("binaries_unchanged_and_executable", lambda: accepted and set(outputs) == {"agent", "server"} and all(sha(output / value["path"]) == value["sha256"] and oct((output / value["path"]).stat().st_mode & 0o777) == value["mode"] and (output / value["path"]).stat().st_mode & 0o111 != 0 for value in outputs.values()))
        expected_lifecycles = {"toolchain-version-pre", "go-env", "ordinary-agent", "ordinary-server", "tagged-agent-normal", "tagged-agent-race", "tagged-server-normal", "tagged-server-race", "build-agent", "build-agent-version", "build-server", "build-server-version", "toolchain-version-post"}
        check("all_groups_joined_without_force", lambda: helper is not None and {path.name.removesuffix(".lifecycle.json") for path in records.glob("*.lifecycle.json")} == expected_lifecycles and all(load_json(path).get("direct_status") == 0 and load_json(path).get("direct_child_joined") is True and load_json(path).get("group_joined") is True and load_json(path).get("forced_cleanup") is False and load_json(path).get("timed_out") is False for path in records.glob("*.lifecycle.json")))
        accepted = accepted and all(checks.values())
        write_json(records / "FINAL.json", {"schema_version": 1, "accepted": accepted, "issue": issue, "post_checks": checks, "post_errors": post_errors, "endpoint_execution": False, "wan_traffic": False})
        write_text(records / "FINAL.status", "0\n" if accepted else "1\n")
        write_text(records / "end-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))
        lines = []
        for path in sorted(records.rglob("*")):
            if path.is_file() and path.name != "SHA256SUMS.txt":
                lines.append(f"{sha(path)}  {path.relative_to(records).as_posix()}\n")
        write_text(records / "SHA256SUMS.txt", "".join(lines))
        if accepted:
            source_ref = f"{SOURCE_REF}+byte-credit-corpus-{sha(records / 'source-post.json')}"
        write_text(output / "FINAL", "complete\n")
        if accepted:
            receipt = {"schema_version": 1, "diagnostic": "wan-below-tls-server-growth", "accepted": True, "diagnostic_only": True, "endpoint_execution": False, "wan_traffic": False, "traffic_run": False, "test_rerun": True, "server_binary_sha256": outputs["server"]["sha256"], "agent_binary_sha256": outputs["agent"]["sha256"], "server_source_ref": source_ref, "agent_source_ref": source_ref, **MATURE_RECEIPT_FIELDS, **MATURE_EVIDENCE_FIELDS, "byte_credit_runtime_checkpoint_sha256": PROTOCOL_CP_SHA, "byte_credit_adapter_checkpoint_sha256": ADAPTER_CP_SHA, "byte_credit_ordinary_proof_receipt_sha256": approved["ordinary_proof_receipt_sha256"], "byte_credit_ordinary_proof_checkpoint_sha256": approved["ordinary_proof_checkpoint_sha256"], "byte_credit_strict_proof_checkpoint_sha256": PROOF_STRICT_CHECKPOINT_SHA, "byte_credit_strict_attempt_records_ledger_sha256": PROOF_STRICT_LEDGER_SHA, "byte_credit_strict_report_sha256": PROOF_STRICT_REPORT_SHA, "byte_credit_protocol_focused_records_ledger_sha256": PROTOCOL_FOCUSED_SHA, "byte_credit_protocol_focused_outer_ledger_sha256": PROTOCOL_OUTER_SHA, "byte_credit_adapter_contract_records_ledger_sha256": ADAPTER_CONTRACT_SHA, "byte_credit_adapter_contract_outer_ledger_sha256": ADAPTER_OUTER_SHA, "current_source_binding_sha256": approved["current_source_binding_sha256"], "base_source_ref": SOURCE_REF, "current_head": CURRENT_HEAD, "base_combined_build_receipt_sha256": BASE_RECEIPT_SHA, "base_source_inventory_sha256": BASE_INVENTORY_SHA, "final_source_inventory_sha256": sha(records / "source-post.json"), "build_tags": ["p2pstream_qualification"], "toolchain_sha256": GO_SHA, "toolchain_version": GO_VERSION, "python_sha256": PYTHON_SHA, "taskset_sha256": TASKSET_SHA, "build_checkpoint_manifest_sha256": approved["build_checkpoint_manifest_sha256"], "build_driver_sha256": approved["build_driver_sha256"], "approved_inputs_sha256": sha(records / "approved-inputs.json"), "server_binary": outputs["server"], "agent_binary": outputs["agent"], "final_sha256": sha(records / "FINAL.json"), "records_ledger_sha256": sha(records / "SHA256SUMS.txt")}
            publish_last(output / "audited-byte-credit-build-receipt.json", receipt)
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
