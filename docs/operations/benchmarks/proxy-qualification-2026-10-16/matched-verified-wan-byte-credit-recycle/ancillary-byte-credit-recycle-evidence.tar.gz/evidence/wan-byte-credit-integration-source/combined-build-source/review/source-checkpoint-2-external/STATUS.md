# External approved inputs

This directory is an external launch binding for source checkpoint 2. It is source-only and unexecuted. The approved inputs bind the immutable checkpoint and driver, the accepted composite byte-credit ordinary-code/referent receipt, and the separately recorded current-source binding. They do not change the rejected strict generated-symbol-name result.
