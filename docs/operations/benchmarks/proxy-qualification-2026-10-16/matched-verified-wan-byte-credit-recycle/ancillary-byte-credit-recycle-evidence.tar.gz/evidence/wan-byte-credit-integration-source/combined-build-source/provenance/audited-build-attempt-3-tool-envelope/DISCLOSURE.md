# Attempt 3 native tool envelope

The single corrected build attempt exited 1 at `tagged-agent-normal`. The returned traceback is preserved exactly. The owned Go process group joined naturally without TERM/KILL, and no endpoint or WAN traffic ran.
