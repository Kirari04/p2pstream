# Audited byte-credit terminal-fix build

Status: source only. This checkpoint has not run Go, built binaries, started endpoints, or generated traffic.

The driver reuses the accepted build checkpoint 10 procedure and its audited `8ac4c8d` base, eleven unchanged Yamux byte-credit files, accepted normal/race Yamux result, Python adapter contract, composite ordinary-code/referent receipt, and current docs-only source binding. It replaces only the four adapter overlay files with reviewed adapter checkpoint 9. The runtime change is the one-shot terminal owner transition; its tagged fixture adds actual five-session, nine-drain HTTP coverage with exact terminal response and replay rejection. The declared agent event set is ten tests: the original seven events plus the three terminal roots. The server event set remains five.

The rejected tiny smoke 1 remains immutable and bound by its complete run ledger, review ledger, launcher ledger, and native tool envelope. The accepted predecessor byte-credit build and its outer envelope are also immutable inputs.

A fresh run performs ordinary compile-only checks, exact agent and server tagged normal/race controls, and fresh tagged agent/server test-binary builds. It does not rerun unchanged Yamux, Python, ordinary-proof, raw-write, or server-growth suites. It requires all thirteen owned commands to exit naturally, verifies source and evidence before and after, writes the records ledger and FINAL, then publishes the receipt last.
