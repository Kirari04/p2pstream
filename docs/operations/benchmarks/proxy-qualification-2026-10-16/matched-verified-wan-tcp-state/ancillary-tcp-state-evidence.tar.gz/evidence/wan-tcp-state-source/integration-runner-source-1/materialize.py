#!/usr/bin/env python3
"""Materialize one reviewed byte-credit integration corpus into a fresh root."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import stat
import sys


HERE = Path(__file__).resolve().parent
MANIFEST = HERE / "SOURCE-CORPUS.json"


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def main() -> int:
    if len(sys.argv) != 3:
        raise ValueError("usage: materialize.py FRESH_OUTPUT_ROOT FRESH_EVIDENCE_ROOT")
    output = Path(sys.argv[1]).resolve()
    evidence = Path(sys.argv[2]).resolve()
    if output.exists() or output.is_symlink() or not output.parent.is_dir():
        raise ValueError("output root must be fresh below an existing parent")
    if evidence.exists() or evidence.is_symlink() or not evidence.parent.is_dir():
        raise ValueError("evidence root must be fresh below an existing parent")
    corpus = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if corpus.get("status") != "ready_for_materialization":
        raise ValueError("reviewed source is not approved for materialization")
    files = corpus.get("files")
    if not isinstance(files, dict) or not files:
        raise ValueError("source corpus is empty or malformed")
    output.mkdir(mode=0o700)
    evidence.mkdir(mode=0o700)
    copied: dict[str, dict[str, object]] = {}
    for relative, expected in sorted(files.items()):
        if (not isinstance(relative, str) or relative.startswith("/") or ".." in Path(relative).parts
                or not isinstance(expected, dict)):
            raise ValueError("unsafe source-corpus entry")
        source = HERE / relative
        info = source.lstat()
        if not stat.S_ISREG(info.st_mode) or source.is_symlink():
            raise ValueError(f"source is not a regular file: {relative}")
        expected_sha = expected.get("sha256")
        expected_mode = expected.get("mode")
        if sha(source) != expected_sha or expected_mode not in (0o644, 0o755):
            raise ValueError(f"source hash or package mode differs: {relative}")
        raw = source.read_bytes()
        if b"PENDING_BYTE_CREDIT_" in raw:
            raise ValueError(f"pending external receipt binding remains: {relative}")
        destination = output / relative
        destination.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
        descriptor = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, expected_mode)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(destination, expected_mode)
        copied[relative] = {"sha256": sha(destination), "mode": expected_mode}
    if copied != files:
        raise ValueError("materialized corpus differs")
    write_json(evidence / "RESULT.json", {
        "schema_version": 1,
        "accepted": True,
        "source_corpus_sha256": sha(MANIFEST),
        "file_count": len(copied),
        "files": copied,
    })
    (evidence / "direct.status").write_text("0\n", encoding="utf-8")
    with (evidence / "SHA256SUMS.txt").open("x", encoding="utf-8") as stream:
        for path in sorted(evidence.iterdir()):
            if path.is_file() and path.name != "SHA256SUMS.txt":
                stream.write(f"{sha(path)}  {path.name}\n")
    (evidence / "FINAL").write_text("complete\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
