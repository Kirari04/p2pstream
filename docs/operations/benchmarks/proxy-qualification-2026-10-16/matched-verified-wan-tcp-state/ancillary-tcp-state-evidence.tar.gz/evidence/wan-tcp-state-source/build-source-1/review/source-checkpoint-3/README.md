# TCP-state audited build derivative source checkpoint 3

This source-only checkpoint derives from accepted byte-credit build 5. It binds final TCP-state integration checkpoint 6, its exact 12-file source map, and the unchanged exact focused test plan. Checkpoint 6 is a test-only correction after failed build attempt 1; runtime and schema payload bytes are unchanged.

The driver copies the accepted build-5 source into a fresh owned root, applies only checkpoint-root payload bytes, proves ordinary selected Go inputs remain byte-identical, records the exact tagged delta, runs affected agent and Yamux roots in normal and race modes, and creates fresh tagged agent and server binaries. Accepted raw and byte-credit ordinary proof receipts, the accepted 25-case TCP validator contract, and unchanged server-focused evidence are reused. It preserves the checkpoint-4 incident and failed build attempt 1 as explicit provenance.

Natural group closure is reported independently from command status: every started owned group must join without timeout, TERM, KILL, or forced cleanup. Status success separately requires the complete reviewed stage set and zero statuses. Acceptance requires all static/post checks and status success. No endpoint or WAN traffic belongs to this driver.
