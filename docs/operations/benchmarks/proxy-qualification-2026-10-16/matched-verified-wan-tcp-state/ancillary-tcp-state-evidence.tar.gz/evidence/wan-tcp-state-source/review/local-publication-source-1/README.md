# TCP-state local publication source 1

Source-only derivative of the reviewed byte-credit publisher. It binds accepted 38-file materialization attempt 1, accepted TCP-state build attempt 2, and the unchanged accepted raw and byte-credit proof receipts. It copies only the three receipts into the fresh active root with mode 0600; binary bytes remain at their audited build paths. No endpoint or traffic command is run.
