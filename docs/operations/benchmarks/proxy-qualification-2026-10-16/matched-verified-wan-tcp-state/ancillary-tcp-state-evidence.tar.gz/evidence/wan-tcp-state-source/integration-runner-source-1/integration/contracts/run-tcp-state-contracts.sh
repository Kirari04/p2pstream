#!/bin/bash
set -euo pipefail
umask 077

integration_dir=${1:?reviewed integration directory required}
output_dir=${2:?fresh owned output directory required}
[[ ! -e $output_dir ]] || { echo "fresh output directory required" >&2; exit 2; }
mkdir -m 700 "$output_dir"

validator=$integration_dir/validate-tcp-state.py
contract=$integration_dir/contracts/test-tcp-state-validator.py
for input in "$validator" "$contract"; do
  [[ -f $input && ! -L $input ]] || { echo "missing regular source: $input" >&2; exit 2; }
done

status=0
if python3 -I -B "$contract" >"$output_dir/result.json" 2>"$output_dir/stderr.txt"; then
  status=0
else
  status=$?
fi
printf '%s\n' "$status" >"$output_dir/direct.status"
python3 -I -B - "$output_dir/result.json" <<'PY'
import json, pathlib, sys
value = json.loads(pathlib.Path(sys.argv[1]).read_text())
assert type(value) is dict and value.get("schema_version") == 1
assert value.get("accepted") is True and value.get("case_count") == 25
assert len(value.get("cases", [])) == 25
assert all(type(row) is dict and row.get("accepted") is True for row in value["cases"])
PY
exit "$status"
