#!/usr/bin/env python3
from pathlib import Path
import sys

source, query_block, wrapper_block, destination = map(Path, sys.argv[1:])
s = source.read_text()
s = s.replace('''  expected_leaf_sha256=""
  smoke_mode=0''', '''  expected_leaf_sha256=""
  copy_record_validator=""
  copy_record_validator_sha256=""
  sender_wait_validator=""
  sender_wait_validator_sha256=""
  smoke_mode=0''', 1)
s = s.replace('''      --expected-leaf-sha256) expected_leaf_sha256=$2; shift 2 ;;
      --smoke)''', '''      --expected-leaf-sha256) expected_leaf_sha256=$2; shift 2 ;;
      --copy-record-validator) copy_record_validator=$2; shift 2 ;;
      --copy-record-validator-sha256) copy_record_validator_sha256=$2; shift 2 ;;
      --sender-wait-validator) sender_wait_validator=$2; shift 2 ;;
      --sender-wait-validator-sha256) sender_wait_validator_sha256=$2; shift 2 ;;
      --smoke)''', 1)
s = s.replace('''  [[ $expected_leaf_sha256 =~ ^[0-9a-f]{64}$ ]] || { echo "--expected-leaf-sha256 must be lowercase SHA-256 hex" >&2; exit 2; }
  mkdir -p''', '''  [[ $expected_leaf_sha256 =~ ^[0-9a-f]{64}$ ]] || { echo "--expected-leaf-sha256 must be lowercase SHA-256 hex" >&2; exit 2; }
  [[ -n $copy_record_validator && $copy_record_validator_sha256 =~ ^[0-9a-f]{64}$ ]] || {
    echo "--copy-record-validator and its lowercase SHA-256 are required" >&2; exit 2;
  }
  copy_record_validator=$(realpath "$copy_record_validator")
  [[ -f $copy_record_validator && -x $copy_record_validator ]] || {
    echo "copy record validator must be an executable regular file" >&2; exit 2;
  }
  [[ $(sha256sum "$copy_record_validator" | awk '{print $1}') == "$copy_record_validator_sha256" ]] || {
    echo "copy record validator hash mismatch" >&2; exit 2;
  }
  [[ -f $sender_wait_validator && $sender_wait_validator_sha256 =~ ^[0-9a-f]{64}$ ]] || {
    echo "--sender-wait-validator and its lowercase SHA-256 are required" >&2; exit 2;
  }
  [[ $(sha256sum "$sender_wait_validator" | awk '{print $1}') == "$sender_wait_validator_sha256" ]] || {
    echo "sender-wait validator hash mismatch" >&2; exit 2;
  }
  mkdir -p''', 1)
s = s.replace('''  export P2PSTREAM_GROWTH_PROTOCOL P2PSTREAM_GROWTH_CERT P2PSTREAM_GROWTH_KEY P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256
  export P2PSTREAM_GROWTH_SMOKE_MODE''', '''  export P2PSTREAM_GROWTH_PROTOCOL P2PSTREAM_GROWTH_CERT P2PSTREAM_GROWTH_KEY P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256
  export P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256
  export P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256
  export P2PSTREAM_GROWTH_SMOKE_MODE''', 1)
s = s.replace('''  P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256=$expected_leaf_sha256
  P2PSTREAM_GROWTH_SMOKE_MODE''', '''  P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256=$expected_leaf_sha256
  P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR=$copy_record_validator
  P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256=$copy_record_validator_sha256
  P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR=$(realpath "$sender_wait_validator")
  P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256=$sender_wait_validator_sha256
  P2PSTREAM_GROWTH_SMOKE_MODE''', 1)
s = s.replace('''P2PSTREAM_GROWTH_PROTOCOL,P2PSTREAM_GROWTH_CERT,P2PSTREAM_GROWTH_KEY,P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256,P2PSTREAM_GROWTH_SMOKE_MODE''', '''P2PSTREAM_GROWTH_PROTOCOL,P2PSTREAM_GROWTH_CERT,P2PSTREAM_GROWTH_KEY,P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256,P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR,P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256,P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR,P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256,P2PSTREAM_GROWTH_SMOKE_MODE''', 1)
s = s.replace('for tool in ip tc nsenter jq python3 taskset openssl sha256sum',
              'for tool in awk ip tc nsenter jq python3 taskset openssl sha256sum', 1)
s = s.replace('''copy_record_validator=./validate-copy-record.py
[[ -x $copy_record_validator ]] || { echo "copy record validator is required" >&2; exit 1; }''', '''copy_record_validator=${P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR:?copy record validator is required}
copy_record_validator_sha256=${P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256:?copy record validator hash is required}
[[ $copy_record_validator == /* && -f $copy_record_validator && -x $copy_record_validator &&
   $copy_record_validator_sha256 =~ ^[0-9a-f]{64}$ ]] || {
	echo "copy record validator binding is unavailable" >&2; exit 2;
}
[[ $(readlink -f "$copy_record_validator") == "$copy_record_validator" ]] || {
	echo "copy record validator path changed across namespace re-exec" >&2; exit 2;
}
[[ $(sha256sum "$copy_record_validator" | awk '{print $1}') == "$copy_record_validator_sha256" ]] || {
	echo "copy record validator changed across namespace re-exec" >&2; exit 2;
}''', 1)
start = s.index('read_wait_trace_dir=${output%.jsonl}.read-wait-traces')
end = s.index('\n\npython3 - "$server_scope_control_dir/runner-owned-namespaces.json"', start)
variables = '''sender_wait_control_dir=${output%.jsonl}.sender-wait-controls
[[ ! -e $sender_wait_control_dir ]] || { echo "sender-wait artifact directory already exists" >&2; exit 2; }
mkdir -m 0700 "$sender_wait_control_dir"
sender_wait_bearer=$(openssl rand -hex 32)
sender_wait_sequences=9,11,14,15
sender_wait_records=${output%.jsonl}.sender-wait-records.jsonl
[[ ! -e $sender_wait_records ]] || { echo "sender-wait record already exists" >&2; exit 2; }
: > "$sender_wait_records"
sender_wait_validator=${P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR:?sender-wait validator is required}
sender_wait_validator_sha256=${P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256:?sender-wait validator hash is required}
[[ -f $sender_wait_validator && $sender_wait_validator_sha256 =~ ^[0-9a-f]{64}$ ]] || {
	echo "sender-wait validator binding is unavailable" >&2; exit 2;
}
[[ $(sha256sum "$sender_wait_validator" | awk '{print $1}') == "$sender_wait_validator_sha256" ]] || {
	echo "sender-wait validator changed across namespace re-exec" >&2; exit 2;
}
((smoke_mode == 0)) || { echo "sender-wait diagnostic has only the fixed sustained sequence set" >&2; exit 2; }'''
s = s[:start] + variables + s[end:]
start = s.index('wan_read_wait_control() {')
end = s.index('cgroup_snapshot() {', start)
s = s[:start] + query_block.read_text() + s[end:]
start = s.index('wan_read_wait_should_trace() {')
end = s.index('run_tiny_response() {', start)
s = s[:start] + wrapper_block.read_text() + s[end:]
s = s.replace('run_maybe_traced_transfer ', 'run_maybe_sender_wait_transfer ')
old_server = '''\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE=1 \\
\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_DIR="$read_wait_trace_dir" \\
\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_SEQUENCES="$read_wait_trace_sequences" \\
\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_BEARER="$read_wait_trace_bearer" \\
'''
new_server = '''\t\tP2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT=1 \\
\t\tP2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_SEQUENCES="$sender_wait_sequences" \\
\t\tP2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_BEARER="$sender_wait_bearer" \\
'''
if s.count(old_server) != 1:
    raise SystemExit(f'server trace environment block count {s.count(old_server)}')
s = s.replace(old_server, new_server)
old_agent = '''      P2PSTREAM_QUALIFICATION_AGENT_TUNNELS=4 \\
      GOMAXPROCS=4 \\
'''
new_agent = '''      P2PSTREAM_QUALIFICATION_AGENT_TUNNELS=4 \\
      P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT=1 \\
      P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_SEQUENCES="$sender_wait_sequences" \\
      P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_BEARER="$sender_wait_bearer" \\
      GOMAXPROCS=4 \\
'''
if s.count(old_agent) != 2:
    raise SystemExit(f'agent environment block count {s.count(old_agent)}')
s = s.replace(old_agent, new_agent)
old_terminal = '''\tcgroup_snapshot "$server_pid" > "$server_scope_control_dir/server-cgroup-post-workload.json"
  stop_process "$label-$iteration-agent" "$agent_process_pid" "$agent_stop"
'''
new_terminal = '''\tlocal sender_terminal_status=0 sender_terminal_validation_status=0
\tset +e
\twan_sender_wait_query agent-drain terminal 15 "$agent_admin" "$sender_wait_control_dir/terminal-sender.json"
\tsender_terminal_status=$?
\tpython3 "$sender_wait_validator" --mode terminal --terminal "$sender_wait_control_dir/terminal-sender.json" \\
\t\t--sequence 15 --output "$sender_wait_control_dir/terminal-validation.json"
\tsender_terminal_validation_status=$?
\tset -e
\tjq -cn --argjson status "$sender_terminal_status" --argjson validation_status "$sender_terminal_validation_status" \\
\t\t--slurpfile terminal "$sender_wait_control_dir/terminal-sender.json" \\
\t\t--slurpfile validation "$sender_wait_control_dir/terminal-validation.json" \\
\t\t'{schema_version:1,diagnostic:"sender-duration",action:"terminal",status:$status,
\t\t  validation_status:$validation_status,response:($terminal[0] // null),validation:($validation[0] // null),
\t\t  valid:($status == 0 and $validation_status == 0)}' \\
\t\t>> "$sender_wait_records"
\tcgroup_snapshot "$server_pid" > "$server_scope_control_dir/server-cgroup-post-workload.json"
  stop_process "$label-$iteration-agent" "$agent_process_pid" "$agent_stop"
'''
if s.count(old_terminal) != 1:
    raise SystemExit(f'terminal insertion point count {s.count(old_terminal)}')
s = s.replace(old_terminal, new_terminal)
s = s.replace('''  sender_wait_validator_sha256=""
  smoke_mode=0''', '''  sender_wait_validator_sha256=""
  sender_wait_small=0
  smoke_mode=0''', 1)
s = s.replace('''      --sender-wait-validator-sha256) sender_wait_validator_sha256=$2; shift 2 ;;
      --smoke)''', '''      --sender-wait-validator-sha256) sender_wait_validator_sha256=$2; shift 2 ;;
      --sender-wait-small) sender_wait_small=1; shift ;;
      --smoke)''', 1)
s = s.replace('''  ((required_pool_mib > 2 || (smoke_mode == 1 && required_pool_mib == 2))) || {
    echo "--required-pool-mib must be greater than the 2 MiB initial pool (exactly 2 is allowed only with --smoke)" >&2''', '''  ((required_pool_mib > 2 || ((smoke_mode == 1 || sender_wait_small == 1) && required_pool_mib == 2))) || {
    echo "--required-pool-mib must be greater than the 2 MiB initial pool (exactly 2 is allowed only with --smoke or --sender-wait-small)" >&2''', 1)
s = s.replace('''  ((pressure_mode == 0 || tiny_response_mode == 0)) || {''', '''  if ((sender_wait_small)); then
    ((smoke_mode == 0 && pressure_mode == 0 && tiny_response_mode == 0 && runs == 1 &&
      warmup_mib == 4 && steady_mib == 4 && transfer_repetitions == 3 && required_pool_mib == 2)) || {
      echo "--sender-wait-small requires the fixed 16-row 4/4 MiB, three-repetition, 2 MiB-pool schedule" >&2; exit 2;
    }
  fi
  ((pressure_mode == 0 || tiny_response_mode == 0)) || {''', 1)
s = s.replace('''  export P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256
  export P2PSTREAM_GROWTH_SMOKE_MODE''', '''  export P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256 P2PSTREAM_GROWTH_SENDER_WAIT_SMALL
  export P2PSTREAM_GROWTH_SMOKE_MODE''', 1)
s = s.replace('''  P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256=$sender_wait_validator_sha256
  P2PSTREAM_GROWTH_SMOKE_MODE''', '''  P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256=$sender_wait_validator_sha256
  P2PSTREAM_GROWTH_SENDER_WAIT_SMALL=$sender_wait_small
  P2PSTREAM_GROWTH_SMOKE_MODE''', 1)
s = s.replace('''P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR,P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256,P2PSTREAM_GROWTH_SMOKE_MODE''', '''P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR,P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256,P2PSTREAM_GROWTH_SENDER_WAIT_SMALL,P2PSTREAM_GROWTH_SMOKE_MODE''', 1)
s = s.replace('''smoke_mode=$P2PSTREAM_GROWTH_SMOKE_MODE
pressure_mode=''', '''sender_wait_small=${P2PSTREAM_GROWTH_SENDER_WAIT_SMALL:-0}
smoke_mode=$P2PSTREAM_GROWTH_SMOKE_MODE
pressure_mode=''', 1)
s = s.replace('''python3 - "$output" "$summary" "$required_pool_mib" "$smoke_mode" "$pressure_mode" "$tiny_response_mode" "$protocol" "$expected_leaf_sha256" "$copy_record_validator" <<'PY'
import importlib.util, json, statistics, sys

source, destination, required_pool_mib, smoke_mode, pressure_mode, tiny_response_mode, protocol, expected_fingerprint, copy_validator_path = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6]), sys.argv[7], sys.argv[8], sys.argv[9]''', '''python3 - "$output" "$summary" "$required_pool_mib" "$smoke_mode" "$pressure_mode" "$tiny_response_mode" "$protocol" "$expected_leaf_sha256" "$copy_record_validator" "$sender_wait_small" <<'PY'
import importlib.util, json, statistics, sys

source, destination, required_pool_mib, smoke_mode, pressure_mode, tiny_response_mode, protocol, expected_fingerprint, copy_validator_path, sender_wait_small = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6]), sys.argv[7], sys.argv[8], sys.argv[9], int(sys.argv[10])''', 1)
s = s.replace('''row.get("configured_payload_bytes") == ((4 if smoke_mode else 256) << 20) and
        row.get("response_bytes") == (((4 if smoke_mode else 256) << 20) if row.get("transfer_direction") == "download" else 32)''', '''row.get("configured_payload_bytes") == ((4 if (smoke_mode or sender_wait_small) else 256) << 20) and
        row.get("response_bytes") == (((4 if (smoke_mode or sender_wait_small) else 256) << 20) if row.get("transfer_direction") == "download" else 32)''', 1)
s = s.replace('''floor_gate_pass = floor_pass or bool(smoke_mode)''', '''floor_gate_pass = floor_pass or bool(smoke_mode) or bool(sender_wait_small)''', 1)
s = s.replace('''"diagnostic_only": True, "public_protocol": protocol, "classification": classification,''', '''"diagnostic_only": True, "public_protocol": protocol, "classification": classification,
        "size_mode": "small" if sender_wait_small else ("smoke" if smoke_mode else "sustained"),''', 1)
destination.write_text(s)
