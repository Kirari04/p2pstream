# TCP-state audited build derivative source

Status: source-only draft. The frozen TCP overlay and exact focused event sets
are bound, but the build checkpoint/driver hashes remain `PENDING`, so the
source is not launchable. No Go command, test, build, endpoint, or traffic has
been executed from this source.

The driver materializes the exact accepted build 5 source, overlays only the
future reviewed TCP-state Yamux and agent files, proves ordinary selected Go
inputs remain byte-identical, records the exact tagged source delta, runs the
new and affected existing Yamux and agent focused roots in normal and race
modes, and creates fresh tagged agent and server binaries. It reuses the
accepted raw and byte-credit ordinary proof receipts and the unchanged server
focused evidence. Fresh focused results are outputs rather than prerequisites.

Acceptance requires pinned offline tools, exact pre/post source and static
inputs, exact Go JSON events, natural owned process-group joins without forced
cleanup, fresh executable binaries with Go metadata, a closed records ledger,
and an accepted receipt published last. The receipt states that no endpoint or
WAN traffic executed.
