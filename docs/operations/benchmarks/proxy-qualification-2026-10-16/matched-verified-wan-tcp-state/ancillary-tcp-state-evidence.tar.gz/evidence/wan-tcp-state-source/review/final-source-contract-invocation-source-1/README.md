# TCP-state final source contract invocation 1

Bounded derivative of the accepted mature invocation. It binds integration runner source 1, fresh integration-source-1, accepted TCP-state build attempt 2, and the exact 38-file corpus. It executes only offline source and validator binding contracts in an owned process group. It does not start endpoints or traffic.
