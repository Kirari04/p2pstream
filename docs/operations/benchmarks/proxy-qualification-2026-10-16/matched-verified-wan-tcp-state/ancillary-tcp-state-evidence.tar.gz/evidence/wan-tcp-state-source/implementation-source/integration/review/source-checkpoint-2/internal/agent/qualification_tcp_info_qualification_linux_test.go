//go:build linux && p2pstream_qualification

package agent

import (
	"errors"
	"net"
	"syscall"
	"testing"
	"time"
	"unsafe"

	"golang.org/x/sys/unix"
)

type qualificationTCPInfoFakeRawControl struct {
	fd        uintptr
	err       error
	callbacks int
	invoked   bool
}

func (raw *qualificationTCPInfoFakeRawControl) Control(callback func(uintptr)) error {
	if raw.err != nil {
		return raw.err
	}
	for range raw.callbacks {
		raw.invoked = true
		callback(raw.fd)
	}
	return nil
}

type qualificationTCPInfoFakeGetsockopt struct {
	info             unix.TCPInfo
	infoLength       uint32
	infoErrno        syscall.Errno
	congestion       [qualificationTCPInfoCongestionNameLimit]byte
	congestionLength uint32
	congestionErrno  syscall.Errno
	infoCalls        uint64
	congestionCalls  uint64
}

func (fake *qualificationTCPInfoFakeGetsockopt) call(_ uintptr, _, option int, value unsafe.Pointer, length *uint32) syscall.Errno {
	switch option {
	case unix.TCP_INFO:
		fake.infoCalls++
		if fake.infoErrno != 0 {
			return fake.infoErrno
		}
		*(*unix.TCPInfo)(value) = fake.info
		*length = fake.infoLength
		return 0
	case unix.TCP_CONGESTION:
		fake.congestionCalls++
		if fake.congestionErrno != 0 {
			return fake.congestionErrno
		}
		*(*[qualificationTCPInfoCongestionNameLimit]byte)(value) = fake.congestion
		*length = fake.congestionLength
		return 0
	default:
		return syscall.ENOPROTOOPT
	}
}

func qualificationTCPInfoTestClock() func() time.Time {
	base := time.Unix(1_700_000_000, 0)
	invocations := 0
	return func() time.Time {
		result := base.Add(time.Duration(invocations) * time.Microsecond)
		invocations++
		return result
	}
}

func qualificationTCPInfoValidFake() *qualificationTCPInfoFakeGetsockopt {
	fake := &qualificationTCPInfoFakeGetsockopt{
		infoLength:       qualificationTCPInfoStructSize,
		congestionLength: 6,
	}
	copy(fake.congestion[:], []byte("cubic\x00"))
	return fake
}

func qualificationTCPInfoTestRaw(fd uintptr) *qualificationTCPInfoFakeRawControl {
	return &qualificationTCPInfoFakeRawControl{fd: fd, callbacks: 1}
}

func qualificationTCPInfoRequireFailure(t *testing.T, snapshot qualificationTCPInfoSnapshot, captureErr error, stage string, errno syscall.Errno) {
	t.Helper()
	if captureErr == nil || snapshot.Captured || snapshot.FailureStage != stage || snapshot.FailureErrno != int64(errno) {
		t.Fatalf("failure snapshot=%+v err=%v, want stage=%q errno=%d", snapshot, captureErr, stage, errno)
	}
}

func TestQualificationTCPInfoReturnedLengthAndAvailableZeroValues(t *testing.T) {
	raw := qualificationTCPInfoTestRaw(41)
	fake := qualificationTCPInfoValidFake()
	snapshot, err := qualificationCaptureTCPInfoWith(raw, fake.call, qualificationTCPInfoTestClock())
	if err != nil {
		t.Fatalf("qualificationCaptureTCPInfoWith: %v", err)
	}
	if !raw.invoked || fake.infoCalls != 1 || fake.congestionCalls != 1 {
		t.Fatalf("calls raw=%t info=%d congestion=%d", raw.invoked, fake.infoCalls, fake.congestionCalls)
	}
	if !snapshot.Captured || !snapshot.TCPInfoAttempted || !snapshot.TCPInfoSucceeded ||
		!snapshot.CongestionControlAttempted || !snapshot.CongestionControlSucceeded || !snapshot.Availability.required() {
		t.Fatalf("snapshot not accepted: %+v", snapshot)
	}
	if snapshot.TCPInfoOptlen != qualificationTCPInfoStructSize || snapshot.RequiredFieldEndOffset != qualificationTCPInfoTotalRTOTimeEnd {
		t.Fatalf("lengths optlen=%d required=%d", snapshot.TCPInfoOptlen, snapshot.RequiredFieldEndOffset)
	}
	if snapshot.CongestionControl != "cubic" || snapshot.CongestionControlOptlen != 6 {
		t.Fatalf("congestion = %q/%d", snapshot.CongestionControl, snapshot.CongestionControlOptlen)
	}
	if snapshot.CaptureDurationNS != uint64(time.Microsecond) || snapshot.RTOUsec != 0 || snapshot.SendCongestionWindow != 0 || snapshot.TotalRTO != 0 {
		t.Fatalf("available zero values or duration changed: %+v", snapshot)
	}
}

func TestQualificationTCPInfoCopiesRequiredTypedValues(t *testing.T) {
	raw := qualificationTCPInfoTestRaw(46)
	fake := qualificationTCPInfoValidFake()
	fake.info = unix.TCPInfo{
		State: 1, Ca_state: 2, Retransmits: 3, Rto: 4, Snd_mss: 5,
		Unacked: 6, Lost: 7, Retrans: 8, Last_data_sent: 9,
		Rtt: 10, Rttvar: 11, Snd_ssthresh: 12, Snd_cwnd: 13,
		Total_retrans: 14, Pacing_rate: 15, Bytes_acked: 16,
		Notsent_bytes: 17, Delivery_rate: 18, Bytes_sent: 19,
		Bytes_retrans: 20, Snd_wnd: 21, Total_rto: 22,
		Total_rto_recoveries: 23, Total_rto_time: 24,
	}
	snapshot, err := qualificationCaptureTCPInfoWith(raw, fake.call, qualificationTCPInfoTestClock())
	if err != nil {
		t.Fatalf("qualificationCaptureTCPInfoWith: %v", err)
	}
	if snapshot.State != 1 || snapshot.CAState != 2 || snapshot.Retransmits != 3 || snapshot.RTOUsec != 4 || snapshot.SendMSS != 5 ||
		snapshot.Unacked != 6 || snapshot.Lost != 7 || snapshot.Retrans != 8 || snapshot.LastDataSentMS != 9 ||
		snapshot.RTTUsec != 10 || snapshot.RTTVarianceUsec != 11 || snapshot.SendSlowStartThreshold != 12 || snapshot.SendCongestionWindow != 13 ||
		snapshot.TotalRetrans != 14 || snapshot.PacingRateBytesPerSecond != 15 || snapshot.BytesAcked != 16 || snapshot.NotSentBytes != 17 ||
		snapshot.DeliveryRateBytesPerSecond != 18 || snapshot.BytesSent != 19 || snapshot.BytesRetransmitted != 20 || snapshot.SendWindowBytes != 21 ||
		snapshot.TotalRTO != 22 || snapshot.TotalRTORecoveries != 23 || snapshot.TotalRTOTimeMS != 24 {
		t.Fatalf("typed TCP_INFO mapping changed: %+v", snapshot)
	}
}

func TestQualificationTCPInfoAcceptsExactRequiredFieldEnd(t *testing.T) {
	raw := qualificationTCPInfoTestRaw(48)
	fake := qualificationTCPInfoValidFake()
	fake.infoLength = qualificationTCPInfoTotalRTOTimeEnd
	snapshot, err := qualificationCaptureTCPInfoWith(raw, fake.call, qualificationTCPInfoTestClock())
	if err != nil {
		t.Fatalf("qualificationCaptureTCPInfoWith: %v", err)
	}
	if !snapshot.Captured || !snapshot.Availability.required() || snapshot.TCPInfoOptlen != qualificationTCPInfoTotalRTOTimeEnd ||
		snapshot.TCPInfoOptlen >= snapshot.TCPInfoStructSize || fake.infoCalls != 1 || fake.congestionCalls != 1 {
		t.Fatalf("minimum required optlen was not accepted exactly: snapshot=%+v calls=%d/%d", snapshot, fake.infoCalls, fake.congestionCalls)
	}
}

func TestQualificationTCPInfoRejectsReturnedLengthBounds(t *testing.T) {
	for _, test := range []struct {
		name   string
		length uint32
	}{
		{name: "zero", length: 0},
		{name: "truncated_required_tail", length: qualificationTCPInfoTotalRTOTimeEnd - 1},
		{name: "oversize", length: qualificationTCPInfoStructSize + 1},
	} {
		t.Run(test.name, func(t *testing.T) {
			raw := qualificationTCPInfoTestRaw(42)
			fake := qualificationTCPInfoValidFake()
			fake.infoLength = test.length
			snapshot, err := qualificationCaptureTCPInfoWith(raw, fake.call, qualificationTCPInfoTestClock())
			if err == nil || snapshot.Captured {
				t.Fatalf("length %d accepted: snapshot=%+v err=%v", test.length, snapshot, err)
			}
			if snapshot.TCPInfoOptlen != test.length {
				t.Fatalf("retained optlen = %d, want %d", snapshot.TCPInfoOptlen, test.length)
			}
			if fake.congestionCalls != 0 {
				t.Fatalf("congestion calls = %d, want 0", fake.congestionCalls)
			}
			if !snapshot.TCPInfoAttempted || !snapshot.TCPInfoSucceeded || snapshot.CongestionControlAttempted || snapshot.CongestionControlSucceeded || snapshot.CongestionControlOptlen != 0 {
				t.Fatalf("attempt/success state for rejected optlen = %+v", snapshot)
			}
		})
	}
}

func TestQualificationTCPInfoRejectsControlAndGetsockoptErrorsWithoutRetry(t *testing.T) {
	t.Run("control", func(t *testing.T) {
		raw := &qualificationTCPInfoFakeRawControl{err: errors.New("closed")}
		fake := qualificationTCPInfoValidFake()
		snapshot, err := qualificationCaptureTCPInfoWith(raw, fake.call, qualificationTCPInfoTestClock())
		if err == nil || snapshot.Captured || snapshot.TCPInfoAttempted || snapshot.TCPInfoSucceeded || snapshot.TCPInfoOptlen != 0 ||
			snapshot.CongestionControlAttempted || snapshot.CongestionControlSucceeded || snapshot.CongestionControlOptlen != 0 ||
			fake.infoCalls != 0 || fake.congestionCalls != 0 {
			t.Fatalf("control failure snapshot=%+v err=%v calls=%d/%d", snapshot, err, fake.infoCalls, fake.congestionCalls)
		}
	})
	t.Run("no_callback", func(t *testing.T) {
		raw := &qualificationTCPInfoFakeRawControl{fd: 49}
		fake := qualificationTCPInfoValidFake()
		snapshot, err := qualificationCaptureTCPInfoWith(raw, fake.call, qualificationTCPInfoTestClock())
		if err == nil || snapshot.Captured || snapshot.TCPInfoAttempted || snapshot.TCPInfoSucceeded || snapshot.TCPInfoOptlen != 0 ||
			snapshot.CongestionControlAttempted || snapshot.CongestionControlSucceeded || snapshot.CongestionControlOptlen != 0 ||
			fake.infoCalls != 0 || fake.congestionCalls != 0 {
			t.Fatalf("no-callback snapshot=%+v err=%v calls=%d/%d", snapshot, err, fake.infoCalls, fake.congestionCalls)
		}
	})
	t.Run("duplicate_callback", func(t *testing.T) {
		raw := &qualificationTCPInfoFakeRawControl{fd: 50, callbacks: 2}
		fake := qualificationTCPInfoValidFake()
		snapshot, err := qualificationCaptureTCPInfoWith(raw, fake.call, qualificationTCPInfoTestClock())
		if err == nil || snapshot.Captured || fake.infoCalls != 1 || fake.congestionCalls != 1 || !snapshot.TCPInfoSucceeded || !snapshot.CongestionControlSucceeded {
			t.Fatalf("duplicate callback snapshot=%+v err=%v calls=%d/%d", snapshot, err, fake.infoCalls, fake.congestionCalls)
		}
	})
	t.Run("tcp_info", func(t *testing.T) {
		raw := qualificationTCPInfoTestRaw(43)
		fake := qualificationTCPInfoValidFake()
		fake.infoErrno = syscall.EBADF
		snapshot, err := qualificationCaptureTCPInfoWith(raw, fake.call, qualificationTCPInfoTestClock())
		if err == nil || snapshot.Captured || !snapshot.TCPInfoAttempted || snapshot.TCPInfoSucceeded || snapshot.TCPInfoOptlen != 0 ||
			snapshot.CongestionControlAttempted || snapshot.CongestionControlSucceeded || snapshot.CongestionControlOptlen != 0 ||
			fake.infoCalls != 1 || fake.congestionCalls != 0 {
			t.Fatalf("TCP_INFO failure snapshot=%+v err=%v calls=%d/%d", snapshot, err, fake.infoCalls, fake.congestionCalls)
		}
	})
	t.Run("tcp_congestion", func(t *testing.T) {
		raw := qualificationTCPInfoTestRaw(44)
		fake := qualificationTCPInfoValidFake()
		fake.congestionErrno = syscall.ENOPROTOOPT
		snapshot, err := qualificationCaptureTCPInfoWith(raw, fake.call, qualificationTCPInfoTestClock())
		if err == nil || snapshot.Captured || !snapshot.TCPInfoAttempted || !snapshot.TCPInfoSucceeded || !snapshot.CongestionControlAttempted ||
			snapshot.CongestionControlSucceeded || snapshot.CongestionControlOptlen != 0 || fake.infoCalls != 1 || fake.congestionCalls != 1 {
			t.Fatalf("TCP_CONGESTION failure snapshot=%+v err=%v calls=%d/%d", snapshot, err, fake.infoCalls, fake.congestionCalls)
		}
	})
}

func TestQualificationTCPInfoRejectsCongestionLengthBounds(t *testing.T) {
	for _, test := range []struct {
		name   string
		length uint32
	}{
		{name: "zero", length: 0},
		{name: "oversize", length: qualificationTCPInfoCongestionNameLimit + 1},
	} {
		t.Run(test.name, func(t *testing.T) {
			raw := qualificationTCPInfoTestRaw(47)
			fake := qualificationTCPInfoValidFake()
			fake.congestionLength = test.length
			snapshot, err := qualificationCaptureTCPInfoWith(raw, fake.call, qualificationTCPInfoTestClock())
			if err == nil || snapshot.Captured || fake.infoCalls != 1 || fake.congestionCalls != 1 {
				t.Fatalf("TCP_CONGESTION length %d accepted: snapshot=%+v err=%v calls=%d/%d", test.length, snapshot, err, fake.infoCalls, fake.congestionCalls)
			}
			if snapshot.CongestionControlOptlen != test.length {
				t.Fatalf("retained congestion optlen = %d, want %d", snapshot.CongestionControlOptlen, test.length)
			}
		})
	}
}

func TestQualificationTCPInfoOwnedLoopbackSocket(t *testing.T) {
	listener, err := net.ListenTCP("tcp4", &net.TCPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		t.Fatalf("ListenTCP: %v", err)
	}
	t.Cleanup(func() { _ = listener.Close() })
	if err := listener.SetDeadline(time.Now().Add(5 * time.Second)); err != nil {
		t.Fatalf("listener SetDeadline: %v", err)
	}

	client, err := net.DialTCP("tcp4", nil, listener.Addr().(*net.TCPAddr))
	if err != nil {
		t.Fatalf("DialTCP: %v", err)
	}
	t.Cleanup(func() { _ = client.Close() })
	server, err := listener.AcceptTCP()
	if err != nil {
		t.Fatalf("AcceptTCP: %v", err)
	}
	t.Cleanup(func() { _ = server.Close() })
	if err := listener.Close(); err != nil {
		t.Fatalf("listener Close: %v", err)
	}

	raw, err := client.SyscallConn()
	if err != nil {
		t.Fatalf("SyscallConn: %v", err)
	}
	snapshot, err := qualificationCaptureTCPInfo(raw)
	if err != nil {
		t.Fatalf("qualificationCaptureTCPInfo: %v", err)
	}
	if !snapshot.Captured || !snapshot.Availability.required() || snapshot.State != 1 {
		t.Fatalf("loopback TCP_INFO = %+v", snapshot)
	}
	if snapshot.TCPInfoOptlen < snapshot.RequiredFieldEndOffset || snapshot.TCPInfoOptlen > snapshot.TCPInfoStructSize {
		t.Fatalf("loopback optlen = %d, required=%d size=%d", snapshot.TCPInfoOptlen, snapshot.RequiredFieldEndOffset, snapshot.TCPInfoStructSize)
	}
	if snapshot.CongestionControl == "" || snapshot.CongestionControlOptlen == 0 {
		t.Fatalf("loopback congestion binding = %q/%d", snapshot.CongestionControl, snapshot.CongestionControlOptlen)
	}
}

func TestQualificationTCPInfoFailureStagesAndErrnos(t *testing.T) {
	t.Run("precondition", func(t *testing.T) {
		snapshot, err := qualificationCaptureTCPInfoWith(nil, qualificationTCPInfoValidFake().call, qualificationTCPInfoTestClock())
		qualificationTCPInfoRequireFailure(t, snapshot, err, "provider_precondition", 0)
	})
	t.Run("raw_control", func(t *testing.T) {
		snapshot, err := qualificationCaptureTCPInfoWith(&qualificationTCPInfoFakeRawControl{err: syscall.EBADF}, qualificationTCPInfoValidFake().call, qualificationTCPInfoTestClock())
		qualificationTCPInfoRequireFailure(t, snapshot, err, "raw_control", syscall.EBADF)
	})
	t.Run("callback_missing", func(t *testing.T) {
		snapshot, err := qualificationCaptureTCPInfoWith(&qualificationTCPInfoFakeRawControl{}, qualificationTCPInfoValidFake().call, qualificationTCPInfoTestClock())
		qualificationTCPInfoRequireFailure(t, snapshot, err, "raw_control_callback_missing", 0)
	})
	t.Run("callback_duplicate", func(t *testing.T) {
		snapshot, err := qualificationCaptureTCPInfoWith(&qualificationTCPInfoFakeRawControl{callbacks: 2}, qualificationTCPInfoValidFake().call, qualificationTCPInfoTestClock())
		qualificationTCPInfoRequireFailure(t, snapshot, err, "raw_control_callback_duplicate", 0)
	})
	t.Run("tcp_info", func(t *testing.T) {
		fake := qualificationTCPInfoValidFake()
		fake.infoErrno = syscall.EBADF
		snapshot, err := qualificationCaptureTCPInfoWith(qualificationTCPInfoTestRaw(1), fake.call, qualificationTCPInfoTestClock())
		qualificationTCPInfoRequireFailure(t, snapshot, err, "tcp_info", syscall.EBADF)
	})
	t.Run("tcp_info_length", func(t *testing.T) {
		fake := qualificationTCPInfoValidFake()
		fake.infoLength = qualificationTCPInfoTotalRTOTimeEnd - 1
		snapshot, err := qualificationCaptureTCPInfoWith(qualificationTCPInfoTestRaw(1), fake.call, qualificationTCPInfoTestClock())
		qualificationTCPInfoRequireFailure(t, snapshot, err, "tcp_info_length", 0)
	})
	t.Run("tcp_congestion", func(t *testing.T) {
		fake := qualificationTCPInfoValidFake()
		fake.congestionErrno = syscall.ENOPROTOOPT
		snapshot, err := qualificationCaptureTCPInfoWith(qualificationTCPInfoTestRaw(1), fake.call, qualificationTCPInfoTestClock())
		qualificationTCPInfoRequireFailure(t, snapshot, err, "tcp_congestion", syscall.ENOPROTOOPT)
	})
	t.Run("tcp_congestion_length", func(t *testing.T) {
		fake := qualificationTCPInfoValidFake()
		fake.congestionLength = 0
		snapshot, err := qualificationCaptureTCPInfoWith(qualificationTCPInfoTestRaw(1), fake.call, qualificationTCPInfoTestClock())
		qualificationTCPInfoRequireFailure(t, snapshot, err, "tcp_congestion_length", 0)
	})
	t.Run("tcp_congestion_value", func(t *testing.T) {
		fake := qualificationTCPInfoValidFake()
		fake.congestion = [qualificationTCPInfoCongestionNameLimit]byte{}
		fake.congestionLength = 1
		snapshot, err := qualificationCaptureTCPInfoWith(qualificationTCPInfoTestRaw(1), fake.call, qualificationTCPInfoTestClock())
		qualificationTCPInfoRequireFailure(t, snapshot, err, "tcp_congestion_value", 0)
	})
	t.Run("capture_clock", func(t *testing.T) {
		calls := 0
		now := func() time.Time {
			calls++
			return time.Unix(1_700_000_000, 0).Add(time.Duration(2-calls) * time.Second)
		}
		snapshot, err := qualificationCaptureTCPInfoWith(qualificationTCPInfoTestRaw(1), qualificationTCPInfoValidFake().call, now)
		qualificationTCPInfoRequireFailure(t, snapshot, err, "capture_clock", 0)
	})
}
