# Selected byte-wait TCP state discriminator

Status: source-only. No compile, endpoint, traffic, policy, sysctl, socket
option, timeout, or window change is authorized.

## Question and limit

For selected streams 9/11/14/15, sample the exact owned TCP socket at byte-wait
entry and retry and around the first raw write in the resulting DATA envelope.
This can show whether sampled H2 state supports or contradicts an idle-cwnd or
other TCP recovery/congestion episode. It cannot prove an unsampled transient
never occurred, make TCP and credit state atomic, identify DATA ciphertext, or
justify a runtime fix.

Evidence: corrected report
`tmp/continuation-20261016/wan-byte-credit-integration-source/provenance/sustained-byte-credit-1-tcp-state-investigation-2/REPORT.md`
SHA `289118b9ebd18b495fbb8b4daf5a62d392e7bbd853cdec9b280f0064ee738d0e`,
ledger `c3d57ded1dcb6391943ab38c5fcc228e17b3793afed4dc2b24501e61401af6cf`.
It binds build-5 x/sys v0.47.0;
the preserved predecessor cited the wrong locally installed module version.

## Source and exact API

Use audited build-5 source/receipt
`93c91824df93bdfd78efc50dbc22b3c028b2e87ac4c88b77600c30207df0daff`,
inventory `dab62af9a09f23fee6bedf57ed014cc63655fcd5f0f91a32e0f8bee23c297b72`, and
only existing qualification-selected files plus one Linux qualification helper.
Add no route, poller, transport wrapper, Stream/Session/sendReady field, or
ordinary source change.

Extend the optional provider already exposed by
`qualificationObservedTunnelBody`:

- `ArmQualificationTCPInterval(sequence)` / matching disarm, invoked only by
  the existing authenticated pre/post control after it proves all exact five
  owners are already present;
- `BeginQualificationTCPWaitSample(kind, streamID, waitToken, classification,
  ordinal, cumulative, credit, observed) -> sampleID` synchronously captures
  TCP_INFO and stores the pre-cursor;
- `FinishQualificationTCPWaitSample(sampleID, ordinal, cumulative)` stores the
  post-cursor and rejects a mismatch/unknown/duplicate completion;
- `MarkQualificationTCPInterveningAllocation(streamID, waitToken)` marks a
  confounding allocation wait without discarding the later raw pair;
- the existing `BeginQualificationRawWriteEnvelope(streamID, ...)` claims an
  eligible pending wait for that owner+stream internally; its public signature
  need not change;
- the existing raw drain/terminal schema carries the additive fixed records.

The agent owner resolves and retains the exact `syscall.RawConn` at bind. A
Linux helper invokes direct `SYS_GETSOCKOPT(TCP_INFO)` in `RawConn.Control`,
retains returned `socklen_t`, and derives per-field availability from that
length. Do not use `unix.GetsockoptTCPInfo`, which discards optlen. The current
diagnostic requires returned length through the entire x/sys v0.47.0 TCPInfo
tail, including `total_rto`, `total_rto_recoveries`, and `total_rto_time`; a
shorter result is preserved as unsupported and makes the interval invalid.
All declared fields still carry availability bits, and an available zero is a
valid value. Required fields cover RTO, cwnd, ssthresh, CA state,
unacked/lost/retrans, notsent,
snd_wnd, last-data-sent age, RTT/variance, byte/retransmit counters,
pacing/delivery rates, and the required tail. Capture exact TCP_CONGESTION
while the socket is live at bind and recheck it at authenticated pre/post while
the same owner remains live. Retain the last live binding through terminal;
never reopen or query a closed FD. Read namespace `tcp_slow_start_after_idle`
once at endpoint setup and again at terminal outside all observer locks; no
setter exists.

## State and mature lifecycle

Reuse each existing raw owner's bounded interval records and the existing exact
five-owner registry. Add fixed arrays for at most 4,096 wait records, each
containing its entry and retry TCP samples, and 4,096 first-raw pairs. Overflow,
unknown/duplicate token, sample error, missing finish, or ambiguity is sticky.
There is no new generation registry or dynamic attacker-sized map.

The authenticated pre control proves all five exact owners exist and are
inactive, then calls the additive arm on each. Post disarms and drains only the
same five owners after all synchronous samples finish. The mature terminal
recorder permits exactly one connected owner per lane and rejects replacement,
second connect, or first bind after pre. Preserve that rule; do not add an
inheritance path or synthesize a baseline. Existing all-five
close/session-join/raw terminal checks remain mandatory.

## Sampling, locks, and correlation

Sampling is synchronous; there is no queue or sampler goroutine. Wait entry
and retry occur while Stream.Write already holds per-stream `sendLock`, after
`stateLock`, aggregate `mu`, and byte-trace `mu` are released. Read the credit
cursor, sample, then read the cursor again. A cursor change is retained and
prevents a point-in-time TCP/credit interpretation. Record monotonic call
start/end and caller-observed time.

Raw before/after samples run below `crypto/tls.Conn.Write`, so existing TLS
`c.out` serialization may be held. Snapshot the immutable RawConn binding,
release raw-owner `mu`, then call `RawConn.Control`. No sample holds stateLock,
recvLock, aggregate `mu`, byte-trace `mu`, raw-owner `mu`, send-ready `mu`, or a
new diagnostic mutex, and no callback returns into TLS/Yamux. Pinned Go 1.26.6
`FD.RawControl` only increfs/decrefs the FD and calls the callback:
`fd_posix.go` SHA
`ff002941e536f405d2876006c2973a1b61d26fd032094ade5ed2fc289fc35084`,
`fd_mutex.go` SHA
`ad10a59470d3848a745f9549afcee67aae9553e385ec41988d7e5266c2bc3902`.

Only a positive `applied_range` retry may create a pending first-raw claim.
Stale/prebuffered/nonadvancing/retry-zero/timeout/shutdown waits are sampled but
cannot claim raw. Deadline, reset, queue failure, terminal-before-DATA, token
reuse, or stream mismatch invalidates the claim. An allocation/session wait
after byte retry sets `intervening_allocation=true`; the later exact raw pair
remains valid, but byte-only attribution is inapplicable.

At existing DATA envelope begin, the owner claims exactly one pending token for
the same stream. Multiple claims for one stream, reversed ownership, or reuse
fail closed. The first raw Write reserves a provisional before/after pair. It
commits only in `finishRawWrite` after existing generation, epoch, envelope,
stream, start-boundary, and enclosure checks prove containment. Outside,
straddling, changed-generation, or mismatched calls remain recorded and reject
the join. Further contained raw writes increment a count only. The pair is
temporal below-TLS occupancy and may include TLS protocol output.

Record call count plus sample-duration count/total/max. Do not subtract observer
cost from throughput. A capture error, unsupported required field, unfinished
sample, drop, or overflow invalidates the interval.

## Validation and decision

Before build, exact `go list` source selection must prove ordinary inputs
unchanged and tagged additions exact; reuse the accepted ordinary proof through
that selected-input/delta binding. Focused controls cover optlen truncation and
available zero values; exact live socket/sysctl identity; cursor change;
sticky capacity/error; pre without five owners and replacement rejection; positive retry
to same-stream raw; excluded wait classes; allocation confounder; two streams;
outside/multiple/missing/straddling raw; finish-only commit; and exact five-owner
terminal closure.

A tiny matched H1/H2 run is required before sustained traffic. Report selected,
conditioning-clean rows and classify sampled support, contradiction, or
unresolved state. Retain getsockopt-to-write races, non-atomic cursor brackets,
and unsampled kernel intervals. No runtime fix follows without separate causal
evidence.
