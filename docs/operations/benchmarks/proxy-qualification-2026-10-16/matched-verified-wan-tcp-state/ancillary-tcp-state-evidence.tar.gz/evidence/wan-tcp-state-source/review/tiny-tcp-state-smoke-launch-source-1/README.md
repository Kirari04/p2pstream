# TCP-state tiny smoke launcher source

Source-only successor derived from the accepted byte-credit tiny launcher source 3. It preserves the reviewed 4 MiB warmup, 4 MiB steady, three repetitions, 2 MiB pool, RTT 80 ms, sequential H1 continuation gate before H2, owned natural lifecycle, tool environment, and source pre/post checks. It binds the accepted TCP runner, build receipt, binaries, materialization, publication, and final offline contracts, and uses a fresh `integration/runs/tiny-tcp-state-smoke-1` output. No idle-timeout control is added.

This working source remains nonlaunchable while explicit publication and final-contract hashes are pending. No endpoint or traffic command has run from it.
