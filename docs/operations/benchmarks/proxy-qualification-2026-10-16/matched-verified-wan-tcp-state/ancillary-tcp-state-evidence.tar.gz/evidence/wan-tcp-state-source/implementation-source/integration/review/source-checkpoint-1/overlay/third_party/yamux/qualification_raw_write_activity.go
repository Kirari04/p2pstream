//go:build p2pstream_qualification

package yamux

import "time"

// QualificationRawWriteClass is one bounded temporal classification of raw
// connection writes. It does not identify TLS record type, ciphertext, syscall,
// kernel residence, or delivery.
type QualificationRawWriteClass struct {
	Calls               uint64                      `json:"calls"`
	AttemptBytes        uint64                      `json:"attempt_bytes"`
	WrittenBytes        uint64                      `json:"written_bytes"`
	Duration            QualificationDurationBucket `json:"duration"`
	SuccessDuration     QualificationDurationBucket `json:"success_duration"`
	ErrorDuration       QualificationDurationBucket `json:"error_duration"`
	ShortDuration       QualificationDurationBucket `json:"short_duration"`
	SuccessCalls        uint64                      `json:"success_calls"`
	ErrorCalls          uint64                      `json:"error_calls"`
	ShortCalls          uint64                      `json:"short_calls"`
	SuccessAttemptBytes uint64                      `json:"success_attempt_bytes"`
	SuccessWrittenBytes uint64                      `json:"success_written_bytes"`
	ErrorAttemptBytes   uint64                      `json:"error_attempt_bytes"`
	ErrorWrittenBytes   uint64                      `json:"error_written_bytes"`
	ShortAttemptBytes   uint64                      `json:"short_attempt_bytes"`
	ShortWrittenBytes   uint64                      `json:"short_written_bytes"`
}

// QualificationRawWriteActivity is a destructive interval snapshot owned by
// one physical tunnel connection. Complete snapshots reset interval fields;
// incomplete live state is returned without reset.
type QualificationRawWriteActivity struct {
	SchemaVersion              int                           `json:"schema_version"`
	Enabled                    bool                          `json:"enabled"`
	Complete                   bool                          `json:"complete"`
	ResetPerformed             bool                          `json:"reset_performed"`
	Bound                      bool                          `json:"bound"`
	CloseObserved              bool                          `json:"close_observed"`
	SessionJoined              bool                          `json:"session_joined"`
	Ambiguous                  bool                          `json:"ambiguous"`
	Overflow                   bool                          `json:"overflow"`
	Lane                       int                           `json:"lane"`
	Generation                 uint64                        `json:"generation"`
	LocalAddress               string                        `json:"local_address"`
	RemoteAddress              string                        `json:"remote_address"`
	StreamObserved             bool                          `json:"stream_observed"`
	ObservedStreamID           uint32                        `json:"observed_stream_id"`
	MultipleStreams            bool                          `json:"multiple_streams"`
	ActiveEnvelopes            uint64                        `json:"active_envelopes"`
	ActiveRawWrites            uint64                        `json:"active_raw_writes"`
	MaximumActiveRawWrites     uint64                        `json:"maximum_active_raw_writes"`
	EnvelopeCount              uint64                        `json:"envelope_count"`
	EnvelopePayloadBytes       uint64                        `json:"envelope_payload_bytes"`
	EnvelopeWireBytes          uint64                        `json:"envelope_wire_bytes"`
	EnvelopeZeroRawCalls       uint64                        `json:"envelope_zero_raw_calls"`
	EnvelopeDuration           QualificationDurationBucket   `json:"envelope_duration"`
	ContainedRawDuration       QualificationDurationBucket   `json:"contained_raw_duration"`
	ResidualDuration           QualificationDurationBucket   `json:"residual_duration"`
	BoundaryActiveRawWrites    uint64                        `json:"boundary_active_raw_writes"`
	BoundaryOutsideCompletions uint64                        `json:"boundary_outside_completions"`
	EnvelopeOverlaps           uint64                        `json:"envelope_overlaps"`
	OwnerGenerationChanges     uint64                        `json:"owner_generation_changes"`
	Contained                  QualificationRawWriteClass    `json:"contained"`
	Outside                    QualificationRawWriteClass    `json:"outside"`
	Straddling                 QualificationRawWriteClass    `json:"straddling"`
	TCPState                   QualificationTCPStateActivity `json:"tcp_state"`
}

type qualificationRawWriteEnvelopeObserver interface {
	BeginQualificationRawWriteEnvelope(streamID uint32, payloadBytes, wireBytes uint64, physicalStarted time.Time) uint64
	FinishQualificationRawWriteEnvelope(token uint64) time.Time
	ArmQualificationTCPInterval(sequence string) bool
	DisarmQualificationTCPInterval(sequence string) bool
	BeginQualificationTCPWaitSample(kind string, streamID uint32, waitToken uint64, classification string, ordinal, cumulative uint64, credit uint32, observed time.Time) uint64
	FinishQualificationTCPWaitSample(sampleID, ordinal, cumulative uint64)
	MarkQualificationTCPInterveningAllocation(streamID uint32, waitToken uint64)
	DrainQualificationRawWriteActivity() QualificationRawWriteActivity
	RetireQualificationRawWriteActivity()
}

func (s *Session) ArmQualificationTCPInterval(sequence string) bool {
	observer := s.qualificationRawWriteObserver()
	return observer != nil && observer.ArmQualificationTCPInterval(sequence)
}

func (s *Session) DisarmQualificationTCPInterval(sequence string) bool {
	observer := s.qualificationRawWriteObserver()
	return observer != nil && observer.DisarmQualificationTCPInterval(sequence)
}

// RetireQualificationRawWriteActivity publishes that Session.Close has joined
// the send loop. Observing the underlying connection close alone is not a
// session-retirement boundary.
func (s *Session) RetireQualificationRawWriteActivity() bool {
	if s == nil {
		return false
	}
	select {
	case <-s.recvDoneCh:
	default:
		return false
	}
	select {
	case <-s.sendDoneCh:
	default:
		return false
	}
	if s.aggregate != nil {
		select {
		case <-s.aggregate.publishDone:
		default:
			return false
		}
	}
	observer := s.qualificationRawWriteObserver()
	if observer != nil {
		observer.RetireQualificationRawWriteActivity()
	}
	return true
}

func (s *Session) qualificationRawWriteObserver() qualificationRawWriteEnvelopeObserver {
	if s == nil {
		return nil
	}
	observer, _ := s.conn.(qualificationRawWriteEnvelopeObserver)
	return observer
}

// DrainQualificationRawWriteActivity returns the connection observer interval
// for this session. A zero snapshot means the tagged connection did not install
// the observer.
func (s *Session) DrainQualificationRawWriteActivity() QualificationRawWriteActivity {
	observer := s.qualificationRawWriteObserver()
	if observer == nil {
		return QualificationRawWriteActivity{}
	}
	return observer.DrainQualificationRawWriteActivity()
}
