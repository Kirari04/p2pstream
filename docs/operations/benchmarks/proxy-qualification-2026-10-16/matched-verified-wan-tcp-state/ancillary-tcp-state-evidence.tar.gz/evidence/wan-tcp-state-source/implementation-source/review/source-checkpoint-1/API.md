# Qualification TCP_INFO provider API

Status: source-only. No Go command, compilation, test, endpoint, traffic, socket setter, sysctl setter, queue, goroutine, or polling loop was run or added.

The provider is selected only by `linux && p2pstream_qualification` and adds two files to `internal/agent`:

- `qualification_tcp_info_qualification_linux.go`
- `qualification_tcp_info_qualification_linux_test.go`

Its narrow integration entry point is:

```go
func qualificationCaptureTCPInfo(raw syscall.RawConn) (qualificationTCPInfoSnapshot, error)
```

The focused injection seam is:

```go
type qualificationTCPInfoRawControl interface {
    Control(func(uintptr)) error
}
type qualificationTCPInfoGetsockopt func(
    fd uintptr,
    level, option int,
    value unsafe.Pointer,
    length *uint32,
) syscall.Errno
func qualificationCaptureTCPInfoWith(
    raw qualificationTCPInfoRawControl,
    getsockopt qualificationTCPInfoGetsockopt,
    now func() time.Time,
) (qualificationTCPInfoSnapshot, error)
```

`qualificationTCPInfoSnapshot` is fixed and typed. It retains capture start/end wall observations, monotonic duration, TCP_INFO returned optlen, generated structure size, required-field end offset, per-field availability, TCP_CONGESTION returned optlen/name, and the required numeric TCP state. The unexported `time.Time` start/end values retain their monotonic readings for same-process integration.

The real getter issues exactly one direct `SYS_GETSOCKOPT(TCP_INFO)` and, only after a valid required length, one direct `SYS_GETSOCKOPT(TCP_CONGESTION)` inside the caller's `syscall.RawConn.Control`. It does not retry. The minimum accepted TCP_INFO optlen is the end of `unix.TCPInfo.Total_rto_time`; the maximum is `unsafe.Sizeof(unix.TCPInfo{})`. Later ECN fields and padding are neither required nor read. Every declared numeric field has an availability bit derived from its own end offset. Zero remains a valid available value.

The provider takes no mutex and starts no background work. The integration caller must snapshot the immutable RawConn binding while holding its owner lock, release every observer lock, call this provider synchronously, then reacquire its lock to publish or invalidate the result.

Focused tests cover full-length zero values, all typed field mappings, truncated/zero/oversize TCP_INFO lengths, Control/TCP_INFO/TCP_CONGESTION failures without retry, TCP_CONGESTION length bounds, and one bounded owned loopback TCP socket query with immediate listener closure.
