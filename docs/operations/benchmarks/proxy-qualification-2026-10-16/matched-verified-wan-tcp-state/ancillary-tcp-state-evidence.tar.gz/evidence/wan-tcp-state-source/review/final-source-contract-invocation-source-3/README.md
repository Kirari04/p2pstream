# TCP-state final source contract invocation 3

Binding-only successor for accepted runner2 and fresh integration-source-2. It preserves failed attempts 1 and 2, then runs the same bounded offline contracts in an owned process group. No endpoint or traffic is started.
