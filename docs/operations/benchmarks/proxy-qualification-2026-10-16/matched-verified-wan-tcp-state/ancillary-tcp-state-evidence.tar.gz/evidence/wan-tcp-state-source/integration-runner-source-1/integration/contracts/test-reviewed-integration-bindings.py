#!/usr/bin/env python3
"""Source contract for the non-self-referential reviewed-corpus binding."""

from pathlib import Path
import sys

if len(sys.argv) != 4:
    raise SystemExit("usage: test-reviewed-integration-bindings.py VERIFIER ARM COORDINATOR")

verifier, arm, coordinator = [Path(path).read_text() for path in sys.argv[1:]]
for required in (
    'manifest["checkpoint_manifest_path"] != "review/implementation-source-checkpoint-10/SHA256SUMS.txt"',
    'manifest["files"] != checkpoint_files',
    'active_sha != expected or frozen_sha != expected',
    'os.O_WRONLY | os.O_CREAT | os.O_EXCL',
):
    if required not in verifier:
        raise SystemExit(f"reviewed-corpus verifier gate missing: {required}")

for name, source in (("arm", arm), ("coordinator", coordinator)):
    for required in (
        'reviewed-integration-source-manifest-cp10.json',
        'implementation-source-checkpoint-10/SHA256SUMS.txt',
        'sender-validator-manifest-correction-receipt.json',
        '.reviewed_integration_source_manifest_sha256 == $base_reviewed',
        '.cp10_integration_checkpoint_sha256 == $integration_checkpoint',
        '.cp10_reviewed_manifest_sha256 == $reviewed_manifest',
        '.cp10_runner_sha256 == $runner',
        '.cp9_contracts.direct_status == 0',
        '.offline_validator_contract.outer_tool_status == 1',
        '.offline_verification.outer_tool_status == 1',
        '.cp9_harness_receipt_sha256 == "11b3f6cfbd1de9a8ff612ef483b127b87e16d4099debc369d5f5db542fc9d53e"',
        'verify-reviewed-integration-manifest.py',
    ):
        if required not in source:
            raise SystemExit(f"{name} reviewed-corpus binding missing: {required}")
    if 'sender_integration_checkpoint_sha256 == "39eac961' in source:
        raise SystemExit(f"{name} still claims checkpoint3 covers the final corpus")
