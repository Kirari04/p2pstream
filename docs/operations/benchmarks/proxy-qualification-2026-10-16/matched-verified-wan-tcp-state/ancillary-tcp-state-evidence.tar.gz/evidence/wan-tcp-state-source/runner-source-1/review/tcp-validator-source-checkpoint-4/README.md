# TCP-state validator source checkpoint 4

This immutable source-only checkpoint binds the TCP-state schema from producer
checkpoint 5. It contains the fail-closed validator and a bounded 25-case
contract source/driver. Nothing in this checkpoint has been executed.

The validator accepts owner-relative monotonic ordering only, treats Unix time
as local ordering rather than a cross-endpoint duration, permits byte-credit
progress around non-atomic samples, and requires exact token/stream/class joins.
It accepts the exact schema-zero pre/terminal TCP_INFO boundary form. It rejects
missing cursor-after validity, invalid/ambiguous/overflow/drop state, unmatched
or zero-credit applied waits, broken pair brackets, and congestion algorithm
changes in pre/post, entry/retry, raw-before/raw-after, or last-live evidence.
Provider capture duration covers RawControl/provider queries; it is not total
instrumentation overhead and must not be subtracted from transfer throughput.

Checkpoint 2 preserves checkpoint 1 and adds exact positive selected-ledger credit for applied-range retries, a negative selected-ledger zero-credit case, and fail-safe direct-status capture. Execution must use the separately reviewed owned-process invocation source.

Checkpoint 3 changes only the immutable producer checkpoint and source-map binding from superseded producer checkpoint 3 to reviewed producer checkpoint 4; validator and contract bytes are unchanged.

Checkpoint 4 supersedes the rejected checkpoint-3 producer binding. It binds fresh producer checkpoint 5; its validator, 25-case contract, and inner driver bytes are unchanged from reviewed checkpoint 3.
