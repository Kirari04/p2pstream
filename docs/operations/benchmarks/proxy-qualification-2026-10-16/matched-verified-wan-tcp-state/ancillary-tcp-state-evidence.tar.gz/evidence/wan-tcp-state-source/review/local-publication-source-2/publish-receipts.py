#!/usr/bin/python3
"""Publish three reviewed receipts into the immutable TCP-state active corpus."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
from pathlib import Path


EXPECTED = {
    "raw": "b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d",
    "byte": "6562b975ba8f25d1b7a1a83c323c4c289f62f97b5508421e9e0f2e244c940460",
    "build": "bcca6079b5de32635701b4a1d5195cd9b9f9e8976d76e48956cea7d396cb7b97",
    "agent": "150761b51a8f326f2decb8889a393010b8333d04b885f17bea2e3c9dbe45bbcd",
    "server": "a9aa0b5e55f73cf01c4ca00f3b26740f683542e1b93268a4e2acc18a94806042",
    "materialization": "efd18d3d431a80be06d58ee898f33fd0d1377c244063a610fbfd52e9b33deb67",
    "corpus": "1bb87b6fc1e06c1183ce3070868564ceeff4718358fb1206745dbc805e80af2a",
}


def sha(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def require(path: Path, expected: str, mode: int | None = None) -> None:
    info = path.lstat()
    if path.is_symlink() or not stat.S_ISREG(info.st_mode) or sha(path) != expected:
        raise ValueError(f"file binding differs: {path}")
    if mode is not None and stat.S_IMODE(info.st_mode) != mode:
        raise ValueError(f"mode differs: {path}")


def create(path: Path, content: bytes, mode: int) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--worktree-root", required=True, type=Path)
    parser.add_argument("--evidence-dir", required=True, type=Path)
    args = parser.parse_args()
    root = args.worktree_root.resolve(strict=True)
    byte_root = root / "tmp/continuation-20261016/wan-tcp-state-source"
    active = byte_root / "integration-source-2"
    build = byte_root / "build-source-1/runs/audited-build-attempt-2"
    sources = {
        "raw": root / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/final-integration-source/provenance/raw-ordinary-proof-receipt.json",
        "byte": root / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle/runs/ordinary-proof-equivalence-attempt-1/RECEIPT.json",
        "build": build / "audited-tcp-state-build-receipt.json",
        "agent": build / "bin/current-agent-wan-tcp-state-audited.test",
        "server": build / "bin/current-server-wan-tcp-state-audited.test",
        "materialization": byte_root / "provenance/materialization-attempt-2/RESULT.json",
    }
    for name, path in sources.items():
        require(path, EXPECTED[name], 0o775 if name in {"agent", "server"} else None)
    materialized = json.loads(sources["materialization"].read_text())
    if materialized.get("accepted") is not True or materialized.get("file_count") != 38 or materialized.get("source_corpus_sha256") != EXPECTED["corpus"]:
        raise ValueError("materialization result is not the accepted 38-file corpus")
    destinations = {
        "raw": active / "provenance/raw-ordinary-proof-receipt.json",
        "byte": active / "provenance/byte-credit-ordinary-proof-receipt.json",
        "build": active / "provenance/audited-combined-build-receipt.json",
    }
    evidence = args.evidence_dir
    if evidence.exists() or evidence.is_symlink() or not evidence.parent.is_dir():
        raise ValueError("evidence directory must be fresh below an existing parent")
    if (active / "provenance").exists() or (active / "provenance").is_symlink():
        raise ValueError("active provenance destination is not fresh")
    evidence.mkdir(mode=0o700)
    (active / "provenance").mkdir(mode=0o700)
    for name, destination in destinations.items():
        create(destination, sources[name].read_bytes(), 0o600)
        require(destination, EXPECTED[name], 0o600)
    if {path.name for path in (active / "provenance").iterdir()} != {path.name for path in destinations.values()}:
        raise ValueError("published receipt inventory differs")
    result = {
        "accepted": True,
        "schema_version": 1,
        "endpoint_execution": False,
        "wan_traffic": False,
        "source_corpus_sha256": EXPECTED["corpus"],
        "materialization_result_sha256": EXPECTED["materialization"],
        "published_receipts": {
            name: {"path": str(destinations[name]), "sha256": EXPECTED[name], "mode": "0o600"}
            for name in sorted(destinations)
        },
        "audited_binaries": {
            name: {"path": str(sources[name]), "sha256": EXPECTED[name], "mode": "0o775", "copied": False}
            for name in ("agent", "server")
        },
    }
    create(evidence / "publication-result.json", (json.dumps(result, indent=2, sort_keys=True) + "\n").encode(), 0o600)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
