# TCP-state local publication source 3

Binding-only successor for runner3 materialization attempt 3. Same three accepted receipts; fresh integration-source-3; no endpoint or traffic.
