//go:build linux && p2pstream_qualification

package agent

import (
	"net"
	"testing"
	"time"

	"github.com/hashicorp/yamux"
)

func qualificationTCPStateTestOwner(t *testing.T) (*qualificationRawWriteOwner, *net.TCPConn, *net.TCPConn) {
	t.Helper()
	listener, err := net.ListenTCP("tcp4", &net.TCPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		t.Fatalf("ListenTCP: %v", err)
	}
	t.Cleanup(func() { _ = listener.Close() })
	if err := listener.SetDeadline(time.Now().Add(5 * time.Second)); err != nil {
		t.Fatalf("listener SetDeadline: %v", err)
	}
	client, err := net.DialTCP("tcp4", nil, listener.Addr().(*net.TCPAddr))
	if err != nil {
		t.Fatalf("DialTCP: %v", err)
	}
	t.Cleanup(func() { _ = client.Close() })
	server, err := listener.AcceptTCP()
	if err != nil {
		t.Fatalf("AcceptTCP: %v", err)
	}
	t.Cleanup(func() { _ = server.Close() })
	if err := listener.Close(); err != nil {
		t.Fatalf("listener Close: %v", err)
	}
	raw, err := client.SyscallConn()
	if err != nil {
		t.Fatalf("SyscallConn: %v", err)
	}
	baseline, err := qualificationCaptureTCPInfo(raw)
	if err != nil {
		t.Fatalf("capture baseline: %v", err)
	}
	owner := &qualificationRawWriteOwner{
		lane: 0, generation: 1, rawBound: true, bodyBound: true,
		localAddr: client.LocalAddr(), remoteAddr: client.RemoteAddr(),
		localAddress: client.LocalAddr().String(), remoteAddress: client.RemoteAddr().String(),
	}
	if !owner.bindTCPState(raw, baseline, 1) {
		t.Fatal("bind TCP state")
	}
	return owner, client, server
}

func qualificationTCPStateFinishSample(owner *qualificationRawWriteOwner, sampleID, ordinal, cumulative uint64) {
	owner.finishTCPWaitSample(sampleID, ordinal, cumulative, true)
}

func TestQualificationTCPStateWaitAndRawPairLifecycle(t *testing.T) {
	owner, client, _ := qualificationTCPStateTestOwner(t)
	if !owner.armTCPInterval("9") {
		t.Fatal("arm TCP interval")
	}
	entry := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
	if entry == 0 {
		t.Fatal("entry sample was not recorded")
	}
	qualificationTCPStateFinishSample(owner, entry, 0, 0)
	retry := owner.beginTCPWaitSample("retry", 7, 11, "applied_range", 1, 65536, 65536, time.Now())
	if retry == 0 {
		t.Fatal("retry sample was not recorded")
	}
	qualificationTCPStateFinishSample(owner, retry, 1, 65536)

	token := owner.beginEnvelope(7, 1, 13, time.Now())
	if token == 0 {
		t.Fatal("DATA envelope did not start")
	}
	observed := &qualificationObservedRawConn{Conn: client, owner: owner}
	if n, err := observed.Write([]byte{1}); err != nil || n != 1 {
		t.Fatalf("raw write n=%d err=%v", n, err)
	}
	owner.finishEnvelopeNow(token)
	if !owner.disarmTCPInterval("9") {
		t.Fatal("disarm TCP interval")
	}
	activity := owner.drain().TCPState
	if !activity.Complete || !activity.ResetPerformed || activity.Invalid || activity.Ambiguous || activity.Overflow ||
		activity.Sequence != "9" || len(activity.WaitRecords) != 1 || len(activity.RawPairs) != 1 {
		t.Fatalf("TCP activity = %+v", activity)
	}
	wait, pair := activity.WaitRecords[0], activity.RawPairs[0]
	if wait.RecordID == 0 || wait.RawPairRecordID != pair.RecordID || wait.StreamID != pair.StreamID ||
		wait.WaitToken != pair.WaitToken || !pair.Committed || pair.Active || !pair.BracketValid ||
		!wait.Entry.Complete || !wait.Retry.Complete || wait.Retry.Classification != "applied_range" || wait.Retry.Credit == 0 {
		t.Fatalf("wait=%+v pair=%+v", wait, pair)
	}
}

func TestQualificationTCPStateUnarmedConditioningIsIgnored(t *testing.T) {
	owner, _, _ := qualificationTCPStateTestOwner(t)
	if sample := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now()); sample != 0 {
		t.Fatalf("unarmed entry sample=%d, want 0", sample)
	}
	if sample := owner.beginTCPWaitSample("retry", 7, 11, "applied_range", 1, 65536, 65536, time.Now()); sample != 0 {
		t.Fatalf("unarmed retry sample=%d, want 0", sample)
	}
	owner.markTCPInterveningAllocation(7, 11)
	if !owner.armTCPInterval("9") || !owner.disarmTCPInterval("9") {
		t.Fatal("unarmed conditioning poisoned the next healthy interval")
	}
	activity := owner.drain().TCPState
	if !activity.Complete || activity.Invalid || len(activity.WaitRecords) != 0 || len(activity.RawPairs) != 0 {
		t.Fatalf("activity after unarmed conditioning = %+v", activity)
	}
}

func TestQualificationTCPStateStickyInvalidation(t *testing.T) {
	t.Run("entry_without_retry", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		entry := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
		qualificationTCPStateFinishSample(owner, entry, 0, 0)
		if owner.disarmTCPInterval("9") {
			t.Fatal("incomplete wait disarmed successfully")
		}
		first := owner.drain().TCPState
		second := owner.drain().TCPState
		if first.Complete || !first.Invalid || second.Complete || !second.Invalid || owner.armTCPInterval("11") {
			t.Fatalf("sticky snapshots first=%+v second=%+v", first, second)
		}
	})
	t.Run("capture_error", func(t *testing.T) {
		owner, client, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		if err := client.Close(); err != nil {
			t.Fatalf("close client: %v", err)
		}
		sample := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
		if sample == 0 {
			t.Fatal("failed capture did not retain its sample")
		}
		qualificationTCPStateFinishSample(owner, sample, 0, 0)
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || activity.CaptureErrors == 0 || activity.WaitRecords[0].Entry.TCPInfo.FailureStage == "" {
			t.Fatalf("capture failure activity = %+v", activity)
		}
	})
	t.Run("duplicate", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		entry := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
		qualificationTCPStateFinishSample(owner, entry, 0, 0)
		if duplicate := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now()); duplicate != 0 {
			t.Fatalf("duplicate sample=%d, want 0", duplicate)
		}
		if activity := owner.drain().TCPState; activity.Complete || !activity.Invalid || !activity.Ambiguous {
			t.Fatalf("duplicate activity = %+v", activity)
		}
	})
	t.Run("overflow", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		owner.mu.Lock()
		owner.tcp.waitCount = yamux.QualificationTCPStateRecordLimit
		owner.mu.Unlock()
		if sample := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now()); sample != 0 {
			t.Fatalf("overflow sample=%d, want 0", sample)
		}
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || !activity.Overflow || activity.DroppedWaitRecords != 1 {
			t.Fatalf("overflow activity = %+v", activity)
		}
	})
	t.Run("applied_zero", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		entry := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
		qualificationTCPStateFinishSample(owner, entry, 0, 0)
		retry := owner.beginTCPWaitSample("retry", 7, 11, "applied_range", 1, 1, 0, time.Now())
		qualificationTCPStateFinishSample(owner, retry, 1, 1)
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || !activity.Ambiguous {
			t.Fatalf("zero-credit applied activity = %+v", activity)
		}
	})
	t.Run("unknown_allocation", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		owner.markTCPInterveningAllocation(7, 99)
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || !activity.Ambiguous {
			t.Fatalf("unknown allocation activity = %+v", activity)
		}
	})
	t.Run("cursor_after_unavailable", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		entry := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
		owner.finishTCPWaitSample(entry, 0, 0, false)
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || !activity.Ambiguous || activity.WaitRecords[0].Entry.CursorAfterValid {
			t.Fatalf("unavailable after-cursor activity = %+v", activity)
		}
	})
	t.Run("congestion_algorithm_changed", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		owner.mu.Lock()
		changed := owner.tcp.bindTCPInfo
		changed.CongestionControl += "-changed"
		owner.recordTCPCaptureLocked(changed, nil)
		owner.mu.Unlock()
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || !activity.Ambiguous {
			t.Fatalf("changed congestion-control activity = %+v", activity)
		}
	})
}
