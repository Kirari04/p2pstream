#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
arm=(root/'integration/run-wan-below-tls-arm.sh').read_text()
pair=(root/'integration/run-wan-below-tls-diagnostic.sh').read_text()
validator_path=root/'integration/validate-wan-below-tls-arm.py'
validator=validator_path.read_text()
tcp=root/'integration/validate-tcp-state.py'
raw=root/'integration/validate-raw-write-activity.py'
runner=root/'integration/generated/qualify-proxy-agent-growth-wan-below-tls.sh'
continuation=root.parents[1]
producer_root=continuation/'wan-tcp-state-source/implementation-source/integration/review/source-checkpoint-6'
producer_map=producer_root/'SOURCE-MAP.json'
producer_agent=producer_root/'internal/agent/proxy_qualification_credit_snapshot_enabled_test.go'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
checks={
 'generated_runner_unchanged':sha(runner)=='a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad',
 'tcp_validator_exact':sha(tcp)=='fda225414ce0df36f2c5a47703b4fec4b1894ae5a3f227640730a8bf941f340d',
 'raw_composes_tcp': 'tcp_state_validator.validate_live' in raw.read_text() and 'tcp_state_validator.validate_boundary' in raw.read_text(),
 'selected_stream_cross_join': 'selected_waits=selected_byte_waits' in validator and 'selected_stream_id=selected_stream' in validator,
 'accepted_build_bound': all('bcca6079b5de32635701b4a1d5195cd9b9f9e8976d76e48956cea7d396cb7b97' in text for text in (arm,pair)),
 'build_schema_bound': all('.diagnostic == "wan-tcp-state-qualification"' in text for text in (arm,pair)),
 'producer_bound': all('809f30484ea276a20586fec84517fdec9ef84ff58b2c96c9da3ab65b5122a3a0' in text and '1211123ced422276abb4156ebd108fb3bec056273b3ddc384448fba283002d33' in text for text in (arm,pair)),
 'validator_receipt_bound': all('7cfe27fc04b1f64facac7c323b611a4b04cf608b87b07c20c41e82ac9e8fba67' in text and 'c0a705bb95d39dbeb05a4291b74b449dd65eb4fae6adb44fef2efe5e227e4c24' in text for text in (arm,pair)),
 'response_bound_unchanged': all(value in runner.read_text() for value in (
     'raw = response.read((4 << 20) + 1)', 'if len(raw) > (4 << 20):',
     'raise ValueError("sender-wait response exceeds 4 MiB bound")')),
 'oversize_omission_metadata_bound': False,
 'validator_syntax': isinstance(ast.parse(validator),ast.Module),
}
checks['oversize_omission_metadata_bound'] = (
    sha(producer_map) == '1211123ced422276abb4156ebd108fb3bec056273b3ddc384448fba283002d33'
    and sha(producer_agent) == '9cdb345559599bc751b39a8d2bfeeb6e3251d41efcbf279d22c14797522f0757'
    and 'json:"omitted_snapshot_bytes,omitempty"' in producer_agent.read_text()
    and 'json:"omitted_snapshot_sha256,omitempty"' in producer_agent.read_text())
result={'schema_version':1,'accepted':all(checks.values()),'checks':checks,'endpoint_execution':False,'wan_traffic':False}
print(json.dumps(result,sort_keys=True))
if not result['accepted']: raise SystemExit(1)
