#!/usr/bin/env python3
"""Fail-closed validation for qualification TCP-state activity.

This draft follows the reviewed WIP producer schema. Final source binding is
deliberately deferred until the producer checkpoint is immutable.
"""
from __future__ import annotations

from typing import Any

UINT8_MAX = (1 << 8) - 1
UINT16_MAX = (1 << 16) - 1
UINT32_MAX = (1 << 32) - 1
UINT64_MAX = (1 << 64) - 1
INT64_MAX = (1 << 63) - 1
RECORD_LIMIT = 4096

AVAILABILITY_FIELDS = {
    "state", "ca_state", "retransmits", "rto", "send_mss", "unacked", "lost",
    "retrans", "last_data_sent", "rtt", "rtt_variance", "send_slow_start_threshold",
    "send_congestion_window", "total_retrans", "pacing_rate", "bytes_acked",
    "not_sent_bytes", "delivery_rate", "bytes_sent", "bytes_retransmitted",
    "send_window", "total_rto", "total_rto_recoveries", "total_rto_time",
}
INFO_FIELDS = {
    "schema_version", "captured", "capture_started_unix_ns", "capture_finished_unix_ns",
    "capture_duration_ns", "capture_monotonic_valid", "capture_started_monotonic_ns",
    "capture_finished_monotonic_ns", "tcp_info_attempted", "tcp_info_succeeded",
    "tcp_info_optlen", "tcp_info_struct_size", "required_field_end_offset",
    "congestion_control_attempted", "congestion_control_succeeded",
    "congestion_control_optlen", "congestion_control", "failure_stage", "failure_errno",
    "availability", "state",
    "ca_state", "retransmits", "rto_us", "send_mss", "unacked", "lost", "retrans",
    "last_data_sent_ms", "rtt_us", "rtt_variance_us", "send_slow_start_threshold",
    "send_congestion_window", "total_retrans", "pacing_rate_bytes_per_second",
    "bytes_acked", "not_sent_bytes", "delivery_rate_bytes_per_second", "bytes_sent",
    "bytes_retransmitted", "send_window_bytes", "total_rto", "total_rto_recoveries",
    "total_rto_time_ms",
}
INFO_BOOL_FIELDS = {
    "captured", "capture_monotonic_valid", "tcp_info_attempted", "tcp_info_succeeded",
    "congestion_control_attempted", "congestion_control_succeeded",
}
INFO_UINT8_FIELDS = {"state", "ca_state", "retransmits"}
INFO_UINT16_FIELDS = {"total_rto", "total_rto_recoveries"}
INFO_UINT32_FIELDS = {
    "tcp_info_optlen", "tcp_info_struct_size", "required_field_end_offset",
    "congestion_control_optlen", "rto_us", "send_mss", "unacked", "lost", "retrans",
    "last_data_sent_ms", "rtt_us", "rtt_variance_us", "send_slow_start_threshold",
    "send_congestion_window", "total_retrans", "not_sent_bytes", "send_window_bytes",
    "total_rto_time_ms",
}
INFO_UINT64_FIELDS = {
    "capture_duration_ns", "capture_started_monotonic_ns", "capture_finished_monotonic_ns",
    "pacing_rate_bytes_per_second", "bytes_acked", "delivery_rate_bytes_per_second",
    "bytes_sent", "bytes_retransmitted",
}
SAMPLE_FIELDS = {
    "present", "complete", "capture_error", "sample_id", "kind", "classification",
    "credit", "observed_unix_ns", "observed_monotonic_valid", "observed_monotonic_ns",
    "cursor_before_ordinal", "cursor_before_cumulative", "cursor_after_valid", "cursor_after_ordinal",
    "cursor_after_cumulative", "cursor_changed", "tcp_info",
}
WAIT_FIELDS = {
    "record_id", "stream_id", "wait_token", "intervening_allocation", "pending_raw",
    "claimed", "raw_pair_record_id", "active", "ambiguous", "entry", "retry",
}
PAIR_FIELDS = {
    "record_id", "wait_record_id", "stream_id", "wait_token", "envelope_token",
    "committed", "active", "ambiguous", "before_capture_error", "after_capture_error",
    "bracket_valid", "raw_write_started_unix_ns", "raw_write_finished_unix_ns",
    "raw_write_monotonic_valid", "raw_write_started_monotonic_ns",
    "raw_write_finished_monotonic_ns", "additional_contained_raw_writes", "before", "after",
}
ACTIVITY_FIELDS = {
    "schema_version", "enabled", "bound", "armed", "sequence", "complete",
    "reset_performed", "invalid", "ambiguous", "overflow", "tcp_slow_start_after_idle",
    "active_samples", "pending_raw_claims", "active_raw_pairs", "dropped_wait_records",
    "dropped_raw_pair_records", "capture_calls", "capture_errors", "capture_duration",
    "bind_tcp_info", "last_live_tcp_info", "pre_tcp_info", "post_tcp_info", "wait_records", "raw_pairs",
}
ACTIVITY_BOOL_FIELDS = {
    "enabled", "bound", "armed", "complete", "reset_performed", "invalid", "ambiguous", "overflow",
}
ACTIVITY_UINT_FIELDS = {
    "active_samples", "pending_raw_claims", "active_raw_pairs", "dropped_wait_records",
    "dropped_raw_pair_records", "capture_calls", "capture_errors",
}
BUCKET_FIELDS = {"count", "total_nanoseconds", "max_nanoseconds"}
WAIT_CLASSIFICATIONS = {"applied_range", "pre_entry_buffered", "stale", "timeout", "shutdown"}


def exact_bool(value: Any) -> bool:
    return type(value) is bool


def exact_uint(value: Any, maximum: int = UINT64_MAX, *, positive: bool = False) -> bool:
    return type(value) is int and (0 < value if positive else 0 <= value) and value <= maximum


def exact_int64(value: Any, *, positive: bool = False) -> bool:
    return type(value) is int and (-INT64_MAX - 1) <= value <= INT64_MAX and (not positive or value > 0)


def duration_bucket(value: Any, path: str, issues: list[str]) -> dict[str, int]:
    if type(value) is not dict:
        issues.append(f"{path} is not an object")
        value = {}
    if set(value) != BUCKET_FIELDS:
        issues.append(f"{path} fields changed")
    result: dict[str, int] = {}
    for key in BUCKET_FIELDS:
        current = value.get(key)
        if not exact_uint(current):
            issues.append(f"{path}.{key} is not a uint64")
            current = 0
        result[key] = current
    if result["max_nanoseconds"] > result["total_nanoseconds"]:
        issues.append(f"{path} maximum exceeds total")
    if result["count"] == 0 and (result["total_nanoseconds"] or result["max_nanoseconds"]):
        issues.append(f"{path} has duration without calls")
    if result["count"] and result["total_nanoseconds"] > result["count"] * result["max_nanoseconds"]:
        issues.append(f"{path} total exceeds count times maximum")
    return result


def absent_tcp_info(value: Any) -> bool:
    if type(value) is not dict or set(value) != INFO_FIELDS:
        return False
    if value.get("schema_version") != 0 or type(value.get("schema_version")) is not int:
        return False
    if any(value.get(key) is not False for key in INFO_BOOL_FIELDS):
        return False
    numeric = ({"capture_started_unix_ns", "capture_finished_unix_ns", "failure_errno"}
               | INFO_UINT8_FIELDS | INFO_UINT16_FIELDS | INFO_UINT32_FIELDS | INFO_UINT64_FIELDS)
    if any(type(value.get(key)) is not int or value.get(key) != 0 for key in numeric):
        return False
    if value.get("congestion_control") != "" or value.get("failure_stage") != "":
        return False
    availability = value.get("availability")
    return (type(availability) is dict and set(availability) == AVAILABILITY_FIELDS
            and all(availability.get(key) is False for key in AVAILABILITY_FIELDS))


def tcp_info(value: Any, path: str, issues: list[str], *, require_healthy: bool,
             allow_absent: bool = False) -> dict[str, Any]:
    if allow_absent and absent_tcp_info(value):
        return value
    if type(value) is not dict:
        issues.append(f"{path} is not an object")
        value = {}
    if set(value) != INFO_FIELDS:
        issues.append(f"{path} fields changed")
    if type(value.get("schema_version")) is not int or value.get("schema_version") != 1:
        issues.append(f"{path}.schema_version is not exact integer one")
    for key in INFO_BOOL_FIELDS:
        if not exact_bool(value.get(key)):
            issues.append(f"{path}.{key} is not an exact boolean")
    for key, maximum in ((key, UINT8_MAX) for key in INFO_UINT8_FIELDS):
        if not exact_uint(value.get(key), maximum):
            issues.append(f"{path}.{key} exceeds uint8")
    for key, maximum in ((key, UINT16_MAX) for key in INFO_UINT16_FIELDS):
        if not exact_uint(value.get(key), maximum):
            issues.append(f"{path}.{key} exceeds uint16")
    for key, maximum in ((key, UINT32_MAX) for key in INFO_UINT32_FIELDS):
        if not exact_uint(value.get(key), maximum):
            issues.append(f"{path}.{key} exceeds uint32")
    for key in INFO_UINT64_FIELDS:
        if not exact_uint(value.get(key)):
            issues.append(f"{path}.{key} is not a uint64")
    for key in ("capture_started_unix_ns", "capture_finished_unix_ns"):
        if not exact_int64(value.get(key)):
            issues.append(f"{path}.{key} is not an int64")
    availability = value.get("availability")
    if type(availability) is not dict or set(availability) != AVAILABILITY_FIELDS:
        issues.append(f"{path}.availability fields changed")
        availability = {}
    for key in AVAILABILITY_FIELDS:
        if not exact_bool(availability.get(key)):
            issues.append(f"{path}.availability.{key} is not an exact boolean")
    congestion = value.get("congestion_control")
    if type(congestion) is not str or congestion != congestion.strip():
        issues.append(f"{path}.congestion_control is noncanonical")
    failure_stage = value.get("failure_stage")
    if type(failure_stage) is not str or failure_stage != failure_stage.strip():
        issues.append(f"{path}.failure_stage is noncanonical")
    if not exact_int64(value.get("failure_errno")):
        issues.append(f"{path}.failure_errno is not an int64")
    started, finished = value.get("capture_started_unix_ns"), value.get("capture_finished_unix_ns")
    if exact_int64(started) and exact_int64(finished) and finished < started:
        issues.append(f"{path} wall capture timestamps regress")
    mono_start = value.get("capture_started_monotonic_ns")
    mono_finish = value.get("capture_finished_monotonic_ns")
    if value.get("capture_monotonic_valid") is True:
        if not (exact_uint(mono_start) and exact_uint(mono_finish)
                and mono_finish >= mono_start):
            issues.append(f"{path} monotonic capture coordinates are invalid")
        elif value.get("capture_duration_ns") != mono_finish - mono_start:
            issues.append(f"{path} duration differs from owner-relative monotonic coordinates")
    elif mono_start or mono_finish:
        issues.append(f"{path} has monotonic coordinates without a valid marker")
    if require_healthy:
        required_true = (
            "captured", "capture_monotonic_valid", "tcp_info_attempted", "tcp_info_succeeded",
            "congestion_control_attempted", "congestion_control_succeeded",
        )
        for key in required_true:
            if value.get(key) is not True:
                issues.append(f"{path}.{key} is not true")
        if not all(availability.get(key) is True for key in AVAILABILITY_FIELDS):
            issues.append(f"{path} does not make every required TCP_INFO field available")
        if not exact_uint(value.get("tcp_info_optlen"), UINT32_MAX, positive=True):
            issues.append(f"{path}.tcp_info_optlen is not positive")
        if not exact_uint(value.get("tcp_info_struct_size"), UINT32_MAX, positive=True):
            issues.append(f"{path}.tcp_info_struct_size is not positive")
        if not exact_uint(value.get("required_field_end_offset"), UINT32_MAX, positive=True):
            issues.append(f"{path}.required_field_end_offset is not positive")
        if (exact_uint(value.get("tcp_info_optlen"), UINT32_MAX)
                and exact_uint(value.get("required_field_end_offset"), UINT32_MAX)
                and value.get("tcp_info_optlen") < value.get("required_field_end_offset")):
            issues.append(f"{path}.tcp_info_optlen is below the required field end")
        if not congestion:
            issues.append(f"{path}.congestion_control is empty")
        if value.get("state") != 1:
            issues.append(f"{path}.state is not TCP_ESTABLISHED")
        if (exact_uint(value.get("tcp_info_optlen"), UINT32_MAX)
                and exact_uint(value.get("tcp_info_struct_size"), UINT32_MAX)
                and value.get("tcp_info_optlen") > value.get("tcp_info_struct_size")):
            issues.append(f"{path}.tcp_info_optlen exceeds the bound structure")
        if failure_stage or value.get("failure_errno") != 0:
            issues.append(f"{path} retains failure metadata in a healthy capture")
        if not (exact_int64(started, positive=True) and exact_int64(finished, positive=True)):
            issues.append(f"{path} healthy wall capture timestamps are not positive")
    return value


def sample(value: Any, path: str, issues: list[str], *, kind: str) -> dict[str, Any]:
    if type(value) is not dict:
        issues.append(f"{path} is not an object")
        value = {}
    if set(value) != SAMPLE_FIELDS:
        issues.append(f"{path} fields changed")
    for key in ("present", "complete", "capture_error", "observed_monotonic_valid",
                "cursor_after_valid", "cursor_changed"):
        if not exact_bool(value.get(key)):
            issues.append(f"{path}.{key} is not an exact boolean")
    for key in ("sample_id", "cursor_before_ordinal", "cursor_before_cumulative",
                "cursor_after_ordinal", "cursor_after_cumulative", "observed_monotonic_ns"):
        if not exact_uint(value.get(key)):
            issues.append(f"{path}.{key} is not a uint64")
    if not exact_uint(value.get("credit"), UINT32_MAX):
        issues.append(f"{path}.credit exceeds uint32")
    if not exact_int64(value.get("observed_unix_ns")):
        issues.append(f"{path}.observed_unix_ns is not an int64")
    if value.get("kind") != kind:
        issues.append(f"{path}.kind is not {kind!r}")
    expected_classifications = {"pending"} if kind == "entry" else WAIT_CLASSIFICATIONS
    if value.get("classification") not in expected_classifications:
        issues.append(f"{path}.classification is outside the fixed domain")
    for key in ("present", "complete", "observed_monotonic_valid", "cursor_after_valid"):
        if value.get(key) is not True:
            issues.append(f"{path}.{key} is not true")
    if value.get("capture_error") is not False:
        issues.append(f"{path}.capture_error is not false")
    if not exact_uint(value.get("sample_id"), positive=True):
        issues.append(f"{path}.sample_id is not positive")
    if not exact_int64(value.get("observed_unix_ns"), positive=True):
        issues.append(f"{path}.observed_unix_ns is not positive")
    if not exact_uint(value.get("observed_monotonic_ns"), positive=True):
        issues.append(f"{path}.observed_monotonic_ns is not positive")
    before = (value.get("cursor_before_ordinal"), value.get("cursor_before_cumulative"))
    after = (value.get("cursor_after_ordinal"), value.get("cursor_after_cumulative"))
    if (all(exact_uint(item) for item in before + after)
            and (after[0] < before[0] or after[1] < before[1])):
        issues.append(f"{path} cursor coordinates regress during the synchronous sample")
    changed = before != after
    if exact_bool(value.get("cursor_changed")) and value.get("cursor_changed") is not changed:
        issues.append(f"{path}.cursor_changed disagrees with the observed cursor bracket")
    info = tcp_info(value.get("tcp_info"), f"{path}.tcp_info", issues, require_healthy=True)
    if (exact_int64(value.get("observed_unix_ns"))
            and exact_int64(info.get("capture_started_unix_ns"))
            and value.get("observed_unix_ns") > info.get("capture_started_unix_ns")):
        issues.append(f"{path} local capture starts before caller observation")
    if value.get("observed_monotonic_valid") is True and info.get("capture_monotonic_valid") is True:
        observed = value.get("observed_monotonic_ns")
        if (exact_uint(observed) and exact_uint(info.get("capture_started_monotonic_ns"))
                and exact_uint(info.get("capture_finished_monotonic_ns"))
                and not (observed <= info.get("capture_started_monotonic_ns")
                         <= info.get("capture_finished_monotonic_ns"))):
            issues.append(f"{path} owner-relative capture is not after caller observation")
    return value


def wait_record(value: Any, path: str, issues: list[str]) -> dict[str, Any]:
    if type(value) is not dict:
        issues.append(f"{path} is not an object")
        value = {}
    if set(value) != WAIT_FIELDS:
        issues.append(f"{path} fields changed")
    for key in ("record_id", "wait_token", "raw_pair_record_id"):
        if not exact_uint(value.get(key)):
            issues.append(f"{path}.{key} is not a uint64")
    if not exact_uint(value.get("stream_id"), UINT32_MAX, positive=True):
        issues.append(f"{path}.stream_id is not a positive uint32")
    for key in ("intervening_allocation", "pending_raw", "claimed", "active", "ambiguous"):
        if not exact_bool(value.get(key)):
            issues.append(f"{path}.{key} is not an exact boolean")
    entry = sample(value.get("entry"), f"{path}.entry", issues, kind="entry")
    retry = sample(value.get("retry"), f"{path}.retry", issues, kind="retry")
    if value.get("active") is not False or value.get("ambiguous") is not False:
        issues.append(f"{path} is active or ambiguous")
    if value.get("pending_raw") is not False:
        issues.append(f"{path} retains a pending raw claim after drain")
    if entry.get("sample_id") == retry.get("sample_id"):
        issues.append(f"{path} reuses one sample ID for entry and retry")
    if (entry.get("observed_monotonic_valid") is True and retry.get("observed_monotonic_valid") is True
            and retry.get("observed_monotonic_ns", 0) < entry.get("observed_monotonic_ns", 0)):
        issues.append(f"{path} retry precedes entry in owner-relative time")
    applied = retry.get("classification") == "applied_range"
    if value.get("claimed") is not False:
        issues.append(f"{path} retains a claimed envelope after committed drain")
    if applied != exact_uint(value.get("raw_pair_record_id"), positive=True):
        issues.append(f"{path} raw-pair identity differs from applied-range classification")
    if applied and not exact_uint(retry.get("credit"), UINT32_MAX, positive=True):
        issues.append(f"{path} applied-range retry does not retain positive byte credit")
    return value


def raw_pair(value: Any, path: str, issues: list[str]) -> dict[str, Any]:
    if type(value) is not dict:
        issues.append(f"{path} is not an object")
        value = {}
    if set(value) != PAIR_FIELDS:
        issues.append(f"{path} fields changed")
    for key in ("record_id", "wait_record_id", "wait_token", "envelope_token",
                "additional_contained_raw_writes", "raw_write_started_monotonic_ns",
                "raw_write_finished_monotonic_ns"):
        if not exact_uint(value.get(key)):
            issues.append(f"{path}.{key} is not a uint64")
    if not exact_uint(value.get("stream_id"), UINT32_MAX, positive=True):
        issues.append(f"{path}.stream_id is not a positive uint32")
    for key in ("committed", "active", "ambiguous", "before_capture_error", "after_capture_error",
                "bracket_valid", "raw_write_monotonic_valid"):
        if not exact_bool(value.get(key)):
            issues.append(f"{path}.{key} is not an exact boolean")
    for key in ("raw_write_started_unix_ns", "raw_write_finished_unix_ns"):
        if not exact_int64(value.get(key), positive=True):
            issues.append(f"{path}.{key} is not a positive int64")
    for key in ("record_id", "wait_record_id", "wait_token", "envelope_token"):
        if not exact_uint(value.get(key), positive=True):
            issues.append(f"{path}.{key} is not positive")
    for key in ("committed", "bracket_valid", "raw_write_monotonic_valid"):
        if value.get(key) is not True:
            issues.append(f"{path}.{key} is not true")
    for key in ("active", "ambiguous", "before_capture_error", "after_capture_error"):
        if value.get(key) is not False:
            issues.append(f"{path}.{key} is not false")
    wall_start, wall_finish = value.get("raw_write_started_unix_ns"), value.get("raw_write_finished_unix_ns")
    if exact_int64(wall_start) and exact_int64(wall_finish) and wall_finish < wall_start:
        issues.append(f"{path} raw-write wall coordinates regress")
    mono_start, mono_finish = value.get("raw_write_started_monotonic_ns"), value.get("raw_write_finished_monotonic_ns")
    if not (exact_uint(mono_start, positive=True) and exact_uint(mono_finish, positive=True)
            and mono_finish >= mono_start):
        issues.append(f"{path} raw-write owner-relative coordinates regress")
    before = tcp_info(value.get("before"), f"{path}.before", issues, require_healthy=True)
    after = tcp_info(value.get("after"), f"{path}.after", issues, require_healthy=True)
    if before.get("congestion_control") != after.get("congestion_control"):
        issues.append(f"{path} congestion-control identity changed within raw write")
    if (before.get("capture_monotonic_valid") is True and after.get("capture_monotonic_valid") is True
            and exact_uint(mono_start) and exact_uint(mono_finish)):
        if not (before.get("capture_finished_monotonic_ns", UINT64_MAX) <= mono_start
                <= mono_finish <= after.get("capture_started_monotonic_ns", 0)):
            issues.append(f"{path} TCP captures do not bracket the raw write in owner-relative time")
    if (exact_int64(before.get("capture_finished_unix_ns")) and exact_int64(wall_start)
            and exact_int64(wall_finish) and exact_int64(after.get("capture_started_unix_ns"))
            and not (before.get("capture_finished_unix_ns") <= wall_start
                     <= wall_finish <= after.get("capture_started_unix_ns"))):
        issues.append(f"{path} TCP captures do not contain the raw write in local wall order")
    return value


def validate_activity(value: Any, path: str = "tcp_state") -> dict[str, Any]:
    issues: list[str] = []
    if type(value) is not dict:
        issues.append(f"{path} is not an object")
        value = {}
    if set(value) != ACTIVITY_FIELDS:
        issues.append(f"{path} fields changed")
    if type(value.get("schema_version")) is not int or value.get("schema_version") != 1:
        issues.append(f"{path}.schema_version is not exact integer one")
    for key in ACTIVITY_BOOL_FIELDS:
        if not exact_bool(value.get(key)):
            issues.append(f"{path}.{key} is not an exact boolean")
    for key in ACTIVITY_UINT_FIELDS:
        if not exact_uint(value.get(key)):
            issues.append(f"{path}.{key} is not a uint64")
    if type(value.get("sequence")) is not str or value.get("sequence") != value.get("sequence", "").strip():
        issues.append(f"{path}.sequence is noncanonical")
    if type(value.get("tcp_slow_start_after_idle")) is not int or value.get("tcp_slow_start_after_idle") not in (0, 1):
        issues.append(f"{path}.tcp_slow_start_after_idle is outside the fixed sysctl domain")
    capture_duration = duration_bucket(value.get("capture_duration"), f"{path}.capture_duration", issues)
    bind = tcp_info(value.get("bind_tcp_info"), f"{path}.bind_tcp_info", issues, require_healthy=False)
    last_live = tcp_info(value.get("last_live_tcp_info"), f"{path}.last_live_tcp_info", issues, require_healthy=False)
    empty_boundary = value.get("sequence") == ""
    pre = tcp_info(value.get("pre_tcp_info"), f"{path}.pre_tcp_info", issues,
                   require_healthy=False, allow_absent=empty_boundary)
    post = tcp_info(value.get("post_tcp_info"), f"{path}.post_tcp_info", issues,
                    require_healthy=False, allow_absent=empty_boundary)
    waits = value.get("wait_records")
    pairs = value.get("raw_pairs")
    if type(waits) is not list or len(waits) > RECORD_LIMIT:
        issues.append(f"{path}.wait_records is missing or exceeds {RECORD_LIMIT}")
        waits = []
    if type(pairs) is not list or len(pairs) > RECORD_LIMIT:
        issues.append(f"{path}.raw_pairs is missing or exceeds {RECORD_LIMIT}")
        pairs = []
    parsed_waits = [wait_record(row, f"{path}.wait_records[{index}]", issues)
                    for index, row in enumerate(waits)]
    parsed_pairs = [raw_pair(row, f"{path}.raw_pairs[{index}]", issues)
                    for index, row in enumerate(pairs)]
    wait_ids = [row.get("record_id") for row in parsed_waits]
    pair_ids = [row.get("record_id") for row in parsed_pairs]
    valid_wait_ids = [record_id for record_id in wait_ids if exact_uint(record_id, positive=True)]
    valid_pair_ids = [record_id for record_id in pair_ids if exact_uint(record_id, positive=True)]
    if len(valid_wait_ids) != len(wait_ids) or any(
            left >= right for left, right in zip(valid_wait_ids, valid_wait_ids[1:])):
        issues.append(f"{path} wait record IDs are not positive and strictly increasing")
    if len(valid_pair_ids) != len(pair_ids) or any(
            left >= right for left, right in zip(valid_pair_ids, valid_pair_ids[1:])):
        issues.append(f"{path} raw-pair record IDs are not positive and strictly increasing")
    if len(valid_wait_ids) + len(valid_pair_ids) != len(parsed_waits) + len(parsed_pairs) or len(
            set(valid_wait_ids + valid_pair_ids)) != len(valid_wait_ids) + len(valid_pair_ids):
        issues.append(f"{path} wait/raw-pair record IDs are not globally unique")
    wait_tokens = [(row.get("stream_id"), row.get("wait_token")) for row in parsed_waits
                   if exact_uint(row.get("stream_id"), UINT32_MAX, positive=True)
                   and exact_uint(row.get("wait_token"), positive=True)]
    if len(wait_tokens) != len(parsed_waits) or len(set(wait_tokens)) != len(wait_tokens):
        issues.append(f"{path} wait stream/token identity is repeated")
    sample_ids = [sample_value.get("sample_id") for row in parsed_waits
                  for sample_value in (row.get("entry", {}), row.get("retry", {}))]
    valid_sample_ids = [sample_id for sample_id in sample_ids if exact_uint(sample_id, positive=True)]
    if len(valid_sample_ids) != len(sample_ids) or len(set(valid_sample_ids)) != len(valid_sample_ids):
        issues.append(f"{path} sample IDs are not positive and globally unique")
    for index, row in enumerate(parsed_waits):
        entry_id = row.get("entry", {}).get("sample_id")
        retry_id = row.get("retry", {}).get("sample_id")
        if not (exact_uint(entry_id, positive=True) and exact_uint(retry_id, positive=True)
                and entry_id < retry_id):
            issues.append(f"{path}.wait_records[{index}] entry sample does not precede retry sample")
    envelope_tokens = [row.get("envelope_token") for row in parsed_pairs
                       if exact_uint(row.get("envelope_token"), positive=True)]
    if len(envelope_tokens) != len(parsed_pairs) or len(set(envelope_tokens)) != len(envelope_tokens):
        issues.append(f"{path} raw-pair envelope token is repeated")
    wait_by_id = {row.get("record_id"): row for row in parsed_waits
                  if exact_uint(row.get("record_id"), positive=True)}
    pair_by_id = {row.get("record_id"): row for row in parsed_pairs
                  if exact_uint(row.get("record_id"), positive=True)}
    for row in parsed_waits:
        pair_id = row.get("raw_pair_record_id")
        if exact_uint(pair_id, positive=True):
            pair = pair_by_id.get(pair_id)
            if pair is None:
                issues.append(f"{path} applied wait lacks its exact raw pair")
            elif (pair.get("wait_record_id"), pair.get("stream_id"), pair.get("wait_token")) != (
                    row.get("record_id"), row.get("stream_id"), row.get("wait_token")):
                issues.append(f"{path} wait/raw-pair identity does not join")
            elif pair.get("record_id", 0) <= row.get("record_id", 0):
                issues.append(f"{path} raw-pair record does not follow its wait record")
    for row in parsed_pairs:
        wait_record_id = row.get("wait_record_id")
        wait = wait_by_id.get(wait_record_id) if exact_uint(wait_record_id, positive=True) else None
        if wait is None or wait.get("raw_pair_record_id") != row.get("record_id"):
            issues.append(f"{path} raw pair lacks a unique reverse wait binding")
    expected_calls = (2 if value.get("sequence") else 0) + 2 * len(parsed_waits) + 2 * len(parsed_pairs)
    if value.get("capture_calls") != expected_calls or capture_duration.get("count") != expected_calls:
        issues.append(f"{path} capture-call count does not conserve pre/post, wait, and raw-pair samples")
    captured_infos: list[dict[str, Any]] = []
    if value.get("sequence"):
        captured_infos.extend((pre, post))
    for row in parsed_waits:
        captured_infos.extend((row.get("entry", {}).get("tcp_info", {}),
                               row.get("retry", {}).get("tcp_info", {})))
    for row in parsed_pairs:
        captured_infos.extend((row.get("before", {}), row.get("after", {})))
    captured_durations = [row.get("capture_duration_ns") for row in captured_infos if type(row) is dict]
    if (len(captured_durations) != expected_calls
            or any(not exact_uint(duration) for duration in captured_durations)
            or capture_duration.get("total_nanoseconds") != sum(
                duration for duration in captured_durations if exact_uint(duration))
            or capture_duration.get("max_nanoseconds") != max(
                (duration for duration in captured_durations if exact_uint(duration)), default=0)):
        issues.append(f"{path} capture duration bucket does not conserve exact sampled durations")
    bind_congestion = bind.get("congestion_control")
    if value.get("sequence") and any(type(row) is not dict or row.get("congestion_control") != bind_congestion
                                     for row in captured_infos):
        issues.append(f"{path} sampled congestion-control identity differs from bind capture")
    if last_live.get("congestion_control") != bind_congestion:
        issues.append(f"{path} last-live congestion-control identity differs from bind capture")
    if value.get("capture_errors") != 0:
        issues.append(f"{path}.capture_errors is nonzero")
    if value.get("complete") != value.get("reset_performed"):
        issues.append(f"{path} complete/reset flags differ")
    if value.get("complete") is True and any(value.get(key) for key in
            ("active_samples", "pending_raw_claims", "active_raw_pairs")):
        issues.append(f"{path} completed snapshot retains active state")
    if value.get("invalid") is True or value.get("ambiguous") is True or value.get("overflow") is True:
        issues.append(f"{path} is invalid, ambiguous, or overflowed")
    if value.get("dropped_wait_records") or value.get("dropped_raw_pair_records"):
        issues.append(f"{path} dropped bounded records")
    if (value.get("sequence") and len({bind.get("congestion_control"), last_live.get("congestion_control"),
            pre.get("congestion_control"), post.get("congestion_control")}) != 1):
        issues.append(f"{path} congestion-control identity changed across bind/pre/post")
    return {
        "schema_version": 1, "accepted": not issues, "issues": issues,
        "wait_records": parsed_waits, "raw_pairs": parsed_pairs,
        "capture_calls": value.get("capture_calls"), "tcp_slow_start_after_idle": value.get("tcp_slow_start_after_idle"),
    }


def validate_live(value: Any, *, sequence: int | None = None, selected_stream_id: int | None = None,
                  selected_waits: Any = None, path: str = "tcp_state") -> dict[str, Any]:
    result = validate_activity(value, path)
    issues = result["issues"]
    normalized = value if type(value) is dict else {}
    for key in ("bind_tcp_info", "last_live_tcp_info", "pre_tcp_info", "post_tcp_info"):
        tcp_info(normalized.get(key), f"{path}.{key}", issues, require_healthy=True)
    if normalized.get("last_live_tcp_info") != normalized.get("post_tcp_info"):
        issues.append(f"{path}.last_live_tcp_info is not the final post capture")
    for key in ("enabled", "bound", "complete", "reset_performed"):
        if normalized.get(key) is not True:
            issues.append(f"{path}.{key} is not true")
    if normalized.get("armed") is not False:
        issues.append(f"{path}.armed is not false after drain")
    if sequence is not None and normalized.get("sequence") != str(sequence):
        issues.append(f"{path}.sequence differs from selected interval")
    for key in ("active_samples", "pending_raw_claims", "active_raw_pairs", "capture_errors",
                "dropped_wait_records", "dropped_raw_pair_records"):
        if normalized.get(key) != 0:
            issues.append(f"{path}.{key} is nonzero")
    if selected_stream_id is not None:
        if not exact_uint(selected_stream_id, UINT32_MAX, positive=True):
            issues.append(f"{path} selected stream ID is invalid")
        for index, row in enumerate(result["wait_records"]):
            if row.get("stream_id") != selected_stream_id:
                issues.append(f"{path}.wait_records[{index}] differs from selected stream")
        for index, row in enumerate(result["raw_pairs"]):
            if row.get("stream_id") != selected_stream_id:
                issues.append(f"{path}.raw_pairs[{index}] differs from selected stream")
    if selected_waits is not None:
        if type(selected_waits) is not list:
            issues.append(f"{path} selected byte-credit waits are not a list")
            selected_waits = []
        expected = {(row.get("token"), row.get("stream_id"), row.get("classification"))
                    for row in selected_waits if type(row) is dict
                    and exact_uint(row.get("token"), positive=True)
                    and exact_uint(row.get("stream_id"), UINT32_MAX, positive=True)
                    and type(row.get("classification")) is str}
        actual = {(row.get("wait_token"), row.get("stream_id"), row.get("retry", {}).get("classification"))
                  for row in result["wait_records"]}
        if actual != expected or len(actual) != len(result["wait_records"]) or len(expected) != len(selected_waits):
            issues.append(f"{path} wait token/stream/classification set differs from byte-credit ledger")
        selected_by_identity = {(row.get("token"), row.get("stream_id")): row
                                for row in selected_waits if type(row) is dict
                                and exact_uint(row.get("token"), positive=True)
                                and exact_uint(row.get("stream_id"), UINT32_MAX, positive=True)}
        for index, row in enumerate(result["wait_records"]):
            byte_wait = selected_by_identity.get((row.get("wait_token"), row.get("stream_id")))
            if type(byte_wait) is not dict:
                continue
            entry = row.get("entry", {})
            retry = row.get("retry", {})
            for sample_value, prefix in ((entry, "entry"), (retry, "retry")):
                byte_ordinal = byte_wait.get(f"{prefix}_ordinal")
                byte_cumulative = byte_wait.get(f"{prefix}_cumulative")
                byte_credit = byte_wait.get(f"{prefix}_byte_credit")
                sample_ordinal = sample_value.get("cursor_before_ordinal")
                sample_cumulative = sample_value.get("cursor_before_cumulative")
                sample_credit = sample_value.get("credit")
                if (not exact_uint(byte_ordinal) or not exact_uint(byte_cumulative)
                        or not exact_uint(byte_credit, UINT32_MAX)
                        or not exact_uint(sample_ordinal) or not exact_uint(sample_cumulative)
                        or not exact_uint(sample_credit, UINT32_MAX)
                        or sample_ordinal < byte_ordinal or sample_cumulative < byte_cumulative
                        or sample_credit < byte_credit):
                    issues.append(f"{path}.wait_records[{index}].{prefix} precedes its byte-credit lower bound")
                byte_observed = byte_wait.get(f"{prefix}_observed_unix_ns")
                tcp_observed = sample_value.get("observed_unix_ns")
                if (not exact_int64(byte_observed, positive=True) or not exact_int64(tcp_observed, positive=True)
                        or tcp_observed < byte_observed):
                    issues.append(f"{path}.wait_records[{index}].{prefix} precedes its local byte-credit observation")
    result["accepted"] = not issues
    return result


def validate_no_data(value: Any, *, sequence: str, path: str = "tcp_state") -> dict[str, Any]:
    result = validate_activity(value, path)
    issues = result["issues"]
    normalized = value if type(value) is dict else {}
    if normalized.get("sequence") != sequence:
        issues.append(f"{path}.sequence differs from boundary")
    if result["wait_records"] or result["raw_pairs"]:
        issues.append(f"{path} contains selected records at a no-DATA boundary")
    for key in ("active_samples", "pending_raw_claims", "active_raw_pairs", "capture_errors",
                "dropped_wait_records", "dropped_raw_pair_records"):
        if normalized.get(key) != 0:
            issues.append(f"{path}.{key} is nonzero")
    result["accepted"] = not issues
    return result


def validate_boundary(value: Any, *, path: str = "tcp_state") -> dict[str, Any]:
    result = validate_no_data(value, sequence="", path=path)
    issues = result["issues"]
    normalized = value if type(value) is dict else {}
    for key in ("bind_tcp_info", "last_live_tcp_info"):
        tcp_info(normalized.get(key), f"{path}.{key}", issues, require_healthy=True)
    for key in ("enabled", "bound", "complete", "reset_performed"):
        if normalized.get(key) is not True:
            issues.append(f"{path}.{key} is not true at final closure")
    if normalized.get("armed") is not False:
        issues.append(f"{path}.armed is not false at final closure")
    if normalized.get("invalid") is not False:
        issues.append(f"{path}.invalid is not false at final closure")
    result["accepted"] = not issues
    return result


validate_final = validate_boundary
