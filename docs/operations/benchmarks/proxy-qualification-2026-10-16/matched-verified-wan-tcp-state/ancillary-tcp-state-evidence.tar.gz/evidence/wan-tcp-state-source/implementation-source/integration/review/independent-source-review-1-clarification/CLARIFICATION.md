# Clarification to independent source review 1

This note clarifies two implementation choices in the frozen review at
`../independent-source-review-1`. It does not modify that review or the rejected
source checkpoint.

1. Review item 5 requires `applied_range` to be proved by the original
   byte-credit wait ledger's entry/retry advancement and by positive retry byte
   credit. It does **not** require the later TCP sample's entry cursor to be less
   than its retry cursor. Peer credit may advance after the original byte-wait
   entry but before the synchronous TCP entry sample; equal TCP-bracket cursors
   can therefore be legitimate. The final validator must join the TCP wait
   record to the exact original byte-wait token and require that original
   ledger's ordinal and cumulative advancement.

2. Review item 2 requires failure of the post-capture cursor read to remain an
   explicit sticky failure rather than fabricate a completed zero cursor. An
   exported validity bit is one valid implementation. Leaving the sample
   unfinished/active so disarm and drain reject it is also valid and avoids a
   schema field, provided the sample cannot later be completed or reset as
   healthy.
