# TCP-state integration runner source checkpoint 1

Status: source-only and unexecuted. This is a narrow successor to accepted byte-credit runner 12. It is ready for independent source review; materialization, receipt publication, endpoint execution, and WAN traffic remain blocked.

The materialized corpus contains 38 files. The 12 changed or added paths compose the reviewed TCP-state validator into the existing below-TLS raw-write and arm validators, bind accepted build attempt 2 and the accepted 25-case validator contract, and extend the mature source contracts and static verifier. `RUNNER12-TO-TCP-STATE-SOURCE.diff` is the exact corpus delta.

The generated workload runner remains byte-identical at `a672ab07...`; the timed `run_transfer` body remains `b8659336...`. H1/H2 schedules, TLS controls, resource ownership, natural-lifecycle gates, raw-write, server-growth, sender-wait, byte-credit, old raw-proof, and byte-credit supplemental-proof gates remain present. The arm requires the exact selected lane/session/tuple and joins stream-filtered TCP waits to the selected byte-credit interval.

The build receipt is `bcca6079...`, with agent `150761b5...`, server `a9aa0b5e...`, source inventory `0595c8e5...`, producer checkpoint `809f3048...`, and validator contract records `7cfe27fc...`. No binary bytes are copied into this source checkpoint.

The fixed 4096-record wait and raw-pair caps are memory-safety ceilings. The authenticated control response remains bounded at 4 MiB. An oversized full snapshot invalidates the interval/run and preserves omission size/hash metadata; it is never truncated into a healthy result. A future tiny run must report actual response byte maxima, TCP bind/pre/post/terminal state for all five owners, CC/sysctl/fingerprint/protocol identity, selected-stream joins, and exact natural endpoint exits.
