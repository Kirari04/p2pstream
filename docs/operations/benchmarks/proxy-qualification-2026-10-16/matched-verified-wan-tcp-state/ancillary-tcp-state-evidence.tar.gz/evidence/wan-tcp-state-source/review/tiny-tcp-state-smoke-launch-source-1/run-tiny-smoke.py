#!/usr/bin/env python3
"""Launch one reviewed TCP-state tiny smoke from a fully bound fresh corpus."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import traceback

REPO = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
CONTINUATION = REPO / "tmp/continuation-20261016"
BYTE_ROOT = CONTINUATION / "wan-byte-credit-integration-source"
TCP_ROOT = CONTINUATION / "wan-tcp-state-source"
RUNNER_SOURCE = TCP_ROOT / "integration-runner-source-3"
ACTIVE = TCP_ROOT / "integration-source-3"
SOURCE_CORPUS = RUNNER_SOURCE / "SOURCE-CORPUS.json"
RUNNER_SOURCE_LEDGER = RUNNER_SOURCE / "SHA256SUMS.txt"
RUNNER_SOURCE_LEDGER_SHA = "15025bfc66dcc8dac6a3cde951a04ec5b8f55c534b27aa319826cc2281e7530f"
SOURCE_CORPUS_SHA = "a9aca74706f7e3c804a8e03e3524b988a7bb39ca75c77a6563a05485a8c14ed2"
MATERIALIZATION_RESULT = TCP_ROOT / "provenance/materialization-attempt-3/RESULT.json"
MATERIALIZATION_RESULT_SHA = "dc44c5598b13a585ca8cac74f96bdaf02aa38c10c05c34b1b55734f720277b12"
PUBLICATION_RESULT = TCP_ROOT / "provenance/local-publication-attempt-3/publication-result.json"
PUBLICATION_RESULT_SHA = "141283e50338928bda78caf428f8abc8379765412cfc787b7875354b2fc52be1"
FINAL_CONTRACT_RECORDS = TCP_ROOT / "runs/final-source-contract-attempt-4/records"
FINAL_CONTRACT_LEDGER_SHA = "a0325eaaa2d00969065b02b87bd4397824894a51d5af5cd9a659ac3e51a144b3"
INVOCATION = Path(__file__).resolve().parent / "INVOCATION.sh"
INVOCATION_SHA = "c5bec2f77e069c752d046fc26276527041c69755d7087e47585c8abe46445903"
OUTPUT = ACTIVE / "integration/runs/tiny-tcp-state-smoke-1"
OUTPUT_RELATIVE = OUTPUT.relative_to(ACTIVE).as_posix()
MATURE_LAUNCH_SOURCE = BYTE_ROOT / "review/tiny-smoke-launch-source-3/SHA256SUMS.txt"
MATURE_LAUNCH_SOURCE_SHA = "1e60215e0791f91b8258056308a5ba8c48e34d23bf3f8c44174e53f37c2386ad"
PRIOR_FAILURE_LEDGERS = {
    BYTE_ROOT / "provenance/tiny-byte-credit-smoke-2-launch/records/SHA256SUMS.txt": "09fcb7700dcb032ad3888a1fdc1d2780bb84af6d9cdcf6202a98648902ec8c06",
    BYTE_ROOT / "provenance/tiny-byte-credit-smoke-2-result-review/RUN-SHA256SUMS.txt": "3d9057407075685cf4541fbf5e65156a9a2991d92733436e8ad0b01b81a1e2c0",
    BYTE_ROOT / "provenance/tiny-byte-credit-smoke-2-result-review/SHA256SUMS.txt": "c770506fec47033131fa12a81020a0f5e3bca3d62a6f3e0102a7b818ecf79b78",
    BYTE_ROOT / "provenance/tiny-byte-credit-smoke-2-semantic-review-1/SHA256SUMS.txt": "4b5c30c2da2120c32ffbd5cd2579c9e658614cd7432cfad3bdb3e2cd1f1626a8",
    BYTE_ROOT / "provenance/tiny-byte-credit-smoke-1-launch/records/SHA256SUMS.txt": "c9a41d84f7f2d5440d87e3e713f9c217cfab2a15be9308d896a048dfa1108769",
    BYTE_ROOT / "provenance/tiny-byte-credit-smoke-1-result-review/RUN-SHA256SUMS.txt": "b0fe4d75bf64eb320cfd65e86717df4cb0e9fc5a85a1ea27a148b3cd1eec8b1a",
    BYTE_ROOT / "provenance/tiny-byte-credit-smoke-1-result-review/SHA256SUMS.txt": "a46152dc319fb38bffb928b319381cecf8071c76c3d10bbe7400c7b009abf019",
    BYTE_ROOT / "provenance/tiny-byte-credit-smoke-1-main-tool-envelope/SHA256SUMS.txt": "e7708d032d31a84c5fcb9112d6cb72012a59e9284994bf6a471abaf157bb6b17",
    CONTINUATION / "wan-below-tls-raw-write-source/implementation-source/server-growth/review/tiny-final-integration-mode-correction-source-1/ATTEMPT1-SHA256SUMS.txt": "cbc0c94448aa8ac843707bf66ce1523e62175a8ba7ac1285b6fe9a5c07fd03da",
    CONTINUATION / "wan-below-tls-raw-write-source/implementation-source/server-growth/review/tiny-final-integration-smoke-launch-source-5/ATTEMPT2-SHA256SUMS.txt": "dd4c4465823bf3d912f1e707d499eae022d9273bf62bd04a1c004086c6a99454",
}
PROVENANCE = {
    "raw-ordinary-proof-receipt.json": "b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d",
    "byte-credit-ordinary-proof-receipt.json": "6562b975ba8f25d1b7a1a83c323c4c289f62f97b5508421e9e0f2e244c940460",
    "audited-combined-build-receipt.json": "bcca6079b5de32635701b4a1d5195cd9b9f9e8976d76e48956cea7d396cb7b97",
}
BINARIES = {
    "agent": (TCP_ROOT / "build-source-1/runs/audited-build-attempt-2/bin/current-agent-wan-tcp-state-audited.test", "150761b51a8f326f2decb8889a393010b8333d04b885f17bea2e3c9dbe45bbcd"),
    "server": (TCP_ROOT / "build-source-1/runs/audited-build-attempt-2/bin/current-server-wan-tcp-state-audited.test", "a9aa0b5e55f73cf01c4ca00f3b26740f683542e1b93268a4e2acc18a94806042"),
}
OWNED_HELPER = CONTINUATION / "wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
OWNED_HELPER_SHA = "8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
PYTHON = Path("/usr/bin/python3.14")
PYTHON_SHA = "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
RUNNER_PATH = "/usr/sbin:/usr/bin:/sbin:/bin"
EXPECTED_RUNNER_TOOLS = {
    "awk": "/usr/bin/mawk", "ip": "/usr/bin/ip", "tc": "/usr/sbin/tc",
    "nsenter": "/usr/bin/nsenter", "jq": "/usr/bin/jq",
    "python3": "/usr/bin/python3.14", "taskset": "/usr/bin/taskset",
    "openssl": "/usr/bin/openssl", "sha256sum": "/usr/lib/cargo/bin/coreutils/sha256sum",
    "ping": "/usr/bin/ping", "ps": "/usr/bin/ps",
    "readlink": "/usr/lib/cargo/bin/coreutils/readlink", "setsid": "/usr/bin/setsid",
    "systemd-run": "/usr/bin/systemd-run",
}
TC_SHA = "2444a535db549341d3fd7caeba73f20bdb188e196a59ee9ca5b6deb08738dea1"


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def write_text(path: Path, value: str) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        stream.write(value)


def require_regular(path: Path, digest: str, mode: int | None = None) -> None:
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or path.is_symlink() or sha(path) != digest:
        raise ValueError(f"file hash/type differs: {path}")
    if mode is not None and stat.S_IMODE(info.st_mode) != mode:
        raise ValueError(f"file mode differs: {path}")


def expected_corpus() -> dict[str, str]:
    require_regular(RUNNER_SOURCE_LEDGER, RUNNER_SOURCE_LEDGER_SHA)
    require_regular(SOURCE_CORPUS, SOURCE_CORPUS_SHA)
    value = json.loads(SOURCE_CORPUS.read_text(encoding="utf-8"))
    if value.get("status") != "ready_for_materialization":
        raise ValueError("final runner source is not approved")
    files = value.get("files")
    if not isinstance(files, dict) or not files:
        raise ValueError("source corpus inventory is malformed")
    expected: dict[str, str] = {}
    for relative, item in files.items():
        path = Path(relative)
        if (not isinstance(relative, str) or path.is_absolute() or ".." in path.parts
                or not isinstance(item, dict) or item.get("mode") not in (0o644, 0o755)
                or re.fullmatch(r"[0-9a-f]{64}", str(item.get("sha256"))) is None):
            raise ValueError("unsafe source corpus entry")
        expected[relative] = item["sha256"]
    return expected


def active_inventory(exclude_output: bool) -> dict[str, str]:
    if not ACTIVE.is_dir() or ACTIVE.is_symlink():
        raise ValueError("active materialized root is unsafe")
    result: dict[str, str] = {}
    for path in sorted(ACTIVE.rglob("*")):
        relative = path.relative_to(ACTIVE).as_posix()
        if relative == "provenance" or relative.startswith("provenance/"):
            continue
        if exclude_output and (relative == OUTPUT_RELATIVE or relative.startswith(OUTPUT_RELATIVE + "/")):
            continue
        if path.is_symlink():
            raise ValueError(f"symlink in active corpus: {path}")
        if path.is_file():
            result[relative] = sha(path)
    return result


def verify_records(root: Path, expected_ledger_sha: str) -> None:
    ledger = root / "SHA256SUMS.txt"
    require_regular(ledger, expected_ledger_sha)
    expected: dict[str, str] = {}
    for line in ledger.read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        if len(digest) != 64 or not name.startswith("./"):
            raise ValueError("malformed final contract ledger")
        relative = Path(name[2:])
        if relative.is_absolute() or ".." in relative.parts or relative.as_posix() in expected:
            raise ValueError("unsafe final contract ledger")
        expected[relative.as_posix()] = digest
    actual = {p.relative_to(root).as_posix(): sha(p) for p in sorted(root.rglob("*"))
              if p.is_file() and not p.is_symlink() and p != ledger}
    if actual != expected:
        raise ValueError("final contract records differ")
    result = json.loads((root / "RESULT.json").read_text(encoding="utf-8"))
    if result.get("accepted") is not True or result.get("endpoint_execution") is not False or result.get("wan_traffic") is not False:
        raise ValueError("final source contract was not accepted offline")


def resolve_tools() -> dict[str, str]:
    result: dict[str, str] = {}
    for name, expected in EXPECTED_RUNNER_TOOLS.items():
        selected = shutil.which(name, path=RUNNER_PATH)
        if selected is None:
            raise ValueError(f"missing runner tool: {name}")
        canonical = Path(selected).resolve(strict=True)
        info = canonical.lstat()
        if (not stat.S_ISREG(info.st_mode) or canonical.is_symlink()
                or not os.access(canonical, os.X_OK) or str(canonical) != expected):
            raise ValueError(f"runner tool binding differs: {name}")
        result[name] = str(canonical)
    if sha(Path(result["tc"])) != TC_SHA:
        raise ValueError("tc binary changed")
    return result


def validated_session_environment() -> dict[str, str]:
    runtime = Path(f"/run/user/{os.geteuid()}")
    bus = runtime / "bus"
    if os.environ.get("XDG_RUNTIME_DIR") != str(runtime) or os.environ.get("DBUS_SESSION_BUS_ADDRESS") != f"unix:path={bus}":
        raise ValueError("owned user session environment differs")
    runtime_info = runtime.lstat()
    bus_info = bus.lstat()
    if (not stat.S_ISDIR(runtime_info.st_mode) or runtime.is_symlink()
            or runtime_info.st_uid != os.geteuid() or stat.S_IMODE(runtime_info.st_mode) != 0o700
            or not stat.S_ISSOCK(bus_info.st_mode) or bus.is_symlink() or bus_info.st_uid != os.geteuid()):
        raise ValueError("owned user session paths differ")
    return {"XDG_RUNTIME_DIR": str(runtime), "DBUS_SESSION_BUS_ADDRESS": f"unix:path={bus}"}


def load_owned_helper():
    spec = importlib.util.spec_from_file_location("reviewed_owned_process", OWNED_HELPER)
    if spec is None or spec.loader is None:
        raise ValueError("owned helper import failed")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def lifecycle_natural(records: Path) -> tuple[bool, int]:
    value = json.loads((records / "coordinator.lifecycle.json").read_text(encoding="utf-8"))
    status = value.get("direct_status")
    natural = (value.get("owned_group_identity_valid") is True
               and value.get("direct_child_joined") is True
               and value.get("timed_out") is False
               and value.get("term_attempted") is False
               and value.get("kill_attempted") is False
               and value.get("forced_cleanup") is False
               and value.get("group_joined") is True
               and type(status) is int and value.get("wait_returncode") == status
               and (records / "coordinator.direct.status").read_text() == f"{status}\n")
    return natural, status if type(status) is int else 125


def verify_fixed_inputs(expected: dict[str, str], *, post: bool) -> dict[str, object]:
    require_regular(MATURE_LAUNCH_SOURCE, MATURE_LAUNCH_SOURCE_SHA)
    for path, digest in PRIOR_FAILURE_LEDGERS.items():
        require_regular(path, digest)
    require_regular(INVOCATION, INVOCATION_SHA, 0o755)
    require_regular(OWNED_HELPER, OWNED_HELPER_SHA)
    require_regular(PYTHON, PYTHON_SHA)
    require_regular(MATERIALIZATION_RESULT, MATERIALIZATION_RESULT_SHA, 0o600)
    materialized = json.loads(MATERIALIZATION_RESULT.read_text())
    if (materialized.get("accepted") is not True
            or materialized.get("source_corpus_sha256") != SOURCE_CORPUS_SHA
            or materialized.get("file_count") != len(expected)):
        raise ValueError("materialization result did not bind the final corpus")
    require_regular(PUBLICATION_RESULT, PUBLICATION_RESULT_SHA, 0o600)
    publication = json.loads(PUBLICATION_RESULT.read_text())
    published = publication.get("published_receipts")
    audited = publication.get("audited_binaries")
    if (publication.get("accepted") is not True or publication.get("endpoint_execution") is not False
            or publication.get("wan_traffic") is not False
            or publication.get("source_corpus_sha256") != SOURCE_CORPUS_SHA
            or publication.get("materialization_result_sha256") != MATERIALIZATION_RESULT_SHA
            or not isinstance(published, dict) or not isinstance(audited, dict)
            or {name: item.get("sha256") for name, item in published.items()}
               != {"raw": PROVENANCE["raw-ordinary-proof-receipt.json"],
                   "byte": PROVENANCE["byte-credit-ordinary-proof-receipt.json"],
                   "build": PROVENANCE["audited-combined-build-receipt.json"]}
            or {name: item.get("sha256") for name, item in audited.items()}
               != {name: digest for name, (_, digest) in BINARIES.items()}):
        raise ValueError("receipt publication was not accepted with the requested corpus and tuple")
    provenance_root = ACTIVE / "provenance"
    for name, digest in PROVENANCE.items():
        require_regular(provenance_root / name, digest, 0o600)
    if {p.name for p in provenance_root.iterdir()} != set(PROVENANCE):
        raise ValueError("published receipt inventory differs")
    for path, digest in BINARIES.values():
        require_regular(path, digest, 0o775)
    verify_records(FINAL_CONTRACT_RECORDS, FINAL_CONTRACT_LEDGER_SHA)
    tools = resolve_tools()
    actual = active_inventory(exclude_output=post)
    if actual != expected:
        raise ValueError("active materialized corpus differs")
    return {"source_corpus_sha256": SOURCE_CORPUS_SHA, "active_corpus": actual,
            "materialization_result_sha256": MATERIALIZATION_RESULT_SHA,
            "publication_result_sha256": PUBLICATION_RESULT_SHA,
            "final_contract_ledger_sha256": FINAL_CONTRACT_LEDGER_SHA,
            "mature_launcher_sha256": MATURE_LAUNCH_SOURCE_SHA,
            "prior_failure_ledgers": {str(p): d for p, d in PRIOR_FAILURE_LEDGERS.items()},
            "runner_path": RUNNER_PATH, "runner_tools": tools,
            "published_receipts": PROVENANCE,
            "audited_binaries": {name: digest for name, (_, digest) in BINARIES.items()}}


def main() -> int:
    if len(sys.argv) != 2:
        raise ValueError("usage: run-tiny-smoke.py FRESH_EVIDENCE_ROOT")
    pending = [RUNNER_SOURCE_LEDGER_SHA, SOURCE_CORPUS_SHA, MATERIALIZATION_RESULT_SHA,
               PUBLICATION_RESULT_SHA, FINAL_CONTRACT_LEDGER_SHA, INVOCATION_SHA,
               *PROVENANCE.values(), *(digest for _, digest in BINARIES.values())]
    if any(re.fullmatch(r"[0-9a-f]{64}", value) is None for value in pending):
        raise ValueError("final build/materialization/publication bindings remain pending")
    if sys.flags.isolated != 1 or not sys.dont_write_bytecode:
        raise ValueError("launcher requires Python -I -B")
    evidence = Path(sys.argv[1]).resolve()
    if evidence.exists() or evidence.is_symlink() or not evidence.parent.is_dir():
        raise ValueError("evidence root must be fresh below an existing parent")
    if OUTPUT.exists() or OUTPUT.is_symlink():
        raise ValueError("tiny smoke output must be fresh")
    evidence.mkdir(mode=0o700)
    records = evidence / "records"
    records.mkdir(mode=0o700)
    status = 125
    started = False
    natural = False
    source_ok = False
    issue = None
    try:
        expected = expected_corpus()
        write_json(records / "preflight-inputs.json", verify_fixed_inputs(expected, post=False))
        environment = {"HOME": "/home/user", "PATH": RUNNER_PATH, "PYTHONDONTWRITEBYTECODE": "1",
                       "PYTHONHASHSEED": "0", "LC_ALL": "C", "TZ": "Europe/Zurich",
                       **validated_session_environment()}
        write_json(records / "environment.json", environment)
        started = True
        status = load_owned_helper().run(records, "coordinator", ["/usr/bin/bash", str(INVOCATION)],
                                         ACTIVE, environment, 3600)
        natural, recorded = lifecycle_natural(records)
        if recorded != status or not natural:
            raise ValueError("coordinator process group did not join naturally")
    except BaseException as error:
        issue = f"{type(error).__name__}: {error}"
        traceback.print_exc()
    finally:
        try:
            expected = expected_corpus()
            write_json(records / "postflight-inputs.json", verify_fixed_inputs(expected, post=True))
            source_ok = True
        except BaseException as error:
            if issue is None:
                issue = f"postflight {type(error).__name__}: {error}"
        write_json(records / "RESULT.json", {"schema_version": 1,
            "evidence_complete": started and natural and source_ok, "coordinator_started": started,
            "coordinator_direct_status": status, "coordinator_succeeded": status == 0,
            "natural_group_join": natural, "source_pre_post_accepted": source_ok,
            "issue": issue, "output_path": str(OUTPUT)})
        write_text(records / "launcher.status", f"{status if source_ok and natural else 125}\n")
        with (records / "SHA256SUMS.txt").open("x", encoding="utf-8") as stream:
            for path in sorted(records.rglob("*")):
                if path.is_file() and path.name != "SHA256SUMS.txt":
                    stream.write(f"{sha(path)}  ./{path.relative_to(records).as_posix()}\n")
        write_text(evidence / "FINAL", "complete\n")
    return status if source_ok and natural else 125


if __name__ == "__main__":
    raise SystemExit(main())
