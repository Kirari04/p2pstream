# Kernel source evidence retained for the threshold review

This directory retains the small exact inputs needed to reproduce the source
interpretation. The files are evidence only and are not compiled or executed.

* `ubuntu-linux-7.0.0-38.38.dsc` is the official Launchpad source description.
* `ubuntu-relevant.diff` contains the complete Ubuntu unified-diff sections for
  the five TCP files used by the review, extracted byte-for-byte from
  `linux_7.0.0-38.38.diff.gz` after decompression.
* `upstream-v7.0-*` are the exact upstream v7.0 files fetched from the official
  kernel.googlesource mirror.

The 254,937,830-byte upstream tar and the 3,455,370-byte compressed Ubuntu
distribution diff are intentionally omitted from this small evidence root.
Their published names, sizes, URLs, and hashes are recorded in `COMMANDS.md`
and in the frozen review's `INPUTS.json`. The retained relevant diff is enough
to verify that Ubuntu's changes to the cited `snd_ssthresh` sites are access
wrappers rather than semantic value or condition changes.
