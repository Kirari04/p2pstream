# Retrieval and extraction record

The files were retrieved on 2026-10-17 without modifying host kernel state.

```sh
curl -fsSL -o /tmp/linux_7.0.0-38.38.dsc \
  https://launchpad.net/ubuntu/+archive/primary/+sourcefiles/linux/7.0.0-38.38/linux_7.0.0-38.38.dsc
curl -fsSL -o /tmp/linux_7.0.0-38.38.diff.gz \
  https://launchpad.net/ubuntu/+archive/primary/+sourcefiles/linux/7.0.0-38.38/linux_7.0.0-38.38.diff.gz
gzip -dc /tmp/linux_7.0.0-38.38.diff.gz > /tmp/linux_7.0.0-38.38.diff
git ls-remote https://git.launchpad.net/~ubuntu-kernel/ubuntu/+source/linux/+git/resolute \
  'refs/tags/Ubuntu-7.0.0-38.38*'
```

The tag dereferenced to commit
`740b32353f43e9b00d0350d6fa7b29a6667deabd`. The source description SHA-256 is
`016d43577bd8a61629a02e140e3b88072b5ccdd1c90cb1ce2f3c8e5c28756e7e`.
The compressed distribution diff is 3,455,370 bytes with SHA-256
`98e913d4a1c1f810e4dcfa573cbcf0f1a3a4427bdcd503722555298a794c52b2`.
The source description declares upstream tar size 254,937,830 and SHA-256
`c6343795c8c7e4feff55f5b309365c8e0eaf49cd6abcb412e32315313f149536`;
the large tar was not retained or used after the official
upstream v7.0 file retrieval below.

Each upstream file was fetched as base64 and decoded exactly:

```sh
curl -fsSL \
  'https://kernel.googlesource.com/pub/scm/linux/kernel/git/torvalds/linux/+/refs/tags/v7.0/FILE?format=TEXT' \
  | base64 -d > OUTPUT
```

`FILE` was each of `include/net/tcp.h`, `net/ipv4/tcp.c`,
`net/ipv4/tcp_input.c`, `net/ipv4/tcp_output.c`, and
`net/ipv4/tcp_cubic.c`. `ubuntu-relevant.diff` was produced by a deterministic
line parser that retained the complete unified-diff section beginning at each
matching `--- linux-7.0.0.orig/FILE` header and ending before the next such
header. No hunk was filtered within a retained section.

Alignment was checked by reading every retained `snd_ssthresh` hunk. At the
reviewed idle-restart, application-limited, CUBIC HyStart, and recovery/loss
sites, Ubuntu preserves the upstream right-hand side and condition and wraps
the assignment in `WRITE_ONCE(...)`.
