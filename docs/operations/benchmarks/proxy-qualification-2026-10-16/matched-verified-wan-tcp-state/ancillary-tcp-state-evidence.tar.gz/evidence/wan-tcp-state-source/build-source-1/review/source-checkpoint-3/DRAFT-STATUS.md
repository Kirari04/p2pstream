# Frozen source status

This source binds integration checkpoint 6, its exact 12-file SOURCE-MAP, and the unchanged exact 31-root/81-event agent plus 12-root/16-event Yamux focused plan. Checkpoint 6 changes one test expectation after failed build attempt 1; all 11 runtime/schema payload files are byte-identical to reviewed checkpoint 5.

The driver separates natural process-group closure from command success. Natural closure requires every started owned group to join without timeout, TERM, KILL, or forced cleanup. Status success independently requires the complete expected stage set and exact zero statuses. Acceptance requires both.

It binds the rejected checkpoint-4 mutation incident, failed build attempt 1, and the accepted 25-case offline validator contract. It has not executed any Go command, test, build, endpoint, or traffic. The external approved-input record must bind this checkpoint manifest and driver hashes before launch.
