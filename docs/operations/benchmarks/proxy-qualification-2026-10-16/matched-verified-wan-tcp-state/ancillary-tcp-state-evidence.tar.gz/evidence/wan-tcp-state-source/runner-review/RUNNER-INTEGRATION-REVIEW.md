# TCP-state runner integration review

Status: read-only integration review. No frozen source, validator, build, test, or
traffic artifact was changed, and no implementation or execution is authorized.

## Accepted anchors

- Active corpus: `wan-byte-credit-integration-source/integration-source-6`, from
  runner-source-12 manifest
  `20ed7a1824c3d95cf5866620cb2dcb7e33d07eacf8ab4885d708d896e77b7f1e` and
  `SOURCE-CORPUS.json`
  `9457dc5253c5df25542640be8b3b5e0df3f30617e1cd499d497137a75bfef94e`.
- Generated qualification runner:
  `integration/generated/qualify-proxy-agent-growth-wan-below-tls.sh`, SHA-256
  `a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad`.
- Its extracted `run_transfer` is 7,350 bytes, SHA-256
  `b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798`.
  A successor must prove that exact byte slice unchanged.
- Accepted build-5 receipt SHA-256
  `93c91824df93bdfd78efc50dbc22b3c028b2e87ac4c88b77600c30207df0daff`,
  records ledger
  `6d8abe7c2a1e6ff2ac5de785fdc67bc201a943e8d0833224b5d6aa027f7a3961`,
  source inventory
  `dab62af9a09f23fee6bedf57ed014cc63655fcd5f0f91a32e0f8bee23c297b72`.

## Exact integration surface

1. `generated/qualify-proxy-agent-growth-wan-below-tls.sh`
   - `wan_sender_wait_query` (lines 622-694) is the only authenticated response
     reader. It uses the existing agent namespace for `agent-drain`, reads at
     most `4 MiB + 1`, rejects `>4 MiB`, and saves the request envelope.
   - `run_transfer` (lines 925-1036) stays byte-identical.
   - `run_maybe_sender_wait_transfer` (lines 1067-1210) already brackets the
     exact selected transfers with one pre and one post destructive drain. TCP
     data should ride those existing response bodies; no new poll/request is
     needed.
   - The terminal drain (lines 1834-1848) and
     `finalize_raw_write_after_agent_join` (lines 1595-1669, called at 1851-1855)
     already preserve the ninth snapshot and post-join five-owner closure. A
     successor should retain those orderings and the natural process lifecycle.
2. `validate-sender-wait-snapshot.py`
   - `response` (lines 158-216) enforces the 4 MiB ceiling and exact schema-2
     top-level fields.
   - `validate_pre`, `validate_terminal`, `validate_pair`, and
     `validate_final_closure` are the structural integration points.
   - If TCP records are nested in the versioned `raw_write_activity`, the
     response top-level key set can remain unchanged; the nested schema/version
     must change explicitly.
3. `validate-raw-write-activity.py`
   - `ACTIVITY_FIELDS` and `validate_activity` (lines 30-33 and 118-205) reject
     any additive field today.
   - `validate_live`, `validate_identity_stable`, `validate_no_data_activity`,
     `validate_interval_outcomes`, and `validate_final_closure` are the minimal
     points for fixed-capacity, drop/overflow/active/ambiguous, identity, and
     terminal checks.
   - A separate `validate-tcp-state.py` can own the TCP snapshot and pair schema;
     this validator should call it for structural/live/final checks rather than
     duplicating the TCP schema.
4. `validate-byte-credit-recycle.py`
   - Its selected wait identity/result is the exact same-stream join input for a
     TCP validator. Its accepted semantics should remain unchanged.
5. `validate-wan-below-tls-arm.py`
   - Add the TCP validator import/path/hash alongside the existing raw,
     server-growth, and byte-credit validators (lines 9-29 and 114-143).
   - In the selected sequence loop (lines 335-505), call the TCP validator with
     the existing independent sender/raw result plus the selected byte-credit
     identity. Emit an additive per-sequence result and fail the integrity gate
     on missing, dropped, overflowed, ambiguous, mismatched, active, or
     incomplete observations.
   - The exact control filename set at lines 539-555 need not change if TCP data
     is retained inside the existing pre/post/terminal sender responses and
     validations.
   - Add explicit TCP interpretation/final-closure fields to the attestation;
     make no causal or cross-clock claim.
6. `validate-post-join-raw-closure.py` and `validate-h1-continuation.py`
   - Final TCP closure should compose through the existing terminal sidecar and
     nine-response history. H1 continuation must require the additive TCP
     integrity/final-closure result while preserving the existing performance
     and conditioning partition.
7. `run-wan-below-tls-arm.sh`, `run-wan-below-tls-diagnostic.sh`,
   `verify-static-paths.py`, `contracts/run-final-source-contracts.sh`, and
   `contracts/test-final-source-bindings.py`
   - Bind the new validator, provider/adapter checkpoint, focused records,
     proof/contract receipts, and successor build receipt/binaries.
   - Extend `write_hashes`/required hash keys and the static materialized corpus;
     retain every existing raw, byte-credit, server-growth, source-ancestry, TLS,
     lifecycle, and build-5 predecessor binding.
   - The successor build receipt should add TCP provider checkpoint/focused
     evidence/proof/adapter contract fields and new exact binary/source-inventory
     hashes. It should not overwrite the existing byte-credit/raw proof lineage.

## Fixed response-bound conflict

The current provider checkpoint-2 `qualificationTCPInfoSnapshot` has 39 JSON
fields, including 24 nested availability flags. With compact JSON and all-zero
or false values, one snapshot is 1,331 bytes. With maximum-width scalar values
and a 16-byte congestion-control name it is 1,647 bytes. These counts exclude
all pair-record identity, cursor, classification, token, and array/container
fields.

The proposal permits, per owner, 4,096 wait pairs and 4,096 first-raw pairs.
Across five owners that is 40,960 pairs or 81,920 snapshots. Even encoding each
pair as only `[snapshot,snapshot]` yields a lower bound of 109,158,400 bytes
(about 26.0 times the 4,194,304-byte control ceiling); maximum-width snapshots
alone reach 135,045,120 bytes. Real pair wrappers make both values larger.

For context, the largest accepted sender-control response in the closed
integration-source-6 runs is 540,328 bytes, leaving 3,653,976 bytes below the
ceiling. Spread across 40,960 possible pairs, that headroom is only about 89.2
bytes per pair, versus the 2,665-byte snapshot-only minimum.

Therefore the existing authenticated response cannot retain the full fixed
maximum. The API/schema must resolve this before runner implementation. Safe
choices are a smaller exact record limit whose worst-case serialized response is
proved below 4 MiB including all existing fields, or an owned file-backed
artifact with exact size/hash/path and lifecycle binding. Raising the 4 MiB
limit, silently truncating arrays, or returning only an omitted-content hash
does not satisfy full observation retention. The existing failure payload can
preserve a small rejected snapshot or its exact omitted byte count/hash, but the
latter is evidence of omission, not the observations themselves; either path
must invalidate the whole interval and prohibit a healthy claim.

## Lifecycle constraint

No new query, endpoint, polling loop, owner registry, or process is needed. The
successor should keep the same four pre/post selected intervals, one terminal
drain, post-RunContext terminal sidecar, five exact owners, and natural endpoint,
namespace, and scope joins. TCP capture failures, capacity overflow, late or
in-flight boundaries, owner replacement, or missing terminal records must flow
to the existing irreversible integrity rejection.
