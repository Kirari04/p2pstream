//go:build p2pstream_qualification

package yamux

import (
	"math"
	"sort"
	"sync"
	"sync/atomic"
	"time"
)

const QualificationByteCreditTraceSchemaVersion = 1
const QualificationByteCreditTraceRecordLimit = 4096

type QualificationByteCreditReceiverRecord struct {
	RelativeOrdinal                         uint64 `json:"relative_ordinal"`
	StreamID                                uint32 `json:"stream_id"`
	Flags                                   uint16 `json:"flags"`
	Kind                                    string `json:"kind"`
	Delta                                   uint32 `json:"delta"`
	Cumulative                              uint64 `json:"cumulative"`
	ReceiveWindowAfter                      uint32 `json:"receive_window_after"`
	EligibilityObservedUnixNS               int64  `json:"eligibility_observed_unix_ns"`
	EnqueueObservedUnixNS                   int64  `json:"enqueue_observed_unix_ns"`
	CompletionResultObservedUnixNS          int64  `json:"completion_result_observed_unix_ns"`
	EligibilityToEnqueueObservedNS          uint64 `json:"eligibility_to_enqueue_observed_ns"`
	EnqueueToCompletionResultObservedNS     uint64 `json:"enqueue_to_completion_result_observed_ns"`
	EligibilityToCompletionResultObservedNS uint64 `json:"eligibility_to_completion_result_observed_ns"`
	EnqueueObserved                         bool   `json:"enqueue_observed"`
	CompletionResultObserved                bool   `json:"completion_result_observed"`
	Active                                  bool   `json:"active"`
	Ambiguous                               bool   `json:"ambiguous"`
	Outcome                                 string `json:"outcome"`
}
type QualificationByteCreditPeerRecord struct {
	RelativeOrdinal                 uint64 `json:"relative_ordinal"`
	StreamID                        uint32 `json:"stream_id"`
	Flags                           uint16 `json:"flags"`
	Delta                           uint32 `json:"delta"`
	Cumulative                      uint64 `json:"cumulative"`
	ByteCreditBefore                uint32 `json:"byte_credit_before"`
	ByteCreditAfter                 uint32 `json:"byte_credit_after"`
	HandlerEntryUnixNS              int64  `json:"handler_entry_unix_ns"`
	CreditAppliedUnixNS             int64  `json:"credit_applied_unix_ns"`
	NotifyObservedUnixNS            int64  `json:"notify_observed_unix_ns"`
	HandlerToCreditAppliedNS        uint64 `json:"handler_to_credit_applied_ns"`
	CreditAppliedToNotifyObservedNS uint64 `json:"credit_applied_to_notify_observed_ns"`
	HandlerToNotifyObservedNS       uint64 `json:"handler_to_notify_observed_ns"`
	NotifyResult                    string `json:"notify_result"`
	ActiveWaitToken                 uint64 `json:"active_wait_token"`
}
type QualificationByteCreditWaitRecord struct {
	Token                  uint64 `json:"token"`
	StreamID               uint32 `json:"stream_id"`
	DecisionCredit         uint32 `json:"decision_credit"`
	EntryOrdinal           uint64 `json:"entry_ordinal"`
	WakeOrdinal            uint64 `json:"wake_ordinal"`
	RetryOrdinal           uint64 `json:"retry_ordinal"`
	EntryCumulative        uint64 `json:"entry_cumulative"`
	WakeCumulative         uint64 `json:"wake_cumulative"`
	RetryCumulative        uint64 `json:"retry_cumulative"`
	EntryByteCredit        uint32 `json:"entry_byte_credit"`
	WakeByteCredit         uint32 `json:"wake_byte_credit"`
	RetryByteCredit        uint32 `json:"retry_byte_credit"`
	EntryObservedUnixNS    int64  `json:"entry_observed_unix_ns"`
	WakeObservedUnixNS     int64  `json:"wake_observed_unix_ns"`
	RetryObservedUnixNS    int64  `json:"retry_observed_unix_ns"`
	EntryToWakeObservedNS  uint64 `json:"entry_to_wake_observed_ns"`
	WakeToRetryObservedNS  uint64 `json:"wake_to_retry_observed_ns"`
	EntryToRetryObservedNS uint64 `json:"entry_to_retry_observed_ns"`
	Outcome                string `json:"outcome"`
	Classification         string `json:"classification"`
	RangeFirstOrdinal      uint64 `json:"range_first_ordinal"`
	RangeLastOrdinal       uint64 `json:"range_last_ordinal"`
	Active                 bool   `json:"active"`
	Ambiguous              bool   `json:"ambiguous"`
	Terminal               bool   `json:"terminal"`
	Advanced               bool   `json:"advanced"`
	RetryZeroAfterAdvance  bool   `json:"retry_zero_after_advance"`
}
type QualificationByteCreditTraceSnapshot struct {
	SchemaVersion              int                                     `json:"schema_version"`
	Enabled                    bool                                    `json:"enabled"`
	Complete                   bool                                    `json:"complete"`
	ResetPerformed             bool                                    `json:"reset_performed"`
	Ambiguous                  bool                                    `json:"ambiguous"`
	Overflow                   bool                                    `json:"overflow"`
	OrphanOverflow             bool                                    `json:"orphan_overflow"`
	ActiveReceiverPublications uint64                                  `json:"active_receiver_publications"`
	ActivePeerWaits            uint64                                  `json:"active_peer_waits"`
	DroppedReceiverRecords     uint64                                  `json:"dropped_receiver_records"`
	DroppedPeerRecords         uint64                                  `json:"dropped_peer_records"`
	DroppedWaitRecords         uint64                                  `json:"dropped_wait_records"`
	ReceiverRecords            []QualificationByteCreditReceiverRecord `json:"receiver_records"`
	PeerRecords                []QualificationByteCreditPeerRecord     `json:"peer_records"`
	WaitRecords                []QualificationByteCreditWaitRecord     `json:"wait_records"`
}

type qualificationByteCreditStreamLedger struct {
	used                                                                              bool
	session                                                                           *Session
	streamID                                                                          uint32
	receiverOrdinal, receiverCumulative, peerOrdinal, peerCumulative, activeWaitToken uint64
	ambiguous, overflow                                                               bool
	droppedReceiver, droppedPeer, droppedWait                                         uint64
}
type qualificationByteCreditReceiverState struct {
	used                 bool
	session              *Session
	public               QualificationByteCreditReceiverRecord
	eligibility, enqueue time.Time
}
type qualificationByteCreditPeerState struct {
	used    bool
	session *Session
	public  QualificationByteCreditPeerRecord
}
type qualificationByteCreditWaitState struct {
	used        bool
	session     *Session
	public      QualificationByteCreditWaitRecord
	entry, wake time.Time
}
type qualificationByteCreditWaitHandle struct {
	session  *Session
	streamID uint32
	token    uint64
	valid    bool
}

var qualificationByteCreditTrace struct {
	mu             sync.Mutex
	ledgers        [QualificationByteCreditTraceRecordLimit]qualificationByteCreditStreamLedger
	receiver       [QualificationByteCreditTraceRecordLimit]qualificationByteCreditReceiverState
	peer           [QualificationByteCreditTraceRecordLimit]qualificationByteCreditPeerState
	waits          [QualificationByteCreditTraceRecordLimit]qualificationByteCreditWaitState
	orphanOverflow bool
}

func qualificationByteCreditElapsed(a, b time.Time) (uint64, bool) {
	if a.IsZero() || b.IsZero() || b.Before(a) {
		return 0, false
	}
	return uint64(b.Sub(a)), true
}
func qualificationByteCreditLedgerLocked(s *Session, id uint32, create bool) *qualificationByteCreditStreamLedger {
	var free *qualificationByteCreditStreamLedger
	for i := range qualificationByteCreditTrace.ledgers {
		x := &qualificationByteCreditTrace.ledgers[i]
		if x.used && x.session == s && x.streamID == id {
			return x
		}
		if !x.used && free == nil {
			free = x
		}
	}
	if !create || free == nil {
		if create {
			qualificationByteCreditTrace.orphanOverflow = true
		}
		return nil
	}
	*free = qualificationByteCreditStreamLedger{used: true, session: s, streamID: id}
	return free
}
func qualificationByteCreditIncrement(v *uint64, l *qualificationByteCreditStreamLedger) bool {
	if *v == ^uint64(0) {
		l.overflow = true
		return false
	}
	*v = *v + 1
	return true
}

func beginQualificationByteCreditPublication(s *Stream, force bool, flags uint16, delta, after uint32) {
	if s == nil || s.session == nil || !s.session.aggregateEnabled() || delta == 0 || flags&uint16(flagFIN|flagRST) != 0 {
		return
	}
	// Capture observer entry before mutex acquisition and fixed-slot scans so
	// that receiver-local observer contention remains inside the measured
	// eligibility-to-publication interval.
	observed := time.Now()
	qualificationByteCreditTrace.mu.Lock()
	defer qualificationByteCreditTrace.mu.Unlock()
	l := qualificationByteCreditLedgerLocked(s.session, s.id, true)
	if l == nil {
		return
	}
	if !qualificationByteCreditIncrement(&l.receiverOrdinal, l) || ^uint64(0)-l.receiverCumulative < uint64(delta) {
		l.overflow = true
		return
	}
	l.receiverCumulative += uint64(delta)
	for i := range qualificationByteCreditTrace.receiver {
		x := &qualificationByteCreditTrace.receiver[i]
		if x.used {
			continue
		}
		kind := "normal_read"
		if force {
			kind = "forced_growth"
		}
		*x = qualificationByteCreditReceiverState{used: true, session: s.session, eligibility: observed, public: QualificationByteCreditReceiverRecord{RelativeOrdinal: l.receiverOrdinal, StreamID: s.id, Flags: flags, Kind: kind, Delta: delta, Cumulative: l.receiverCumulative, ReceiveWindowAfter: after, EligibilityObservedUnixNS: observed.UnixNano(), Active: true, Outcome: "pending"}}
		return
	}
	l.overflow = true
	l.droppedReceiver++
}
func qualificationByteCreditReceiverCandidate(s *Session, h header, body []byte) bool {
	return s != nil && s.aggregateEnabled() && len(body) == 0 && len(h) == headerSize && h.MsgType() == typeWindowUpdate && h.StreamID() != 0 && h.Length() > 0 && h.Flags()&uint16(flagFIN|flagRST) == 0
}
func qualificationByteCreditReceiverStateLocked(s *Session, h header) (*qualificationByteCreditReceiverState, *qualificationByteCreditStreamLedger) {
	l := qualificationByteCreditLedgerLocked(s, h.StreamID(), false)
	var found *qualificationByteCreditReceiverState
	for i := range qualificationByteCreditTrace.receiver {
		x := &qualificationByteCreditTrace.receiver[i]
		if !x.used || !x.public.Active || x.session != s || x.public.StreamID != h.StreamID() {
			continue
		}
		if x.public.Flags != h.Flags() || x.public.Delta != h.Length() || found != nil {
			if l != nil {
				l.ambiguous = true
			}
			if found != nil {
				found.public.Ambiguous = true
			}
			x.public.Ambiguous = true
			return nil, l
		}
		found = x
	}
	return found, l
}
func observeQualificationByteCreditEnqueue(s *Session, h header, outcome string) {
	if !qualificationByteCreditReceiverCandidate(s, h, nil) {
		return
	}
	qualificationByteCreditTrace.mu.Lock()
	defer qualificationByteCreditTrace.mu.Unlock()
	x, l := qualificationByteCreditReceiverStateLocked(s, h)
	if x == nil {
		if l == nil {
			qualificationByteCreditTrace.orphanOverflow = true
		} else if l.droppedReceiver == 0 {
			l.ambiguous = true
		}
		return
	}
	now := time.Now()
	switch outcome {
	case "accepted":
		if x.public.EnqueueObserved {
			x.public.Ambiguous = true
			l.ambiguous = true
			return
		}
		x.enqueue = now
		x.public.EnqueueObserved = true
		x.public.EnqueueObservedUnixNS = now.UnixNano()
		if d, ok := qualificationByteCreditElapsed(x.eligibility, now); ok {
			x.public.EligibilityToEnqueueObservedNS = d
		} else {
			x.public.Ambiguous = true
			l.ambiguous = true
		}
	case "enqueue_shutdown", "enqueue_timeout":
		x.public.Outcome = outcome
		x.public.Ambiguous = true
		x.public.Active = false
		l.ambiguous = true
	default:
		x.public.Ambiguous = true
		l.ambiguous = true
	}
}
func observeQualificationByteCreditCompletion(s *Session, h header, outcome string) {
	if !qualificationByteCreditReceiverCandidate(s, h, nil) {
		return
	}
	qualificationByteCreditTrace.mu.Lock()
	defer qualificationByteCreditTrace.mu.Unlock()
	x, l := qualificationByteCreditReceiverStateLocked(s, h)
	if x == nil {
		if l == nil {
			qualificationByteCreditTrace.orphanOverflow = true
		} else if l.droppedReceiver == 0 {
			l.ambiguous = true
		}
		return
	}
	now := time.Now()
	x.public.CompletionResultObserved = true
	x.public.CompletionResultObservedUnixNS = now.UnixNano()
	x.public.Outcome = outcome
	whole, ok1 := qualificationByteCreditElapsed(x.eligibility, now)
	after, ok2 := qualificationByteCreditElapsed(x.enqueue, now)
	if !x.public.EnqueueObserved || !ok1 || !ok2 {
		x.public.Ambiguous = true
		l.ambiguous = true
	} else {
		x.public.EligibilityToCompletionResultObservedNS = whole
		x.public.EnqueueToCompletionResultObservedNS = after
	}
	switch outcome {
	case "success":
		x.public.Active = false
	case "error":
		x.public.Active = false
		x.public.Ambiguous = true
		l.ambiguous = true
	case "completion_shutdown", "completion_timeout":
		x.public.Active = true
		x.public.Ambiguous = true
		l.ambiguous = true
	default:
		x.public.Ambiguous = true
		l.ambiguous = true
	}
}

func applyQualificationByteCredit(s *Stream, delta uint32, flags uint16, entered time.Time) error {
	qualificationByteCreditTrace.mu.Lock()
	defer qualificationByteCreditTrace.mu.Unlock()
	var before, after uint32
	for {
		before = atomic.LoadUint32(&s.sendWindow)
		if delta > math.MaxUint32-before {
			return ErrStreamWindowExceeded
		}
		after = before + delta
		if atomic.CompareAndSwapUint32(&s.sendWindow, before, after) {
			break
		}
	}
	applied := time.Now()
	var l *qualificationByteCreditStreamLedger
	if delta > 0 {
		l = qualificationByteCreditLedgerLocked(s.session, s.id, true)
		if l != nil && flags&uint16(flagFIN|flagRST) != 0 {
			// Production still applies terminal-frame credit and notifies exactly as
			// before. The accepted observer domain excludes it, so retain a sticky
			// ambiguity instead of misclassifying its wake as stale.
			l.ambiguous = true
			asyncNotify(s.sendNotifyCh)
			return nil
		}
		if flags&uint16(flagFIN|flagRST) == 0 && l != nil {
			if !qualificationByteCreditIncrement(&l.peerOrdinal, l) || ^uint64(0)-l.peerCumulative < uint64(delta) {
				l.overflow = true
			} else {
				l.peerCumulative += uint64(delta)
				recorded := false
				for i := range qualificationByteCreditTrace.peer {
					x := &qualificationByteCreditTrace.peer[i]
					if x.used {
						continue
					}
					*x = qualificationByteCreditPeerState{used: true, session: s.session, public: QualificationByteCreditPeerRecord{RelativeOrdinal: l.peerOrdinal, StreamID: s.id, Flags: flags, Delta: delta, Cumulative: l.peerCumulative, ByteCreditBefore: before, ByteCreditAfter: after, HandlerEntryUnixNS: entered.UnixNano(), CreditAppliedUnixNS: applied.UnixNano(), ActiveWaitToken: l.activeWaitToken}}
					if d, ok := qualificationByteCreditElapsed(entered, applied); ok {
						x.public.HandlerToCreditAppliedNS = d
					} else {
						l.ambiguous = true
					}
					delivered := false
					select {
					case s.sendNotifyCh <- struct{}{}:
						delivered = true
					default:
					}
					notified := time.Now()
					x.public.NotifyObservedUnixNS = notified.UnixNano()
					if delivered {
						x.public.NotifyResult = "delivered"
					} else {
						x.public.NotifyResult = "coalesced"
					}
					if d, ok := qualificationByteCreditElapsed(applied, notified); ok {
						x.public.CreditAppliedToNotifyObservedNS = d
					} else {
						l.ambiguous = true
					}
					if d, ok := qualificationByteCreditElapsed(entered, notified); ok {
						x.public.HandlerToNotifyObservedNS = d
					} else {
						l.ambiguous = true
					}
					recorded = true
					break
				}
				if !recorded {
					l.overflow = true
					l.droppedPeer++
					asyncNotify(s.sendNotifyCh)
				}
				return nil
			}
		}
	}
	asyncNotify(s.sendNotifyCh)
	return nil
}

func beginQualificationByteCreditWaitTrace(s *Stream, token uint64, decision uint32) qualificationByteCreditWaitHandle {
	if s == nil || s.session == nil || !s.session.aggregateEnabled() || token == 0 {
		return qualificationByteCreditWaitHandle{}
	}
	qualificationByteCreditTrace.mu.Lock()
	defer qualificationByteCreditTrace.mu.Unlock()
	l := qualificationByteCreditLedgerLocked(s.session, s.id, true)
	if l == nil {
		return qualificationByteCreditWaitHandle{}
	}
	if l.activeWaitToken != 0 {
		l.ambiguous = true
		return qualificationByteCreditWaitHandle{}
	}
	for i := range qualificationByteCreditTrace.waits {
		x := &qualificationByteCreditTrace.waits[i]
		if x.used {
			continue
		}
		now := time.Now()
		credit := atomic.LoadUint32(&s.sendWindow)
		*x = qualificationByteCreditWaitState{used: true, session: s.session, entry: now, public: QualificationByteCreditWaitRecord{Token: token, StreamID: s.id, DecisionCredit: decision, EntryOrdinal: l.peerOrdinal, EntryCumulative: l.peerCumulative, EntryByteCredit: credit, EntryObservedUnixNS: now.UnixNano(), Outcome: "pending", Classification: "pending", Active: true, Ambiguous: decision != 0}}
		if decision != 0 {
			l.ambiguous = true
		}
		l.activeWaitToken = token
		return qualificationByteCreditWaitHandle{session: s.session, streamID: s.id, token: token, valid: true}
	}
	l.overflow = true
	l.droppedWait++
	return qualificationByteCreditWaitHandle{}
}
func qualificationByteCreditWaitStateLocked(h qualificationByteCreditWaitHandle) (*qualificationByteCreditWaitState, *qualificationByteCreditStreamLedger) {
	l := qualificationByteCreditLedgerLocked(h.session, h.streamID, false)
	for i := range qualificationByteCreditTrace.waits {
		x := &qualificationByteCreditTrace.waits[i]
		if x.used && x.public.Active && x.session == h.session && x.public.StreamID == h.streamID && x.public.Token == h.token {
			return x, l
		}
	}
	if l != nil && l.droppedWait == 0 {
		l.ambiguous = true
	}
	return nil, l
}
func observeQualificationByteCreditWaitWake(s *Stream, h qualificationByteCreditWaitHandle) {
	if !h.valid || s == nil {
		return
	}
	qualificationByteCreditTrace.mu.Lock()
	defer qualificationByteCreditTrace.mu.Unlock()
	x, l := qualificationByteCreditWaitStateLocked(h)
	if x == nil || l == nil {
		return
	}
	if !x.wake.IsZero() {
		x.public.Ambiguous = true
		l.ambiguous = true
		return
	}
	now := time.Now()
	x.wake = now
	x.public.WakeObservedUnixNS = now.UnixNano()
	x.public.WakeOrdinal = l.peerOrdinal
	x.public.WakeCumulative = l.peerCumulative
	x.public.WakeByteCredit = atomic.LoadUint32(&s.sendWindow)
	if d, ok := qualificationByteCreditElapsed(x.entry, now); ok {
		x.public.EntryToWakeObservedNS = d
	} else {
		x.public.Ambiguous = true
		l.ambiguous = true
	}
}
func observeQualificationByteCreditWaitRetry(s *Stream, h qualificationByteCreditWaitHandle) {
	if !h.valid || s == nil {
		return
	}
	qualificationByteCreditTrace.mu.Lock()
	defer qualificationByteCreditTrace.mu.Unlock()
	x, l := qualificationByteCreditWaitStateLocked(h)
	if x == nil || l == nil {
		return
	}
	now := time.Now()
	x.public.RetryObservedUnixNS = now.UnixNano()
	x.public.RetryOrdinal = l.peerOrdinal
	x.public.RetryCumulative = l.peerCumulative
	x.public.RetryByteCredit = atomic.LoadUint32(&s.sendWindow)
	x.public.Outcome = "retry"
	if d, ok := qualificationByteCreditElapsed(x.entry, now); ok {
		x.public.EntryToRetryObservedNS = d
	} else {
		x.public.Ambiguous = true
		l.ambiguous = true
	}
	if d, ok := qualificationByteCreditElapsed(x.wake, now); ok {
		x.public.WakeToRetryObservedNS = d
	} else {
		x.public.Ambiguous = true
		l.ambiguous = true
	}
	ao := x.public.RetryOrdinal > x.public.EntryOrdinal
	ac := x.public.RetryCumulative > x.public.EntryCumulative
	x.public.Advanced = ao && ac
	if ao != ac {
		x.public.Ambiguous = true
		l.ambiguous = true
	}
	if x.public.Advanced {
		x.public.RangeFirstOrdinal = x.public.EntryOrdinal + 1
		x.public.RangeLastOrdinal = x.public.RetryOrdinal
		x.public.Classification = "applied_range"
		x.public.RetryZeroAfterAdvance = x.public.RetryByteCredit == 0
		if x.public.RetryZeroAfterAdvance {
			x.public.Ambiguous = true
			l.ambiguous = true
		}
	} else if x.public.EntryByteCredit > 0 {
		x.public.Classification = "pre_entry_buffered"
	} else {
		x.public.Classification = "stale"
	}
	x.public.Active = false
	l.activeWaitToken = 0
}

func qualificationByteCreditTCPCursor(s *Stream, h qualificationByteCreditWaitHandle) (qualificationTCPWaitCursor, uint32, bool) {
	if !h.valid || s == nil || s.session != h.session || s.id != h.streamID {
		return qualificationTCPWaitCursor{}, 0, false
	}
	qualificationByteCreditTrace.mu.Lock()
	defer qualificationByteCreditTrace.mu.Unlock()
	l := qualificationByteCreditLedgerLocked(h.session, h.streamID, false)
	if l == nil {
		return qualificationTCPWaitCursor{}, 0, false
	}
	found := false
	for i := range qualificationByteCreditTrace.waits {
		x := &qualificationByteCreditTrace.waits[i]
		if x.used && x.session == h.session && x.public.StreamID == h.streamID && x.public.Token == h.token {
			if found {
				l.ambiguous = true
				return qualificationTCPWaitCursor{}, 0, false
			}
			found = true
		}
	}
	if !found {
		if l.droppedWait == 0 {
			l.ambiguous = true
		}
		return qualificationTCPWaitCursor{}, 0, false
	}
	return qualificationTCPWaitCursor{Ordinal: l.peerOrdinal, Cumulative: l.peerCumulative}, atomic.LoadUint32(&s.sendWindow), true
}

func qualificationByteCreditWaitClassification(h qualificationByteCreditWaitHandle) string {
	if !h.valid {
		return ""
	}
	qualificationByteCreditTrace.mu.Lock()
	defer qualificationByteCreditTrace.mu.Unlock()
	l := qualificationByteCreditLedgerLocked(h.session, h.streamID, false)
	classification := ""
	for i := range qualificationByteCreditTrace.waits {
		x := &qualificationByteCreditTrace.waits[i]
		if !x.used || x.session != h.session || x.public.StreamID != h.streamID || x.public.Token != h.token {
			continue
		}
		if classification != "" {
			if l != nil {
				l.ambiguous = true
			}
			return ""
		}
		classification = x.public.Classification
		if x.public.RetryZeroAfterAdvance {
			classification = "retry_zero_after_advance"
		}
	}
	return classification
}
func finishQualificationByteCreditWaitTrace(h qualificationByteCreditWaitHandle, outcome string) {
	if !h.valid {
		return
	}
	qualificationByteCreditTrace.mu.Lock()
	defer qualificationByteCreditTrace.mu.Unlock()
	x, l := qualificationByteCreditWaitStateLocked(h)
	if x == nil || l == nil {
		return
	}
	x.public.Outcome = outcome
	x.public.Classification = outcome
	x.public.Terminal = true
	x.public.Active = false
	l.activeWaitToken = 0
	if outcome != "shutdown" && outcome != "timeout" {
		x.public.Ambiguous = true
		l.ambiguous = true
	}
}

func (session *Session) DrainQualificationByteCreditTrace() QualificationByteCreditTraceSnapshot {
	out := QualificationByteCreditTraceSnapshot{
		SchemaVersion:   QualificationByteCreditTraceSchemaVersion,
		Enabled:         true,
		ReceiverRecords: []QualificationByteCreditReceiverRecord{},
		PeerRecords:     []QualificationByteCreditPeerRecord{},
		WaitRecords:     []QualificationByteCreditWaitRecord{},
	}
	if session == nil {
		out.Ambiguous = true
		return out
	}
	qualificationByteCreditTrace.mu.Lock()
	defer qualificationByteCreditTrace.mu.Unlock()
	out.OrphanOverflow = qualificationByteCreditTrace.orphanOverflow
	for i := range qualificationByteCreditTrace.receiver {
		x := &qualificationByteCreditTrace.receiver[i]
		if x.used && x.session == session {
			out.ReceiverRecords = append(out.ReceiverRecords, x.public)
			if x.public.Active {
				out.ActiveReceiverPublications++
			}
			out.Ambiguous = out.Ambiguous || x.public.Ambiguous
		}
	}
	for i := range qualificationByteCreditTrace.peer {
		x := &qualificationByteCreditTrace.peer[i]
		if x.used && x.session == session {
			out.PeerRecords = append(out.PeerRecords, x.public)
		}
	}
	for i := range qualificationByteCreditTrace.waits {
		x := &qualificationByteCreditTrace.waits[i]
		if x.used && x.session == session {
			out.WaitRecords = append(out.WaitRecords, x.public)
			if x.public.Active {
				out.ActivePeerWaits++
			}
			out.Ambiguous = out.Ambiguous || x.public.Ambiguous
		}
	}
	for i := range qualificationByteCreditTrace.ledgers {
		l := &qualificationByteCreditTrace.ledgers[i]
		if !l.used || l.session != session {
			continue
		}
		out.Ambiguous = out.Ambiguous || l.ambiguous
		out.Overflow = out.Overflow || l.overflow
		out.DroppedReceiverRecords += l.droppedReceiver
		out.DroppedPeerRecords += l.droppedPeer
		out.DroppedWaitRecords += l.droppedWait
	}
	sort.Slice(out.ReceiverRecords, func(i, j int) bool {
		a, b := out.ReceiverRecords[i], out.ReceiverRecords[j]
		if a.StreamID != b.StreamID {
			return a.StreamID < b.StreamID
		}
		return a.RelativeOrdinal < b.RelativeOrdinal
	})
	sort.Slice(out.PeerRecords, func(i, j int) bool {
		a, b := out.PeerRecords[i], out.PeerRecords[j]
		if a.StreamID != b.StreamID {
			return a.StreamID < b.StreamID
		}
		return a.RelativeOrdinal < b.RelativeOrdinal
	})
	sort.Slice(out.WaitRecords, func(i, j int) bool {
		a, b := out.WaitRecords[i], out.WaitRecords[j]
		if a.StreamID != b.StreamID {
			return a.StreamID < b.StreamID
		}
		return a.Token < b.Token
	})
	out.Complete = out.ActiveReceiverPublications == 0 && out.ActivePeerWaits == 0 && !out.Ambiguous && !out.Overflow && !out.OrphanOverflow && out.DroppedReceiverRecords == 0 && out.DroppedPeerRecords == 0 && out.DroppedWaitRecords == 0
	out.ResetPerformed = out.Complete
	if out.Complete {
		for i := range qualificationByteCreditTrace.receiver {
			if qualificationByteCreditTrace.receiver[i].used && qualificationByteCreditTrace.receiver[i].session == session {
				qualificationByteCreditTrace.receiver[i] = qualificationByteCreditReceiverState{}
			}
		}
		for i := range qualificationByteCreditTrace.peer {
			if qualificationByteCreditTrace.peer[i].used && qualificationByteCreditTrace.peer[i].session == session {
				qualificationByteCreditTrace.peer[i] = qualificationByteCreditPeerState{}
			}
		}
		for i := range qualificationByteCreditTrace.waits {
			if qualificationByteCreditTrace.waits[i].used && qualificationByteCreditTrace.waits[i].session == session {
				qualificationByteCreditTrace.waits[i] = qualificationByteCreditWaitState{}
			}
		}
		for i := range qualificationByteCreditTrace.ledgers {
			if qualificationByteCreditTrace.ledgers[i].used && qualificationByteCreditTrace.ledgers[i].session == session {
				qualificationByteCreditTrace.ledgers[i] = qualificationByteCreditStreamLedger{}
			}
		}
	}
	return out
}
