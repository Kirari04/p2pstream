# Source checkpoint 4 in-place mutation incident

`source-checkpoint-4` was announced frozen with manifest SHA-256 `3de07e56394e9955b498ca0f56e181a04cf9c760369e73b93b45b72d0a93f`. Before execution, its provenance was changed in place and later announced with manifest SHA-256 `4ad1687ed0714983758d8c3936a4d5b41e044895832c2b733d6c6f3f1389e4ae`.

The confirmed affected provenance paths are `SHA256SUMS.txt`, the added `CP2-TO-CP3.diff`, and the replaced/regenerated `CP3-TO-CP4.diff`. The initially announced manifest bytes and original cp3-to-cp4 diff bytes were not preserved. Removing only the added cp2-to-cp3 ledger line from the replacement yields `1534c5f41c84a532044c6e9e17ecd1eb01af43b1cbb93c47790d7e65a77f5125`, not the announced hash, so the missing original cannot be represented as that single-line change.

No Go command, build, endpoint, or traffic used checkpoint 4. The 12 reviewed source/test payload files were not changed by this provenance repair, but checkpoint 4 is rejected as an immutable source authority. A fresh checkpoint 5 carries the byte-identical reviewed payload and binds this incident.
