# TCP-state local publication source 2

Binding-only successor for accepted runner2 materialization attempt 2. It publishes the same three accepted receipts into fresh integration-source-2/provenance. Binary bytes remain at audited build attempt 2 paths. No endpoint or traffic is run.
