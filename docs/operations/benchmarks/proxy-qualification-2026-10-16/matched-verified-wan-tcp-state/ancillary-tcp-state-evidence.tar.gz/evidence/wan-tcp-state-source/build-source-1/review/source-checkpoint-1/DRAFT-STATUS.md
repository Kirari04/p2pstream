# Draft status

This directory is mutable source-only review work. It is not a frozen
checkpoint. It intentionally has no `SHA256SUMS.txt`, and its approved-input
template retains `PENDING` build checkpoint/driver hashes.

No command in this driver has run. The immutable TCP overlay checkpoint and
exact normal/race test event sets are now bound. Finalization requires source
review and a new immutable checkpoint manifest.
