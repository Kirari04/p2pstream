import importlib.util,json,pathlib
p=pathlib.Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-tcp-state-source/review/sustained-tcp-state-launch-source-1/run-sustained.py")
spec=importlib.util.spec_from_file_location("s",p)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
e=m.expected_corpus()
r=m.verify_fixed_inputs(e,post=False)
print(json.dumps({"accepted":True,"expected_corpus_files":len(e),"active_corpus_files":len(r["active_corpus"]),"tiny_run_ledger_sha256":r["tiny_run_ledger_sha256"],"tiny_review_ledger_sha256":r["tiny_review_ledger_sha256"],"tiny_outer_ledger_sha256":r["tiny_outer_ledger_sha256"],"audited_binaries":r["audited_binaries"]},sort_keys=True))
