# TCP-state integration runner source checkpoint 3

Status: source-only and unexecuted. Runtime, validators, wrappers, generated runner, timed transfer body, and receipt bindings are byte-identical to checkpoint 2. The sole corpus change corrects the TCP source contract to assert the actual unchanged 4 MiB read/length/rejection path and the omission size/hash fields in the exact cp6 producer source bound by its verified SOURCE-MAP. Checkpoints 1/2 and failed contract attempts remain preserved. Fresh materialization/publication/contracts are required; no endpoint or traffic ran.
