#!/usr/bin/env bash
set -Eeuo pipefail
exec /usr/bin/env \
  -u P2PSTREAM_QUALIFICATION_PROFILE_DIR \
  -u P2PSTREAM_QUALIFICATION_PROFILE_MODE \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_DIR \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_SEQUENCES \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_BEARER \
  /usr/bin/taskset -c 0-15 \
  /usr/bin/bash \
  /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-tcp-state-source/integration-source-3/integration/run-wan-below-tls-diagnostic.sh \
  --server-binary /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-tcp-state-source/build-source-1/runs/audited-build-attempt-2/bin/current-server-wan-tcp-state-audited.test \
  --aggregate-agent-binary /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-tcp-state-source/build-source-1/runs/audited-build-attempt-2/bin/current-agent-wan-tcp-state-audited.test \
  --server-source-ref 8ac4c8df8237e37777ba2fac0da6f949da17bdea+tcp-state-corpus-0595c8e5fa4b19bc6612b409cfe69b7ddd0d4f7fa190a6dc26e27fd610648cd4 \
  --aggregate-agent-source-ref 8ac4c8df8237e37777ba2fac0da6f949da17bdea+tcp-state-corpus-0595c8e5fa4b19bc6612b409cfe69b7ddd0d4f7fa190a6dc26e27fd610648cd4 \
  --output-dir /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-tcp-state-source/integration-source-3/integration/runs/tiny-tcp-state-smoke-1 \
  --small-diagnostic
