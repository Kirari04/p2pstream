# TCP-state validator contract invocation source 1

This unexecuted source invokes validator checkpoint 2 through the reviewed
owned-process helper in one bounded process group. It pins the checkpoint,
contract driver, Python, Bash, and helper bytes; records inner and outer direct
statuses; requires a natural join; and rechecks all inputs after execution.
It runs no Go command, endpoint, or WAN traffic.
