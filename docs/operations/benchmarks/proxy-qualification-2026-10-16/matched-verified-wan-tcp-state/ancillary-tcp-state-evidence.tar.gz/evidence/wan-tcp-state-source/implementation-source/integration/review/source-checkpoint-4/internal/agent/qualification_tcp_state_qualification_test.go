//go:build linux && p2pstream_qualification

package agent

import (
	"net"
	"testing"
	"time"

	"github.com/hashicorp/yamux"
)

func qualificationTCPStateTestOwner(t *testing.T) (*qualificationRawWriteOwner, *net.TCPConn, *net.TCPConn) {
	t.Helper()
	listener, err := net.ListenTCP("tcp4", &net.TCPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		t.Fatalf("ListenTCP: %v", err)
	}
	t.Cleanup(func() { _ = listener.Close() })
	if err := listener.SetDeadline(time.Now().Add(5 * time.Second)); err != nil {
		t.Fatalf("listener SetDeadline: %v", err)
	}
	client, err := net.DialTCP("tcp4", nil, listener.Addr().(*net.TCPAddr))
	if err != nil {
		t.Fatalf("DialTCP: %v", err)
	}
	t.Cleanup(func() { _ = client.Close() })
	server, err := listener.AcceptTCP()
	if err != nil {
		t.Fatalf("AcceptTCP: %v", err)
	}
	t.Cleanup(func() { _ = server.Close() })
	if err := listener.Close(); err != nil {
		t.Fatalf("listener Close: %v", err)
	}
	raw, err := client.SyscallConn()
	if err != nil {
		t.Fatalf("SyscallConn: %v", err)
	}
	baseline, err := qualificationCaptureTCPInfo(raw)
	if err != nil {
		t.Fatalf("capture baseline: %v", err)
	}
	owner := &qualificationRawWriteOwner{
		lane: 0, generation: 1, rawBound: true, bodyBound: true,
		localAddr: client.LocalAddr(), remoteAddr: client.RemoteAddr(),
		localAddress: client.LocalAddr().String(), remoteAddress: client.RemoteAddr().String(),
	}
	if !owner.bindTCPState(raw, baseline, 1) {
		t.Fatal("bind TCP state")
	}
	return owner, client, server
}

func qualificationTCPStateFinishSample(owner *qualificationRawWriteOwner, sampleID, ordinal, cumulative uint64) {
	owner.finishTCPWaitSample(sampleID, ordinal, cumulative, true)
}

func qualificationTCPStateAppliedWait(t *testing.T, owner *qualificationRawWriteOwner, streamID uint32, waitToken uint64, ordinal, cumulative uint64) {
	t.Helper()
	entry := owner.beginTCPWaitSample("entry", streamID, waitToken, "pending", ordinal, cumulative, 0, time.Now())
	if entry == 0 {
		t.Fatal("entry sample was not recorded")
	}
	qualificationTCPStateFinishSample(owner, entry, ordinal, cumulative)
	retry := owner.beginTCPWaitSample("retry", streamID, waitToken, "applied_range", ordinal, cumulative, 65536, time.Now())
	if retry == 0 {
		t.Fatal("retry sample was not recorded")
	}
	qualificationTCPStateFinishSample(owner, retry, ordinal, cumulative)
}

func qualificationTCPStateContainedWrite(t *testing.T, owner *qualificationRawWriteOwner, conn net.Conn, streamID uint32) {
	t.Helper()
	token := owner.beginEnvelope(streamID, 1, 13, time.Now())
	if token == 0 {
		t.Fatal("DATA envelope did not start")
	}
	observed := &qualificationObservedRawConn{Conn: conn, owner: owner}
	if n, err := observed.Write([]byte{1}); err != nil || n != 1 {
		t.Fatalf("raw write n=%d err=%v", n, err)
	}
	owner.finishEnvelopeNow(token)
}

func TestQualificationTCPStateWaitAndRawPairLifecycle(t *testing.T) {
	owner, client, _ := qualificationTCPStateTestOwner(t)
	if !owner.armTCPInterval("9") {
		t.Fatal("arm TCP interval")
	}
	entry := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
	if entry == 0 {
		t.Fatal("entry sample was not recorded")
	}
	qualificationTCPStateFinishSample(owner, entry, 0, 0)
	retry := owner.beginTCPWaitSample("retry", 7, 11, "applied_range", 1, 65536, 65536, time.Now())
	if retry == 0 {
		t.Fatal("retry sample was not recorded")
	}
	qualificationTCPStateFinishSample(owner, retry, 1, 65536)

	token := owner.beginEnvelope(7, 1, 13, time.Now())
	if token == 0 {
		t.Fatal("DATA envelope did not start")
	}
	observed := &qualificationObservedRawConn{Conn: client, owner: owner}
	if n, err := observed.Write([]byte{1}); err != nil || n != 1 {
		t.Fatalf("raw write n=%d err=%v", n, err)
	}
	owner.finishEnvelopeNow(token)
	if !owner.disarmTCPInterval("9") {
		t.Fatal("disarm TCP interval")
	}
	activity := owner.drain().TCPState
	if !activity.Complete || !activity.ResetPerformed || activity.Invalid || activity.Ambiguous || activity.Overflow ||
		activity.Sequence != "9" || len(activity.WaitRecords) != 1 || len(activity.RawPairs) != 1 {
		t.Fatalf("TCP activity = %+v", activity)
	}
	wait, pair := activity.WaitRecords[0], activity.RawPairs[0]
	if wait.RecordID == 0 || wait.RawPairRecordID != pair.RecordID || wait.StreamID != pair.StreamID ||
		wait.WaitToken != pair.WaitToken || !pair.Committed || pair.Active || !pair.BracketValid ||
		!wait.Entry.Complete || !wait.Retry.Complete || wait.Retry.Classification != "applied_range" || wait.Retry.Credit == 0 {
		t.Fatalf("wait=%+v pair=%+v", wait, pair)
	}
}

func TestQualificationTCPStateUnarmedConditioningIsIgnored(t *testing.T) {
	owner, _, _ := qualificationTCPStateTestOwner(t)
	if sample := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now()); sample != 0 {
		t.Fatalf("unarmed entry sample=%d, want 0", sample)
	}
	if sample := owner.beginTCPWaitSample("retry", 7, 11, "applied_range", 1, 65536, 65536, time.Now()); sample != 0 {
		t.Fatalf("unarmed retry sample=%d, want 0", sample)
	}
	owner.markTCPInterveningAllocation(7, 11)
	if !owner.armTCPInterval("9") || !owner.disarmTCPInterval("9") {
		t.Fatal("unarmed conditioning poisoned the next healthy interval")
	}
	activity := owner.drain().TCPState
	if !activity.Complete || activity.Invalid || len(activity.WaitRecords) != 0 || len(activity.RawPairs) != 0 {
		t.Fatalf("activity after unarmed conditioning = %+v", activity)
	}
}

func TestQualificationTCPStateLastLiveCaptureIsChronological(t *testing.T) {
	owner, _, _ := qualificationTCPStateTestOwner(t)
	owner.mu.Lock()
	baseline := owner.tcp.lastLiveTCPInfo
	newer := baseline
	newer.captureStarted = baseline.captureFinished.Add(time.Millisecond)
	newer.captureFinished = newer.captureStarted.Add(time.Microsecond)
	newer.CaptureStartedUnixNS = newer.captureStarted.UnixNano()
	newer.CaptureFinishedUnixNS = newer.captureFinished.UnixNano()
	older := baseline
	older.captureStarted = baseline.captureFinished.Add(500 * time.Microsecond)
	older.captureFinished = older.captureStarted.Add(time.Microsecond)
	older.CaptureStartedUnixNS = older.captureStarted.UnixNano()
	older.CaptureFinishedUnixNS = older.captureFinished.UnixNano()
	owner.recordTCPCaptureLocked(newer, nil)
	owner.recordTCPCaptureLocked(older, nil)
	got := owner.tcp.lastLiveTCPInfo
	owner.mu.Unlock()
	if !got.captureFinished.Equal(newer.captureFinished) || got.CaptureFinishedUnixNS != newer.CaptureFinishedUnixNS {
		t.Fatalf("last live capture regressed: got=%+v newer=%+v older=%+v", got, newer, older)
	}
}

func TestQualificationTCPStateJoinControls(t *testing.T) {
	t.Run("equal_cursor_applied_range", func(t *testing.T) {
		owner, client, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		qualificationTCPStateAppliedWait(t, owner, 7, 11, 4, 65536)
		qualificationTCPStateContainedWrite(t, owner, client, 7)
		if !owner.disarmTCPInterval("9") {
			t.Fatal("disarm")
		}
		activity := owner.drain().TCPState
		if !activity.Complete || len(activity.WaitRecords) != 1 || len(activity.RawPairs) != 1 ||
			activity.WaitRecords[0].Entry.CursorBeforeOrdinal != activity.WaitRecords[0].Retry.CursorBeforeOrdinal ||
			activity.WaitRecords[0].Entry.CursorBeforeCumulative != activity.WaitRecords[0].Retry.CursorBeforeCumulative ||
			!activity.RawPairs[0].Committed {
			t.Fatalf("equal-cursor applied activity = %+v", activity)
		}
	})

	t.Run("intervening_allocation", func(t *testing.T) {
		owner, client, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		qualificationTCPStateAppliedWait(t, owner, 7, 11, 4, 65536)
		owner.markTCPInterveningAllocation(7, 11)
		qualificationTCPStateContainedWrite(t, owner, client, 7)
		if !owner.disarmTCPInterval("9") {
			t.Fatal("disarm")
		}
		activity := owner.drain().TCPState
		if !activity.Complete || len(activity.WaitRecords) != 1 || !activity.WaitRecords[0].InterveningAllocation ||
			len(activity.RawPairs) != 1 || !activity.RawPairs[0].Committed {
			t.Fatalf("allocation-confounded activity = %+v", activity)
		}
	})

	t.Run("interleaved_two_streams", func(t *testing.T) {
		owner, client, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		for _, stream := range []uint32{7, 8} {
			entry := owner.beginTCPWaitSample("entry", stream, uint64(stream+100), "pending", 0, 0, 0, time.Now())
			qualificationTCPStateFinishSample(owner, entry, 0, 0)
		}
		for _, stream := range []uint32{8, 7} {
			retry := owner.beginTCPWaitSample("retry", stream, uint64(stream+100), "applied_range", 1, 65536, 65536, time.Now())
			qualificationTCPStateFinishSample(owner, retry, 1, 65536)
		}
		qualificationTCPStateContainedWrite(t, owner, client, 7)
		qualificationTCPStateContainedWrite(t, owner, client, 8)
		if !owner.disarmTCPInterval("9") {
			t.Fatal("disarm")
		}
		activity := owner.drain().TCPState
		if !activity.Complete || len(activity.WaitRecords) != 2 || len(activity.RawPairs) != 2 ||
			!activity.RawPairs[0].Committed || !activity.RawPairs[1].Committed {
			t.Fatalf("two-stream activity = %+v", activity)
		}
	})

	t.Run("excluded_retry_classes", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		classes := []string{"stale", "pre_entry_buffered", "timeout", "shutdown"}
		for index, classification := range classes {
			streamID, token := uint32(index+1), uint64(index+1)
			entry := owner.beginTCPWaitSample("entry", streamID, token, "pending", 0, 0, 0, time.Now())
			qualificationTCPStateFinishSample(owner, entry, 0, 0)
			retry := owner.beginTCPWaitSample("retry", streamID, token, classification, 0, 0, 0, time.Now())
			qualificationTCPStateFinishSample(owner, retry, 0, 0)
		}
		if !owner.disarmTCPInterval("9") {
			t.Fatal("disarm")
		}
		activity := owner.drain().TCPState
		if !activity.Complete || len(activity.WaitRecords) != len(classes) || len(activity.RawPairs) != 0 {
			t.Fatalf("excluded retry activity = %+v", activity)
		}
		for index, record := range activity.WaitRecords {
			if record.Retry.Classification != classes[index] || record.PendingRaw || record.Claimed || record.RawPairRecordID != 0 {
				t.Fatalf("excluded retry record[%d] = %+v", index, record)
			}
		}
	})
}

func TestQualificationTCPStateRawPairBoundariesAndFinishCommit(t *testing.T) {
	t.Run("finish_only_commit", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		qualificationTCPStateAppliedWait(t, owner, 7, 11, 0, 0)
		token := owner.beginEnvelope(7, 1, 13, time.Now())
		underlying := &qualificationRawWriteTestConn{started: make(chan struct{}), release: make(chan struct{}), written: -1, closeUnblocks: true}
		observed := &qualificationObservedRawConn{Conn: underlying, owner: owner}
		done := make(chan error, 1)
		joined := false
		t.Cleanup(func() {
			_ = underlying.Close()
			if joined {
				return
			}
			select {
			case <-done:
			case <-time.After(5 * time.Second):
				t.Errorf("blocked raw writer did not join during cleanup")
			}
		})
		go func() {
			_, err := observed.Write([]byte{1})
			done <- err
		}()
		select {
		case <-underlying.started:
		case <-time.After(5 * time.Second):
			t.Fatal("timed out waiting for blocked raw writer")
		case <-t.Context().Done():
			t.Fatal(t.Context().Err())
		}
		owner.mu.Lock()
		if owner.tcp.rawPairCount != 1 || !owner.tcp.rawPairs[0].Active || owner.tcp.rawPairs[0].Committed {
			got := owner.tcp.rawPairs[0]
			owner.mu.Unlock()
			t.Fatalf("pre-finish pair = %+v", got)
		}
		owner.mu.Unlock()
		underlying.closeOnce.Do(func() { close(underlying.release) })
		select {
		case err := <-done:
			joined = true
			if err != nil {
				t.Fatal(err)
			}
		case <-time.After(5 * time.Second):
			t.Fatal("timed out joining blocked raw writer")
		case <-t.Context().Done():
			t.Fatal(t.Context().Err())
		}
		owner.finishEnvelopeNow(token)
		if !owner.disarmTCPInterval("9") {
			t.Fatal("disarm")
		}
		activity := owner.drain().TCPState
		if !activity.Complete || len(activity.RawPairs) != 1 || !activity.RawPairs[0].Committed || activity.RawPairs[0].Active {
			t.Fatalf("post-finish pair = %+v", activity)
		}
	})

	for _, test := range []struct {
		name       string
		streamID   uint32
		startWrite bool
		straddle   bool
	}{
		{name: "mismatched_stream", streamID: 8, startWrite: true},
		{name: "straddling", streamID: 7, startWrite: true, straddle: true},
		{name: "missing_first_write", streamID: 7},
	} {
		t.Run(test.name, func(t *testing.T) {
			owner, _, _ := qualificationTCPStateTestOwner(t)
			if !owner.armTCPInterval("9") {
				t.Fatal("arm")
			}
			qualificationTCPStateAppliedWait(t, owner, 7, 11, 0, 0)
			token := owner.beginEnvelope(test.streamID, 1, 13, time.Now())
			if test.startWrite {
				underlying := &qualificationRawWriteTestConn{written: -1}
				if test.straddle {
					underlying.started = make(chan struct{})
					underlying.release = make(chan struct{})
					underlying.closeUnblocks = true
				}
				observed := &qualificationObservedRawConn{Conn: underlying, owner: owner}
				if test.straddle {
					done := make(chan error, 1)
					joined := false
					t.Cleanup(func() {
						_ = underlying.Close()
						if joined {
							return
						}
						select {
						case <-done:
						case <-time.After(5 * time.Second):
							t.Errorf("straddling raw writer did not join during cleanup")
						}
					})
					go func() { _, err := observed.Write([]byte{1}); done <- err }()
					select {
					case <-underlying.started:
					case <-time.After(5 * time.Second):
						t.Fatal("timed out waiting for straddling raw writer")
					case <-t.Context().Done():
						t.Fatal(t.Context().Err())
					}
					owner.finishEnvelopeNow(token)
					underlying.closeOnce.Do(func() { close(underlying.release) })
					select {
					case err := <-done:
						joined = true
						if err != nil {
							t.Fatal(err)
						}
					case <-time.After(5 * time.Second):
						t.Fatal("timed out joining straddling raw writer")
					case <-t.Context().Done():
						t.Fatal(t.Context().Err())
					}
				} else if n, err := observed.Write([]byte{1}); err != nil || n != 1 {
					t.Fatalf("raw write n=%d err=%v", n, err)
				}
			}
			if !test.straddle {
				owner.finishEnvelopeNow(token)
			}
			if owner.disarmTCPInterval("9") {
				t.Fatal("invalid pair state disarmed successfully")
			}
			activity := owner.drain().TCPState
			if activity.Complete || !activity.Invalid || !activity.Ambiguous {
				t.Fatalf("invalid pair activity = %+v", activity)
			}
		})
	}
}

func TestQualificationTCPStateStickyInvalidation(t *testing.T) {
	t.Run("entry_without_retry", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		entry := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
		qualificationTCPStateFinishSample(owner, entry, 0, 0)
		if owner.disarmTCPInterval("9") {
			t.Fatal("incomplete wait disarmed successfully")
		}
		first := owner.drain().TCPState
		second := owner.drain().TCPState
		if first.Complete || !first.Invalid || second.Complete || !second.Invalid || owner.armTCPInterval("11") {
			t.Fatalf("sticky snapshots first=%+v second=%+v", first, second)
		}
	})
	t.Run("capture_error", func(t *testing.T) {
		owner, client, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		if err := client.Close(); err != nil {
			t.Fatalf("close client: %v", err)
		}
		sample := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
		if sample == 0 {
			t.Fatal("failed capture did not retain its sample")
		}
		qualificationTCPStateFinishSample(owner, sample, 0, 0)
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || activity.CaptureErrors == 0 || activity.WaitRecords[0].Entry.TCPInfo.FailureStage == "" {
			t.Fatalf("capture failure activity = %+v", activity)
		}
	})
	t.Run("duplicate", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		entry := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
		qualificationTCPStateFinishSample(owner, entry, 0, 0)
		if duplicate := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now()); duplicate != 0 {
			t.Fatalf("duplicate sample=%d, want 0", duplicate)
		}
		if activity := owner.drain().TCPState; activity.Complete || !activity.Invalid || !activity.Ambiguous {
			t.Fatalf("duplicate activity = %+v", activity)
		}
	})
	t.Run("overflow", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		owner.mu.Lock()
		owner.tcp.waitCount = yamux.QualificationTCPStateRecordLimit
		owner.mu.Unlock()
		if sample := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now()); sample != 0 {
			t.Fatalf("overflow sample=%d, want 0", sample)
		}
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || !activity.Overflow || activity.DroppedWaitRecords != 1 {
			t.Fatalf("overflow activity = %+v", activity)
		}
	})
	t.Run("applied_zero", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		entry := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
		qualificationTCPStateFinishSample(owner, entry, 0, 0)
		retry := owner.beginTCPWaitSample("retry", 7, 11, "applied_range", 1, 1, 0, time.Now())
		qualificationTCPStateFinishSample(owner, retry, 1, 1)
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || !activity.Ambiguous {
			t.Fatalf("zero-credit applied activity = %+v", activity)
		}
	})
	t.Run("unknown_allocation", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		owner.markTCPInterveningAllocation(7, 99)
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || !activity.Ambiguous {
			t.Fatalf("unknown allocation activity = %+v", activity)
		}
	})
	t.Run("cursor_after_unavailable", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		entry := owner.beginTCPWaitSample("entry", 7, 11, "pending", 0, 0, 0, time.Now())
		owner.finishTCPWaitSample(entry, 0, 0, false)
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || !activity.Ambiguous || activity.WaitRecords[0].Entry.CursorAfterValid {
			t.Fatalf("unavailable after-cursor activity = %+v", activity)
		}
	})
	t.Run("congestion_algorithm_changed", func(t *testing.T) {
		owner, _, _ := qualificationTCPStateTestOwner(t)
		if !owner.armTCPInterval("9") {
			t.Fatal("arm")
		}
		owner.mu.Lock()
		changed := owner.tcp.bindTCPInfo
		changed.CongestionControl += "-changed"
		owner.recordTCPCaptureLocked(changed, nil)
		owner.mu.Unlock()
		activity := owner.drain().TCPState
		if activity.Complete || !activity.Invalid || !activity.Ambiguous {
			t.Fatalf("changed congestion-control activity = %+v", activity)
		}
	})
}
