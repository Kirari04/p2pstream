# TCP-state diagnostic implementation checkpoint 1

This qualification-only overlay adds synchronous, bracketed Linux TCP_INFO and TCP_CONGESTION snapshots to the existing owned raw-write observer. It changes no socket option, receive-window policy, timeout, wire format, ordinary build file, dependency, background work, or production runtime constant.

The authenticated four selected pre/post actions arm and disarm exactly five pre-existing owned sessions. Fixed 4096 wait-record and raw-pair arrays are memory-safety limits. The existing 4 MiB response limit remains unchanged: an oversized response is rejected with the existing bounded failure metadata (attempted byte count and digest), never truncated or accepted.

A wait entry and its retry retain synchronous TCP samples, byte-credit cursor brackets, fixed classifications, and owner-relative monotonic coordinates. Only a positive applied-range retry can claim the first contained raw-write pair for the same stream. Allocation waits remain explicit confounders. Capture errors, unsupported lengths, ownership changes, ambiguity, overflow, incomplete records, and terminal activity are sticky invalid states that cannot be reset into a healthy interval.

The terminal sidecar performs no closed-socket query. It retains the last successful live TCP snapshot and independently binds the setup and terminal tcp_slow_start_after_idle values outside observer locks.

No Go test, build, endpoint, namespace, or traffic command was executed for this checkpoint. The only source-preparation command was gofmt from the pinned Go 1.26.6 toolchain, SHA256 0ef6fe2d15c972d15b8ecb75dcb9c861e042ac94a0e48baf0202a840648b0fdc.
