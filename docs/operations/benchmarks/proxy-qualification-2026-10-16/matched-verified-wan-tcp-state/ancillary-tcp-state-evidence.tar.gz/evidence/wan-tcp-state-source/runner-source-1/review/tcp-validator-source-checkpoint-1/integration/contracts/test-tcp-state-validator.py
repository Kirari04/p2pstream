#!/usr/bin/env python3
"""Focused source contract for the additive TCP-state validator.

This file is source-only until the producer schema and runner successor are
independently reviewed and frozen.
"""
from __future__ import annotations

import copy
import importlib.util
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("tcp_state_validator", ROOT / "validate-tcp-state.py")
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("load TCP-state validator")
validator = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(validator)


def info(base: int, *, congestion: str = "cubic") -> dict:
    value = {key: 0 for key in validator.INFO_FIELDS}
    value.update({
        "schema_version": 1,
        "captured": True,
        "capture_started_unix_ns": 1_000_000 + base,
        "capture_finished_unix_ns": 1_000_005 + base,
        "capture_duration_ns": 5,
        "capture_monotonic_valid": True,
        "capture_started_monotonic_ns": base,
        "capture_finished_monotonic_ns": base + 5,
        "tcp_info_attempted": True,
        "tcp_info_succeeded": True,
        "tcp_info_optlen": 280,
        "tcp_info_struct_size": 280,
        "required_field_end_offset": 248,
        "congestion_control_attempted": True,
        "congestion_control_succeeded": True,
        "congestion_control_optlen": len(congestion) + 1,
        "congestion_control": congestion,
        "failure_stage": "",
        "failure_errno": 0,
        "availability": {key: True for key in validator.AVAILABILITY_FIELDS},
        "state": 1,
    })
    return value


def sample(sample_id: int, kind: str, classification: str, observed: int,
           ordinal: int, cumulative: int, capture: int, *, credit: int = 0,
           after_ordinal: int | None = None, after_cumulative: int | None = None) -> dict:
    final_ordinal = ordinal if after_ordinal is None else after_ordinal
    final_cumulative = cumulative if after_cumulative is None else after_cumulative
    return {
        "present": True, "complete": True, "capture_error": False,
        "sample_id": sample_id, "kind": kind, "classification": classification,
        "credit": credit, "observed_unix_ns": 1_000_000 + observed,
        "observed_monotonic_valid": True, "observed_monotonic_ns": observed,
        "cursor_before_ordinal": ordinal, "cursor_before_cumulative": cumulative,
        "cursor_after_valid": True,
        "cursor_after_ordinal": final_ordinal, "cursor_after_cumulative": final_cumulative,
        "cursor_changed": (ordinal, cumulative) != (final_ordinal, final_cumulative),
        "tcp_info": info(capture),
    }


def absent_info() -> dict:
    value = {key: 0 for key in validator.INFO_FIELDS}
    value.update({
        "captured": False,
        "capture_monotonic_valid": False,
        "tcp_info_attempted": False,
        "tcp_info_succeeded": False,
        "congestion_control_attempted": False,
        "congestion_control_succeeded": False,
        "congestion_control": "",
        "failure_stage": "",
        "availability": {key: False for key in validator.AVAILABILITY_FIELDS},
    })
    return value


def activity() -> dict:
    entry = sample(1, "entry", "pending", 100, 0, 0, 101, credit=0,
                   after_ordinal=1, after_cumulative=65_536)
    retry = sample(2, "retry", "applied_range", 200, 1, 65_536, 201, credit=65_536)
    wait = {
        "record_id": 1, "stream_id": 7, "wait_token": 9,
        "intervening_allocation": False, "pending_raw": False, "claimed": False,
        "raw_pair_record_id": 2, "active": False, "ambiguous": False,
        "entry": entry, "retry": retry,
    }
    pair = {
        "record_id": 2, "wait_record_id": 1, "stream_id": 7, "wait_token": 9,
        "envelope_token": 11, "committed": True, "active": False, "ambiguous": False,
        "before_capture_error": False, "after_capture_error": False, "bracket_valid": True,
        "raw_write_started_unix_ns": 1_000_307, "raw_write_finished_unix_ns": 1_000_310,
        "raw_write_monotonic_valid": True, "raw_write_started_monotonic_ns": 307,
        "raw_write_finished_monotonic_ns": 310, "additional_contained_raw_writes": 0,
        "before": info(301), "after": info(311),
    }
    return {
        "schema_version": 1, "enabled": True, "bound": True, "armed": False,
        "sequence": "9", "complete": True, "reset_performed": True, "invalid": False,
        "ambiguous": False, "overflow": False, "tcp_slow_start_after_idle": 1,
        "active_samples": 0, "pending_raw_claims": 0, "active_raw_pairs": 0,
        "dropped_wait_records": 0, "dropped_raw_pair_records": 0,
        "capture_calls": 6, "capture_errors": 0,
        "capture_duration": {"count": 6, "total_nanoseconds": 30, "max_nanoseconds": 5},
        "bind_tcp_info": info(0), "last_live_tcp_info": info(400),
        "pre_tcp_info": info(10), "post_tcp_info": info(400),
        "wait_records": [wait], "raw_pairs": [pair],
    }


def accepted(value: dict, *, waits: list[dict] | None = None) -> bool:
    selected = waits if waits is not None else [{
        "token": 9, "stream_id": 7, "classification": "applied_range",
        "entry_ordinal": 0, "entry_cumulative": 0, "entry_byte_credit": 0,
        "entry_observed_unix_ns": 1_000_099,
        "retry_ordinal": 1, "retry_cumulative": 65_536, "retry_byte_credit": 0,
        "retry_observed_unix_ns": 1_000_199,
    }]
    return validator.validate_live(value, sequence=9, selected_stream_id=7, selected_waits=selected)["accepted"]


def main() -> int:
    base = activity()
    cases: list[tuple[str, bool]] = [("valid", accepted(base))]

    boundary = copy.deepcopy(base)
    boundary.update({
        "sequence": "", "capture_calls": 0,
        "capture_duration": {"count": 0, "total_nanoseconds": 0, "max_nanoseconds": 0},
        "pre_tcp_info": absent_info(), "post_tcp_info": absent_info(),
        "wait_records": [], "raw_pairs": [],
    })
    cases.append(("exact-zero-boundary", validator.validate_boundary(boundary)["accepted"]))

    interleaved = copy.deepcopy(base)
    second = {
        "record_id": 3, "stream_id": 8, "wait_token": 10,
        "intervening_allocation": False, "pending_raw": False, "claimed": False,
        "raw_pair_record_id": 0, "active": False, "ambiguous": False,
        "entry": sample(2, "entry", "pending", 120, 0, 0, 121),
        "retry": sample(3, "retry", "stale", 180, 0, 0, 181),
    }
    interleaved["wait_records"][0]["entry"]["sample_id"] = 1
    interleaved["wait_records"][0]["retry"]["sample_id"] = 4
    interleaved["wait_records"].append(second)
    interleaved["capture_calls"] = 8
    interleaved["capture_duration"] = {"count": 8, "total_nanoseconds": 40, "max_nanoseconds": 5}
    cases.append(("interleaved-stream-sample-ids", validator.validate_activity(interleaved)["accepted"]))

    def rejected(name: str, mutate) -> None:
        value = copy.deepcopy(base)
        mutate(value)
        cases.append((name, not accepted(value)))

    rejected("boolean-schema", lambda value: value.__setitem__("schema_version", True))
    rejected("invalid-sticky", lambda value: value.__setitem__("invalid", True))
    rejected("overflow-sticky", lambda value: value.__setitem__("overflow", True))
    rejected("record-cap", lambda value: value.__setitem__("wait_records", value["wait_records"] * 4097))
    rejected("capture-count", lambda value: value.__setitem__("capture_calls", 5))
    rejected("unsupported-field", lambda value: value["pre_tcp_info"]["availability"].__setitem__("total_rto_time", False))
    rejected("cursor-change-marker", lambda value: value["wait_records"][0]["entry"].__setitem__("cursor_changed", False))
    rejected("cursor-after-invalid", lambda value: value["wait_records"][0]["entry"].__setitem__("cursor_after_valid", False))
    rejected("sample-monotonic", lambda value: value["wait_records"][0]["retry"].__setitem__("observed_monotonic_ns", 50))
    rejected("pair-bracket", lambda value: value["raw_pairs"][0].__setitem__("raw_write_started_monotonic_ns", 300))
    rejected("pair-reverse-link", lambda value: value["raw_pairs"][0].__setitem__("wait_record_id", 2))
    rejected("congestion-change", lambda value: value["post_tcp_info"].__setitem__("congestion_control", "bbr"))
    rejected("entry-congestion-change", lambda value: value["wait_records"][0]["entry"]["tcp_info"].__setitem__("congestion_control", "bbr"))
    rejected("retry-congestion-change", lambda value: value["wait_records"][0]["retry"]["tcp_info"].__setitem__("congestion_control", "bbr"))
    rejected("raw-before-congestion-change", lambda value: value["raw_pairs"][0]["before"].__setitem__("congestion_control", "bbr"))
    rejected("raw-after-congestion-change", lambda value: value["raw_pairs"][0]["after"].__setitem__("congestion_control", "bbr"))
    rejected("last-live-mismatch", lambda value: value.__setitem__("last_live_tcp_info", info(500)))
    rejected("applied-retry-zero-credit", lambda value: value["wait_records"][0]["retry"].__setitem__("credit", 0))
    rejected("sysctl-domain", lambda value: value.__setitem__("tcp_slow_start_after_idle", 2))
    wrong_wait = accepted(base, waits=[{"token": 10, "stream_id": 7, "classification": "applied_range"}])
    cases.append(("byte-credit-wait-join", not wrong_wait))
    wrong_stream = validator.validate_live(base, sequence=9, selected_stream_id=8)["accepted"]
    cases.append(("selected-stream-join", not wrong_stream))

    result = {
        "schema_version": 1,
        "case_count": len(cases),
        "cases": [{"name": name, "accepted": ok} for name, ok in cases],
        "accepted": all(ok for _, ok in cases),
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
