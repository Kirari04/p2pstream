# Qualification TCP_INFO provider API

Status: source-only. No Go command, compilation, test, endpoint, traffic, socket setter, sysctl setter, queue, goroutine, or polling loop was run or added.

The provider is selected only by `linux && p2pstream_qualification` and adds two files to `internal/agent`:

- `qualification_tcp_info_qualification_linux.go`
- `qualification_tcp_info_qualification_linux_test.go`

Its narrow integration entry point is:

```go
func qualificationCaptureTCPInfo(raw syscall.RawConn) (qualificationTCPInfoSnapshot, error)
```

The focused injection seam is:

```go
type qualificationTCPInfoRawControl interface {
    Control(func(uintptr)) error
}
type qualificationTCPInfoGetsockopt func(
    fd uintptr,
    level, option int,
    value unsafe.Pointer,
    length *uint32,
) syscall.Errno
func qualificationCaptureTCPInfoWith(
    raw qualificationTCPInfoRawControl,
    getsockopt qualificationTCPInfoGetsockopt,
    now func() time.Time,
) (qualificationTCPInfoSnapshot, error)
```

`qualificationTCPInfoSnapshot` is fixed and typed. It retains capture start/end wall observations, monotonic duration, explicit attempted/succeeded state for TCP_INFO and TCP_CONGESTION, each successful syscall's returned optlen, generated structure size, required-field end offset, per-field availability, TCP_CONGESTION name, and the required numeric TCP state. A syscall that was skipped or failed retains returned optlen zero. The unexported `time.Time` start/end values retain their monotonic readings for same-process integration.

The real getter issues exactly one direct `SYS_GETSOCKOPT(TCP_INFO)` and, only after a valid required length, one direct `SYS_GETSOCKOPT(TCP_CONGESTION)` inside the caller's `syscall.RawConn.Control`. It does not retry. A missing or duplicate RawConn callback is rejected. The minimum accepted TCP_INFO optlen is exactly the end of `unix.TCPInfo.Total_rto_time`; the maximum is `unsafe.Sizeof(unix.TCPInfo{})`. Later ECN fields and padding are neither required nor read. Every declared numeric field has an availability bit derived from its own end offset. Zero remains a valid available value.

The provider takes no mutex and starts no background work. The integration caller must snapshot the immutable RawConn binding while holding its owner lock, release every observer lock, call this provider synchronously, then reacquire its lock to publish or invalidate the result.

Focused source tests cover full-length zero values, the exact minimum accepted `Total_rto_time` end offset, all typed field mappings, truncated/zero/oversize TCP_INFO lengths, missing/duplicate Control callbacks, Control/TCP_INFO/TCP_CONGESTION failures without retry, TCP_CONGESTION length bounds, and one bounded owned loopback TCP socket query with immediate listener closure. No test has been executed.
