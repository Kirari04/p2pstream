# Checkpoint 4 manifest citation erratum

Four frozen metadata artifacts cite the initially announced checkpoint-4 manifest as `3de07e56394e9955b498ca0f56e181a04cf9c760369e73b93b45b72d0a93f`, which is only 61 hexadecimal characters. The complete announced SHA-256 is `3de07e56394e9955b498ca0f56e181a04cf9c760369e73b93b45b72d0a93f961`.

The affected frozen artifacts and their hashes are listed in `ERRATUM.json`. They remain unchanged. This metadata-only correction does not change checkpoint 5's 12 source/test payload files and does not represent any execution.
