#!/usr/bin/env python3
"""No-endpoint source contract for sender arm joins and fixed ordering."""

import ast
import json
import os
from pathlib import Path
import sys

if len(sys.argv) != 3:
    raise SystemExit("usage: test-sender-arm-bindings.py VALIDATOR FRESH_WORK_DIRECTORY")
source = Path(sys.argv[1]).read_text()
work = Path(sys.argv[2])
if work.exists():
    raise SystemExit("behavior work directory must be fresh")
work.mkdir(mode=0o700, parents=False)
required = (
    'expected_sender_specs = {9: ("retained-warmup", 1), 11: ("steady", 1), 14: ("steady", 2), 15: ("steady", 3)}',
    'transfer_row.get("diagnostic_sequence") == sequence',
    'transfer_row.get("measurement_stage") == expected_spec[0]',
    'transfer_row.get("transfer_direction") == "download"',
    'wall_contained = sender_interval_wall_contained(',
    '"request_wall_interval_contained": wall_contained',
    'record.get("measurement_start_valid") is True',
    'independent_pair.get("accepted") is True',
    'actual_control_names != expected_control_names',
    'supervisor.get("sender_evidence", {}).get("terminal_valid") is True',
    '"sender_duration_intervals": sender_intervals',
    '"sender_terminal_closure_valid": terminal_valid',
    '"performance_gate_enabled": not small',
)
missing = [text for text in required if text not in source]
if missing:
    raise SystemExit(f"sender arm join/gate source is incomplete: {missing!r}")
for forbidden in ("trace_reduction", "read-wait-reductions", "run_interned_trace_parser"):
    if forbidden in source:
        raise SystemExit(f"receiver trace dependency remained in sender arm validator: {forbidden}")

# Execute only the four pure validation helpers. These fixtures prove behavior,
# rather than merely checking that gate strings occur in the source.
tree = ast.parse(source)
helper_names = {
    "sender_interval_wall_contained",
    "sender_record_order_valid",
    "sender_terminal_record_cardinality_valid",
    "sender_terminal_closure_valid",
}
definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in helper_names]
if {node.name for node in definitions} != helper_names:
    raise SystemExit("pure sender arm validation helpers are incomplete")
namespace = {}
exec(compile(ast.Module(body=definitions, type_ignores=[]), "sender-arm-helpers", "exec"), namespace)

cases = []
failures = []
def check(name, expected, actual):
    accepted = type(actual) is bool and actual is expected
    cases.append({"case": name, "expected": expected, "actual": actual, "accepted": accepted})
    if not accepted:
        failures.append(name)

contains = namespace["sender_interval_wall_contained"]
pre = {"request_finished_unix_ns": 100}
post = {"request_started_unix_ns": 200}
copy = {"started_unix_ns": 101, "handler_return_unix_ns": 199}
check("wall-valid", True, contains(pre, post, copy))
check("wall-copy-before-pre", False, contains(pre, post, {**copy, "started_unix_ns": 99}))
check("wall-copy-after-post", False, contains(pre, post, {**copy, "handler_return_unix_ns": 201}))
check("wall-bool-rejected", False, contains(pre, post, {**copy, "started_unix_ns": True}))
check("wall-uint64-overflow", False, contains(pre, post, {**copy, "handler_return_unix_ns": 1 << 64}))

order_valid = namespace["sender_record_order_valid"]
check("order-valid", True, order_valid([9, 11, 14, 15, "terminal"]))
check("order-wrong", False, order_valid([9, 14, 11, 15, "terminal"]))
check("order-missing", False, order_valid([9, 11, 14, "terminal"]))
check("order-repeated", False, order_valid([9, 11, 14, 15, 15, "terminal"]))

terminal_cardinality_valid = namespace["sender_terminal_record_cardinality_valid"]
check("terminal-cardinality-valid", True, terminal_cardinality_valid([{"action": "terminal"}]))
check("terminal-missing", False, terminal_cardinality_valid([]))
check("terminal-duplicate", False, terminal_cardinality_valid([{"action": "terminal"}, {"action": "terminal"}]))

terminal_valid = namespace["sender_terminal_closure_valid"]
raw = {"response": "bounded"}
validation = {"accepted": True, "closure_valid": True}
record = {
    "diagnostic": "sender-duration", "action": "terminal", "status": 0,
    "validation_status": 0, "valid": True, "response": raw,
    "validation": validation,
}
check("terminal-valid", True, terminal_valid(record, raw, validation, validation))
incomplete = {**validation, "closure_valid": False}
check("terminal-incomplete", False,
      terminal_valid({**record, "validation": incomplete}, raw, incomplete, incomplete))

summary = {"schema_version": 1, "accepted": not failures, "case_count": len(cases),
           "failed_cases": failures, "cases": cases}
output = work / "behavior-summary.json"
descriptor = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(descriptor, "w") as destination:
    json.dump(summary, destination, indent=2, sort_keys=True)
    destination.write("\n")
if failures:
    raise SystemExit(f"sender arm behavior contract failed: {failures!r}")
