# Command evidence

All commands were executed from the active worktree. Stdout, stderr, and exact exit status are retained in sibling files.

- `git rev-parse HEAD`
- `git status --porcelain=v1 --untracked-files=no`
- `git diff --name-status BASE HEAD` and `git diff --name-only BASE HEAD`
- `git diff --name-status PRIOR HEAD` and `git diff --name-only PRIOR HEAD`
- `git diff --name-status BASE HEAD -- . ":(exclude)docs/**"`
- `git diff --name-status BASE HEAD -- go.mod go.sum`
- `git show -s --format=%H%x09%P%x09%s PRIOR HEAD`

`BASE` is `8ac4c8df8237e37777ba2fac0da6f949da17bdea`, `PRIOR` is `8bad77a456876fac0ee4b76673890a2243951d5f`, and `HEAD` is `9a1e4133ba63485c59476d09b4b569fd18267fd6`. Empty non-doc and module diff outputs are retained as zero-byte stdout files; they are evidence, not missing outputs.
