#!/usr/bin/env python3
"""No-endpoint contract for exact copy-validator path/hash shell bindings."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

if len(sys.argv) != 5:
    raise SystemExit("usage: test-copy-validator-binding.py RUNNER ARM HELPER FRESH_WORK")
runner_path, arm_path, helper_path, work_path = map(Path, sys.argv[1:])
runner = runner_path.read_text()
arm = arm_path.read_text()


def fail(message):
    raise SystemExit(message)


required_once = (
    "--copy-record-validator) copy_record_validator=$2; shift 2 ;;",
    "--copy-record-validator-sha256) copy_record_validator_sha256=$2; shift 2 ;;",
    'copy_record_validator=$(realpath "$copy_record_validator")',
    "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR=$copy_record_validator",
    "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256=$copy_record_validator_sha256",
    "copy_record_validator=${P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR:?copy record validator is required}",
    "copy_record_validator_sha256=${P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256:?copy record validator hash is required}",
    '$(readlink -f "$copy_record_validator") == "$copy_record_validator"',
    "copy record validator changed across namespace re-exec",
)
for value in required_once:
    actual = runner.count(value)
    if actual != 1:
        fail(f"runner binding cardinality changed: {value!r} count={actual}")

preserve = next((line for line in runner.splitlines() if "exec sudo -n --preserve-env=" in line), "")
if not preserve:
    fail("sudo preservation line is absent")
preserved = preserve.split("--preserve-env=", 1)[1].split(None, 1)[0].split(",")
for name in (
    "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR",
    "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256",
):
    if preserved.count(name) != 1:
        fail(f"sudo re-exec does not preserve exactly one {name}: {preserved!r}")

if "copy_record_validator=./validate-copy-record.py" in runner:
    fail("runner retains the relocated relative validator lookup")
for value in (
    '--copy-record-validator "$copy_record_validator"',
    '--copy-record-validator-sha256 "$(sha256sum "$copy_record_validator" | awk \'{print $1}\')"',
):
    if arm.count(value) != 1:
        fail(f"arm does not pass exact helper binding: {value!r}")


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def exact_block(source, start_marker, end_marker):
    if source.count(start_marker) != 1 or source.count(end_marker) != 1:
        fail(f"binding block marker cardinality changed: {start_marker!r} / {end_marker!r}")
    start = source.index(start_marker)
    end = source.index(end_marker, start)
    if end <= start:
        fail("binding block marker order changed")
    return source[start:end]


outer = exact_block(
    runner,
    '  [[ -n $copy_record_validator && $copy_record_validator_sha256 =~ ^[0-9a-f]{64}$ ]] || {',
    '  [[ -f $sender_wait_validator && $sender_wait_validator_sha256 =~ ^[0-9a-f]{64}$ ]] || {',
)
inner = exact_block(
    runner,
    'copy_record_validator=${P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR:?copy record validator is required}',
    'if [[ ${P2PSTREAM_GROWTH_PRESSURE_MODE:-0} == 1 ]]; then',
)
export_line = next(
    (line for line in runner.splitlines() if line.strip() ==
     "export P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256"),
    None,
)
if export_line is None:
    fail("exact copy-validator export line is absent")
assignment_lines = []
for expected in (
    "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR=$copy_record_validator",
    "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256=$copy_record_validator_sha256",
):
    matches = [line for line in runner.splitlines() if line.strip() == expected]
    if len(matches) != 1:
        fail(f"copy-validator assignment cardinality changed: {expected!r}")
    assignment_lines.append(matches[0])

if work_path.exists():
    fail("fresh contract work directory is required")
work_path.mkdir(mode=0o700, parents=True)
known_sha = digest(helper_path)
if known_sha != "f1c70a2f347a77975a00330d4d37929700b1a38bac5fa195c3dff02b3f773c26":
    fail("mature copy validator hash changed")

inner_script = work_path / "inner-binding.sh"
inner_script.write_text(
    "#!/usr/bin/env bash\nset -Eeuo pipefail\n" + inner +
    "printf '%s\\n%s\\n' \"$copy_record_validator\" \"$copy_record_validator_sha256\" > \"$1\"\n"
)
inner_script.chmod(0o700)
outer_script = work_path / "outer-binding.sh"
outer_script.write_text(
    "#!/usr/bin/env bash\nset -Eeuo pipefail\n"
    "copy_record_validator=$1\ncopy_record_validator_sha256=$2\nresult=$3\n" +
    outer + "\n" +
    "printf '%s\\n%s\\n' \"$copy_record_validator\" \"$copy_record_validator_sha256\" > \"$result\"\n"
)
outer_script.chmod(0o700)
propagation_script = work_path / "propagation-binding.sh"
propagation_script.write_text(
    "#!/usr/bin/env bash\nset -Eeuo pipefail\n"
    "copy_record_validator=$1\ncopy_record_validator_sha256=$2\ninner_script=$3\nresult=$4\n" +
    outer + "\n" + export_line + "\n" + "\n".join(assignment_lines) + "\n" +
    "exec /bin/bash \"$inner_script\" \"$result\"\n"
)
propagation_script.chmod(0o700)

correct = work_path / "correct-validator.py"
shutil.copyfile(helper_path, correct)
correct.chmod(0o700)
changed = work_path / "changed-validator.py"
shutil.copyfile(helper_path, changed)
with changed.open("ab") as stream:
    stream.write(b"\n# changed contract fixture\n")
changed.chmod(0o700)
missing = work_path / "missing-validator.py"

environment = {"PATH": "/usr/bin:/bin", "LC_ALL": "C"}
cases = []

def run_case(name, argv, expected_class, expected_output=None, extra_env=None):
    result_path = work_path / f"{name}.binding"
    process_env = dict(environment)
    if extra_env:
        process_env.update(extra_env)
    completed = subprocess.run(
        argv + [str(result_path)], stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=process_env,
        timeout=10, check=False,
    )
    actual_class = 0 if completed.returncode == 0 else 1
    cases.append({
        "case": name,
        "expected_status_class": expected_class,
        "actual_status": completed.returncode,
        "actual_status_class": actual_class,
        "stdout": completed.stdout.decode("utf-8", "replace")[:4096],
        "stderr": completed.stderr.decode("utf-8", "replace")[:4096],
        "binding_output_exists": result_path.exists(),
    })
    if actual_class != expected_class:
        fail(f"copy-validator shell binding case failed: {name} expected={expected_class} actual={completed.returncode}")
    if expected_class == 0:
        if not result_path.is_file() or result_path.read_text() != expected_output:
            fail(f"valid helper case did not publish the exact binding: {name}")
    elif result_path.exists():
        fail(f"rejected helper case unexpectedly published a binding: {name}")

canonical_correct = str(correct.resolve(strict=True))
expected_correct = f"{canonical_correct}\n{known_sha}\n"
for name, path, expected_class in (
    ("outer_correct", correct, 0),
    ("outer_missing", missing, 1),
    ("outer_changed", changed, 1),
):
    run_case(
        name,
        ["/bin/bash", str(outer_script), str(path), known_sha],
        expected_class,
        expected_correct if expected_class == 0 else None,
    )
for name, path, expected_class in (
    ("inner_correct", correct, 0),
    ("inner_missing", missing, 1),
    ("inner_changed", changed, 1),
):
    canonical = str(path.resolve())
    run_case(
        name,
        ["/bin/bash", str(inner_script)],
        expected_class,
        expected_correct if expected_class == 0 else None,
        {
            "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR": canonical,
            "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256": known_sha,
        },
    )
run_case(
    "exported_child_correct",
    ["/bin/bash", str(propagation_script), str(correct), known_sha, str(inner_script)],
    0,
    expected_correct,
)

result = {
    "schema_version": 1,
    "accepted": True,
    "case_count": len(cases),
    "helper_sha256": known_sha,
    "outer_block_sha256": hashlib.sha256(outer.encode()).hexdigest(),
    "inner_block_sha256": hashlib.sha256(inner.encode()).hexdigest(),
    "static_reexec_binding": True,
    "cases": cases,
}
output = work_path / "summary.json"
with output.open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
