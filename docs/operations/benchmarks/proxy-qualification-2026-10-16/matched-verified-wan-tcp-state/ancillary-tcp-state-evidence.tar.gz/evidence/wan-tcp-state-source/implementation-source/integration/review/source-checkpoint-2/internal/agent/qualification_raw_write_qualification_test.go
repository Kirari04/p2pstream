//go:build p2pstream_qualification

package agent

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/hashicorp/yamux"

	"p2pstream/internal/tunnel"
)

type qualificationRawWriteTestConn struct {
	started       chan struct{}
	release       chan struct{}
	written       int
	err           error
	closeUnblocks bool
	closeOnce     sync.Once
}

func (conn *qualificationRawWriteTestConn) Read([]byte) (int, error) { return 0, io.EOF }
func (conn *qualificationRawWriteTestConn) Write(payload []byte) (int, error) {
	if conn.started != nil {
		close(conn.started)
	}
	if conn.release != nil {
		<-conn.release
	}
	written := conn.written
	if written < 0 {
		written = len(payload)
	}
	return written, conn.err
}
func (conn *qualificationRawWriteTestConn) Close() error {
	if conn.closeUnblocks && conn.release != nil {
		conn.closeOnce.Do(func() { close(conn.release) })
	}
	return nil
}
func (conn *qualificationRawWriteTestConn) LocalAddr() net.Addr {
	return qualificationRawWriteTestAddr("local")
}
func (conn *qualificationRawWriteTestConn) RemoteAddr() net.Addr {
	return qualificationRawWriteTestAddr("remote")
}
func (conn *qualificationRawWriteTestConn) SetDeadline(time.Time) error      { return nil }
func (conn *qualificationRawWriteTestConn) SetReadDeadline(time.Time) error  { return nil }
func (conn *qualificationRawWriteTestConn) SetWriteDeadline(time.Time) error { return nil }

type qualificationRawWriteTestAddr string

func (addr qualificationRawWriteTestAddr) Network() string { return "test" }
func (addr qualificationRawWriteTestAddr) String() string  { return string(addr) }

func qualificationRawWriteTestTCPPair(t *testing.T) (*net.TCPConn, *net.TCPConn) {
	t.Helper()
	listener, err := net.ListenTCP("tcp4", &net.TCPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		t.Fatal(err)
	}
	if err := listener.SetDeadline(time.Now().Add(5 * time.Second)); err != nil {
		_ = listener.Close()
		t.Fatal(err)
	}
	client, err := net.DialTCP("tcp4", nil, listener.Addr().(*net.TCPAddr))
	if err != nil {
		_ = listener.Close()
		t.Fatal(err)
	}
	server, err := listener.AcceptTCP()
	if err != nil {
		_ = client.Close()
		_ = listener.Close()
		t.Fatal(err)
	}
	if err := listener.Close(); err != nil {
		_ = client.Close()
		_ = server.Close()
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = client.Close() })
	t.Cleanup(func() { _ = server.Close() })
	return client, server
}

func TestQualificationRawWriteActualWrapperBlockedErrorAndShort(t *testing.T) {
	t.Run("blocked write remains live until exact release", func(t *testing.T) {
		owner := &qualificationRawWriteOwner{lane: 1, generation: 1, rawBound: true, bodyBound: true}
		underlying := &qualificationRawWriteTestConn{started: make(chan struct{}), release: make(chan struct{}), written: -1}
		observed := &qualificationObservedRawConn{Conn: underlying, owner: owner}
		done := make(chan error, 1)
		go func() {
			_, err := observed.Write(make([]byte, 8))
			done <- err
		}()
		select {
		case <-underlying.started:
		case <-t.Context().Done():
			t.Fatal(t.Context().Err())
		}
		live := owner.drain()
		if live.Complete || live.ResetPerformed || live.ActiveRawWrites != 1 {
			t.Fatalf("blocked wrapper drain = %+v", live)
		}
		close(underlying.release)
		select {
		case err := <-done:
			if err != nil {
				t.Fatal(err)
			}
		case <-t.Context().Done():
			t.Fatal(t.Context().Err())
		}
		complete := owner.drain()
		if !complete.Complete || complete.Outside.SuccessCalls != 1 || complete.Outside.SuccessAttemptBytes != 8 || complete.Outside.SuccessWrittenBytes != 8 {
			t.Fatalf("released wrapper drain = %+v", complete)
		}
	})

	t.Run("close releases blocked write and ownership joins", func(t *testing.T) {
		owner := &qualificationRawWriteOwner{lane: 1, generation: 1, rawBound: true, bodyBound: true}
		underlying := &qualificationRawWriteTestConn{
			started: make(chan struct{}), release: make(chan struct{}), written: 0,
			err: net.ErrClosed, closeUnblocks: true,
		}
		observed := &qualificationObservedRawConn{Conn: underlying, owner: owner}
		done := make(chan error, 1)
		go func() {
			_, err := observed.Write(make([]byte, 8))
			done <- err
		}()
		select {
		case <-underlying.started:
		case <-t.Context().Done():
			t.Fatal(t.Context().Err())
		}
		if err := observed.Close(); err != nil {
			t.Fatal(err)
		}
		select {
		case err := <-done:
			if !errors.Is(err, net.ErrClosed) {
				t.Fatalf("blocked close result = %v", err)
			}
		case <-t.Context().Done():
			t.Fatal(t.Context().Err())
		}
		got := owner.drain()
		if !got.Complete || !got.CloseObserved || got.Outside.ErrorCalls != 1 || got.ActiveRawWrites != 0 {
			t.Fatalf("blocked close snapshot = %+v", got)
		}
	})

	for _, test := range []struct {
		name       string
		written    int
		err        error
		wantErrors uint64
		wantShorts uint64
	}{
		{name: "error", written: 2, err: errors.New("injected write error"), wantErrors: 1},
		{name: "short", written: 3, wantShorts: 1},
	} {
		t.Run(test.name, func(t *testing.T) {
			owner := &qualificationRawWriteOwner{lane: 1, generation: 1, rawBound: true, bodyBound: true}
			observed := &qualificationObservedRawConn{Conn: &qualificationRawWriteTestConn{written: test.written, err: test.err}, owner: owner}
			_, _ = observed.Write(make([]byte, 8))
			got := owner.drain()
			if !got.Complete || got.Outside.ErrorCalls != test.wantErrors || got.Outside.ShortCalls != test.wantShorts || got.Outside.Duration.Count != 1 {
				t.Fatalf("actual wrapper outcome = %+v", got)
			}
		})
	}
}

func TestQualificationRawWriteBindingRejectsMissingDuplicateAndCustomTLSDialer(t *testing.T) {
	t.Setenv(qualificationRawWriteEnableEnv, "1")
	previous := http.DefaultTransport
	base := http.DefaultTransport.(*http.Transport).Clone()
	base.DialContext = (&net.Dialer{}).DialContext
	http.DefaultTransport = base
	t.Cleanup(func() { http.DefaultTransport = previous })
	restore, err := installExternalQualificationRawWriteObserver()
	if err != nil {
		t.Fatal(err)
	}
	restored := false
	t.Cleanup(func() {
		if !restored {
			_ = restore()
		}
	})
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, "https://management.test/", nil)
	if err != nil {
		t.Fatal(err)
	}
	req, err = qualificationBindRawWriteRequest(req, tunnelLaneRegistration{lane: 1})
	if err != nil {
		t.Fatal(err)
	}
	clientConn, _ := qualificationRawWriteTestTCPPair(t)
	if _, err := qualificationBindRawWriteBody(req, clientConn); err == nil {
		t.Fatal("body binding succeeded before raw connection binding")
	}
	binding := req.Context().Value(qualificationRawWriteContextKey{}).(*qualificationRawWriteBinding)
	if _, err := binding.bindRaw(clientConn); err != nil {
		t.Fatal(err)
	}
	if _, err := binding.bindRaw(clientConn); err == nil {
		t.Fatal("duplicate raw connection binding succeeded")
	}
	if _, err := qualificationBindRawWriteBody(req, clientConn); err != nil {
		t.Fatal(err)
	}
	if _, err := qualificationBindRawWriteBody(req, clientConn); err == nil {
		t.Fatal("duplicate body binding succeeded")
	}

	t.Run("terminal recorder rejects duplicate reconnect and mismatch", func(t *testing.T) {
		first := new(yamux.Session)
		second := new(yamux.Session)
		duplicate := &qualificationRawWriteTerminalRecorder{
			path: "unused", expected: 5, active: make(map[int]*yamux.Session),
			records: make(map[int]qualificationRawWriteTerminalRecord),
		}
		duplicate.observe(tunnelSessionObservation{Lane: 0, Connected: true, Session: first})
		duplicate.observe(tunnelSessionObservation{Lane: 0, Connected: true, Session: second})
		if !duplicate.invalid {
			t.Fatal("duplicate active lane was accepted")
		}

		mismatch := &qualificationRawWriteTerminalRecorder{
			path: "unused", expected: 5, active: map[int]*yamux.Session{0: first},
			records: make(map[int]qualificationRawWriteTerminalRecord),
		}
		mismatch.observe(tunnelSessionObservation{Lane: 0, Connected: false, Session: second})
		if !mismatch.invalid {
			t.Fatal("mismatched disconnect session was accepted")
		}

		reconnect := &qualificationRawWriteTerminalRecorder{
			path: "unused", expected: 5, active: make(map[int]*yamux.Session),
			records: map[int]qualificationRawWriteTerminalRecord{0: {Lane: 0}},
		}
		reconnect.observe(tunnelSessionObservation{Lane: 0, Connected: true, Session: first})
		if !reconnect.invalid {
			t.Fatal("reconnect overwrote a terminal lane")
		}
	})

	t.Run("terminal sidecar orders exact five lanes and is fresh", func(t *testing.T) {
		path := filepath.Join(t.TempDir(), "terminal.json")
		recorder := &qualificationRawWriteTerminalRecorder{
			path: path, expected: 5, active: make(map[int]*yamux.Session),
			records: make(map[int]qualificationRawWriteTerminalRecord, 5),
		}
		slowStartAfterIdle, err := qualificationReadTCPSlowStartAfterIdle()
		if err != nil {
			t.Fatal(err)
		}
		for lane := 4; lane >= 0; lane-- {
			client, _ := qualificationRawWriteTestTCPPair(t)
			raw, err := client.SyscallConn()
			if err != nil {
				t.Fatal(err)
			}
			baseline, err := qualificationCaptureTCPInfo(raw)
			if err != nil {
				t.Fatal(err)
			}
			owner := &qualificationRawWriteOwner{
				lane: lane, generation: uint64(lane + 1), rawBound: true, bodyBound: true,
				localAddr: client.LocalAddr(), remoteAddr: client.RemoteAddr(),
				localAddress: client.LocalAddr().String(), remoteAddress: client.RemoteAddr().String(),
			}
			if !owner.bindTCPState(raw, baseline, slowStartAfterIdle) {
				t.Fatalf("lane %d bind TCP state", lane)
			}
			owner.markClosed()
			owner.markSessionJoined()
			snapshot := owner.drain()
			if !snapshot.Complete || !snapshot.TCPState.Complete {
				t.Fatalf("lane %d terminal snapshot = %+v", lane, snapshot)
			}
			recorder.records[lane] = qualificationRawWriteTerminalRecord{
				Lane: lane, Aggregate: true, SessionIdentity: fmt.Sprintf("session-%d", lane),
				RawWrite: snapshot,
			}
		}
		if err := recorder.write(); err != nil {
			t.Fatal(err)
		}
		data, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		var sidecar qualificationRawWriteTerminalSidecar
		if err := json.Unmarshal(data, &sidecar); err != nil {
			t.Fatal(err)
		}
		if !sidecar.Complete || sidecar.Invalid || sidecar.Expected != 5 || len(sidecar.Records) != 5 {
			t.Fatalf("ordered sidecar = %+v", sidecar)
		}
		for lane, record := range sidecar.Records {
			if record.Lane != lane || record.RawWrite.Lane != lane {
				t.Fatalf("sidecar[%d] = %+v", lane, record)
			}
		}
		if err := recorder.write(); err == nil {
			t.Fatal("terminal sidecar overwrote its fresh output")
		}
	})

	if err := restore(); err != nil {
		t.Fatal(err)
	}
	restored = true

	custom := base.Clone()
	custom.DialTLSContext = func(context.Context, string, string) (net.Conn, error) { return nil, errors.New("unused") }
	http.DefaultTransport = custom
	if _, err := installExternalQualificationRawWriteObserver(); err == nil {
		t.Fatal("custom TLS dialer was accepted")
	}
}

func TestQualificationRawWriteTLS101PathSharesPhysicalInterval(t *testing.T) {
	t.Setenv(qualificationRawWriteEnableEnv, "1")
	terminalPath := filepath.Join(t.TempDir(), "raw-terminal.json")
	t.Setenv(qualificationRawWriteTerminalEnv, terminalPath)
	terminal, err := newExternalQualificationRawWriteTerminalRecorder(1)
	if err != nil {
		t.Fatal(err)
	}
	serverSession := make(chan *yamux.Session, 1)
	serverError := make(chan error, 1)
	management := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Connection") != "Upgrade" || r.Header.Get("Upgrade") != tunnel.UpgradeToken {
			http.Error(w, "missing upgrade", http.StatusBadRequest)
			return
		}
		hijacker, ok := w.(http.Hijacker)
		if !ok {
			serverError <- errors.New("TLS response does not support hijack")
			return
		}
		conn, rw, err := hijacker.Hijack()
		if err != nil {
			serverError <- err
			return
		}
		if _, err := fmt.Fprintf(rw, "HTTP/1.1 101 Switching Protocols\r\nConnection: Upgrade\r\nUpgrade: %s\r\n\r\n", tunnel.UpgradeToken); err != nil {
			_ = conn.Close()
			serverError <- err
			return
		}
		if err := rw.Flush(); err != nil {
			_ = conn.Close()
			serverError <- err
			return
		}
		config, err := tunnel.NewAggregateYamuxConfig(nil, tunnel.DefaultMaxStreamWindowSizeBytes, 4)
		if err != nil {
			_ = conn.Close()
			serverError <- err
			return
		}
		session, err := yamux.Server(conn, config)
		if err != nil {
			_ = conn.Close()
			serverError <- err
			return
		}
		serverSession <- session
	}))
	t.Cleanup(management.Close)

	previousTransport := http.DefaultTransport
	transport := management.Client().Transport.(*http.Transport).Clone()
	transport.DialContext = (&net.Dialer{}).DialContext
	http.DefaultTransport = transport
	t.Cleanup(func() { http.DefaultTransport = previousTransport })
	restore, err := installExternalQualificationRawWriteObserver()
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if err := restore(); err != nil {
			t.Errorf("restore raw-write observer: %v", err)
		}
	})

	req, err := http.NewRequestWithContext(t.Context(), http.MethodGet, management.URL, nil)
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Connection", "Upgrade")
	req.Header.Set("Upgrade", tunnel.UpgradeToken)
	req, err = qualificationBindRawWriteRequest(req, tunnelLaneRegistration{lane: 0})
	if err != nil {
		t.Fatal(err)
	}
	client, err := managementTunnelHTTPClient(&http.Client{Transport: http.DefaultTransport})
	if err != nil {
		t.Fatal(err)
	}
	response, err := client.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	if response.StatusCode != http.StatusSwitchingProtocols {
		t.Fatalf("upgrade status = %d", response.StatusCode)
	}
	body, ok := response.Body.(io.ReadWriteCloser)
	if !ok {
		t.Fatalf("upgrade body = %T", response.Body)
	}
	body, err = qualificationBindRawWriteBody(req, body)
	if err != nil {
		t.Fatal(err)
	}
	clientConfig, err := tunnel.NewAggregateYamuxConfig(nil, tunnel.DefaultMaxStreamWindowSizeBytes, 4)
	if err != nil {
		t.Fatal(err)
	}
	clientSession, err := yamux.Client(body, clientConfig)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = clientSession.Close() })
	terminal.observe(tunnelSessionObservation{Lane: 0, Aggregate: true, Connected: true, Session: clientSession})
	binding := req.Context().Value(qualificationRawWriteContextKey{}).(*qualificationRawWriteBinding)
	if clientSession.LocalAddr().String() != binding.owner.localAddress || clientSession.RemoteAddr().String() != binding.owner.remoteAddress {
		t.Fatalf("client session tuple = %s -> %s, raw = %s -> %s", clientSession.LocalAddr(), clientSession.RemoteAddr(), binding.owner.localAddress, binding.owner.remoteAddress)
	}
	var peer *yamux.Session
	select {
	case peer = <-serverSession:
	case err := <-serverError:
		t.Fatal(err)
	case <-t.Context().Done():
		t.Fatal(t.Context().Err())
	}
	t.Cleanup(func() { _ = peer.Close() })
	if peer.LocalAddr().String() != clientSession.RemoteAddr().String() || peer.RemoteAddr().String() != clientSession.LocalAddr().String() {
		t.Fatalf("peer tuple = %s -> %s, client = %s -> %s", peer.LocalAddr(), peer.RemoteAddr(), clientSession.LocalAddr(), clientSession.RemoteAddr())
	}
	if clientSession.RetireQualificationRawWriteActivity() {
		t.Fatal("live Yamux session published premature raw observer retirement")
	}
	handshake := clientSession.DrainQualificationRawWriteActivity()
	if !handshake.Complete || handshake.EnvelopeCount != 0 || handshake.Contained.Calls != 0 || handshake.Outside.Calls == 0 || handshake.SessionJoined {
		t.Fatalf("TLS handshake classification = %+v", handshake)
	}
	if _, err := clientSession.Ping(); err != nil {
		t.Fatal(err)
	}
	control := clientSession.DrainQualificationRawWriteActivity()
	if !control.Complete || control.EnvelopeCount != 0 || control.Contained.Calls != 0 || control.Outside.Calls == 0 {
		t.Fatalf("PING/control classification = %+v", control)
	}
	if sender := clientSession.DrainQualificationAggregateSendCounters(); !sender.Timing.Complete || sender.Timing.PhysicalAttemptFrames != 0 {
		t.Fatalf("pre-DATA physical ledger = %+v", sender)
	}

	accepted := make(chan *yamux.Stream, 1)
	acceptError := make(chan error, 1)
	go func() {
		stream, err := peer.AcceptStream()
		if err != nil {
			acceptError <- err
			return
		}
		accepted <- stream
	}()
	stream, err := clientSession.OpenStream()
	if err != nil {
		t.Fatal(err)
	}
	defer stream.Close()
	var peerStream *yamux.Stream
	select {
	case peerStream = <-accepted:
	case err := <-acceptError:
		t.Fatal(err)
	case <-t.Context().Done():
		t.Fatal(t.Context().Err())
	}
	defer peerStream.Close()
	payload := make([]byte, 32*1024)
	readDone := make(chan error, 1)
	go func() {
		_, err := io.ReadFull(peerStream, make([]byte, len(payload)))
		readDone <- err
	}()
	if written, err := stream.Write(payload); err != nil || written != len(payload) {
		t.Fatalf("stream write = %d, %v", written, err)
	}
	select {
	case err := <-readDone:
		if err != nil {
			t.Fatal(err)
		}
	case <-t.Context().Done():
		t.Fatal(t.Context().Err())
	}

	got := clientSession.DrainQualificationRawWriteActivity()
	if !got.Complete || got.Ambiguous || got.Overflow || !got.Bound || got.Lane != 0 || got.EnvelopeCount != 1 || got.Contained.Calls <= 1 {
		t.Fatalf("TLS 101 raw activity = %+v", got)
	}
	const yamuxHeaderBytes = 12
	if got.EnvelopePayloadBytes != uint64(len(payload)) || got.EnvelopeWireBytes != uint64(len(payload)+yamuxHeaderBytes) {
		t.Fatalf("TLS 101 envelope bytes = %+v", got)
	}
	if got.EnvelopeDuration.TotalNanoseconds != got.ContainedRawDuration.TotalNanoseconds+got.ResidualDuration.TotalNanoseconds {
		t.Fatalf("TLS 101 duration conservation = %+v", got)
	}
	sender := clientSession.DrainQualificationAggregateSendCounters()
	if !sender.Timing.Complete || sender.Timing.Ambiguous || sender.Timing.Overflow ||
		sender.Timing.PhysicalAttemptFrames != got.EnvelopeCount ||
		sender.Timing.PhysicalAttemptPayloadBytes != got.EnvelopePayloadBytes ||
		sender.Timing.PhysicalAttemptWireBytes != got.EnvelopeWireBytes ||
		sender.Timing.PhysicalSuccessFrames != 1 {
		t.Fatalf("raw/physical ledger join: raw=%+v sender=%+v", got, sender)
	}
	if err := clientSession.Close(); err != nil {
		t.Fatal(err)
	}
	if !clientSession.RetireQualificationRawWriteActivity() {
		t.Fatal("joined Yamux session did not publish raw observer retirement")
	}
	terminal.observe(tunnelSessionObservation{Lane: 0, Aggregate: true, Connected: false, Session: clientSession})
	joined := clientSession.DrainQualificationRawWriteActivity()
	if !joined.CloseObserved || !joined.SessionJoined || !joined.Complete || joined.EnvelopeCount != 0 || joined.Contained.Calls != 0 {
		t.Fatalf("TLS 101 terminal lifecycle = %+v", joined)
	}
	if err := terminal.write(); err != nil {
		t.Fatal(err)
	}
	terminalBytes, err := os.ReadFile(terminalPath)
	if err != nil {
		t.Fatal(err)
	}
	var terminalSidecar qualificationRawWriteTerminalSidecar
	if err := json.Unmarshal(terminalBytes, &terminalSidecar); err != nil {
		t.Fatal(err)
	}
	if !terminalSidecar.Complete || terminalSidecar.Invalid || terminalSidecar.Expected != 1 || len(terminalSidecar.Records) != 1 || !terminalSidecar.Records[0].RawWrite.SessionJoined {
		t.Fatalf("terminal sidecar = %+v", terminalSidecar)
	}
}

func TestQualificationRawWriteOutcomeDurationsConserveSuccessErrorShort(t *testing.T) {
	owner := &qualificationRawWriteOwner{lane: 2, generation: 7, rawBound: true, bodyBound: true}
	base := time.Unix(0, 1_000_000)

	token := owner.beginEnvelope(11, 32, 44, base)
	contained := owner.beginRawWrite()
	contained.started = base.Add(time.Microsecond)
	owner.finishRawWrite(contained, 12, 12, nil, base.Add(4*time.Microsecond))
	owner.finishEnvelope(token, base.Add(8*time.Microsecond))

	short := owner.beginRawWrite()
	short.started = base.Add(9 * time.Microsecond)
	owner.finishRawWrite(short, 10, 6, nil, base.Add(14*time.Microsecond))
	errorWrite := owner.beginRawWrite()
	errorWrite.started = base.Add(15 * time.Microsecond)
	owner.finishRawWrite(errorWrite, 9, 2, errors.New("test write failure"), base.Add(22*time.Microsecond))

	got := owner.drain()
	if !got.Complete || !got.ResetPerformed || got.Ambiguous || got.Overflow {
		t.Fatalf("snapshot state = %+v", got)
	}
	if got.Contained.SuccessCalls != 1 || got.Contained.SuccessDuration.Count != 1 || got.Contained.SuccessDuration.TotalNanoseconds != 3_000 {
		t.Fatalf("contained success = %+v", got.Contained)
	}
	if got.Outside.ShortCalls != 1 || got.Outside.ShortDuration.Count != 1 || got.Outside.ShortDuration.TotalNanoseconds != 5_000 {
		t.Fatalf("outside short = %+v", got.Outside)
	}
	if got.Outside.ErrorCalls != 1 || got.Outside.ErrorDuration.Count != 1 || got.Outside.ErrorDuration.TotalNanoseconds != 7_000 {
		t.Fatalf("outside error = %+v", got.Outside)
	}
	if got.Contained.Duration.TotalNanoseconds != got.Contained.SuccessDuration.TotalNanoseconds+got.Contained.ErrorDuration.TotalNanoseconds+got.Contained.ShortDuration.TotalNanoseconds {
		t.Fatalf("contained duration outcomes do not conserve: %+v", got.Contained)
	}
	if got.Outside.Duration.TotalNanoseconds != got.Outside.SuccessDuration.TotalNanoseconds+got.Outside.ErrorDuration.TotalNanoseconds+got.Outside.ShortDuration.TotalNanoseconds {
		t.Fatalf("outside duration outcomes do not conserve: %+v", got.Outside)
	}
}

func TestQualificationRawWriteEnvelopeRejectsBoundaryActiveAndStraddling(t *testing.T) {
	owner := &qualificationRawWriteOwner{lane: 1, generation: 3, rawBound: true, bodyBound: true}
	base := time.Unix(0, 2_000_000)
	straddler := owner.beginRawWrite()
	straddler.started = base
	token := owner.beginEnvelope(9, 64, 76, base.Add(time.Microsecond))
	owner.finishRawWrite(straddler, 8, 8, nil, base.Add(3*time.Microsecond))
	owner.finishEnvelope(token, base.Add(4*time.Microsecond))

	got := owner.drain()
	if !got.Complete || !got.Ambiguous || got.BoundaryActiveRawWrites != 1 || got.Straddling.Calls != 1 || got.Contained.Calls != 0 {
		t.Fatalf("straddling snapshot = %+v", got)
	}
}

func TestQualificationRawWriteDrainRetainsLiveOwnershipAndPublishesJoin(t *testing.T) {
	owner := &qualificationRawWriteOwner{lane: 4, generation: 5, rawBound: true, bodyBound: true}
	base := time.Unix(0, 3_000_000)
	active := owner.beginRawWrite()
	active.started = base

	first := owner.drain()
	if first.Complete || first.ResetPerformed || first.ActiveRawWrites != 1 {
		t.Fatalf("live drain = %+v", first)
	}
	owner.finishRawWrite(active, 4, 4, nil, base.Add(time.Microsecond))
	owner.markClosed()
	beforeJoin := owner.drain()
	if !beforeJoin.CloseObserved || beforeJoin.SessionJoined {
		t.Fatalf("pre-join lifecycle = %+v", beforeJoin)
	}
	owner.markSessionJoined()
	afterJoin := owner.drain()
	if !afterJoin.CloseObserved || !afterJoin.SessionJoined || !afterJoin.Complete {
		t.Fatalf("joined lifecycle = %+v", afterJoin)
	}
}

func TestQualificationRawWriteStartTimestampMustBeInsideEnvelope(t *testing.T) {
	owner := &qualificationRawWriteOwner{lane: 1, generation: 1, rawBound: true, bodyBound: true}
	base := time.Unix(0, 4_000_000)
	token := owner.beginEnvelope(3, 16, 28, base.Add(2*time.Microsecond))
	raw := owner.beginRawWrite()
	// Model a raw ownership reservation that preceded the envelope even though
	// its bookkeeping lock completed after the envelope opened.
	raw.started = base
	owner.finishRawWrite(raw, 2, 2, nil, base.Add(3*time.Microsecond))
	owner.finishEnvelope(token, base.Add(4*time.Microsecond))
	got := owner.drain()
	if got.Contained.Calls != 0 || got.Straddling.Calls != 1 {
		t.Fatalf("timestamp enclosure classification = %+v", got)
	}
}

func TestQualificationRawWriteInvalidBoundariesOverflowGenerationAndZeroRaw(t *testing.T) {
	base := time.Unix(0, 5_000_000)
	t.Run("zero raw remains explicit", func(t *testing.T) {
		owner := &qualificationRawWriteOwner{lane: 1, generation: 1, rawBound: true, bodyBound: true}
		token := owner.beginEnvelope(3, 16, 28, base)
		owner.finishEnvelope(token, base.Add(time.Microsecond))
		got := owner.drain()
		if !got.Complete || got.EnvelopeCount != 1 || got.EnvelopeZeroRawCalls != 1 || got.Contained.Calls != 0 {
			t.Fatalf("zero-raw envelope = %+v", got)
		}
	})

	t.Run("end straddler closes into next epoch", func(t *testing.T) {
		owner := &qualificationRawWriteOwner{lane: 1, generation: 1, rawBound: true, bodyBound: true}
		token := owner.beginEnvelope(3, 16, 28, base)
		raw := owner.beginRawWrite()
		raw.started = base.Add(time.Nanosecond)
		owner.finishEnvelope(token, base.Add(time.Microsecond))
		owner.finishRawWrite(raw, 2, 2, nil, base.Add(2*time.Microsecond))
		got := owner.drain()
		if !got.Ambiguous || got.BoundaryActiveRawWrites != 1 || got.Straddling.Calls != 1 || got.Contained.Calls != 0 {
			t.Fatalf("end straddler = %+v", got)
		}
	})

	t.Run("concurrent raw writes are bounded and invalid", func(t *testing.T) {
		owner := &qualificationRawWriteOwner{lane: 1, generation: 1, rawBound: true, bodyBound: true}
		first := owner.beginRawWrite()
		first.started = base
		second := owner.beginRawWrite()
		second.started = base.Add(time.Nanosecond)
		owner.finishRawWrite(second, 1, 1, nil, base.Add(2*time.Nanosecond))
		owner.finishRawWrite(first, 1, 1, nil, base.Add(3*time.Nanosecond))
		got := owner.drain()
		if !got.Ambiguous || got.MaximumActiveRawWrites != 2 || got.Outside.Calls != 2 {
			t.Fatalf("concurrent raw writes = %+v", got)
		}
	})

	t.Run("generation replacement cannot reattribute live write", func(t *testing.T) {
		owner := &qualificationRawWriteOwner{lane: 1, generation: 1, rawBound: true, bodyBound: true}
		raw := owner.beginRawWrite()
		raw.started = base
		owner.mu.Lock()
		owner.generation++
		owner.mu.Unlock()
		owner.finishRawWrite(raw, 1, 1, nil, base.Add(time.Nanosecond))
		got := owner.drain()
		if got.OwnerGenerationChanges != 1 || got.Straddling.Calls != 1 {
			t.Fatalf("generation replacement = %+v", got)
		}
	})

	t.Run("checked additions expose overflow", func(t *testing.T) {
		owner := &qualificationRawWriteOwner{lane: 1, generation: 1, rawBound: true, bodyBound: true}
		owner.interval.envelopeCount = ^uint64(0)
		token := owner.beginEnvelope(3, 16, 28, base)
		owner.finishEnvelope(token, base.Add(time.Nanosecond))
		got := owner.drain()
		if !got.Overflow || !got.Complete {
			t.Fatalf("overflow snapshot = %+v", got)
		}
	})
}

func TestQualificationRawWriteConcurrentProtocolWriteUsesTemporalClassification(t *testing.T) {
	owner := &qualificationRawWriteOwner{lane: 1, generation: 1, rawBound: true, bodyBound: true}
	base := time.Unix(0, 6_000_000)
	token := owner.beginEnvelope(7, 32, 44, base)
	// The shared owner cannot identify whether this contained call came from
	// DATA record emission or a concurrent TLS protocol writer. It records only
	// temporal occupancy and keeps that identity limitation explicit.
	protocolWrite := owner.beginRawWrite()
	protocolWrite.started = base.Add(time.Microsecond)
	owner.finishRawWrite(protocolWrite, 5, 5, nil, base.Add(2*time.Microsecond))
	owner.finishEnvelope(token, base.Add(3*time.Microsecond))
	got := owner.drain()
	if got.Ambiguous || got.Contained.Calls != 1 || got.Contained.SuccessCalls != 1 || got.Straddling.Calls != 0 {
		t.Fatalf("temporal protocol write = %+v", got)
	}
}
