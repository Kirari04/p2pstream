//go:build linux && p2pstream_qualification

package agent

import (
	"errors"
	"fmt"
	"runtime"
	"syscall"
	"time"
	"unsafe"

	"golang.org/x/sys/unix"
)

const (
	qualificationTCPInfoSnapshotSchemaVersion = 1
	qualificationTCPInfoCongestionNameLimit   = 16
)

type qualificationTCPInfoFieldAvailability struct {
	State              bool `json:"state"`
	CAState            bool `json:"ca_state"`
	Retransmits        bool `json:"retransmits"`
	RTO                bool `json:"rto"`
	SendMSS            bool `json:"send_mss"`
	Unacked            bool `json:"unacked"`
	Lost               bool `json:"lost"`
	Retrans            bool `json:"retrans"`
	LastDataSent       bool `json:"last_data_sent"`
	RTT                bool `json:"rtt"`
	RTTVariance        bool `json:"rtt_variance"`
	SendSlowStartThreshold bool `json:"send_slow_start_threshold"`
	SendCongestionWnd  bool `json:"send_congestion_window"`
	TotalRetrans       bool `json:"total_retrans"`
	PacingRate         bool `json:"pacing_rate"`
	BytesAcked         bool `json:"bytes_acked"`
	NotSentBytes       bool `json:"not_sent_bytes"`
	DeliveryRate       bool `json:"delivery_rate"`
	BytesSent          bool `json:"bytes_sent"`
	BytesRetransmitted bool `json:"bytes_retransmitted"`
	SendWindow         bool `json:"send_window"`
	TotalRTO           bool `json:"total_rto"`
	TotalRTORecoveries bool `json:"total_rto_recoveries"`
	TotalRTOTime       bool `json:"total_rto_time"`
}

type qualificationTCPInfoSnapshot struct {
	SchemaVersion                   int                                   `json:"schema_version"`
	Captured                        bool                                  `json:"captured"`
	CaptureStartedUnixNS            int64                                 `json:"capture_started_unix_ns"`
	CaptureFinishedUnixNS           int64                                 `json:"capture_finished_unix_ns"`
	CaptureDurationNS               uint64                                `json:"capture_duration_ns"`
	TCPInfoAttempted                bool                                  `json:"tcp_info_attempted"`
	TCPInfoSucceeded                bool                                  `json:"tcp_info_succeeded"`
	TCPInfoOptlen                   uint32                                `json:"tcp_info_optlen"`
	TCPInfoStructSize               uint32                                `json:"tcp_info_struct_size"`
	RequiredFieldEndOffset          uint32                                `json:"required_field_end_offset"`
	CongestionControlAttempted      bool                                  `json:"congestion_control_attempted"`
	CongestionControlSucceeded      bool                                  `json:"congestion_control_succeeded"`
	CongestionControlOptlen         uint32                                `json:"congestion_control_optlen"`
	CongestionControl               string                                `json:"congestion_control"`
	Availability                    qualificationTCPInfoFieldAvailability `json:"availability"`
	State                           uint8                                 `json:"state"`
	CAState                         uint8                                 `json:"ca_state"`
	Retransmits                     uint8                                 `json:"retransmits"`
	RTOUsec                         uint32                                `json:"rto_us"`
	SendMSS                         uint32                                `json:"send_mss"`
	Unacked                         uint32                                `json:"unacked"`
	Lost                            uint32                                `json:"lost"`
	Retrans                         uint32                                `json:"retrans"`
	LastDataSentMS                  uint32                                `json:"last_data_sent_ms"`
	RTTUsec                         uint32                                `json:"rtt_us"`
	RTTVarianceUsec                 uint32                                `json:"rtt_variance_us"`
	SendSlowStartThreshold          uint32                                `json:"send_slow_start_threshold"`
	SendCongestionWindow            uint32                                `json:"send_congestion_window"`
	TotalRetrans                    uint32                                `json:"total_retrans"`
	PacingRateBytesPerSecond        uint64                                `json:"pacing_rate_bytes_per_second"`
	BytesAcked                      uint64                                `json:"bytes_acked"`
	NotSentBytes                    uint32                                `json:"not_sent_bytes"`
	DeliveryRateBytesPerSecond      uint64                                `json:"delivery_rate_bytes_per_second"`
	BytesSent                       uint64                                `json:"bytes_sent"`
	BytesRetransmitted              uint64                                `json:"bytes_retransmitted"`
	SendWindowBytes                 uint32                                `json:"send_window_bytes"`
	TotalRTO                        uint16                                `json:"total_rto"`
	TotalRTORecoveries              uint16                                `json:"total_rto_recoveries"`
	TotalRTOTimeMS                  uint32                                `json:"total_rto_time_ms"`
	captureStarted, captureFinished time.Time
}

type qualificationTCPInfoRawControl interface {
	Control(func(uintptr)) error
}

type qualificationTCPInfoGetsockopt func(fd uintptr, level, option int, value unsafe.Pointer, length *uint32) syscall.Errno

var (
	qualificationTCPInfoStructSize = uint32(unsafe.Sizeof(unix.TCPInfo{}))

	qualificationTCPInfoStateEnd              = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.State), unsafe.Sizeof(unix.TCPInfo{}.State))
	qualificationTCPInfoCongestionStateEnd    = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Ca_state), unsafe.Sizeof(unix.TCPInfo{}.Ca_state))
	qualificationTCPInfoRetransmitsEnd        = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Retransmits), unsafe.Sizeof(unix.TCPInfo{}.Retransmits))
	qualificationTCPInfoRTOEnd                = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Rto), unsafe.Sizeof(unix.TCPInfo{}.Rto))
	qualificationTCPInfoSendMSSEnd            = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Snd_mss), unsafe.Sizeof(unix.TCPInfo{}.Snd_mss))
	qualificationTCPInfoUnackedEnd            = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Unacked), unsafe.Sizeof(unix.TCPInfo{}.Unacked))
	qualificationTCPInfoLostEnd               = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Lost), unsafe.Sizeof(unix.TCPInfo{}.Lost))
	qualificationTCPInfoRetransEnd            = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Retrans), unsafe.Sizeof(unix.TCPInfo{}.Retrans))
	qualificationTCPInfoLastDataSentEnd       = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Last_data_sent), unsafe.Sizeof(unix.TCPInfo{}.Last_data_sent))
	qualificationTCPInfoRTTEnd                = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Rtt), unsafe.Sizeof(unix.TCPInfo{}.Rtt))
	qualificationTCPInfoRTTVarianceEnd        = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Rttvar), unsafe.Sizeof(unix.TCPInfo{}.Rttvar))
	qualificationTCPInfoSendSlowStartEnd      = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Snd_ssthresh), unsafe.Sizeof(unix.TCPInfo{}.Snd_ssthresh))
	qualificationTCPInfoSendCongestionWndEnd  = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Snd_cwnd), unsafe.Sizeof(unix.TCPInfo{}.Snd_cwnd))
	qualificationTCPInfoTotalRetransEnd       = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Total_retrans), unsafe.Sizeof(unix.TCPInfo{}.Total_retrans))
	qualificationTCPInfoPacingRateEnd         = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Pacing_rate), unsafe.Sizeof(unix.TCPInfo{}.Pacing_rate))
	qualificationTCPInfoBytesAckedEnd         = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Bytes_acked), unsafe.Sizeof(unix.TCPInfo{}.Bytes_acked))
	qualificationTCPInfoNotSentBytesEnd       = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Notsent_bytes), unsafe.Sizeof(unix.TCPInfo{}.Notsent_bytes))
	qualificationTCPInfoDeliveryRateEnd       = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Delivery_rate), unsafe.Sizeof(unix.TCPInfo{}.Delivery_rate))
	qualificationTCPInfoBytesSentEnd          = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Bytes_sent), unsafe.Sizeof(unix.TCPInfo{}.Bytes_sent))
	qualificationTCPInfoBytesRetransmittedEnd = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Bytes_retrans), unsafe.Sizeof(unix.TCPInfo{}.Bytes_retrans))
	qualificationTCPInfoSendWindowEnd         = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Snd_wnd), unsafe.Sizeof(unix.TCPInfo{}.Snd_wnd))
	qualificationTCPInfoTotalRTOEnd           = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Total_rto), unsafe.Sizeof(unix.TCPInfo{}.Total_rto))
	qualificationTCPInfoTotalRTORecoveriesEnd = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Total_rto_recoveries), unsafe.Sizeof(unix.TCPInfo{}.Total_rto_recoveries))
	qualificationTCPInfoTotalRTOTimeEnd       = qualificationTCPInfoFieldEnd(unsafe.Offsetof(unix.TCPInfo{}.Total_rto_time), unsafe.Sizeof(unix.TCPInfo{}.Total_rto_time))
)

func qualificationTCPInfoFieldEnd(offset, size uintptr) uint32 {
	return uint32(offset + size)
}

func qualificationTCPInfoFieldAvailable(length, end uint32) bool {
	return length >= end
}

func qualificationTCPInfoAvailability(length uint32) qualificationTCPInfoFieldAvailability {
	return qualificationTCPInfoFieldAvailability{
		State:              qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoStateEnd),
		CAState:            qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoCongestionStateEnd),
		Retransmits:        qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoRetransmitsEnd),
		RTO:                qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoRTOEnd),
		SendMSS:            qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoSendMSSEnd),
		Unacked:            qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoUnackedEnd),
		Lost:               qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoLostEnd),
		Retrans:            qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoRetransEnd),
		LastDataSent:       qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoLastDataSentEnd),
		RTT:                qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoRTTEnd),
		RTTVariance:        qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoRTTVarianceEnd),
		SendSlowStartThreshold: qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoSendSlowStartEnd),
		SendCongestionWnd:  qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoSendCongestionWndEnd),
		TotalRetrans:       qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoTotalRetransEnd),
		PacingRate:         qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoPacingRateEnd),
		BytesAcked:         qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoBytesAckedEnd),
		NotSentBytes:       qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoNotSentBytesEnd),
		DeliveryRate:       qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoDeliveryRateEnd),
		BytesSent:          qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoBytesSentEnd),
		BytesRetransmitted: qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoBytesRetransmittedEnd),
		SendWindow:         qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoSendWindowEnd),
		TotalRTO:           qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoTotalRTOEnd),
		TotalRTORecoveries: qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoTotalRTORecoveriesEnd),
		TotalRTOTime:       qualificationTCPInfoFieldAvailable(length, qualificationTCPInfoTotalRTOTimeEnd),
	}
}

func (availability qualificationTCPInfoFieldAvailability) required() bool {
	return availability.State && availability.CAState && availability.Retransmits &&
		availability.RTO && availability.SendMSS && availability.Unacked && availability.Lost &&
		availability.Retrans && availability.LastDataSent && availability.RTT &&
		availability.RTTVariance && availability.SendSlowStartThreshold && availability.SendCongestionWnd &&
		availability.TotalRetrans && availability.PacingRate && availability.BytesAcked &&
		availability.NotSentBytes && availability.DeliveryRate && availability.BytesSent &&
		availability.BytesRetransmitted && availability.SendWindow && availability.TotalRTO &&
		availability.TotalRTORecoveries && availability.TotalRTOTime
}

func qualificationCaptureTCPInfo(raw syscall.RawConn) (qualificationTCPInfoSnapshot, error) {
	return qualificationCaptureTCPInfoWith(raw, qualificationTCPInfoGetsockoptLinux, time.Now)
}

func qualificationCaptureTCPInfoWith(raw qualificationTCPInfoRawControl, getsockopt qualificationTCPInfoGetsockopt, now func() time.Time) (qualificationTCPInfoSnapshot, error) {
	snapshot := qualificationTCPInfoSnapshot{
		SchemaVersion:          qualificationTCPInfoSnapshotSchemaVersion,
		TCPInfoStructSize:      qualificationTCPInfoStructSize,
		RequiredFieldEndOffset: qualificationTCPInfoTotalRTOTimeEnd,
	}
	if raw == nil {
		return snapshot, errors.New("TCP_INFO raw connection is unavailable")
	}
	if getsockopt == nil || now == nil {
		return snapshot, errors.New("TCP_INFO capture seam is unavailable")
	}
	if qualificationTCPInfoStructSize != uint32(unix.SizeofTCPInfo) {
		return snapshot, fmt.Errorf("TCP_INFO generated size mismatch: struct=%d constant=%d", qualificationTCPInfoStructSize, unix.SizeofTCPInfo)
	}

	started := now()
	snapshot.captureStarted = started
	snapshot.CaptureStartedUnixNS = started.UnixNano()

	var info unix.TCPInfo
	infoLength := qualificationTCPInfoStructSize
	var congestion [qualificationTCPInfoCongestionNameLimit]byte
	congestionLength := uint32(len(congestion))
	var infoErrno, congestionErrno syscall.Errno
	controlInvocations := uint64(0)
	controlErr := raw.Control(func(fd uintptr) {
		controlInvocations++
		if controlInvocations != 1 {
			return
		}
		snapshot.TCPInfoAttempted = true
		infoErrno = getsockopt(fd, unix.IPPROTO_TCP, unix.TCP_INFO, unsafe.Pointer(&info), &infoLength)
		if infoErrno == 0 {
			snapshot.TCPInfoSucceeded = true
			snapshot.TCPInfoOptlen = infoLength
		}
		if infoErrno == 0 && infoLength >= qualificationTCPInfoTotalRTOTimeEnd && infoLength <= qualificationTCPInfoStructSize {
			snapshot.CongestionControlAttempted = true
			congestionErrno = getsockopt(fd, unix.IPPROTO_TCP, unix.TCP_CONGESTION, unsafe.Pointer(&congestion[0]), &congestionLength)
			if congestionErrno == 0 {
				snapshot.CongestionControlSucceeded = true
				snapshot.CongestionControlOptlen = congestionLength
			}
		}
	})

	finished := now()
	snapshot.captureFinished = finished
	snapshot.CaptureFinishedUnixNS = finished.UnixNano()
	if finished.Before(started) {
		return snapshot, errors.New("TCP_INFO capture clock moved backwards")
	}
	snapshot.CaptureDurationNS = uint64(finished.Sub(started))
	if snapshot.TCPInfoSucceeded {
		snapshot.Availability = qualificationTCPInfoAvailability(snapshot.TCPInfoOptlen)
	}

	if controlErr != nil {
		return snapshot, fmt.Errorf("TCP_INFO raw control: %w", controlErr)
	}
	if controlInvocations == 0 {
		return snapshot, errors.New("TCP_INFO raw control did not invoke its callback")
	}
	if controlInvocations != 1 {
		return snapshot, fmt.Errorf("TCP_INFO raw control invoked its callback %d times", controlInvocations)
	}
	if infoErrno != 0 {
		return snapshot, fmt.Errorf("TCP_INFO getsockopt: %w", infoErrno)
	}
	if snapshot.TCPInfoOptlen == 0 || snapshot.TCPInfoOptlen > qualificationTCPInfoStructSize {
		return snapshot, fmt.Errorf("TCP_INFO returned invalid optlen %d (buffer %d)", snapshot.TCPInfoOptlen, qualificationTCPInfoStructSize)
	}
	if !snapshot.Availability.required() {
		return snapshot, fmt.Errorf("TCP_INFO optlen %d does not cover required field end %d", snapshot.TCPInfoOptlen, snapshot.RequiredFieldEndOffset)
	}
	if congestionErrno != 0 {
		return snapshot, fmt.Errorf("TCP_CONGESTION getsockopt: %w", congestionErrno)
	}
	if snapshot.CongestionControlOptlen == 0 || snapshot.CongestionControlOptlen > uint32(len(congestion)) {
		return snapshot, fmt.Errorf("TCP_CONGESTION returned invalid optlen %d (buffer %d)", snapshot.CongestionControlOptlen, len(congestion))
	}
	congestionNameLength := int(snapshot.CongestionControlOptlen)
	for i := 0; i < int(snapshot.CongestionControlOptlen); i++ {
		if congestion[i] == 0 {
			congestionNameLength = i
			break
		}
	}
	if congestionNameLength == 0 {
		return snapshot, errors.New("TCP_CONGESTION returned an empty algorithm name")
	}

	snapshot.CongestionControl = string(congestion[:congestionNameLength])
	snapshot.State = info.State
	snapshot.CAState = info.Ca_state
	snapshot.Retransmits = info.Retransmits
	snapshot.RTOUsec = info.Rto
	snapshot.SendMSS = info.Snd_mss
	snapshot.Unacked = info.Unacked
	snapshot.Lost = info.Lost
	snapshot.Retrans = info.Retrans
	snapshot.LastDataSentMS = info.Last_data_sent
	snapshot.RTTUsec = info.Rtt
	snapshot.RTTVarianceUsec = info.Rttvar
	snapshot.SendSlowStartThreshold = info.Snd_ssthresh
	snapshot.SendCongestionWindow = info.Snd_cwnd
	snapshot.TotalRetrans = info.Total_retrans
	snapshot.PacingRateBytesPerSecond = info.Pacing_rate
	snapshot.BytesAcked = info.Bytes_acked
	snapshot.NotSentBytes = info.Notsent_bytes
	snapshot.DeliveryRateBytesPerSecond = info.Delivery_rate
	snapshot.BytesSent = info.Bytes_sent
	snapshot.BytesRetransmitted = info.Bytes_retrans
	snapshot.SendWindowBytes = info.Snd_wnd
	snapshot.TotalRTO = info.Total_rto
	snapshot.TotalRTORecoveries = info.Total_rto_recoveries
	snapshot.TotalRTOTimeMS = info.Total_rto_time
	snapshot.Captured = true
	return snapshot, nil
}

func qualificationTCPInfoGetsockoptLinux(fd uintptr, level, option int, value unsafe.Pointer, length *uint32) syscall.Errno {
	_, _, errno := unix.Syscall6(
		unix.SYS_GETSOCKOPT,
		fd,
		uintptr(level),
		uintptr(option),
		uintptr(value),
		uintptr(unsafe.Pointer(length)),
		0,
	)
	runtime.KeepAlive(value)
	runtime.KeepAlive(length)
	return errno
}
