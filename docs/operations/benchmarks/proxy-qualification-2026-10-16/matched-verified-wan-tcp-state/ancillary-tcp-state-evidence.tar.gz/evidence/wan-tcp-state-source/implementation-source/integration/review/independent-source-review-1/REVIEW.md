# TCP-state integration checkpoint 1 independent review

Status: **NOT READY**. This is a source-only review. No Go command, build,
endpoint, namespace, or traffic command was run.

Reviewed checkpoint:

- `review/source-checkpoint-1/SHA256SUMS.txt`
- manifest SHA-256
  `37f2bb5d02bc2aff5d535301bbdb08e4bd54894ba82e46ba24b6327fa9fae100`
- implementation patch SHA-256
  `15a873918abad67e35f4515c407a7dce868bd108437324c4a8b89e9dd548fbc6`
- active design manifest SHA-256
  `1175d11a26897af13a7c987752ec5027e1c148510ae7d440e607d0f271356d10`
- accepted provider checkpoint manifest SHA-256
  `1e10289f5f2ed214dd09e2b260723d374748e2acc2575c932e157f57dd83c6ab`

## Blocking corrections

1. `qualificationObserveTCPWaitSample` runs for qualification byte waits before
   an authenticated selected interval is armed, but
   `beginTCPWaitSample` treats `!tcp.armed` as a sticky ambiguity. Ordinary
   conditioning traffic can therefore poison an owner before the first selected
   pre action. Expected unarmed observation must be a clean no-op. The retry
   call must also report whether it created an actual armed pending claim:
   `Stream.write` currently retains `qualificationTCPPendingWait` after any
   `applied_range`, even when `BeginQualificationTCPWaitSample` returned zero,
   so a later allocation wait can call `MarkQualificationTCPInterveningAllocation`
   with no TCP record and poison the owner. A focused control must perform an
   unarmed byte wait, applied retry, and allocation wait, then prove the next arm
   remains healthy. Malformed calls while armed must remain sticky failures.

2. Failure of the second byte-credit cursor read is converted into an all-zero
   cursor and then marked `Complete`. The record has no cursor-validity bit, so
   the exported TCP bracket can appear complete despite an unknown endpoint.
   Pass explicit after-cursor validity into `Finish`, retain it in the record,
   and make missing/invalid cursor completion sticky. Do not synthesize a zero
   cursor.

3. `qualificationTCPFailure` infers the failure stage from partial provider
   fields. This misclassifies cases such as a duplicate `RawControl` callback
   after a successful getsockopt. The accepted provider must publish an exact
   fixed failure stage and errno; the integration should copy those values
   rather than infer them.

4. Disarm must reject every sticky and active state before its post capture:
   invalid/ambiguous/overflow, capture or drop counters, active samples, pending
   claims, active raw pairs, and active envelope wait/pair slots. A rejected
   interval must not be reset into a later healthy interval.

5. A raw claim classified `applied_range` must additionally prove positive
   retry byte credit and an advancing ordinal and cumulative cursor. A
   zero-credit advancing retry remains an invalid defect and cannot create a
   claim.

6. Every successful live capture queries `TCP_CONGESTION`, but checkpoint 1
   compares only bind/pre/post values. Require each successful sample to have a
   nonempty congestion-control name equal to the bind-time name. A transient
   different algorithm that reverts before post must not pass.

7. Concurrent captures can complete in one order and reacquire the owner mutex
   in another. `recordTCPCaptureLocked` unconditionally overwrites
   `lastLiveTCPInfo`, so the field is not necessarily the chronologically last
   successful capture. Retain the successful snapshot with the greatest valid
   monotonic capture-finish coordinate, or rename and validate the field as
   last committed. The design and terminal record call it the last live
   snapshot, so maximum finish time is the direct correction.

8. `FOCUSED-TEST-PLAN.json` lists planned roots, but checkpoint 1 contains no
   integration controls implementing them. The successor needs actual bounded
   controls for the corrected lifecycle and negative cases before any focused
   execution is reviewed.

## Accepted source properties

- Sampling is synchronous and uses the retained exact raw socket. There is no
  sampler goroutine, dynamic attacker-sized map, socket/sysctl setter, timeout,
  wire, or receive-window policy change.
- Wait entry/retry records and first-contained-raw pairs use fixed 4,096-entry
  bounds. Missing finish, capture error, overflow, ambiguity, pending claim, and
  terminal activity fail closed in the drain path. The 4 MiB response limit is
  retained; an oversized bounded snapshot is rejected rather than truncated or
  accepted.
- The first raw pair commits only after generation, envelope, stream, and
  temporal enclosure checks. Before-capture completion is required before raw
  write start, and raw write finish before after-capture start. Allocation wait
  remains an explicit confounder rather than invalidating an otherwise valid
  temporal pair.
- The authenticated control retains exact five-lane ownership, ordered pre/post
  transitions, terminal one-owner-per-lane closure, and no owner replacement or
  late bind path.
- Data-path syscalls occur after releasing `stateLock`, `recvLock`, aggregate,
  byte-trace, raw-owner, send-ready, and new diagnostic mutexes. Existing
  `Stream.sendLock` at wait entry/retry and TLS `c.out` serialization at raw
  before/after are required existing serializations and are accepted. The
  untimed authenticated control may retain
  `externalQualificationWANSenderWaitOwner.mu` across exact-five pre/post
  capture: that mutex is not acquired by the data/raw/wait path, and the raw
  callback does not return into the control owner.
- Setup and terminal `tcp_slow_start_after_idle` reads occur outside observer
  locks. Terminal retains live state and does not reopen or query a closed FD.
- All added runtime files are qualification-selected. Ordinary source selection
  still requires an exact build-time `go list`/hash proof; it was not executed
  during this review.

Checkpoint 1 must remain preserved as rejected source-only evidence. A successor
can be reviewed narrowly against these eight corrections and its actual focused
test sources.
