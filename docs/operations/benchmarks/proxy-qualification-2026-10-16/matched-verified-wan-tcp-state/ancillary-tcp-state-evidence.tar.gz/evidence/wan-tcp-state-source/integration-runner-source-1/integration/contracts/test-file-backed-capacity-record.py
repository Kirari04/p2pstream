#!/usr/bin/env python3
"""Exercise the actual selected-transfer wrapper with small and >128 KiB capacity responses."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


if len(sys.argv) != 9:
    raise SystemExit("usage: test-file-backed-capacity-record.py OLD NEW FAILED_ROOT TINY_ROOT JQ BASH PYTHON FRESH_WORK")

old_runner, new_runner, failed_root, tiny_root, jq, bash, python, work = map(Path, sys.argv[1:])
if work.exists() or work.is_symlink() or not work.parent.is_dir():
    raise SystemExit("work root must be fresh")
work.mkdir(mode=0o700)


def extract(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    start_marker = "wan_sender_wait_should_measure() {\n"
    end_marker = "run_tiny_response() {\n"
    if text.count(start_marker) != 1 or text.count(end_marker) != 1:
        raise ValueError("wrapper extraction markers differ")
    start = text.index(start_marker)
    end = text.index(end_marker, start)
    return text[start:end]


old_functions = extract(old_runner)
new_functions = extract(new_runner)
if old_functions.count('--argjson pre_capacity "$pre_capacity"') != 3:
    raise ValueError("old wrapper no longer contains the three rejected argument bindings")
if '--argjson pre_capacity "$pre_capacity"' in new_functions or '--argjson post_capacity "$post_capacity"' in new_functions:
    raise ValueError("new wrapper retained a capacity response argument binding")
if new_functions.count("$pre_capacity_request[0].response // {}") != 3 or new_functions.count("$post_capacity_request[0].response // {}") != 1:
    raise ValueError("new wrapper file-backed response cardinality differs")

stub = work / "validator.py"
stub.write_text("""#!/usr/bin/env python3
import json, os, sys
out = sys.argv[sys.argv.index('--output') + 1]
fd = os.open(out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, 'w', encoding='utf-8') as stream:
    json.dump({'accepted': True}, stream)
    stream.write('\\n')
""", encoding="utf-8")
stub.chmod(0o700)


def run_case(label: str, functions: str, pre_capacity: Path, post_capacity: Path,
             pre_sender: Path, post_sender: Path, expected_status: int) -> tuple[int, Path]:
    case = work / label
    case.mkdir(mode=0o700)
    extracted = case / "functions.sh"
    extracted.write_text(functions, encoding="utf-8")
    output = case / "record.jsonl"
    script = case / "run.sh"
    script.write_text(f"""#!/usr/bin/env bash
set -Eeuo pipefail
source {extracted}
query_server_json() {{ printf '%s\\n' '{{"runtime":true}}'; }}
cgroup_snapshot() {{ printf '%s\\n' '{{"cgroup_path":"/scope","memory_max_bytes":4294967296,"memory_swap_max_bytes":0,"memory_events":{{"high":0,"max":0,"oom":0,"oom_kill":0,"oom_group_kill":0}}}}'; }}
wan_sender_wait_server_capacity() {{
  local phase=$1 destination=$4
  case "$phase" in pre) cp -- "$PRE_CAPACITY" "$destination" ;; post) cp -- "$POST_CAPACITY" "$destination" ;; *) return 2 ;; esac
}}
wan_sender_wait_query() {{
  local phase=$2 destination=$5
  case "$phase" in pre) cp -- "$PRE_SENDER" "$destination" ;; post) cp -- "$POST_SENDER" "$destination" ;; *) return 2 ;; esac
}}
run_transfer() {{ return 0; }}
sequence=8
sender_wait_control_dir={case}/controls
sender_wait_records={output}
sender_wait_validator={stub}
mkdir -p "$sender_wait_control_dir"
run_maybe_sender_wait_transfer a b /scope d http://server f http://agent retained-warmup download j 1
""", encoding="utf-8")
    script.chmod(0o700)
    environment = {
        "PATH": "/usr/sbin:/usr/bin:/sbin:/bin",
        "LC_ALL": "C",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PRE_CAPACITY": str(pre_capacity.resolve()),
        "POST_CAPACITY": str(post_capacity.resolve()),
        "PRE_SENDER": str(pre_sender.resolve()),
        "POST_SENDER": str(post_sender.resolve()),
    }
    completed = subprocess.run([str(bash), str(script)], cwd=case, env=environment,
                               stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, timeout=30, check=False)
    (case / "status").write_text(f"{completed.returncode}\n", encoding="utf-8")
    (case / "stdout").write_bytes(completed.stdout)
    (case / "stderr").write_bytes(completed.stderr)
    if completed.returncode != expected_status:
        raise ValueError(f"{label} status {completed.returncode} differs")
    return completed.returncode, output


def controls(root: Path) -> tuple[Path, Path, Path, Path]:
    directory = root / "h1/results.sender-wait-controls"
    return tuple(directory / f"sequence-9-{phase}-{kind}.json"
                 for phase, kind in (("pre", "capacity"), ("post", "capacity"),
                                     ("pre", "sender"), ("post", "sender")))


tiny = controls(tiny_root)
failed = controls(failed_root)
for path in (*tiny, *failed):
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"fixture is unavailable: {path}")

_, old_small = run_case("small-old", old_functions, *tiny, 0)
_, new_small = run_case("small-new", new_functions, *tiny, 0)
if old_small.read_bytes() != new_small.read_bytes():
    raise ValueError("small known-row serialization changed")

_, large = run_case("large-new", new_functions, *failed, 0)
large_row = json.loads(large.read_text(encoding="utf-8"))
pre_envelope = json.loads(failed[0].read_text(encoding="utf-8"))
post_envelope = json.loads(failed[1].read_text(encoding="utf-8"))
if (large_row.get("pre_capacity_request") != pre_envelope
        or large_row.get("post_capacity_request") != post_envelope
        or large_row.get("pre_server_capacity") != pre_envelope.get("response", {})
        or large_row.get("post_server_capacity") != post_envelope.get("response", {})):
    raise ValueError("large response or envelope was not retained exactly")

malformed = work / "malformed.json"
malformed.write_text("{\n", encoding="utf-8")
missing = work / "missing.json"
run_case("malformed", new_functions, malformed, failed[1], failed[2], failed[3], 2)
run_case("missing", new_functions, missing, failed[1], failed[2], failed[3], 2)

compact_pre = subprocess.run([str(jq), "-c", ".response // {}", str(failed[0])],
                             stdout=subprocess.PIPE, check=True).stdout.rstrip(b"\n")
summary = {
    "accepted": True,
    "case_count": 5,
    "cases": ["small-old", "small-new", "large-new", "malformed", "missing"],
    "large_pre_capacity_file_bytes": failed[0].stat().st_size,
    "large_pre_capacity_compact_response_bytes": len(compact_pre),
    "linux_max_arg_strlen_bytes": 32 * os.sysconf("SC_PAGE_SIZE"),
    "small_record_sha256": hashlib.sha256(new_small.read_bytes()).hexdigest(),
    "large_record_sha256": hashlib.sha256(large.read_bytes()).hexdigest(),
    "large_record_bytes": large.stat().st_size,
}
if summary["large_pre_capacity_compact_response_bytes"] < summary["linux_max_arg_strlen_bytes"]:
    raise ValueError("large fixture does not exercise the rejected single-argument size")
(work / "SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
