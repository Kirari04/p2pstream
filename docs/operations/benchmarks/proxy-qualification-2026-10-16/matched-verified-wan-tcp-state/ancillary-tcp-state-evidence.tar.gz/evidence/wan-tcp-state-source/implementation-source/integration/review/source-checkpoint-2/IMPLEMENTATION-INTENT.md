# TCP state diagnostic integration checkpoint 2

This source-only checkpoint implements proposal checkpoint 2 without changing ordinary builds, wire formats, socket policy, receive-window policy, or the fixed 4 MiB authenticated response bound.

Qualification builds synchronously sample the exact owned TCP socket with the reviewed provider at bind, selected interval pre/post, byte-credit wait entry/retry, and the first contained raw write for each applied-range wait. The existing Stream send serialization and TLS output serialization may be held. No observer, raw-owner, state, receive, aggregate, or control lock is held across `RawConn.Control`.

The observer is armed only by the authenticated selected pre transition after all five live owners are verified. Expected unarmed conditioning is a clean no-op. Once armed, malformed identities, unfinished samples, capture failures, congestion-algorithm changes, overflow, ambiguous pairs, and lifecycle violations are sticky and cannot be erased by drain or rearm. Every applied-range claim has positive credit and exactly one fully contained raw-write pair. Original byte-credit records prove advancement; TCP cursor equality between entry and retry remains valid.

The public record retains owner-relative monotonic coordinates, explicit cursor-after validity, provider-origin failure stage and errno, the last successful live socket capture, fixed record limits, and the sampled `tcp_slow_start_after_idle` value. Terminal evidence never queries a closed file descriptor.

If serialization exceeds the existing authenticated response bound, the request remains rejected with bounded attempted-size/digest/error evidence. It is never truncated, retried unchanged, or accepted for qualification.

This checkpoint includes focused provider, lifecycle, raw-owner, authenticated-route, and actual `Stream.write` test sources. No Go test, build, endpoint, or traffic command was executed while preparing it. The pinned Go 1.26.6 `gofmt` binary was used only to format the mutable source before freezing.
