# TCP-state validator contract invocation source 3

This unexecuted source invokes validator checkpoint 4 through the reviewed
owned-process helper in one bounded process group. It pins the checkpoint,
contract driver, Python, Bash, and helper bytes; records inner and outer direct
statuses; requires a natural join; and rechecks all inputs after execution.
It runs no Go command, endpoint, or WAN traffic.

Source 3 supersedes source 2 because its producer checkpoint was rejected after mutation; invocation semantics are unchanged.
