#!/usr/bin/python3
"""Run the frozen TCP-state validator contract in one owned process group."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import traceback

REPO = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
CHECKPOINT = REPO / "tmp/continuation-20261016/wan-tcp-state-source/runner-source-1/review/tcp-validator-source-checkpoint-4"
CHECKPOINT_SHA = "91d3cc3ae0ab28722f75885cb318358c080a3212e8de5cba0ea2a6d8c90d946c"
CONTRACT_DRIVER = CHECKPOINT / "integration/contracts/run-tcp-state-contracts.sh"
CONTRACT_DRIVER_SHA = "27246a06dc48dcde2fca38ffb8072b8b49e496d320193e5b1eeffcf8752f0915"
OWNED_HELPER = REPO / "tmp/continuation-20261016/wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
OWNED_HELPER_SHA = "8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
PYTHON = Path("/usr/bin/python3.14")
PYTHON_SHA = "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
BASH = Path("/usr/bin/bash")
BASH_SHA = "3efccc187bafa75ff1e37d246270ab3e7aa559f242c7a52bf3ec2a1b5450bdbd"


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_text(path: Path, value: str) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as destination:
        destination.write(value)


def write_json(path: Path, value: object) -> None:
    write_text(path, json.dumps(value, indent=2, sort_keys=True) + "\n")


def relative(value: str) -> PurePosixPath:
    path = PurePosixPath(value)
    if path.is_absolute() or not path.parts or "." in path.parts or ".." in path.parts:
        raise ValueError(f"unsafe ledger path: {value!r}")
    return path


def checkpoint_inventory() -> dict[str, str]:
    ledger_path = CHECKPOINT / "SHA256SUMS.txt"
    if sha(ledger_path) != CHECKPOINT_SHA:
        raise ValueError("checkpoint manifest changed")
    expected: dict[str, str] = {}
    for line in ledger_path.read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        if len(digest) != 64 or not name.startswith("./"):
            raise ValueError("malformed checkpoint manifest")
        key = relative(name[2:]).as_posix()
        if key in expected:
            raise ValueError("duplicate checkpoint manifest path")
        expected[key] = digest
    actual: dict[str, str] = {}
    for path in sorted(CHECKPOINT.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"checkpoint symlink rejected: {path}")
        if path.is_file() and path != ledger_path:
            actual[path.relative_to(CHECKPOINT).as_posix()] = sha(path)
    if actual != expected:
        raise ValueError("checkpoint inventory differs")
    return actual


def exact_tool(path: Path, digest: str, *, executable: bool) -> None:
    canonical = path.resolve(strict=True)
    info = canonical.lstat()
    if path.is_symlink() or not stat.S_ISREG(info.st_mode) or sha(canonical) != digest:
        raise ValueError(f"tool changed: {path}")
    if executable and not os.access(canonical, os.X_OK):
        raise ValueError(f"tool is not executable: {path}")


def load_owned_helper():
    exact_tool(OWNED_HELPER, OWNED_HELPER_SHA, executable=False)
    spec = importlib.util.spec_from_file_location("reviewed_owned_process", OWNED_HELPER)
    if spec is None or spec.loader is None:
        raise ValueError("owned helper import failed")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def natural_lifecycle(path: Path) -> bool:
    value = json.loads(path.read_text(encoding="utf-8"))
    return (
        value.get("owned_group_identity_valid") is True
        and value.get("direct_child_joined") is True
        and value.get("timed_out") is False
        and value.get("term_attempted") is False
        and value.get("kill_attempted") is False
        and value.get("forced_cleanup") is False
        and value.get("group_joined") is True
        and value.get("direct_status") == 0
        and value.get("wait_returncode") == 0
    )


def main() -> int:
    if len(sys.argv) != 2:
        raise ValueError("usage: run-contract.py FRESH_OUTPUT")
    output = Path(sys.argv[1]).resolve()
    if output.exists() or output.is_symlink() or not output.parent.is_dir():
        raise ValueError("output must be fresh below an existing parent")
    output.mkdir(mode=0o700)
    records = output / "records"
    records.mkdir(mode=0o700)
    work = records / "contract-work"
    accepted = False
    issue = None
    before = None
    try:
        if sys.flags.isolated != 1 or not sys.dont_write_bytecode:
            raise ValueError("invocation requires Python -I -B")
        exact_tool(PYTHON, PYTHON_SHA, executable=True)
        exact_tool(BASH, BASH_SHA, executable=True)
        if sha(CONTRACT_DRIVER) != CONTRACT_DRIVER_SHA:
            raise ValueError("contract driver changed")
        before = checkpoint_inventory()
        owned = load_owned_helper()
        environment = {
            "HOME": "/home/user",
            "PATH": "/usr/bin:/bin",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONHASHSEED": "0",
            "LC_ALL": "C",
            "TZ": "Europe/Zurich",
        }
        write_json(records / "inputs-pre.json", {
            "schema_version": 1,
            "checkpoint_manifest_sha256": CHECKPOINT_SHA,
            "contract_driver_sha256": CONTRACT_DRIVER_SHA,
            "owned_process_helper_sha256": OWNED_HELPER_SHA,
            "python_sha256": PYTHON_SHA,
            "bash_sha256": BASH_SHA,
            "checkpoint_files": before,
        })
        status = owned.run(
            records,
            "tcp-state-contracts",
            [str(BASH), str(CONTRACT_DRIVER), str(CHECKPOINT / "integration"), str(work)],
            REPO,
            environment,
            60,
        )
        if status != 0:
            raise ValueError(f"contract driver returned {status}")
        if not natural_lifecycle(records / "tcp-state-contracts.lifecycle.json"):
            raise ValueError("contract process did not join naturally")
        if (records / "tcp-state-contracts.direct.status").read_text(encoding="utf-8") != "0\n":
            raise ValueError("owned direct status differs")
        if (work / "direct.status").read_text(encoding="utf-8") != "0\n":
            raise ValueError("inner direct status differs")
        result = json.loads((work / "result.json").read_text(encoding="utf-8"))
        if (type(result) is not dict or result.get("schema_version") != 1
                or result.get("accepted") is not True or result.get("case_count") != 25
                or len(result.get("cases", [])) != 25
                or any(type(row) is not dict or row.get("accepted") is not True for row in result["cases"])):
            raise ValueError("contract result differs")
        accepted = True
    except BaseException as error:
        issue = f"{type(error).__name__}: {error}"
        traceback.print_exc()
    finally:
        checks: dict[str, object] = {}
        try:
            after = checkpoint_inventory()
            checks["checkpoint_unchanged"] = before is not None and after == before
            checks["contract_driver_unchanged"] = sha(CONTRACT_DRIVER) == CONTRACT_DRIVER_SHA
            checks["owned_process_helper_unchanged"] = sha(OWNED_HELPER) == OWNED_HELPER_SHA
            checks["python_unchanged"] = sha(PYTHON.resolve(strict=True)) == PYTHON_SHA
            checks["bash_unchanged"] = sha(BASH.resolve(strict=True)) == BASH_SHA
            accepted = accepted and all(value is True for value in checks.values())
        except BaseException as error:
            accepted = False
            checks["finalization_error"] = f"{type(error).__name__}: {error}"
        write_json(records / "RESULT.json", {
            "schema_version": 1,
            "accepted": accepted,
            "issue": issue,
            "case_count": 25,
            "post_checks": checks,
            "endpoint_execution": False,
            "go_execution": False,
            "wan_traffic": False,
        })
        write_text(records / "final.status", "0\n" if accepted else "1\n")
        ledger = records / "SHA256SUMS.txt"
        with ledger.open("x", encoding="utf-8") as destination:
            for path in sorted(records.rglob("*")):
                if path.is_file() and path != ledger:
                    destination.write(f"{sha(path)}  ./{path.relative_to(records).as_posix()}\n")
        write_text(output / "FINAL", "complete\n")
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
