# TCP-state audited build derivative source checkpoint 2

This source-only checkpoint derives from accepted byte-credit build 5. It binds final TCP-state integration checkpoint 4, its exact 12-file source map, and its exact focused test plan. It is unexecuted.

The driver copies the accepted build-5 source into a fresh owned root, applies only checkpoint-root payload bytes, proves ordinary selected Go inputs remain byte-identical, records the exact tagged delta, runs affected agent and Yamux roots in normal and race modes, and creates fresh tagged agent and server binaries. Accepted raw and byte-credit ordinary proof receipts and unchanged server-focused evidence are reused; no new full ordinary proof or unchanged server test rerun is requested.

Acceptance requires pinned offline tools, exact Go JSON event sets, source/static pre/post equality, natural owned process-group joins without force, fresh binaries with audited Go metadata, a closed records ledger, and a receipt published last. No endpoint or WAN traffic belongs to this driver.
