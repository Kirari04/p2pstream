# TCP-state response-bound decision

Status: architecture decision recorded after the read-only runner integration
review. This note is append-only and does not alter the preserved review or any
frozen source/artifact.

The fixed 4,096 wait-record and 4,096 first-raw-record capacities per owner are
memory-safety ceilings. They are not a guarantee that every capacity-filling
snapshot can be serialized through the existing 4 MiB authenticated response.
The sizing lower bound in `RUNNER-INTEGRATION-REVIEW.md` remains useful for
showing that those ceilings are distinct.

Keep the current 4 MiB transport ceiling. If an actual complete snapshot would
exceed it, the existing bounded failure path must make the interval and whole run
invalid and retain the exact omitted snapshot size, digest, and error. It must
not truncate records, raise the bound silently, return a healthy classification,
or retry the destructive drain. A full-capacity response guarantee is not a
precondition for the successor.

The conservative current model uses 138 observed waits and estimates about
1.1 MiB of new TCP records. That is a planning estimate, not a size guarantee.
The first authorized tiny run must retain and report the actual response byte
counts; an oversize result is a valid failed diagnostic outcome and evidence for
reconsidering transport design. Do not reduce the fixed in-memory capacities or
add a file-backed transport before observed evidence requires either change.
