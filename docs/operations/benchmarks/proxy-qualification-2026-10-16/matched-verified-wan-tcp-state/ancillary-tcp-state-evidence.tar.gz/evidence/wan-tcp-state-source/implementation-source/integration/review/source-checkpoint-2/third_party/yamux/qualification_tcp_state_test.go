//go:build p2pstream_qualification

package yamux

import (
	"io"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

type qualificationTCPStateObserverSample struct {
	id             uint64
	kind           string
	classification string
	credit         uint32
	finished       bool
	afterValid     bool
}

type qualificationTCPStateObserver struct {
	mu      sync.Mutex
	armed   bool
	nextID  uint64
	samples []qualificationTCPStateObserverSample
	marks   uint64
}

func (*qualificationTCPStateObserver) Read([]byte) (int, error)    { return 0, io.EOF }
func (*qualificationTCPStateObserver) Write(p []byte) (int, error) { return len(p), nil }
func (*qualificationTCPStateObserver) Close() error                { return nil }

func (*qualificationTCPStateObserver) BeginQualificationRawWriteEnvelope(uint32, uint64, uint64, time.Time) uint64 {
	return 1
}
func (*qualificationTCPStateObserver) FinishQualificationRawWriteEnvelope(uint64) time.Time {
	return time.Now()
}
func (observer *qualificationTCPStateObserver) ArmQualificationTCPInterval(string) bool {
	observer.mu.Lock()
	defer observer.mu.Unlock()
	if observer.armed {
		return false
	}
	observer.armed = true
	return true
}
func (observer *qualificationTCPStateObserver) DisarmQualificationTCPInterval(string) bool {
	observer.mu.Lock()
	defer observer.mu.Unlock()
	if !observer.armed {
		return false
	}
	observer.armed = false
	return true
}
func (observer *qualificationTCPStateObserver) BeginQualificationTCPWaitSample(kind string, _ uint32, _ uint64, classification string, _, _ uint64, credit uint32, _ time.Time) uint64 {
	observer.mu.Lock()
	defer observer.mu.Unlock()
	if !observer.armed {
		return 0
	}
	observer.nextID++
	observer.samples = append(observer.samples, qualificationTCPStateObserverSample{
		id: observer.nextID, kind: kind, classification: classification, credit: credit,
	})
	return observer.nextID
}
func (observer *qualificationTCPStateObserver) FinishQualificationTCPWaitSample(id, _, _ uint64, valid bool) {
	observer.mu.Lock()
	defer observer.mu.Unlock()
	for index := range observer.samples {
		if observer.samples[index].id == id {
			observer.samples[index].finished = true
			observer.samples[index].afterValid = valid
			return
		}
	}
}
func (observer *qualificationTCPStateObserver) MarkQualificationTCPInterveningAllocation(uint32, uint64) {
	observer.mu.Lock()
	defer observer.mu.Unlock()
	if observer.armed {
		observer.marks++
	}
}
func (*qualificationTCPStateObserver) DrainQualificationRawWriteActivity() QualificationRawWriteActivity {
	return QualificationRawWriteActivity{}
}
func (*qualificationTCPStateObserver) RetireQualificationRawWriteActivity() {}

func qualificationTCPStateCompleteActualWrite(t *testing.T, session *Session, stream *Stream) {
	t.Helper()
	atomicStoreUint32ForQualificationTCPState(&stream.sendWindow, 0)
	execution := startQualificationByteCreditWrite(t, session, stream)
	waitForQualificationByteCreditActiveWait(t, session)
	header := header(make([]byte, headerSize))
	header.encode(typeWindowUpdate, 0, stream.id, 1)
	if err := stream.incrSendWindow(header, 0); err != nil {
		t.Fatalf("apply credit: %v", err)
	}
	select {
	case ready := <-session.sendCh:
		if ready.Commit != nil {
			ready.Commit()
		}
		ready.Err <- nil
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for DATA enqueue")
	}
	result := waitQualificationByteCreditWriteResult(t, execution)
	if result.err != nil || result.n != 1 {
		t.Fatalf("write result = %+v", result)
	}
}

func atomicStoreUint32ForQualificationTCPState(target *uint32, value uint32) {
	// Kept as a tiny wrapper so the actual Stream.write control stays readable.
	atomic.StoreUint32(target, value)
}

func TestQualificationTCPStateActualStreamWriteSelectedAndUnarmed(t *testing.T) {
	for _, test := range []struct {
		name  string
		armed bool
	}{
		{name: "conditioning_unarmed", armed: false},
		{name: "selected_armed", armed: true},
	} {
		t.Run(test.name, func(t *testing.T) {
			resetQualificationByteCreditTraceForTest(t)
			session, stream := newQualificationByteCreditTestStream(41)
			observer := &qualificationTCPStateObserver{}
			session.conn = observer
			if test.armed && !observer.ArmQualificationTCPInterval("9") {
				t.Fatal("arm observer")
			}
			qualificationTCPStateCompleteActualWrite(t, session, stream)
			observer.mu.Lock()
			defer observer.mu.Unlock()
			if !test.armed {
				if len(observer.samples) != 0 || observer.marks != 0 {
					t.Fatalf("unarmed samples=%+v marks=%d", observer.samples, observer.marks)
				}
				return
			}
			if len(observer.samples) != 2 {
				t.Fatalf("armed samples=%+v", observer.samples)
			}
			entry, retry := observer.samples[0], observer.samples[1]
			if entry.kind != "entry" || entry.classification != "pending" || entry.credit != 0 || !entry.finished || !entry.afterValid ||
				retry.kind != "retry" || retry.classification != "applied_range" || retry.credit == 0 || !retry.finished || !retry.afterValid {
				t.Fatalf("entry=%+v retry=%+v", entry, retry)
			}
		})
	}
}

func TestQualificationTCPStateActualUnarmedAppliedRetryThenAllocation(t *testing.T) {
	resetQualificationByteCreditTraceForTest(t)
	session, stream := newQualificationByteCreditTestStream(43)
	observer := &qualificationTCPStateObserver{}
	session.conn = observer
	session.aggregate.mu.Lock()
	session.aggregate.sendWindow = 0
	session.aggregate.mu.Unlock()
	atomic.StoreUint32(&stream.sendWindow, 0)
	execution := startQualificationByteCreditWrite(t, session, stream)
	waitForQualificationByteCreditActiveWait(t, session)
	header := header(make([]byte, headerSize))
	header.encode(typeWindowUpdate, 0, stream.id, 1)
	if err := stream.incrSendWindow(header, 0); err != nil {
		t.Fatalf("apply credit: %v", err)
	}
	deadline := time.Now().Add(time.Second)
	for {
		session.aggregate.mu.Lock()
		waitingOnAllocation := session.aggregate.sendNotifyRegistered
		session.aggregate.mu.Unlock()
		if waitingOnAllocation {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("timed out waiting for aggregate allocation wait")
		}
		time.Sleep(time.Millisecond)
	}
	closeQualificationByteCreditTestSession(session)
	result := waitQualificationByteCreditWriteResult(t, execution)
	if result.err != ErrSessionShutdown {
		t.Fatalf("write error=%v, want %v", result.err, ErrSessionShutdown)
	}
	observer.mu.Lock()
	if len(observer.samples) != 0 || observer.marks != 0 {
		observer.mu.Unlock()
		t.Fatalf("unarmed samples=%+v marks=%d", observer.samples, observer.marks)
	}
	observer.mu.Unlock()
	if !observer.ArmQualificationTCPInterval("9") {
		t.Fatal("unarmed allocation path poisoned the next arm")
	}
}
