//go:build p2pstream_qualification

package yamux

import "time"

const QualificationTCPStateSchemaVersion = 1
const QualificationTCPStateRecordLimit = 4096

// QualificationTCPInfoAvailability distinguishes an available zero from a
// field omitted by a shorter kernel TCP_INFO result.
type QualificationTCPInfoAvailability struct {
	State                  bool `json:"state"`
	CAState                bool `json:"ca_state"`
	Retransmits            bool `json:"retransmits"`
	RTO                    bool `json:"rto"`
	SendMSS                bool `json:"send_mss"`
	Unacked                bool `json:"unacked"`
	Lost                   bool `json:"lost"`
	Retrans                bool `json:"retrans"`
	LastDataSent           bool `json:"last_data_sent"`
	RTT                    bool `json:"rtt"`
	RTTVariance            bool `json:"rtt_variance"`
	SendSlowStartThreshold bool `json:"send_slow_start_threshold"`
	SendCongestionWindow   bool `json:"send_congestion_window"`
	TotalRetrans           bool `json:"total_retrans"`
	PacingRate             bool `json:"pacing_rate"`
	BytesAcked             bool `json:"bytes_acked"`
	NotSentBytes           bool `json:"not_sent_bytes"`
	DeliveryRate           bool `json:"delivery_rate"`
	BytesSent              bool `json:"bytes_sent"`
	BytesRetransmitted     bool `json:"bytes_retransmitted"`
	SendWindow             bool `json:"send_window"`
	TotalRTO               bool `json:"total_rto"`
	TotalRTORecoveries     bool `json:"total_rto_recoveries"`
	TotalRTOTime           bool `json:"total_rto_time"`
}

// QualificationTCPInfoSnapshot is one synchronous, non-atomic view of the
// exact owned TCP socket. It is evidence about sampled state only.
type QualificationTCPInfoSnapshot struct {
	SchemaVersion              int                              `json:"schema_version"`
	Captured                   bool                             `json:"captured"`
	CaptureStartedUnixNS       int64                            `json:"capture_started_unix_ns"`
	CaptureFinishedUnixNS      int64                            `json:"capture_finished_unix_ns"`
	CaptureDurationNS          uint64                           `json:"capture_duration_ns"`
	CaptureMonotonicValid      bool                             `json:"capture_monotonic_valid"`
	CaptureStartedMonotonicNS  uint64                           `json:"capture_started_monotonic_ns"`
	CaptureFinishedMonotonicNS uint64                           `json:"capture_finished_monotonic_ns"`
	TCPInfoAttempted           bool                             `json:"tcp_info_attempted"`
	TCPInfoSucceeded           bool                             `json:"tcp_info_succeeded"`
	TCPInfoOptlen              uint32                           `json:"tcp_info_optlen"`
	TCPInfoStructSize          uint32                           `json:"tcp_info_struct_size"`
	RequiredFieldEndOffset     uint32                           `json:"required_field_end_offset"`
	CongestionControlAttempted bool                             `json:"congestion_control_attempted"`
	CongestionControlSucceeded bool                             `json:"congestion_control_succeeded"`
	CongestionControlOptlen    uint32                           `json:"congestion_control_optlen"`
	CongestionControl          string                           `json:"congestion_control"`
	FailureStage               string                           `json:"failure_stage"`
	FailureErrno               int64                            `json:"failure_errno"`
	Availability               QualificationTCPInfoAvailability `json:"availability"`
	State                      uint8                            `json:"state"`
	CAState                    uint8                            `json:"ca_state"`
	Retransmits                uint8                            `json:"retransmits"`
	RTOUsec                    uint32                           `json:"rto_us"`
	SendMSS                    uint32                           `json:"send_mss"`
	Unacked                    uint32                           `json:"unacked"`
	Lost                       uint32                           `json:"lost"`
	Retrans                    uint32                           `json:"retrans"`
	LastDataSentMS             uint32                           `json:"last_data_sent_ms"`
	RTTUsec                    uint32                           `json:"rtt_us"`
	RTTVarianceUsec            uint32                           `json:"rtt_variance_us"`
	SendSlowStartThreshold     uint32                           `json:"send_slow_start_threshold"`
	SendCongestionWindow       uint32                           `json:"send_congestion_window"`
	TotalRetrans               uint32                           `json:"total_retrans"`
	PacingRateBytesPerSecond   uint64                           `json:"pacing_rate_bytes_per_second"`
	BytesAcked                 uint64                           `json:"bytes_acked"`
	NotSentBytes               uint32                           `json:"not_sent_bytes"`
	DeliveryRateBytesPerSecond uint64                           `json:"delivery_rate_bytes_per_second"`
	BytesSent                  uint64                           `json:"bytes_sent"`
	BytesRetransmitted         uint64                           `json:"bytes_retransmitted"`
	SendWindowBytes            uint32                           `json:"send_window_bytes"`
	TotalRTO                   uint16                           `json:"total_rto"`
	TotalRTORecoveries         uint16                           `json:"total_rto_recoveries"`
	TotalRTOTimeMS             uint32                           `json:"total_rto_time_ms"`
}

type QualificationTCPStateSample struct {
	Present                bool                         `json:"present"`
	Complete               bool                         `json:"complete"`
	CaptureError           bool                         `json:"capture_error"`
	SampleID               uint64                       `json:"sample_id"`
	Kind                   string                       `json:"kind"`
	Classification         string                       `json:"classification"`
	Credit                 uint32                       `json:"credit"`
	ObservedUnixNS         int64                        `json:"observed_unix_ns"`
	ObservedMonotonicValid bool                         `json:"observed_monotonic_valid"`
	ObservedMonotonicNS    uint64                       `json:"observed_monotonic_ns"`
	CursorBeforeOrdinal    uint64                       `json:"cursor_before_ordinal"`
	CursorBeforeCumulative uint64                       `json:"cursor_before_cumulative"`
	CursorAfterValid       bool                         `json:"cursor_after_valid"`
	CursorAfterOrdinal     uint64                       `json:"cursor_after_ordinal"`
	CursorAfterCumulative  uint64                       `json:"cursor_after_cumulative"`
	CursorChanged          bool                         `json:"cursor_changed"`
	TCPInfo                QualificationTCPInfoSnapshot `json:"tcp_info"`
}

type QualificationTCPWaitRecord struct {
	RecordID              uint64                      `json:"record_id"`
	StreamID              uint32                      `json:"stream_id"`
	WaitToken             uint64                      `json:"wait_token"`
	InterveningAllocation bool                        `json:"intervening_allocation"`
	PendingRaw            bool                        `json:"pending_raw"`
	Claimed               bool                        `json:"claimed"`
	RawPairRecordID       uint64                      `json:"raw_pair_record_id"`
	Active                bool                        `json:"active"`
	Ambiguous             bool                        `json:"ambiguous"`
	Entry                 QualificationTCPStateSample `json:"entry"`
	Retry                 QualificationTCPStateSample `json:"retry"`
}

type QualificationTCPRawPairRecord struct {
	RecordID                     uint64                       `json:"record_id"`
	WaitRecordID                 uint64                       `json:"wait_record_id"`
	StreamID                     uint32                       `json:"stream_id"`
	WaitToken                    uint64                       `json:"wait_token"`
	EnvelopeToken                uint64                       `json:"envelope_token"`
	Committed                    bool                         `json:"committed"`
	Active                       bool                         `json:"active"`
	Ambiguous                    bool                         `json:"ambiguous"`
	BeforeCaptureError           bool                         `json:"before_capture_error"`
	AfterCaptureError            bool                         `json:"after_capture_error"`
	BracketValid                 bool                         `json:"bracket_valid"`
	RawWriteStartedUnixNS        int64                        `json:"raw_write_started_unix_ns"`
	RawWriteFinishedUnixNS       int64                        `json:"raw_write_finished_unix_ns"`
	RawWriteMonotonicValid       bool                         `json:"raw_write_monotonic_valid"`
	RawWriteStartedMonotonicNS   uint64                       `json:"raw_write_started_monotonic_ns"`
	RawWriteFinishedMonotonicNS  uint64                       `json:"raw_write_finished_monotonic_ns"`
	AdditionalContainedRawWrites uint64                       `json:"additional_contained_raw_writes"`
	Before                       QualificationTCPInfoSnapshot `json:"before"`
	After                        QualificationTCPInfoSnapshot `json:"after"`
}

// QualificationTCPThresholdHistoryRecord brackets one existing raw connection
// Write. TLS handshake, alert, and control writes have no DATA attribution;
// those fields remain zero rather than being inferred from ciphertext.
type QualificationTCPThresholdHistoryRecord struct {
	Present                       bool                         `json:"present"`
	RawWriteOrdinal               uint64                       `json:"raw_write_ordinal"`
	OwnerLane                     int                          `json:"owner_lane"`
	OwnerGeneration               uint64                       `json:"owner_generation"`
	LocalAddress                  string                       `json:"local_address"`
	RemoteAddress                 string                       `json:"remote_address"`
	AttemptedBytes                uint64                       `json:"attempted_bytes"`
	WrittenBytes                  uint64                       `json:"written_bytes"`
	WriteError                    bool                         `json:"write_error"`
	ShortWrite                    bool                         `json:"short_write"`
	EnvelopeAttributed            bool                         `json:"envelope_attributed"`
	EnvelopeToken                 uint64                       `json:"envelope_token"`
	StreamID                      uint32                       `json:"stream_id"`
	EnvelopePayloadBytes          uint64                       `json:"envelope_payload_bytes"`
	EnvelopeWireBytes             uint64                       `json:"envelope_wire_bytes"`
	RawWriteStartedUnixNS         int64                        `json:"raw_write_started_unix_ns"`
	RawWriteFinishedUnixNS        int64                        `json:"raw_write_finished_unix_ns"`
	RawWriteMonotonicValid        bool                         `json:"raw_write_monotonic_valid"`
	RawWriteStartedMonotonicNS    uint64                       `json:"raw_write_started_monotonic_ns"`
	RawWriteFinishedMonotonicNS   uint64                       `json:"raw_write_finished_monotonic_ns"`
	BracketValid                  bool                         `json:"bracket_valid"`
	TransitionLocation            string                       `json:"transition_location"`
	TransitionObservedAcrossWrite bool                         `json:"transition_observed_across_write"`
	Before                        QualificationTCPInfoSnapshot `json:"before"`
	After                         QualificationTCPInfoSnapshot `json:"after"`
}

// QualificationTCPThresholdHistory is constant-size, qualification-only
// evidence about the first sampled snd_ssthresh change on one owned socket.
// Its discrete brackets are not an atomic trace of a kernel assignment.
type QualificationTCPThresholdHistory struct {
	SchemaVersion                            int                                    `json:"schema_version"`
	Enabled                                  bool                                   `json:"enabled"`
	Required                                 bool                                   `json:"required"`
	Monitoring                               bool                                   `json:"monitoring"`
	Complete                                 bool                                   `json:"complete"`
	TransitionObserved                       bool                                   `json:"transition_observed"`
	SelectedPreCompared                      bool                                   `json:"selected_pre_compared"`
	SelectedPreSequence                      string                                 `json:"selected_pre_sequence"`
	SelectedPreArmOrdinal                    uint64                                 `json:"selected_pre_arm_ordinal"`
	SelectedPreInitial                       bool                                   `json:"selected_pre_initial"`
	SelectedPreMatched                       bool                                   `json:"selected_pre_matched"`
	Inconclusive                             bool                                   `json:"inconclusive"`
	FailureReason                            string                                 `json:"failure_reason"`
	ExplanationStatus                        string                                 `json:"explanation_status"`
	ExplanationAvailable                     bool                                   `json:"explanation_available"`
	ExplanationInconclusive                  bool                                   `json:"explanation_inconclusive"`
	ExplanationReason                        string                                 `json:"explanation_reason"`
	PreBindUnobserved                        bool                                   `json:"pre_bind_unobserved"`
	Exhausted                                bool                                   `json:"exhausted"`
	ActiveSample                             bool                                   `json:"active_sample"`
	Closed                                   bool                                   `json:"closed"`
	BaselineThreshold                        uint32                                 `json:"baseline_threshold"`
	FirstChangedThreshold                    uint32                                 `json:"first_changed_threshold"`
	SelectedPreThreshold                     uint32                                 `json:"selected_pre_threshold"`
	SelectedPreTCPInfo                       QualificationTCPInfoSnapshot           `json:"selected_pre_tcp_info"`
	RawWriteOrdinal                          uint64                                 `json:"raw_write_ordinal"`
	MonitoredRawWriteAttempts                uint64                                 `json:"monitored_raw_write_attempts"`
	ProviderCaptureCalls                     uint64                                 `json:"provider_capture_calls"`
	ProviderCaptureErrors                    uint64                                 `json:"provider_capture_errors"`
	ProviderCaptureDuration                  QualificationDurationBucket            `json:"provider_capture_duration"`
	RawProviderCallsSharedWithTCPInterval    uint64                                 `json:"raw_provider_calls_shared_with_tcp_interval"`
	RawProviderDurationSharedWithTCPInterval QualificationDurationBucket            `json:"raw_provider_duration_shared_with_tcp_interval"`
	Baseline                                 QualificationTCPInfoSnapshot           `json:"baseline"`
	LastEqual                                QualificationTCPThresholdHistoryRecord `json:"last_equal"`
	FirstDifferent                           QualificationTCPThresholdHistoryRecord `json:"first_different"`
	Failure                                  QualificationTCPThresholdHistoryRecord `json:"failure"`
}

// QualificationTCPStateActivity is part of the existing destructive raw
// activity drain. The fixed internal capacities are safety bounds, not a
// guarantee that a full interval fits the authenticated response byte bound.
type QualificationTCPStateActivity struct {
	SchemaVersion         int                              `json:"schema_version"`
	Enabled               bool                             `json:"enabled"`
	Bound                 bool                             `json:"bound"`
	Armed                 bool                             `json:"armed"`
	Sequence              string                           `json:"sequence"`
	Complete              bool                             `json:"complete"`
	ResetPerformed        bool                             `json:"reset_performed"`
	Invalid               bool                             `json:"invalid"`
	Ambiguous             bool                             `json:"ambiguous"`
	Overflow              bool                             `json:"overflow"`
	TCPSlowStartAfterIdle int                              `json:"tcp_slow_start_after_idle"`
	ActiveSamples         uint64                           `json:"active_samples"`
	PendingRawClaims      uint64                           `json:"pending_raw_claims"`
	ActiveRawPairs        uint64                           `json:"active_raw_pairs"`
	DroppedWaitRecords    uint64                           `json:"dropped_wait_records"`
	DroppedRawPairRecords uint64                           `json:"dropped_raw_pair_records"`
	CaptureCalls          uint64                           `json:"capture_calls"`
	CaptureErrors         uint64                           `json:"capture_errors"`
	CaptureDuration       QualificationDurationBucket      `json:"capture_duration"`
	BindTCPInfo           QualificationTCPInfoSnapshot     `json:"bind_tcp_info"`
	LastLiveTCPInfo       QualificationTCPInfoSnapshot     `json:"last_live_tcp_info"`
	PreTCPInfo            QualificationTCPInfoSnapshot     `json:"pre_tcp_info"`
	PostTCPInfo           QualificationTCPInfoSnapshot     `json:"post_tcp_info"`
	WaitRecords           []QualificationTCPWaitRecord     `json:"wait_records"`
	RawPairs              []QualificationTCPRawPairRecord  `json:"raw_pairs"`
	ThresholdHistory      QualificationTCPThresholdHistory `json:"threshold_history"`
}

type qualificationTCPWaitCursor struct {
	Ordinal    uint64
	Cumulative uint64
}

func qualificationObserveTCPWaitSample(s *Stream, h qualificationByteCreditWaitHandle, kind, classification string, observed time.Time) bool {
	if s == nil || s.session == nil || !h.valid || observed.IsZero() {
		return false
	}
	before, credit, ok := qualificationByteCreditTCPCursor(s, h)
	if !ok {
		return false
	}
	observer := s.session.qualificationRawWriteObserver()
	if observer == nil {
		return false
	}
	sampleID := observer.BeginQualificationTCPWaitSample(kind, s.id, h.token, classification, before.Ordinal, before.Cumulative, credit, observed)
	if sampleID == 0 {
		return false
	}
	after, _, afterValid := qualificationByteCreditTCPCursor(s, h)
	observer.FinishQualificationTCPWaitSample(sampleID, after.Ordinal, after.Cumulative, afterValid)
	return true
}

func qualificationMarkTCPInterveningAllocation(s *Stream, h qualificationByteCreditWaitHandle) {
	if s == nil || s.session == nil || !h.valid {
		return
	}
	observer := s.session.qualificationRawWriteObserver()
	if observer != nil {
		observer.MarkQualificationTCPInterveningAllocation(s.id, h.token)
	}
}
