# Threshold-history tiny smoke launcher working source

Source-only derivative of the accepted TCP-state tiny launcher (`82681c52…`). It preserves the reviewed 4 MiB warmup, 4 MiB steady, three repetitions, 2 MiB pool, RTT 80 ms, sequential H1 continuation gate before H2, fresh endpoints, owned natural lifecycle, tool environment, generated runner, timed transfer body, 4 MiB control response bound, and source pre/post inventory checks. It changes only the accepted threshold-history build tuple, prior accepted TCP tiny bindings, eventual runner/materialization/publication/final-contract bindings, and fresh output path. No idle-timeout or performance gate is added.

All runner, active-root, materialization, publication, final-contract, build, binary, and invocation bindings are populated. No endpoint or traffic command has run from this source.
