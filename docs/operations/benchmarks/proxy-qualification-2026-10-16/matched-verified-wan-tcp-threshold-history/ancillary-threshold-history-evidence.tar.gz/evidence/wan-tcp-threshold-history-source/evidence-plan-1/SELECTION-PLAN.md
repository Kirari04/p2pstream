# TCP threshold-history evidence selection plan

Status: source-only staging. No archive or tracked files are created by this plan. Tiny and sustained result selections remain pending their frozen reviews.

## Preserve in full

- Producer checkpoints 1–8, including metadata-only rejections, source defects, the cp4/cp5/cp6/cp7 succession, and accepted cp8.
- Validator checkpoints 1–2 and invocation sources 1–2, including the rejected permissive state table and the accepted exact 68-case contract.
- Build source checkpoints 1–5, all no-Go preflight failures, and all three audited build attempts. Attempts 1 and 2 remain failed evidence; attempt 3 is the accepted 21-stage build.
- The strict-shell native-wrapper discrepancy review and every raw reported exit status. The evidence must not infer an underlying cause or rewrite outer status from an inner direct status.
- Runner source checkpoint 1, exact 38-file corpus, source delta, materialization result, receipt publication source/result, unexecuted rejected final-contract invocation source 1, corrected source 2, accepted final-contract records, and the limited native envelope.
- Future tiny and sustained safe selections, review ledgers, semantic reviews, launch ledgers, summaries, attestations, and public certificates after those runs are frozen.

## Include selected run evidence

For each WAN run, retain compact results, summaries, arm attestations, sender/raw/TCP/history validator outputs, terminal closure, resource/namespace attestations, lifecycle records, source pre/post hashes, launch result/ledger, review, and public certificate. Large selected JSON belongs in the deterministic archive only, not duplicated loose.

## Omit bytes but retain exact hash metadata

- Audited server and agent binaries.
- Go build/test caches, copied base source trees, and duplicate materialized source bytes already bound by exact corpus manifests.
- Private TLS keys, bearer/control secrets, readiness files, private namespace/process control files, and unreviewed raw logs.
- Full raw WAN trees; their frozen complete ledgers bind omitted files and exact sizes.
- Python caches and temporary working files.

The omission table must identify source path, SHA-256, size, reason, and the authoritative ledger. Secret scans are nonprinting and operate on the exact package allowlist. No gate clearance, production fix, parity claim, or causal claim is permitted.
