#!/usr/bin/env python3
"""Static fail-closed contracts for the byte-credit runner derivative."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INTEGRATION = ROOT / "integration"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


runner = INTEGRATION / "generated/qualify-proxy-agent-growth-wan-below-tls.sh"
arm = INTEGRATION / "run-wan-below-tls-arm.sh"
pair = INTEGRATION / "run-wan-below-tls-diagnostic.sh"
validator = INTEGRATION / "validate-wan-below-tls-arm.py"
runner_text = runner.read_text(encoding="utf-8")
arm_text = arm.read_text(encoding="utf-8")
pair_text = pair.read_text(encoding="utf-8")
validator_text = validator.read_text(encoding="utf-8")

require(sha(runner) == "a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad",
        "mature generated runner changed")
require(runner_text.count("wan_sender_wait_query()") == 1, "query helper cardinality changed")
require("DrainQualificationByteCreditTrace" not in runner_text,
        "runner added an observer poll instead of using existing authenticated drains")
for text, label in ((arm_text, "arm"), (pair_text, "pair")):
    require("expected_raw_ordinary_proof_receipt_sha256=b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d" in text,
            f"{label} changed the mature raw ordinary-proof gate")
    require("expected_byte_credit_ordinary_proof_receipt_sha256=6562b975ba8f25d1b7a1a83c323c4c289f62f97b5508421e9e0f2e244c940460" in text,
            f"{label} omitted the separate accepted byte-credit proof")
    require('byte_credit_ordinary_proof_receipt="$combined_root/provenance/byte-credit-ordinary-proof-receipt.json"' in text,
            f"{label} did not use the canonical published byte-credit proof")
    require("expected_combined_build_receipt_sha256=dae7e3e7e58cd829804b07aea9b063aa6d0233552ae0068d9c38725bed427f13" in text,
            f"{label} omitted the accepted audited build receipt")
    pending_prefix = "PENDING_" + "BYTE_CREDIT_"
    require(pending_prefix not in text,
            f"{label} retained a pending receipt binding")
    require(pending_prefix + "ORDINARY_PROOF" not in text,
            f"{label} retained a superseded proof placeholder")
    for required in (
        '.diagnostic == "wan-byte-credit-recycle"',
        '.diagnostic == "wan-tcp-threshold-history-qualification"',
        '.strict_proof_accepted == false',
        '.supplemental_reference_equivalence_accepted == true',
        '.byte_credit_ordinary_proof_receipt_sha256 == $byte_proof',
        '.base_build_receipt_sha256 == "bcca6079b5de32635701b4a1d5195cd9b9f9e8976d76e48956cea7d396cb7b97"',
    ):
        require(required in text, f"{label} missing receipt gate: {required}")

for text, label in ((arm_text, "arm"), (pair_text, "pair")):
    require(text.count('"$raw_ordinary_proof_receipt" "$byte_credit_ordinary_proof_receipt" "$combined_build_receipt"') == 1,
            f"{label} producer argv must contain the three receipts exactly once in order")
    require(text.count('raw_ordinary_proof_receipt, byte_credit_ordinary_proof_receipt, combined_build_receipt') == 1 or
            text.count('raw_ordinary_proof_receipt byte_credit_ordinary_proof_receipt combined_build_receipt') == 1,
            f"{label} producer mapping omitted the distinct proof/build receipt names")

for text, label in ((arm_text, "arm"), (pair_text, "pair")):
    for required in (
        "byte_credit_adapter_checkpoint", "byte_credit_adapter_contract_ledger",
        "byte_credit_protocol_checkpoint", "byte_credit_protocol_focused_ledger",
        "byte_credit_protocol_focused_outer", "byte_credit_validator",
        "tcp_state_validator", "tcp_producer_checkpoint", "tcp_source_map",
        "tcp_build_records_ledger", "tcp_build_outer_ledger",
        "tcp_validator_contract_ledger", "tcp_validator_contract_outer",
    ):
        require(required in text, f"{label} missing {required}")
require('"byte_credit_recycle_intervals"' in validator_text,
        "arm validator omitted byte-credit interval results")
require("4b91d78895462b0280ac0915bbf9580e49c864b747a6f231c3065d227f994062" in arm_text and
        "4b91d78895462b0280ac0915bbf9580e49c864b747a6f231c3065d227f994062" in pair_text,
        "adapter checkpoint 11 is not bound in both wrappers")
require("bcca6079b5de32635701b4a1d5195cd9b9f9e8976d76e48956cea7d396cb7b97" in arm_text and "bcca6079b5de32635701b4a1d5195cd9b9f9e8976d76e48956cea7d396cb7b97" in pair_text,
        "accepted base TCP build receipt ancestry is not bound in both wrappers")
require('"byte_credit_validator"' in validator_text and
        '"byte_credit_adapter_checkpoint"' in validator_text and
        '"tcp_state_validator"' in validator_text and
        '"tcp_validator_contract_ledger"' in validator_text,
        "arm validator omitted additive provenance keys")
for path, expected in (
    (INTEGRATION / "validate-byte-credit-recycle.py", "e53f911e0362eeae728a55386cce5ebb0eb60a52163df14f8a95d0135aa0c3eb"),
    (INTEGRATION / "validate-sender-wait-snapshot.py", "cf813b4863a087eb4b944a60aaa745bddbceb65c185f839ccc78a0690b4a89fc"),
    (INTEGRATION / "validate-server-receive-growth.py", "bab8a8def06fc4347b5cfd8e7547c40ca85013fe28892da43c0e365c32dd7477"),
):
    require(sha(path) == expected, f"validator source changed: {path.name}")

print(json.dumps({"schema_version": 1, "accepted": True,
                  "scope": "runner-and-validator-source-bindings"}, sort_keys=True))
