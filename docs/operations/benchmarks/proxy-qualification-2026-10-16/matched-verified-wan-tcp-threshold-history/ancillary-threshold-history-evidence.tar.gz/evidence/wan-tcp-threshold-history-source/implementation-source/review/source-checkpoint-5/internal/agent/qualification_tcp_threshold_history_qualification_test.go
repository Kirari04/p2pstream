//go:build linux && p2pstream_qualification

package agent

import (
	"crypto/tls"
	"encoding/json"
	"errors"
	"io"
	"math"
	"net"
	"net/http"
	"net/http/httptest"
	"sync"
	"syscall"
	"testing"
	"time"

	"github.com/hashicorp/yamux"
)

type qualificationTCPThresholdTestProvider struct {
	mu         sync.Mutex
	thresholds []uint32
	snapshots  []qualificationTCPInfoSnapshot
	errors     map[int]error
	calls      int
	entered    chan struct{}
	release    chan struct{}
	enterOnce  sync.Once
}

func (provider *qualificationTCPThresholdTestProvider) capture(_ syscall.RawConn) (qualificationTCPInfoSnapshot, error) {
	provider.mu.Lock()
	call := provider.calls
	provider.calls++
	threshold := uint32(math.MaxInt32)
	if call < len(provider.thresholds) {
		threshold = provider.thresholds[call]
	}
	captureErr := provider.errors[call]
	var snapshot qualificationTCPInfoSnapshot
	if call < len(provider.snapshots) {
		snapshot = provider.snapshots[call]
	}
	entered, release := provider.entered, provider.release
	provider.mu.Unlock()
	if entered != nil && call == 0 {
		provider.enterOnce.Do(func() { close(entered) })
		<-release
	}
	if captureErr != nil {
		return qualificationTCPInfoSnapshot{}, captureErr
	}
	if snapshot.Captured || snapshot.TCPInfoAttempted || snapshot.CongestionControlAttempted {
		return snapshot, nil
	}
	return qualificationTCPThresholdTestSnapshot(threshold), nil
}

func (provider *qualificationTCPThresholdTestProvider) callCount() int {
	provider.mu.Lock()
	defer provider.mu.Unlock()
	return provider.calls
}

func qualificationTCPThresholdTestSnapshot(threshold uint32) qualificationTCPInfoSnapshot {
	now := time.Now()
	return qualificationTCPInfoSnapshot{
		SchemaVersion: qualificationTCPInfoSnapshotSchemaVersion,
		Captured:      true, TCPInfoAttempted: true, TCPInfoSucceeded: true,
		CongestionControlAttempted: true, CongestionControlSucceeded: true,
		CongestionControl: "cubic", SendSlowStartThreshold: threshold,
		Availability:   qualificationTCPInfoFieldAvailability{SendSlowStartThreshold: true},
		captureStarted: now, captureFinished: now,
		CaptureStartedUnixNS: now.UnixNano(), CaptureFinishedUnixNS: now.UnixNano(),
	}
}

func qualificationTCPThresholdTestOwner(t *testing.T, lane int, baseline uint32, provider *qualificationTCPThresholdTestProvider) *qualificationRawWriteOwner {
	t.Helper()
	raw := qualificationTCPInfoTestRaw(1)
	snapshot := qualificationTCPThresholdTestSnapshot(baseline)
	owner := &qualificationRawWriteOwner{
		lane: lane, generation: 7, rawBound: true, bodyBound: true,
		localAddress: "local", remoteAddress: "remote",
	}
	if !owner.bindTCPState(raw, snapshot, 1) {
		t.Fatal("bind TCP state")
	}
	owner.mu.Lock()
	owner.tcp.thresholdHistory.capture = provider.capture
	owner.mu.Unlock()
	return owner
}

func qualificationTCPThresholdTestWrite(t *testing.T, owner *qualificationRawWriteOwner, conn *qualificationRawWriteTestConn) {
	t.Helper()
	observed := &qualificationObservedRawConn{Conn: conn, owner: owner}
	if written, err := observed.Write([]byte("threshold-history")); err != nil || written != len("threshold-history") {
		t.Fatalf("Write = %d, %v", written, err)
	}
}

func qualificationTCPThresholdTestActivity(owner *qualificationRawWriteOwner) yamux.QualificationTCPThresholdHistory {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	return owner.tcpThresholdHistoryPublicLocked()
}

func TestQualificationTCPThresholdHistoryFirstTransition(t *testing.T) {
	t.Run("across_pre_tls_write_and_stop", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{thresholds: []uint32{math.MaxInt32, 240}}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		activity := qualificationTCPThresholdTestActivity(owner)
		if !activity.TransitionObserved || activity.FirstChangedThreshold != 240 ||
			activity.FirstDifferent.TransitionLocation != "across_write_observation" ||
			!activity.FirstDifferent.TransitionObservedAcrossWrite || activity.FirstDifferent.EnvelopeAttributed ||
			activity.RawWriteOrdinal != 2 || activity.MonitoredRawWriteAttempts != 1 || provider.callCount() != 2 {
			t.Fatalf("activity = %+v; provider calls = %d", activity, provider.callCount())
		}
	})

	t.Run("between_control_writes", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{thresholds: []uint32{math.MaxInt32, math.MaxInt32, 246, 246}}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		activity := qualificationTCPThresholdTestActivity(owner)
		if activity.LastEqual.RawWriteOrdinal != 1 || activity.FirstDifferent.RawWriteOrdinal != 2 ||
			activity.FirstDifferent.TransitionLocation != "between_writes" ||
			activity.FirstDifferent.TransitionObservedAcrossWrite || activity.FirstChangedThreshold != 246 {
			t.Fatalf("activity = %+v", activity)
		}
	})

	t.Run("between_bind_and_first_write", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{thresholds: []uint32{240, 240}}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		record := qualificationTCPThresholdTestActivity(owner).FirstDifferent
		if record.RawWriteOrdinal != 1 || record.TransitionLocation != "between_bind_and_first_write" ||
			record.TransitionObservedAcrossWrite {
			t.Fatalf("record = %+v", record)
		}
	})

	t.Run("data_attribution", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{thresholds: []uint32{math.MaxInt32, 250}}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		token := owner.beginEnvelope(23, 10, 22, time.Now())
		if token == 0 {
			t.Fatal("begin DATA envelope")
		}
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		owner.finishEnvelopeNow(token)
		record := qualificationTCPThresholdTestActivity(owner).FirstDifferent
		if !record.EnvelopeAttributed || record.EnvelopeToken != token || record.StreamID != 23 ||
			record.EnvelopePayloadBytes != 10 || record.EnvelopeWireBytes != 22 {
			t.Fatalf("record = %+v", record)
		}
	})
}

func TestQualificationTCPThresholdHistorySelectedPreClassification(t *testing.T) {
	t.Run("not_reproduced", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		owner.mu.Lock()
		owner.compareTCPThresholdHistorySelectedPreLocked("9", qualificationTCPThresholdTestSnapshot(math.MaxInt32), nil)
		owner.mu.Unlock()
		owner.markClosed()
		activity := qualificationTCPThresholdTestActivity(owner)
		if !activity.Complete || activity.Inconclusive || !activity.SelectedPreInitial ||
			activity.ExplanationStatus != "not_reproduced" {
			t.Fatalf("activity = %+v", activity)
		}
	})

	t.Run("transition_observed_with_initial_pre", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{thresholds: []uint32{math.MaxInt32, 251}}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		owner.mu.Lock()
		owner.compareTCPThresholdHistorySelectedPreLocked("9", qualificationTCPThresholdTestSnapshot(math.MaxInt32), nil)
		owner.mu.Unlock()
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		owner.markClosed()
		activity := qualificationTCPThresholdTestActivity(owner)
		if !activity.Complete || !activity.TransitionObserved || !activity.SelectedPreInitial ||
			activity.ExplanationStatus != "transition_observed_with_initial_pre" {
			t.Fatalf("activity = %+v", activity)
		}
	})

	for _, test := range []struct {
		name     string
		changed  uint32
		selected uint32
		failure  string
		matched  bool
	}{
		{name: "matched", changed: 240, selected: 240, matched: true},
		{name: "mismatch", changed: 240, selected: 241, failure: "selected_pre_mismatch"},
	} {
		t.Run(test.name, func(t *testing.T) {
			provider := &qualificationTCPThresholdTestProvider{thresholds: []uint32{math.MaxInt32, test.changed}}
			owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
			qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
			owner.mu.Lock()
			owner.compareTCPThresholdHistorySelectedPreLocked("9", qualificationTCPThresholdTestSnapshot(test.selected), nil)
			owner.mu.Unlock()
			activity := qualificationTCPThresholdTestActivity(owner)
			if activity.SelectedPreMatched != test.matched || activity.ExplanationReason != test.failure ||
				activity.ExplanationInconclusive != (test.failure != "") || activity.Inconclusive {
				t.Fatalf("activity = %+v", activity)
			}
			owner.mu.Lock()
			if owner.tcp.invalid {
				t.Fatal("history explanation failure invalidated mature TCP evidence")
			}
			owner.mu.Unlock()
		})
	}

	t.Run("finite_selected_pre_without_observed_transition", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		owner.mu.Lock()
		owner.compareTCPThresholdHistorySelectedPreLocked("9", qualificationTCPThresholdTestSnapshot(240), nil)
		owner.mu.Unlock()
		activity := qualificationTCPThresholdTestActivity(owner)
		if !activity.Inconclusive || activity.FailureReason != "selected_pre_transition_unobserved" || activity.FirstDifferent.Present {
			t.Fatalf("activity = %+v", activity)
		}
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		if later := qualificationTCPThresholdTestActivity(owner); later.FirstDifferent.Present || provider.callCount() != 0 || later.ProviderCaptureCalls != 0 {
			t.Fatalf("later activity = %+v", later)
		}
	})

	t.Run("comparison_refreshes_per_sequence_without_overwriting_first_transition", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{thresholds: []uint32{math.MaxInt32, 240}}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		owner.mu.Lock()
		owner.compareTCPThresholdHistorySelectedPreLocked("9", qualificationTCPThresholdTestSnapshot(240), nil)
		first := owner.tcp.thresholdHistory.firstDifferent
		owner.compareTCPThresholdHistorySelectedPreLocked("11", qualificationTCPThresholdTestSnapshot(241), nil)
		owner.mu.Unlock()
		mismatch := qualificationTCPThresholdTestActivity(owner)
		if mismatch.SelectedPreSequence != "11" || mismatch.SelectedPreArmOrdinal != 2 ||
			!mismatch.ExplanationInconclusive || mismatch.ExplanationReason != "selected_pre_mismatch" ||
			mismatch.Inconclusive || mismatch.FirstDifferent != first {
			t.Fatalf("mismatch = %+v", mismatch)
		}
		owner.mu.Lock()
		owner.compareTCPThresholdHistorySelectedPreLocked("14", qualificationTCPThresholdTestSnapshot(240), nil)
		owner.mu.Unlock()
		matched := qualificationTCPThresholdTestActivity(owner)
		if matched.SelectedPreSequence != "14" || matched.SelectedPreArmOrdinal != 3 ||
			!matched.SelectedPreMatched || matched.ExplanationInconclusive || matched.FirstDifferent != first {
			t.Fatalf("matched = %+v", matched)
		}
	})

	t.Run("comparison_requires_decisive_capture_strictly_prior", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{thresholds: []uint32{math.MaxInt32, 240}}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		owner.mu.Lock()
		first := owner.tcp.thresholdHistory.firstDifferent
		overlap := qualificationTCPThresholdTestSnapshot(240)
		overlap.captureStarted = owner.tcp.monotonicOrigin
		overlap.captureFinished = owner.tcp.monotonicOrigin
		overlap.CaptureStartedUnixNS = overlap.captureStarted.UnixNano()
		overlap.CaptureFinishedUnixNS = overlap.captureFinished.UnixNano()
		owner.compareTCPThresholdHistorySelectedPreLocked("9", overlap, nil)
		owner.mu.Unlock()
		unavailable := qualificationTCPThresholdTestActivity(owner)
		if unavailable.SelectedPreMatched || !unavailable.ExplanationInconclusive ||
			unavailable.ExplanationReason != "selected_pre_transition_not_strictly_prior" ||
			unavailable.Inconclusive || unavailable.FirstDifferent != first {
			t.Fatalf("unavailable = %+v", unavailable)
		}
		owner.mu.Lock()
		owner.compareTCPThresholdHistorySelectedPreLocked("11", qualificationTCPThresholdTestSnapshot(240), nil)
		owner.mu.Unlock()
		matched := qualificationTCPThresholdTestActivity(owner)
		if !matched.SelectedPreMatched || matched.ExplanationInconclusive || matched.FirstDifferent != first {
			t.Fatalf("matched = %+v", matched)
		}

		overlapProvider := &qualificationTCPThresholdTestProvider{thresholds: []uint32{math.MaxInt32, 240}}
		overlapOwner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, overlapProvider)
		qualificationTCPThresholdTestWrite(t, overlapOwner, &qualificationRawWriteTestConn{written: -1})
		overlapOwner.mu.Lock()
		decisiveStart := overlapOwner.tcp.thresholdHistory.firstDifferent.After.CaptureStartedMonotonicNS
		overlapOwner.tcp.thresholdHistory.firstDifferent.After.CaptureFinishedMonotonicNS = decisiveStart + 2
		overlap = qualificationTCPThresholdTestSnapshot(240)
		overlap.captureStarted = overlapOwner.tcp.monotonicOrigin.Add(time.Duration(decisiveStart + 1))
		overlap.captureFinished = overlap.captureStarted
		overlap.CaptureStartedUnixNS = overlap.captureStarted.UnixNano()
		overlap.CaptureFinishedUnixNS = overlap.captureFinished.UnixNano()
		overlapOwner.compareTCPThresholdHistorySelectedPreLocked("9", overlap, nil)
		overlapOwner.mu.Unlock()
		if activity := qualificationTCPThresholdTestActivity(overlapOwner); activity.SelectedPreMatched ||
			!activity.ExplanationInconclusive || activity.ExplanationReason != "selected_pre_transition_not_strictly_prior" {
			t.Fatalf("overlap activity = %+v", activity)
		}
	})

	t.Run("control_no_transition", func(t *testing.T) {
		owner := qualificationTCPThresholdTestOwner(t, 0, math.MaxInt32, &qualificationTCPThresholdTestProvider{})
		owner.markClosed()
		activity := qualificationTCPThresholdTestActivity(owner)
		if !activity.Complete || activity.Required || activity.Inconclusive ||
			activity.ExplanationStatus != "not_required_no_transition" {
			t.Fatalf("activity = %+v", activity)
		}
	})
}

func TestQualificationTCPThresholdHistoryFailuresAreSticky(t *testing.T) {
	t.Run("finite_bind_baseline", func(t *testing.T) {
		owner := qualificationTCPThresholdTestOwner(t, 1, 240, &qualificationTCPThresholdTestProvider{})
		first := qualificationTCPThresholdTestActivity(owner)
		owner.markClosed()
		second := qualificationTCPThresholdTestActivity(owner)
		if !first.Inconclusive || first.FailureReason != "pre_bind_unobserved" || !first.PreBindUnobserved ||
			second.FailureReason != first.FailureReason || second.Complete {
			t.Fatalf("first = %+v; second = %+v", first, second)
		}
	})

	t.Run("attempt_limit", func(t *testing.T) {
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, &qualificationTCPThresholdTestProvider{})
		owner.mu.Lock()
		owner.tcp.thresholdHistory.monitoredRawWriteAttempts = yamux.QualificationTCPStateRecordLimit
		owner.mu.Unlock()
		begin := owner.beginRawWrite()
		owner.finishRawWrite(begin, 0, 0, nil, time.Now())
		activity := qualificationTCPThresholdTestActivity(owner)
		if !activity.Exhausted || activity.FailureReason != "attempt_limit" || activity.RawWriteOrdinal != 1 {
			t.Fatalf("activity = %+v", activity)
		}
	})

	for _, test := range []struct {
		name    string
		written int
		err     error
	}{
		{name: "short_write", written: 1},
		{name: "write_error", written: 0, err: errors.New("write failed")},
	} {
		t.Run(test.name, func(t *testing.T) {
			provider := &qualificationTCPThresholdTestProvider{thresholds: []uint32{math.MaxInt32, math.MaxInt32}}
			owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
			observed := &qualificationObservedRawConn{Conn: &qualificationRawWriteTestConn{written: test.written, err: test.err}, owner: owner}
			_, _ = observed.Write([]byte("threshold-history"))
			activity := qualificationTCPThresholdTestActivity(owner)
			if !activity.Inconclusive || activity.FailureReason != "incomplete_write" ||
				!activity.Failure.Present || activity.Failure.WriteError != (test.err != nil) {
				t.Fatalf("activity = %+v", activity)
			}
		})
	}

	t.Run("provider_failure", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{errors: map[int]error{0: errors.New("capture failed")}}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		activity := qualificationTCPThresholdTestActivity(owner)
		if !activity.Inconclusive || activity.FailureReason != "capture_or_bracket_invalid" ||
			activity.ProviderCaptureErrors != 1 || provider.callCount() != 2 {
			t.Fatalf("activity = %+v; calls = %d", activity, provider.callCount())
		}
	})

	for _, test := range []struct {
		name    string
		mutate  func(*qualificationTCPInfoSnapshot)
		failure string
	}{
		{
			name:    "missing_threshold_availability",
			mutate:  func(snapshot *qualificationTCPInfoSnapshot) { snapshot.Availability.SendSlowStartThreshold = false },
			failure: "capture_or_bracket_invalid",
		},
		{
			name:    "congestion_control_mismatch",
			mutate:  func(snapshot *qualificationTCPInfoSnapshot) { snapshot.CongestionControl = "reno" },
			failure: "congestion_control_mismatch",
		},
	} {
		t.Run(test.name, func(t *testing.T) {
			before := qualificationTCPThresholdTestSnapshot(math.MaxInt32)
			after := qualificationTCPThresholdTestSnapshot(math.MaxInt32)
			test.mutate(&before)
			provider := &qualificationTCPThresholdTestProvider{snapshots: []qualificationTCPInfoSnapshot{before, after}}
			owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
			qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
			if activity := qualificationTCPThresholdTestActivity(owner); !activity.Inconclusive || activity.FailureReason != test.failure {
				t.Fatalf("activity = %+v", activity)
			}
		})
	}

	t.Run("concurrent_reservation", func(t *testing.T) {
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, &qualificationTCPThresholdTestProvider{})
		first := owner.beginRawWrite()
		second := owner.beginRawWrite()
		first.started = time.Now()
		second.started = first.started
		owner.finishRawWrite(second, 0, 0, nil, time.Now())
		owner.finishRawWrite(first, 0, 0, nil, time.Now())
		if activity := qualificationTCPThresholdTestActivity(owner); !activity.Inconclusive || activity.FailureReason != "concurrent_raw_write" {
			t.Fatalf("activity = %+v", activity)
		}
	})

	t.Run("permission_denial_not_counted", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		begin := owner.beginRawWrite()
		begin.started = time.Now()
		owner.mu.Lock()
		owner.generation++
		owner.mu.Unlock()
		before, beforeErr, beforeInvoked := owner.captureTCPRawInfoIfPermitted(begin, begin.threshold.raw)
		finished := time.Now()
		owner.finishRawWriteWithTCP(begin, 0, 0, nil, finished, before, beforeErr, qualificationTCPInfoSnapshot{}, beforeErr, beforeInvoked, false)
		activity := qualificationTCPThresholdTestActivity(owner)
		if beforeInvoked || provider.callCount() != 0 || activity.ProviderCaptureCalls != 0 ||
			!activity.Inconclusive || activity.FailureReason != "owner_mismatch" {
			t.Fatalf("activity = %+v; provider calls = %d", activity, provider.callCount())
		}
	})
}

func TestQualificationTCPThresholdHistorySharesSelectedRawPairCapturesOnce(t *testing.T) {
	provider := &qualificationTCPThresholdTestProvider{thresholds: []uint32{math.MaxInt32, math.MaxInt32}}
	owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
	owner.mu.Lock()
	owner.tcp.armed = true
	owner.tcp.sequence = "9"
	owner.tcp.waitCount = 1
	owner.tcp.pendingRawClaims = 1
	owner.tcp.waits[0] = yamux.QualificationTCPWaitRecord{
		RecordID: 1, StreamID: 31, WaitToken: 41, PendingRaw: true,
	}
	owner.mu.Unlock()
	token := owner.beginEnvelope(31, 1, 13, time.Now())
	if token == 0 {
		t.Fatal("begin DATA envelope")
	}
	qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
	owner.finishEnvelopeNow(token)
	owner.mu.Lock()
	activity := owner.tcpThresholdHistoryPublicLocked()
	captureCalls := owner.tcp.captureCalls
	owner.mu.Unlock()
	if provider.callCount() != 2 || captureCalls != 2 || activity.ProviderCaptureCalls != 2 ||
		activity.RawProviderCallsSharedWithTCPInterval != 2 ||
		activity.MonitoredRawWriteAttempts != 1 {
		t.Fatalf("activity = %+v; provider calls = %d; TCP capture calls = %d", activity, provider.callCount(), captureCalls)
	}
}

func TestQualificationTCPThresholdHistoryPersistsAcrossHealthyDrain(t *testing.T) {
	owner := qualificationTCPThresholdTestOwner(t, 0, math.MaxInt32, &qualificationTCPThresholdTestProvider{})
	owner.markClosed()
	first := owner.drain()
	second := owner.drain()
	if !first.Complete || !first.ResetPerformed || !first.TCPState.ThresholdHistory.Complete ||
		first.TCPState.ThresholdHistory.ExplanationStatus != "not_required_no_transition" {
		t.Fatalf("first drain = %+v", first)
	}
	if second.TCPState.ThresholdHistory != first.TCPState.ThresholdHistory {
		t.Fatalf("history was not retained: first=%+v second=%+v", first.TCPState.ThresholdHistory, second.TCPState.ThresholdHistory)
	}
}

func TestQualificationTCPThresholdHistoryJSONShape(t *testing.T) {
	owner := qualificationTCPThresholdTestOwner(t, 0, math.MaxInt32, &qualificationTCPThresholdTestProvider{})
	encoded, err := json.Marshal(qualificationTCPThresholdTestActivity(owner))
	if err != nil {
		t.Fatal(err)
	}
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(encoded, &fields); err != nil {
		t.Fatal(err)
	}
	expected := []string{
		"schema_version", "enabled", "required", "monitoring", "complete", "transition_observed",
		"selected_pre_compared", "selected_pre_sequence", "selected_pre_arm_ordinal", "selected_pre_initial",
		"selected_pre_matched", "inconclusive", "failure_reason", "explanation_status", "explanation_available",
		"explanation_inconclusive", "explanation_reason", "pre_bind_unobserved", "exhausted", "active_sample",
		"closed", "baseline_threshold", "first_changed_threshold", "selected_pre_threshold", "selected_pre_tcp_info",
		"raw_write_ordinal", "monitored_raw_write_attempts", "provider_capture_calls", "provider_capture_errors",
		"provider_capture_duration", "raw_provider_calls_shared_with_tcp_interval",
		"raw_provider_duration_shared_with_tcp_interval",
		"baseline", "last_equal", "first_different", "failure",
	}
	if len(fields) != len(expected) {
		t.Fatalf("JSON fields = %d, want %d: %s", len(fields), len(expected), encoded)
	}
	for _, name := range expected {
		if _, ok := fields[name]; !ok {
			t.Fatalf("JSON field %q is missing: %s", name, encoded)
		}
	}
}

func TestQualificationTCPThresholdHistoryRefreshesThroughArmDrain(t *testing.T) {
	owner, _, _ := qualificationTCPStateTestOwner(t)
	if !owner.armTCPInterval("9") || !owner.disarmTCPInterval("9") {
		t.Fatal("seq9 arm/disarm")
	}
	first := owner.drain().TCPState
	if !first.Complete || first.ThresholdHistory.SelectedPreSequence != "9" ||
		first.ThresholdHistory.SelectedPreArmOrdinal != 1 ||
		first.ThresholdHistory.SelectedPreTCPInfo != first.PreTCPInfo {
		t.Fatalf("seq9 = %+v", first)
	}
	firstDifferent := first.ThresholdHistory.FirstDifferent
	lastEqual := first.ThresholdHistory.LastEqual
	if !owner.armTCPInterval("11") || !owner.disarmTCPInterval("11") {
		t.Fatal("seq11 arm/disarm")
	}
	second := owner.drain().TCPState
	if !second.Complete || second.ThresholdHistory.SelectedPreSequence != "11" ||
		second.ThresholdHistory.SelectedPreArmOrdinal != 2 ||
		second.ThresholdHistory.SelectedPreTCPInfo != second.PreTCPInfo ||
		second.ThresholdHistory.FirstDifferent != firstDifferent || second.ThresholdHistory.LastEqual != lastEqual {
		t.Fatalf("seq11 = %+v", second)
	}
}

func TestQualificationTCPThresholdHistoryCloseOrdering(t *testing.T) {
	t.Run("real_tls_orderly_close_allows_alert_before_physical_close", func(t *testing.T) {
		certificateServer := httptest.NewTLSServer(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {}))
		t.Cleanup(certificateServer.Close)
		serverConfig := certificateServer.TLS.Clone()
		clientConfig := certificateServer.Client().Transport.(*http.Transport).TLSClientConfig.Clone()

		clientPipe, serverPipe := net.Pipe()
		var closeOnce sync.Once
		closePipes := func() {
			closeOnce.Do(func() {
				_ = clientPipe.Close()
				_ = serverPipe.Close()
			})
		}
		serverHandshakeDone := make(chan error, 1)
		serverReadDone := make(chan error, 1)
		handshakeJoined := false
		readStarted := false
		readJoined := false
		t.Cleanup(func() {
			closePipes()
			if !handshakeJoined {
				select {
				case <-serverHandshakeDone:
				case <-time.After(5 * time.Second):
					t.Error("TLS server handshake did not join during cleanup")
				}
			}
			if readStarted && !readJoined {
				select {
				case <-serverReadDone:
				case <-time.After(5 * time.Second):
					t.Error("TLS server close-notify read did not join during cleanup")
				}
			}
		})

		provider := &qualificationTCPThresholdTestProvider{}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		observedRaw := &qualificationObservedRawConn{Conn: clientPipe, owner: owner}
		clientTLS := tls.Client(observedRaw, clientConfig)
		serverTLS := tls.Server(serverPipe, serverConfig)
		go func() { serverHandshakeDone <- serverTLS.Handshake() }()
		if err := clientTLS.Handshake(); err != nil {
			t.Fatal(err)
		}
		select {
		case err := <-serverHandshakeDone:
			handshakeJoined = true
			if err != nil {
				t.Fatal(err)
			}
		case <-time.After(5 * time.Second):
			t.Fatal("TLS server handshake did not join")
		}

		owner.mu.Lock()
		owner.compareTCPThresholdHistorySelectedPreLocked("9", qualificationTCPThresholdTestSnapshot(math.MaxInt32), nil)
		owner.mu.Unlock()
		before := qualificationTCPThresholdTestActivity(owner)
		beforeCalls := provider.callCount()

		readStarted = true
		go func() {
			var one [1]byte
			_, err := serverTLS.Read(one[:])
			if !errors.Is(err, io.EOF) {
				serverReadDone <- err
				return
			}
			serverReadDone <- nil
		}()
		body := &qualificationObservedTunnelBody{ReadWriteCloser: clientTLS, owner: owner}
		if err := body.Close(); err != nil {
			t.Fatal(err)
		}
		select {
		case err := <-serverReadDone:
			readJoined = true
			if err != nil {
				t.Fatal(err)
			}
		case <-time.After(5 * time.Second):
			t.Fatal("TLS server did not consume close_notify")
		}

		after := qualificationTCPThresholdTestActivity(owner)
		if after.RawWriteOrdinal != before.RawWriteOrdinal+1 || provider.callCount() != beforeCalls+2 ||
			!after.Complete || after.Inconclusive || after.FailureReason != "" {
			t.Fatalf("before = %+v; after = %+v; calls = %d -> %d", before, after, beforeCalls, provider.callCount())
		}
		owner.mu.Lock()
		closed, observed, active := owner.closeStarted, owner.closeObserved, owner.activeRawWrites
		rawAmbiguous, tcpInvalid, tcpAmbiguous := owner.interval.ambiguous, owner.tcp.invalid, owner.tcp.ambiguous
		owner.mu.Unlock()
		if !closed || !observed || active != 0 || rawAmbiguous || tcpInvalid || tcpAmbiguous {
			t.Fatalf("orderly TLS close invalidated observer: close=%v/%v active=%d raw_ambiguous=%v tcp_invalid=%v tcp_ambiguous=%v",
				closed, observed, active, rawAmbiguous, tcpInvalid, tcpAmbiguous)
		}
		snapshot := owner.drain()
		if !snapshot.Complete || snapshot.Ambiguous || snapshot.TCPState.Invalid || snapshot.TCPState.Ambiguous {
			t.Fatalf("orderly TLS close snapshot = %+v", snapshot)
		}
		closePipes()
	})

	t.Run("close_before_reservation", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		owner.beginClose()
		qualificationTCPThresholdTestWrite(t, owner, &qualificationRawWriteTestConn{written: -1})
		activity := qualificationTCPThresholdTestActivity(owner)
		if provider.callCount() != 0 || activity.RawWriteOrdinal != 1 || activity.ActiveSample ||
			activity.MonitoredRawWriteAttempts != 0 {
			t.Fatalf("activity = %+v; calls = %d", activity, provider.callCount())
		}
		owner.mu.Lock()
		if !owner.interval.ambiguous || !owner.tcp.invalid || !owner.tcp.ambiguous {
			t.Fatal("post-close raw write did not invalidate mature raw/TCP evidence")
		}
		owner.mu.Unlock()
	})

	t.Run("reserved_capture_races_close", func(t *testing.T) {
		provider := &qualificationTCPThresholdTestProvider{
			thresholds: []uint32{math.MaxInt32, math.MaxInt32},
			entered:    make(chan struct{}), release: make(chan struct{}),
		}
		owner := qualificationTCPThresholdTestOwner(t, 1, math.MaxInt32, provider)
		underlying := &qualificationRawWriteTestConn{written: -1}
		observed := &qualificationObservedRawConn{Conn: underlying, owner: owner}
		done := make(chan struct{})
		var releaseOnce sync.Once
		t.Cleanup(func() {
			releaseOnce.Do(func() { close(provider.release) })
			select {
			case <-done:
			case <-time.After(5 * time.Second):
				t.Error("write did not join during cleanup")
			}
		})
		go func() {
			_, _ = observed.Write([]byte("threshold-history"))
			close(done)
		}()
		select {
		case <-provider.entered:
		case <-time.After(5 * time.Second):
			t.Fatal("capture did not begin")
		}
		if err := observed.Close(); err != nil {
			t.Fatal(err)
		}
		releaseOnce.Do(func() { close(provider.release) })
		select {
		case <-done:
		case <-time.After(5 * time.Second):
			t.Fatal("write did not join")
		}
		activity := qualificationTCPThresholdTestActivity(owner)
		if !activity.Inconclusive || activity.FailureReason != "close_race" || provider.callCount() != 2 {
			t.Fatalf("activity = %+v; calls = %d", activity, provider.callCount())
		}
	})
}
