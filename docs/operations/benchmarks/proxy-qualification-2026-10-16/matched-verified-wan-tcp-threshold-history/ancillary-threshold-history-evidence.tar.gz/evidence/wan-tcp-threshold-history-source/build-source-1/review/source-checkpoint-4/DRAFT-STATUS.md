# Frozen-input build derivative candidate

This source-only derivative binds accepted history producer checkpoint 8, its exact five-file overlay and 32-name focused plan, the accepted TCP-state build attempt 2, current tracked head `00814fb`, the accepted 68-case validator contract, and the owned empty runs-parent preparation. Its combined test contract retains the accepted TCP focused roots and appends the exact producer history roots.

No Go command, test, build, endpoint, or traffic has run from this derivative. The exact 21-stage command/lifecycle audit, Go 1.26.6 pins, source pre/post inventories, ordinary selected-source equality, normal/race focused tests, fresh tagged agent/server binaries, and receipt-last publication are preserved.

The rejected build attempt 1 is retained and bound: it closed naturally after a test-only fake lacked `syscall.RawConn.Read`; tagged tests did not start, no binaries were accepted, and no endpoint or traffic ran. Checkpoint 7 changes only that test fixture, while its runtime/schema payload stays byte-identical to checkpoint 6, so the accepted 68-case validator contract is carried with an explicit equality proof.

Rejected build attempt 2 is also retained: the real validator rejected a stale test fixture whose TCP captures preceded the raw write, before the intended congestion-control mismatch assertion. Checkpoint 8 changes only that fixture; runtime/schema bytes remain equal to checkpoint 6 and the accepted 68-case contract remains authoritative.
