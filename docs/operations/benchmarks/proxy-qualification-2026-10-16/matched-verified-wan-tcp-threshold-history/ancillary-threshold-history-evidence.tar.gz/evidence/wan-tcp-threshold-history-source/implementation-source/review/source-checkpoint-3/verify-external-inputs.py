#!/usr/bin/env python3
import hashlib, json, re, sys
from pathlib import Path
if len(sys.argv) != 2:
    raise SystemExit("usage: verify-external-inputs.py REPOSITORY_ROOT")
root = Path(sys.argv[1]).resolve()
cp = Path(__file__).resolve().parent
audit = json.loads((cp / "EXTERNAL-INPUT-AUDIT.json").read_text())
hex64 = re.compile(r"^[0-9a-f]{64}$")
values = {}
for record in audit["records"]:
    path = Path(record["path"])
    if not path.is_absolute():
        path = root / path
    if record["kind"] == "file_sha256":
        got = hashlib.sha256(path.read_bytes()).hexdigest()
    elif record["kind"] == "json_field":
        value = json.loads(path.read_text())
        for part in record["json_pointer"].strip("/").split("/"):
            value = value[part]
        got = value
    else:
        raise AssertionError(record["kind"])
    assert got == record["actual"], (record["field"], got, record["actual"])
    if record.get("lowercase_hex_64"):
        assert hex64.fullmatch(got), (record["field"], got)
    values[record["field"]] = got
inputs = json.loads((cp / "INPUTS.json").read_text())
source_map = json.loads((cp / "SOURCE-MAP.json").read_text())
for field in ("accepted_tcp_build_receipt_sha256","accepted_tcp_checkpoint_manifest_sha256","accepted_tcp_source_inventory_sha256","accepted_tcp_source_map_sha256","accepted_tcp_test_plan_sha256","current_head_binding_manifest_sha256","gofmt_sha256","kernel_review_ledger_sha256","kernel_review_erratum_ledger_sha256","kernel_source_evidence_ledger_sha256"):
    assert inputs[field] == values[field], (field, inputs[field], values[field])
assert source_map["accepted_tcp_build_receipt_sha256"] == values["accepted_tcp_build_receipt_sha256"]
assert source_map["accepted_tcp_checkpoint_manifest_sha256"] == values["accepted_tcp_checkpoint_manifest_sha256"]
assert source_map["base_source_ref"] == values["accepted_tcp_agent_source_ref"] == values["accepted_tcp_server_source_ref"]
assert values["accepted_tcp_checkpoint_manifest_sha256"] == values["accepted_tcp_receipt_tcp_checkpoint_manifest_sha256"]
assert values["accepted_tcp_source_map_sha256"] == values["accepted_tcp_receipt_tcp_source_map_sha256"]
assert values["accepted_tcp_test_plan_sha256"] == values["accepted_tcp_receipt_tcp_test_plan_sha256"]
for name, expected in source_map["overlay"].items():
    assert hex64.fullmatch(expected), (name, expected)
    assert hashlib.sha256((cp / name).read_bytes()).hexdigest() == expected, name
for field in ("design_sha256", "design_revision_2_sha256"):
    name = "DESIGN.md" if field == "design_sha256" else "DESIGN-REVISION-2.md"
    assert inputs[field] == hashlib.sha256((cp / name).read_bytes()).hexdigest(), field
assert all(audit["cross_checks"].values())
assert audit["all_external_file_hashes_computed_from_disk"]
assert audit["all_hash_values_lowercase_hex_64"]
assert audit["all_cross_document_bindings_equal"]
print(json.dumps({"accepted": True, "external_record_count": len(audit["records"]), "overlay_count": len(source_map["overlay"])}, sort_keys=True))
