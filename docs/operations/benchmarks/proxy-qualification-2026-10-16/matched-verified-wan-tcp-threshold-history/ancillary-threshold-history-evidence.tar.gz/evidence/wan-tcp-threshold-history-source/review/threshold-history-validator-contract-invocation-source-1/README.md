# Threshold-history validator contract invocation source 1

This unexecuted invocation runs the frozen 47-case Python contract from validator source checkpoint 1 under the reviewed owned-process helper. It pins the complete checkpoint, contract, Python, and helper bytes; requires Python isolated/no-bytecode mode, exact unique case names, direct status zero, and a natural process-group join; then rechecks every input before writing the final ledger.

It runs no Go command, build, endpoint, or WAN traffic. The result output path must be fresh.
