//go:build linux && p2pstream_qualification

package agent

import (
	"errors"
	"math"
	"syscall"
	"time"

	"github.com/hashicorp/yamux"
)

const qualificationTCPThresholdHistorySchemaVersion = 1

type qualificationTCPThresholdCapture func(syscall.RawConn) (qualificationTCPInfoSnapshot, error)

type qualificationTCPThresholdHistoryOwner struct {
	required      bool
	monitoring    bool
	closed        bool
	activeSample  bool
	inconclusive  bool
	failureReason string
	exhausted     bool

	baseline                qualificationTCPInfoSnapshot
	baselineThreshold       uint32
	preBindUnobserved       bool
	transitionObserved      bool
	firstChangedThreshold   uint32
	selectedPreCompared     bool
	selectedPreSequence     string
	selectedPreArmOrdinal   uint64
	selectedPreInitial      bool
	selectedPreMatched      bool
	selectedPreThreshold    uint32
	selectedPreTCPInfo      qualificationTCPInfoSnapshot
	explanationInconclusive bool
	explanationReason       string

	rawWriteOrdinal           uint64
	monitoredRawWriteAttempts uint64
	providerCaptureCalls      uint64
	providerCaptureErrors     uint64
	providerCaptureDuration   qualificationRawWriteDuration
	providerCallsShared       uint64
	providerDurationShared    qualificationRawWriteDuration
	lastEqual                 yamux.QualificationTCPThresholdHistoryRecord
	firstDifferent            yamux.QualificationTCPThresholdHistoryRecord
	failure                   yamux.QualificationTCPThresholdHistoryRecord
	capture                   qualificationTCPThresholdCapture
}

type qualificationTCPThresholdReservation struct {
	active               bool
	raw                  syscall.RawConn
	generation           uint64
	rawWriteOrdinal      uint64
	lane                 int
	localAddress         string
	remoteAddress        string
	envelopeAttributed   bool
	envelopeToken        uint64
	streamID             uint32
	envelopePayloadBytes uint64
	envelopeWireBytes    uint64
}

func qualificationTCPThresholdSnapshotValid(snapshot qualificationTCPInfoSnapshot, captureErr error) bool {
	return captureErr == nil && snapshot.Captured && snapshot.TCPInfoSucceeded && snapshot.CongestionControlSucceeded &&
		snapshot.Availability.SendSlowStartThreshold && snapshot.CongestionControl != "" &&
		snapshot.captureStarted.IsZero() == false && snapshot.captureFinished.IsZero() == false &&
		!snapshot.captureFinished.Before(snapshot.captureStarted)
}

func (owner *qualificationRawWriteOwner) bindTCPThresholdHistoryLocked(snapshot qualificationTCPInfoSnapshot) {
	history := &owner.tcp.thresholdHistory
	*history = qualificationTCPThresholdHistoryOwner{
		required: owner.lane != 0, monitoring: true, baseline: snapshot,
		baselineThreshold: snapshot.SendSlowStartThreshold, capture: qualificationCaptureTCPInfo,
	}
	if !qualificationTCPThresholdSnapshotValid(snapshot, nil) {
		owner.failTCPThresholdHistoryLocked("bind_capture_invalid", yamux.QualificationTCPThresholdHistoryRecord{})
		return
	}
	if snapshot.SendSlowStartThreshold != math.MaxInt32 {
		history.preBindUnobserved = true
		owner.failTCPThresholdHistoryLocked("pre_bind_unobserved", yamux.QualificationTCPThresholdHistoryRecord{})
	}
}

func (owner *qualificationRawWriteOwner) failTCPThresholdHistoryLocked(reason string, record yamux.QualificationTCPThresholdHistoryRecord) {
	history := &owner.tcp.thresholdHistory
	if !history.inconclusive {
		history.failureReason = reason
		history.failure = record
	}
	history.inconclusive = true
	history.monitoring = false
}

func (owner *qualificationRawWriteOwner) beginTCPThresholdHistoryLocked() qualificationTCPThresholdReservation {
	history := &owner.tcp.thresholdHistory
	overflow := false
	history.rawWriteOrdinal = qualificationRawAdd(history.rawWriteOrdinal, 1, &overflow)
	if overflow || history.rawWriteOrdinal == 0 {
		owner.failTCPThresholdHistoryLocked("raw_ordinal_overflow", yamux.QualificationTCPThresholdHistoryRecord{})
		return qualificationTCPThresholdReservation{}
	}
	if !history.monitoring || history.transitionObserved || history.inconclusive || owner.closeStarted || owner.closeObserved || owner.sessionJoined {
		return qualificationTCPThresholdReservation{}
	}
	if history.activeSample {
		owner.failTCPThresholdHistoryLocked("concurrent_raw_write", yamux.QualificationTCPThresholdHistoryRecord{})
		return qualificationTCPThresholdReservation{}
	}
	if history.monitoredRawWriteAttempts >= yamux.QualificationTCPStateRecordLimit {
		history.exhausted = true
		owner.failTCPThresholdHistoryLocked("attempt_limit", yamux.QualificationTCPThresholdHistoryRecord{})
		return qualificationTCPThresholdReservation{}
	}
	history.monitoredRawWriteAttempts++
	history.activeSample = true
	return qualificationTCPThresholdReservation{
		active: true, raw: owner.tcp.raw, generation: owner.generation,
		rawWriteOrdinal: history.rawWriteOrdinal, lane: owner.lane,
		localAddress: owner.localAddress, remoteAddress: owner.remoteAddress,
		envelopeAttributed: owner.activeEnvelope, envelopeToken: owner.activeEnvelopeToken,
		streamID: owner.activeEnvelopeStreamID, envelopePayloadBytes: owner.activeEnvelopePayloadBytes,
		envelopeWireBytes: owner.activeEnvelopeWireBytes,
	}
}

func (owner *qualificationRawWriteOwner) captureTCPThresholdInfo(raw syscall.RawConn) (qualificationTCPInfoSnapshot, error) {
	owner.mu.Lock()
	capture := owner.tcp.thresholdHistory.capture
	owner.mu.Unlock()
	if capture == nil {
		capture = qualificationCaptureTCPInfo
	}
	return capture(raw)
}

func (owner *qualificationRawWriteOwner) captureTCPRawInfoIfPermitted(begin qualificationRawWriteBegin, raw syscall.RawConn) (qualificationTCPInfoSnapshot, error, bool) {
	owner.mu.Lock()
	permitted := (begin.tcp.first || begin.threshold.active) && begin.generation == owner.generation &&
		raw != nil && raw == owner.tcp.raw
	owner.mu.Unlock()
	if !permitted {
		return qualificationTCPInfoSnapshot{}, errors.New("TCP threshold history capture lost its live owner permission"), false
	}
	snapshot, err := owner.captureTCPThresholdInfo(raw)
	return snapshot, err, true
}

func (owner *qualificationRawWriteOwner) tcpThresholdHistoryRecordLocked(
	reservation qualificationTCPThresholdReservation,
	attempted, written int,
	writeErr error,
	started, finished time.Time,
	before qualificationTCPInfoSnapshot,
	beforeErr error,
	after qualificationTCPInfoSnapshot,
	afterErr error,
) yamux.QualificationTCPThresholdHistoryRecord {
	record := yamux.QualificationTCPThresholdHistoryRecord{
		Present: true, RawWriteOrdinal: reservation.rawWriteOrdinal,
		OwnerLane: reservation.lane, OwnerGeneration: reservation.generation,
		LocalAddress: reservation.localAddress, RemoteAddress: reservation.remoteAddress,
		WriteError: writeErr != nil, EnvelopeAttributed: reservation.envelopeAttributed,
		EnvelopeToken: reservation.envelopeToken, StreamID: reservation.streamID,
		EnvelopePayloadBytes: reservation.envelopePayloadBytes, EnvelopeWireBytes: reservation.envelopeWireBytes,
		RawWriteStartedUnixNS: started.UnixNano(), RawWriteFinishedUnixNS: finished.UnixNano(),
		Before: owner.tcpInfoPublicLocked(before, beforeErr), After: owner.tcpInfoPublicLocked(after, afterErr),
	}
	if attempted >= 0 {
		record.AttemptedBytes = uint64(attempted)
	}
	if written >= 0 {
		record.WrittenBytes = uint64(written)
	}
	record.ShortWrite = writeErr == nil && written != attempted
	if !owner.tcp.monotonicOrigin.IsZero() && !started.Before(owner.tcp.monotonicOrigin) && !finished.Before(started) {
		record.RawWriteMonotonicValid = true
		record.RawWriteStartedMonotonicNS = uint64(started.Sub(owner.tcp.monotonicOrigin))
		record.RawWriteFinishedMonotonicNS = uint64(finished.Sub(owner.tcp.monotonicOrigin))
	}
	record.BracketValid = qualificationTCPThresholdSnapshotValid(before, beforeErr) &&
		qualificationTCPThresholdSnapshotValid(after, afterErr) &&
		!before.captureFinished.After(started) && !finished.After(after.captureStarted) && record.RawWriteMonotonicValid
	record.TransitionObservedAcrossWrite = record.BracketValid &&
		before.SendSlowStartThreshold == owner.tcp.thresholdHistory.baselineThreshold &&
		after.SendSlowStartThreshold != owner.tcp.thresholdHistory.baselineThreshold
	if record.BracketValid {
		switch {
		case before.SendSlowStartThreshold != owner.tcp.thresholdHistory.baselineThreshold:
			if owner.tcp.thresholdHistory.lastEqual.Present {
				record.TransitionLocation = "between_writes"
			} else {
				record.TransitionLocation = "between_bind_and_first_write"
			}
		case after.SendSlowStartThreshold != owner.tcp.thresholdHistory.baselineThreshold:
			record.TransitionLocation = "across_write_observation"
		}
	}
	return record
}

func (owner *qualificationRawWriteOwner) finishTCPThresholdHistoryLocked(
	reservation qualificationTCPThresholdReservation,
	attempted, written int,
	writeErr error,
	started, finished time.Time,
	before qualificationTCPInfoSnapshot,
	beforeErr error,
	after qualificationTCPInfoSnapshot,
	afterErr error,
	beforeProviderInvoked, afterProviderInvoked bool,
	sharedWithTCPTotals bool,
) {
	if !reservation.active {
		return
	}
	history := &owner.tcp.thresholdHistory
	if beforeProviderInvoked {
		history.providerCaptureCalls = qualificationRawAdd(history.providerCaptureCalls, 1, &history.exhausted)
		history.providerCaptureDuration.add(time.Duration(before.CaptureDurationNS), &history.exhausted)
	}
	if afterProviderInvoked {
		history.providerCaptureCalls = qualificationRawAdd(history.providerCaptureCalls, 1, &history.exhausted)
		history.providerCaptureDuration.add(time.Duration(after.CaptureDurationNS), &history.exhausted)
	}
	if sharedWithTCPTotals {
		if beforeProviderInvoked {
			history.providerCallsShared = qualificationRawAdd(history.providerCallsShared, 1, &history.exhausted)
			history.providerDurationShared.add(time.Duration(before.CaptureDurationNS), &history.exhausted)
		}
		if afterProviderInvoked {
			history.providerCallsShared = qualificationRawAdd(history.providerCallsShared, 1, &history.exhausted)
			history.providerDurationShared.add(time.Duration(after.CaptureDurationNS), &history.exhausted)
		}
	}
	if beforeProviderInvoked && (beforeErr != nil || !before.Captured) {
		history.providerCaptureErrors = qualificationRawAdd(history.providerCaptureErrors, 1, &history.exhausted)
	}
	if afterProviderInvoked && (afterErr != nil || !after.Captured) {
		history.providerCaptureErrors = qualificationRawAdd(history.providerCaptureErrors, 1, &history.exhausted)
	}
	record := owner.tcpThresholdHistoryRecordLocked(reservation, attempted, written, writeErr, started, finished, before, beforeErr, after, afterErr)
	history.activeSample = false
	if history.inconclusive {
		if !history.failure.Present {
			history.failure = record
		}
		return
	}
	if history.exhausted {
		owner.failTCPThresholdHistoryLocked("counter_overflow", record)
		return
	}
	if reservation.generation != owner.generation || reservation.raw != owner.tcp.raw ||
		reservation.lane != owner.lane || reservation.localAddress != owner.localAddress ||
		reservation.remoteAddress != owner.remoteAddress {
		owner.failTCPThresholdHistoryLocked("owner_mismatch", record)
		return
	}
	if owner.closeObserved || owner.sessionJoined {
		owner.failTCPThresholdHistoryLocked("close_race", record)
		return
	}
	if attempted < 0 || written < 0 || written > attempted || writeErr != nil || written != attempted {
		owner.failTCPThresholdHistoryLocked("incomplete_write", record)
		return
	}
	if !record.BracketValid {
		owner.failTCPThresholdHistoryLocked("capture_or_bracket_invalid", record)
		return
	}
	if before.CongestionControl != history.baseline.CongestionControl || after.CongestionControl != history.baseline.CongestionControl {
		owner.failTCPThresholdHistoryLocked("congestion_control_mismatch", record)
		return
	}
	baseline := history.baselineThreshold
	if before.SendSlowStartThreshold == baseline && after.SendSlowStartThreshold == baseline {
		history.lastEqual = record
		if history.monitoredRawWriteAttempts == yamux.QualificationTCPStateRecordLimit {
			history.exhausted = true
			owner.failTCPThresholdHistoryLocked("attempt_limit", record)
		}
		return
	}
	history.transitionObserved = true
	history.monitoring = false
	history.firstDifferent = record
	if before.SendSlowStartThreshold != baseline {
		history.firstChangedThreshold = before.SendSlowStartThreshold
	} else {
		history.firstChangedThreshold = after.SendSlowStartThreshold
	}
}

func (owner *qualificationRawWriteOwner) compareTCPThresholdHistorySelectedPreLocked(sequence string, snapshot qualificationTCPInfoSnapshot, captureErr error) {
	history := &owner.tcp.thresholdHistory
	overflow := false
	history.selectedPreArmOrdinal = qualificationRawAdd(history.selectedPreArmOrdinal, 1, &overflow)
	history.selectedPreCompared = true
	history.selectedPreSequence = sequence
	history.selectedPreInitial = false
	history.selectedPreMatched = false
	history.selectedPreThreshold = 0
	history.selectedPreTCPInfo = qualificationTCPInfoSnapshot{}
	history.explanationInconclusive = false
	history.explanationReason = ""
	if overflow || history.selectedPreArmOrdinal == 0 {
		owner.failTCPThresholdHistoryLocked("selected_pre_arm_ordinal_overflow", yamux.QualificationTCPThresholdHistoryRecord{})
		return
	}
	if !qualificationTCPThresholdSnapshotValid(snapshot, captureErr) {
		owner.failTCPThresholdHistoryLocked("selected_pre_capture_invalid", yamux.QualificationTCPThresholdHistoryRecord{})
		return
	}
	history.selectedPreThreshold = snapshot.SendSlowStartThreshold
	history.selectedPreTCPInfo = snapshot
	if history.inconclusive {
		return
	}
	if !history.transitionObserved {
		if snapshot.SendSlowStartThreshold == history.baselineThreshold {
			history.selectedPreInitial = true
			return
		}
		owner.failTCPThresholdHistoryLocked("selected_pre_transition_unobserved", yamux.QualificationTCPThresholdHistoryRecord{})
		return
	}
	if snapshot.SendSlowStartThreshold != history.firstChangedThreshold {
		history.explanationInconclusive = true
		history.explanationReason = "selected_pre_mismatch"
		return
	}
	decisive := history.firstDifferent.Before
	if history.firstDifferent.TransitionLocation == "across_write_observation" {
		decisive = history.firstDifferent.After
	}
	origin := owner.tcp.monotonicOrigin
	if origin.IsZero() || snapshot.captureStarted.Before(origin) || !decisive.CaptureMonotonicValid ||
		decisive.CaptureFinishedMonotonicNS > uint64(snapshot.captureStarted.Sub(origin)) {
		history.explanationInconclusive = true
		history.explanationReason = "selected_pre_transition_not_strictly_prior"
		return
	}
	history.selectedPreMatched = true
}

func (owner *qualificationRawWriteOwner) closeTCPThresholdHistoryLocked() {
	history := &owner.tcp.thresholdHistory
	history.closed = true
	if history.activeSample {
		owner.failTCPThresholdHistoryLocked("close_race", yamux.QualificationTCPThresholdHistoryRecord{})
		return
	}
	if history.inconclusive {
		return
	}
	if !history.required {
		history.monitoring = false
		return
	}
	if !history.selectedPreCompared {
		owner.failTCPThresholdHistoryLocked("close_before_selected_pre", yamux.QualificationTCPThresholdHistoryRecord{})
		return
	}
	if !history.transitionObserved && !history.selectedPreInitial {
		owner.failTCPThresholdHistoryLocked("close_before_observation", yamux.QualificationTCPThresholdHistoryRecord{})
		return
	}
	history.monitoring = false
}

func (owner *qualificationRawWriteOwner) tcpThresholdHistoryPublicLocked() yamux.QualificationTCPThresholdHistory {
	history := &owner.tcp.thresholdHistory
	status := "monitoring"
	switch {
	case history.inconclusive:
		status = "inconclusive"
	case history.selectedPreMatched:
		status = "selected_pre_matched"
	case history.selectedPreInitial && history.transitionObserved:
		status = "transition_observed_with_initial_pre"
	case history.selectedPreInitial:
		status = "not_reproduced"
	case history.explanationInconclusive:
		status = history.explanationReason
	case history.transitionObserved:
		status = "transition_observed"
	case history.closed && !history.required:
		status = "not_required_no_transition"
	}
	complete := history.closed && !history.activeSample && !history.monitoring && !history.inconclusive
	return yamux.QualificationTCPThresholdHistory{
		SchemaVersion: qualificationTCPThresholdHistorySchemaVersion, Enabled: true,
		Required: history.required, Monitoring: history.monitoring, Complete: complete,
		TransitionObserved: history.transitionObserved, SelectedPreCompared: history.selectedPreCompared,
		SelectedPreSequence: history.selectedPreSequence, SelectedPreArmOrdinal: history.selectedPreArmOrdinal,
		SelectedPreInitial: history.selectedPreInitial, SelectedPreMatched: history.selectedPreMatched,
		Inconclusive: history.inconclusive, FailureReason: history.failureReason, ExplanationStatus: status,
		ExplanationAvailable:    history.selectedPreMatched,
		ExplanationInconclusive: history.explanationInconclusive, ExplanationReason: history.explanationReason,
		PreBindUnobserved: history.preBindUnobserved, Exhausted: history.exhausted,
		ActiveSample: history.activeSample, Closed: history.closed,
		BaselineThreshold: history.baselineThreshold, FirstChangedThreshold: history.firstChangedThreshold,
		SelectedPreThreshold: history.selectedPreThreshold, RawWriteOrdinal: history.rawWriteOrdinal,
		SelectedPreTCPInfo:        owner.tcpInfoPublicLocked(history.selectedPreTCPInfo, nil),
		MonitoredRawWriteAttempts: history.monitoredRawWriteAttempts,
		ProviderCaptureCalls:      history.providerCaptureCalls, ProviderCaptureErrors: history.providerCaptureErrors,
		ProviderCaptureDuration:                  qualificationRawDurationSnapshot(history.providerCaptureDuration),
		RawProviderCallsSharedWithTCPInterval:    history.providerCallsShared,
		RawProviderDurationSharedWithTCPInterval: qualificationRawDurationSnapshot(history.providerDurationShared),
		Baseline:                                 owner.tcpInfoPublicLocked(history.baseline, nil), LastEqual: history.lastEqual,
		FirstDifferent: history.firstDifferent, Failure: history.failure,
	}
}
