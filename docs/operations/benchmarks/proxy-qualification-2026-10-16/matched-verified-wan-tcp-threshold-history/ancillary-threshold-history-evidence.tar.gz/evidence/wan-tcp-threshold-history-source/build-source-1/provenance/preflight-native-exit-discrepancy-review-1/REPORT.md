# Preflight native-exit discrepancy review

The checkpoint-3 and checkpoint-5 preflight scripts each recorded an accepted JSON result and `direct.status=0`, but their outer native tool envelopes reported exit 1. Neither outer envelope is classified as accepted or as a natural status-0 execution.

A bounded shell-only isolation (no Go, endpoint, or traffic) reproduced the discrepancy:

- strict shell (`set -euo pipefail`) followed by an explicit `exit 0`: native wrapper reports 1;
- the same strict shell ending with `true`: native wrapper reports 0;
- non-strict shell followed by `exit 0`: native wrapper reports 0.

The strict-shell control printed its local exit variable as zero immediately before `exit`. This localizes the discrepancy to the native execution wrapper's handling of explicit `exit` under the strict-shell invocation shape; it does not change either preserved raw status. Build authorization relies on the independently executed direct-status-0 preflight and independent source review, not on these anomalous outer envelopes.
