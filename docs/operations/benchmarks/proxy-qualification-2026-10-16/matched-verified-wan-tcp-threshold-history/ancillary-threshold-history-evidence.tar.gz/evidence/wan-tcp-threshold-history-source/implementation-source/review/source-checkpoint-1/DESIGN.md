# Qualification-only first-threshold-history extension

## Source delta

Create a fresh successor of accepted TCP producer checkpoint 6. Change only
qualification-tagged sources:

* `internal/agent/qualification_raw_write_qualification.go`: reserve a bounded
  history sample in the existing raw-owner `beginRawWrite`, capture TCP_INFO
  before and after every existing raw connection `Write`, and finish the sample
  under the owner lock. Reuse a capture when the selected TCP raw-pair observer
  also needs it.
* `internal/agent/qualification_tcp_state_qualification.go`: retain the
  per-owner constant-size state machine, bind baseline, last-equal bracket,
  first-different bracket, sticky inconclusive state, capture accounting, and
  selected-pre comparison. Preserve it across interval drains and terminal
  closure.
* `third_party/yamux/qualification_tcp_state.go`: add the fixed public history
  schema nested in existing `raw_write_activity.tcp_state`.
* Existing qualification tests gain focused controls. No ordinary file,
  provider implementation, dependency, endpoint, queue, goroutine, poller, or
  runtime policy changes.

## State machine

Binding occurs post-connect and before the wrapper is returned to TLS. The bind
TCP_INFO snapshot is the baseline and the existing owner tuple/generation is
the identity. Data lanes require one observed transition; the control lane does
not.

Each raw write receives a monotonically increasing owner raw ordinal. Until the
first sampled threshold difference, reserve at most one sample, capture before
the measured raw-write start and after its finish, then validate identity,
bracketing, provider results, congestion-control identity, byte counts, close
state, and monotonic coordinates. A fully equal bracket replaces the retained
last-equal bracket. The first bracket whose before or after threshold differs
from baseline is retained permanently and disables further provider calls.

The retained record includes raw ordinal, attempted/written/error/short result,
owner generation/tuple, optional envelope/token/stream/body/wire attribution,
raw and provider monotonic bounds, and before/after TCP_INFO. Global counters
retain raw attempts, provider capture count, total/max capture duration, and
the 4096 existing record-limit safety ceiling.

Baseline already finite is explicitly `pre_bind_unobserved`. Exhaustion,
capture failure, invalid availability, congestion-control mismatch, incomplete
write, duplicate/concurrent sample, owner mismatch, or required close without
an observation is sticky inconclusive. No history state is reset by an interval
drain. No syscall occurs after close.

At the selected pre-capture, compare the retained first changed threshold with
the selected pre threshold. Equality is a valid history join. A mismatch means
later unobserved threshold history and remains inconclusive for explanation.
Neither equality nor a within-write bracket is described as atomic kernel
assignment or causation.

## Focused tests

Table-driven qualification tests cover:

* post-bind, pre-TLS/control transition with no DATA attribution;
* transition inside a later write after an equal bracket;
* data-envelope stream/body/wire attribution when available;
* control owner with no transition versus a required data owner;
* no provider calls after the first difference;
* baseline already finite (`pre_bind_unobserved`);
* selected-pre match and mismatch;
* 4096-attempt exhaustion;
* before/after provider failure and unavailable threshold;
* short/error write, concurrent sample, and close before observation;
* retained history through healthy interval drain and terminal snapshot;
* exact qualification JSON shape and ordinary selected-source equality.

No Go command, build, endpoint, or traffic run is part of source preparation.
