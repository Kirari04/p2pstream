# TCP threshold-history runner and validator plan (draft)

## Immutable behavior

- Preserve the generated workload runner SHA-256 `a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad` and timed `run_transfer` body SHA-256 `b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798`.
- Preserve the H1/H2 schedule, WAN shaping, TLS policy, certificate handling, five-owner lifecycle, process/scope joins, raw-write closure, sender timing, server growth, byte-credit, TCP-state, proof, build, and source gates.
- Preserve the authenticated query path and fixed response read of `(4 << 20) + 1`; responses above 4 MiB fail closed. Do not truncate or raise the bound.
- Copy/materialize only a reviewed explicit source allowlist. Never copy prior run outputs, credentials, binaries, logs, caches, or private keys.

## Planned source delta after producer freeze

1. Extend the strict TCP-state validation at `integration/validate-tcp-state.py` for nested `raw_write_activity.tcp_state.threshold_history`. Keep structural integrity separate from explanation availability.
2. Extend `integration/contracts/test-tcp-state-validator.py` with producer-shaped positive and negative history controls. Do not mirror only local helper logic.
3. Extend `integration/validate-wan-below-tls-arm.py` to publish a separate history explanation result for each selected interval while leaving the mature raw/byte/TCP acceptance conjunct intact unless the history structure itself is invalid.
4. Cascade only exact validator, producer checkpoint, build receipt, contract ledger, and source map bindings through `integration/run-wan-below-tls-arm.sh`, `integration/run-wan-below-tls-diagnostic.sh`, the final source binding contracts, and static verifier.
5. Preserve the generated workload bytes. If wrapper provenance keys are additive, require exact producer/validator key-set equality and explicit cardinality derived from the reviewed named set.

## Required structural validation

- Exact schema fields and exact scalar types; reject booleans where integers are required.
- Exact lane, positive generation, canonical non-placeholder local/remote tuple, session identity, and congestion-control identity joins to the enclosing raw owner.
- Fixed record bound 4096, exact unique/increasing raw-write ordinals, nondecreasing counters, exact capture-call/error/duration conservation, and sticky invalid/overflow/exhaustion/active-state rules from the frozen producer.
- Baseline, last-equal, first-different, and failure records must obey their status-dependent presence rules. First-different must be the earliest retained different threshold and must follow the last retained equal threshold when both exist.
- History provider counters count only actual raw-boundary provider calls and exclude bind. The provisional shared subset fields are `raw_provider_calls_shared_with_tcp_interval` and `raw_provider_duration_shared_with_tcp_interval`; they count only the same capture reused by an existing selected raw pair. Bind baseline snapshot cost separately; do not equate the new history counters with the older TCP-state activity capture counter.
- Persistent history counters are cumulative across interval drains. Validate successive snapshots by identity and nondecreasing deltas, never by summing repeated cumulative snapshots.
- Record before/after TCP snapshots must retain the full accepted TCP_INFO schema and the same owner/congestion-control identity. Raw write wall/owner-relative monotonic brackets are local ordering evidence only; no cross-clock subtraction.
- DATA attribution, when present, must be internally complete and exact; TLS/control records may be unattributed only in the exact producer-defined form. Persistent first-transition history can belong to an earlier warmup or DATA stream and therefore must not be forced to the later selected interval's stream ID.
- Persistent bind-to-first-transition history must never be overwritten by a later interval comparison. Authenticated pre captures all five owners on every sequence, so the producer must expose a separate current comparison identity (sequence/epoch plus exact selected pre threshold) for the interval.
- Current provisional comparison fields are `selected_pre_sequence`, `selected_pre_arm_ordinal`, `selected_pre_tcp_info`, `explanation_available`, `explanation_inconclusive`, and `explanation_reason`. The final validator must bind the exact frozen names, require each authenticated pre to refresh them, and reject stale sequence/arm identity while leaving persistent baseline/last-equal/first-different records unchanged.
- The comparison belongs to the post response for the sequence just armed: require `selected_pre_sequence == tcp_state.sequence`, a positive exact arm ordinal, and `selected_pre_tcp_info == tcp_state.pre_tcp_info`. The pre drain can legitimately retain the prior interval comparison. Terminal must retain the sequence-15 comparison.
- For `selected_pre_matched`, require independent local chronology: the decisive capture is `first_different.before` for `between_bind_and_first_write` and `between_writes`, and `first_different.after` for `across_write_observation`; it must finish no later than the selected-pre capture begins. Treat overlap or reversed chronology as explanation unavailable, never as proof of equality at the selected pre.
- Terminal/final closure must prove monitoring stopped, no active sample remains, close/join completed, and no provider call occurred after close or after a completed first transition, as specified by the frozen producer.

## Explanation availability (separate from integrity)

- A selected interval is explanation-available only when its exact sequence/epoch comparison joins its selected pre TCP_INFO threshold to the persistent first-transition history under the frozen status rules.
- A legitimate no-transition interval whose selected pre equals the persistent initial threshold is `not_reproduced`; tiny need not trigger a transition.
- If a retained transition coexists with an initial selected-pre snapshot, classify the fact neutrally as `transition_observed_with_initial_pre`; capture overlap and commit timing mean it does not establish that the transition happened after the selected pre, and it does not explain the selected transfer.
- A finite selected pre with a missing first transition, or a first transition whose threshold differs because it occurred later than the selected interval, is explanation-inconclusive/later-history-unobserved. This does not invalidate already accepted raw-write, byte-credit, or TCP-state evidence.
- Current producer semantics use sticky `inconclusive=true` plus `failure_reason=selected_pre_transition_unobserved` for finite pre without a retained transition, and explanation-only `explanation_inconclusive`/`selected_pre_mismatch` after a retained transition mismatch. Validate these as distinct status families; do not turn the latter into structural invalidity.
- Structural corruption, owner mismatch, malformed state transitions, impossible counters, or status fields inconsistent with the declared failure remain fail-closed. A correctly encoded producer-declared observation failure can make history explanation unavailable without rewriting already accepted mature raw/byte/TCP evidence; the final frozen failure/status table decides which terminal shapes are coherent. Unexpected active state at a required drained/terminal boundary remains invalid.
- Reports must not infer atomic kernel assignment, cross-clock duration, or causation. Provider capture duration does not include all observer overhead.
- Do not subtract history capture duration from transfer wall time or label it total instrumentation overhead; owner locking, cursor work, record copying, and JSON serialization remain outside that bucket.

## Focused contract cases (pending final names)

Positive controls:
- exact first transition with selected current-sequence pre match;
- no transition with selected pre equal to the initial baseline (`not_reproduced`);
- finite selected pre but transition absent (`inconclusive`, mature gates still accepted);
- finite selected pre mismatching a later persistent first transition (`later history unobserved`, mature gates still accepted);
- control/TLS records without DATA attribution in the exact allowed form;
- terminal complete/unarmed/closed record with persistent history retained.

Negative controls:
- unknown/missing/extra field, bool-as-int, noncanonical status/reason;
- wrong lane/generation/session/tuple/CC identity;
- duplicate/regressing ordinal, broken counters/durations, record cap/drop/overflow;
- malformed baseline/last-equal/first-different ordering or thresholds;
- DATA attribution stream/token/envelope mismatch;
- per-sequence comparison epoch/sequence/pre-threshold mismatch;
- status flags inconsistent with record presence, monitoring/complete/active/closed state, or sticky failure;
- provider calls after completed first transition or close.

The final case list and exact field names must be generated from the immutable producer checkpoint, not from this draft. No contract in this draft is authorized to run.
