# Implementation intent

This qualification-only overlay adds a constant-size, socket-lifetime history of the first sampled `snd_ssthresh` change. It samples synchronously around existing raw writes from the post-connect/pre-TLS bind baseline, reuses selected raw-pair captures, stops after the first difference, and retains exact owner/envelope attribution, monotonic brackets, raw outcomes, and actual raw-boundary provider cost.

Authenticated pre-capture refreshes a per-sequence comparison without replacing persistent history. Missing first history for a finite pre is sticky history-inconclusive; a later mismatch or temporal overlap is explanation-only and does not invalidate mature byte/TCP evidence. Close uses a pre-close reservation barrier, holds no observer lock over provider calls, and treats pre-reserved races as inconclusive. The observer makes no atomic setter, HyStart, retransmission, ECN, or causal claim.

Only the five paths in `SOURCE-MAP.json` differ from the accepted TCP build source. No ordinary source, dependency, policy, endpoint, wrapper architecture, queue, goroutine, poller, test, build, or traffic command is part of this checkpoint.
