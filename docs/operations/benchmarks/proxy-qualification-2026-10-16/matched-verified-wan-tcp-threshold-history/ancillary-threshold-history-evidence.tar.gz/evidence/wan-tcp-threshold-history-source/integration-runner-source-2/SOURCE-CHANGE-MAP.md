# Runner successor 2 source change map

- `contracts/test-byte-credit-runner-source.py`
- `contracts/test-tcp-state-runner-source.py`
- `integration/contracts/run-final-source-contracts.sh`
- `integration/contracts/run-tcp-state-contracts.sh`
- `integration/contracts/test-tcp-state-validator.py`
- `integration/run-wan-below-tls-arm.sh`
- `integration/run-wan-below-tls-diagnostic.sh`
- `integration/validate-sender-wait-snapshot.py`
- `integration/validate-tcp-state.py`
- `verify-static-paths.py`

Runtime changes are limited to both generation identity constructors and explicit selected-context scoping. The other changes carry exact self-gates, source bindings, failed-tiny lineage, or the reviewed 85-case contract chain. `RUNNER-SUCCESSOR.diff` is the complete direct-predecessor delta. No workload, query, wrapper, TLS, timing, floor, producer, binary, or policy change occurs.
