# TCP slow-start threshold history validator source checkpoint 1

This immutable source-only checkpoint derives from accepted TCP runner 3 and binds producer checkpoint 6. It adds strict structural validation for persistent threshold history, current-interval explanation availability, owner and congestion-control identity, selected-pre chronology, provider accounting, terminal closure, and pre/post progression. Persistent historical DATA attribution is validated internally and may belong to an earlier stream; current TCP wait/raw-pair records remain joined to the selected stream.

The fixed 4096 monitored-write limit is enforced exactly. The existing authenticated response bound remains 4 MiB and fails closed on oversize; this checkpoint does not truncate a response or raise the bound. Provider durations cover only provider calls and are not total observer overhead. No cross-clock subtraction, causal conclusion, runtime fix, gate clearance, endpoint execution, or traffic is claimed.

The focused contract is frozen but unexecuted. Production/Yamux files, the workload runner, and the timed `run_transfer` body are absent and unchanged.
