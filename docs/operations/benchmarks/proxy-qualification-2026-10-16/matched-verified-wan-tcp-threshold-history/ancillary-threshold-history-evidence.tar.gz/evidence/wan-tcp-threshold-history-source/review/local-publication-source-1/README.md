Publishes the accepted raw proof, byte-credit proof, and threshold-history build receipt into the fresh 38-file active corpus. It copies no binaries and performs no endpoint or WAN execution.
