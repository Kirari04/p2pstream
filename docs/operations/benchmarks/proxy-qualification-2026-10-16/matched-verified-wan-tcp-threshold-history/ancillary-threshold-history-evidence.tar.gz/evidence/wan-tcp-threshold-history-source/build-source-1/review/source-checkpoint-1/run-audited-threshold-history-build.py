#!/usr/bin/python3.14
"""Build the reviewed TCP threshold-history diagnostic corpus.

This reviewed source binds frozen inputs and derives from the accepted TCP-state build attempt 2 source, proves the ordinary Go
selection is unchanged, runs only the reviewed affected focused roots, and
publishes its receipt last. It never runs an endpoint or WAN traffic.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import shutil
import stat
import sys
import time
import traceback
from pathlib import Path, PurePosixPath

sys.dont_write_bytecode = True

REPO = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
CONT = REPO / "tmp/continuation-20261016"
ROOT = CONT / "wan-tcp-threshold-history-source"
BUILD = ROOT / "build-source-1"
RUNS = BUILD / "runs"
RUNS_PREP = BUILD / "provenance/runs-parent-preparation-1"
RUNS_PREP_LEDGER_SHA = "9b464bca4403a834f46a76129f29662aec801c9d7bf2e22954b4a7d06e97f1dc"
RUNS_PREP_RESULT_SHA = "af151d837bff18d5d9c953525bdf970e6d357d9c9da9f12fdae3a595d811a06c"

BASE_RUN = CONT / "wan-tcp-state-source/build-source-1/runs/audited-build-attempt-2"
BASE_SOURCE = BASE_RUN / "source"
BASE_RECORDS = BASE_RUN / "records"
BASE_RECEIPT = BASE_RUN / "audited-tcp-state-build-receipt.json"
BASE_RECEIPT_SHA = "bcca6079b5de32635701b4a1d5195cd9b9f9e8976d76e48956cea7d396cb7b97"
BASE_LEDGER_SHA = "3419e3da3b395db795e544aea1c1c59262033ad1827674ecf0dbce1d7200bbd8"
BASE_SOURCE_INVENTORY_SHA = "0595c8e5fa4b19bc6612b409cfe69b7ddd0d4f7fa190a6dc26e27fd610648cd4"
BASE_OUTER_SHA = "442ffeb22586ad5179fd18646cbf48097848d0a3d2d8f5e7bc89a7a6bf0af8b0"
BASE_OUTER = CONT / "wan-tcp-state-source/build-source-1/provenance/audited-build-attempt-2-tool-envelope"

TCP_CHECKPOINT = CONT / "wan-tcp-threshold-history-source/implementation-source/review/source-checkpoint-6"
TCP_CHECKPOINT_SHA = "f6ea2fa7d0e1be0581d0f7b8af972e09e3d4f7c7e2e6a1cb898878dcaedf0beb"
TCP_OVERLAY_SHA = "1fa516731ee454eaf4fccaa329947743fe7c273aaad83a98fe55c4bde5f47d19"
TCP_FOCUSED_PLAN_SHA = "f6f6c04169c03b8e13210b0a6932199f4b064d2f0c6cca6c828dbfb0e56d0057"
BUILD_TEST_PLAN_SHA = "70547f39e17bf03092a5d38bf635689bfe54dcb6c06a5ca7c9e6c439e80fc236"
TCP_OVERLAY_ROOT = TCP_CHECKPOINT

HISTORY_EXTERNAL = TCP_CHECKPOINT
HISTORY_EXTERNAL_SHA = TCP_CHECKPOINT_SHA
VALIDATOR_RUN = ROOT / "runner-source-1/runs/history-validator-contract-attempt-1"
VALIDATOR_LEDGER_SHA = "058b0c7b912fe506867262f09f87f4d015ea2049acd3c51ede3d3e7dd8c23dac"
VALIDATOR_OUTER = ROOT / "runner-source-1/provenance/history-validator-contract-attempt-1-outer"
VALIDATOR_OUTER_SHA = "fff73fb6e841714e3677c5b694afdfee2f7df7ebc9c64aff1ecb0abc1255040b"
CURRENT_BINDING = CONT / "wan-tcp-threshold-history-source/runner-review/current-head-binding-00814fb/binding.json"
CURRENT_BINDING_SHA = "75769813b15a50db65cb524e9e6d2bc2b3343aca0d4600f9229c4fd3dd6c6700"
CURRENT_BINDING_LEDGER_SHA = "d809af1d4829ce4b360830588ba7f645a67dbad2a84a805121b14fe312ce7ab7"
BASE_SOURCE_REF = "8ac4c8df8237e37777ba2fac0da6f949da17bdea"
BASE_CORPUS_REF = BASE_SOURCE_REF + "+tcp-state-corpus-" + BASE_SOURCE_INVENTORY_SHA
RAW_PROOF_SHA = "b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d"
BYTE_PROOF_SHA = "6562b975ba8f25d1b7a1a83c323c4c289f62f97b5508421e9e0f2e244c940460"
SERVER_FOCUSED_SHA = "2109895c1d9d0d4824f49b9823b034a44693dfa1d8ca05c5340491024fa726ff"
CURRENT_HEAD = "00814fb88bff3ca2a1cc03e2432014ee27cd82f1"

HELPER = CONT / "wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
HELPER_SHA = "8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
GO = Path("/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go")
GO_SHA = "29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45"
GO_VERSION = "go version go1.26.6 linux/amd64"
PYTHON = Path("/usr/bin/python3.14")
PYTHON_SHA = "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
TASKSET = Path("/usr/bin/taskset")
TASKSET_SHA = "42acb8e233943873f3bf9eeb1e15bd3281498b5603a5b10d0f9bc37067a12d57"
GO_MOD_SHA = "165d373cd30192573bfd30e0f0997b393c433368d3ac01df8b178aaf4bdb5d65"
GO_SUM_SHA = "7e451e21339534258c770d5d4669cffd5c126d38e91026e09f35fa93c89173f2"

MAX_FILE = 1 << 30
MAX_STREAM = 64 << 20
MAX_LINE = 1 << 20
SELECTED_FIELDS = ("GoFiles", "CgoFiles", "TestGoFiles", "XTestGoFiles")
APPROVED_FIELDS = {
    "schema_version", "accepted", "build_checkpoint_manifest_sha256",
    "build_driver_sha256", "history_checkpoint_manifest_sha256",
    "history_overlay_manifest_sha256", "history_focused_test_plan_sha256",
    "history_validator_contract_records_ledger_sha256",
    "history_validator_contract_outer_ledger_sha256", "current_source_binding_sha256",
    "build_expected_tests_sha256", "runs_parent_preparation_ledger_sha256",
}


def sha(path: Path) -> str:
    path = Path(path)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_FILE:
        raise ValueError(f"unsafe file: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path):
    return json.loads(path.read_text())


def write_json(path: Path, value) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def write_text(path: Path, value: str) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w") as stream:
        stream.write(value)


def safe_name(value: str) -> str:
    if value.startswith("./") and not value.startswith("././"):
        value = value[2:]
    item = PurePosixPath(value)
    if (not value or value != item.as_posix() or item.is_absolute()
            or any(part in ("", ".", "..") for part in item.parts)):
        raise ValueError(f"unsafe relative path: {value!r}")
    return value


def inventory(root: Path) -> dict[str, str]:
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError(f"unsafe inventory root: {root}")
    result = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"symlink in inventory: {path}")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha(path)
    return result


def parse_ledger(path: Path) -> dict[str, str]:
    result = {}
    for line in path.read_text().splitlines():
        digest, name = line.split("  ", 1)
        name = safe_name(name)
        if re.fullmatch(r"[0-9a-f]{64}", digest) is None or name in result:
            raise ValueError(f"malformed ledger: {path}")
        result[name] = digest
    if not result:
        raise ValueError(f"empty ledger: {path}")
    return result


def verify_ledger(root: Path, expected_sha: str, *, ledger: str = "SHA256SUMS.txt") -> dict[str, str]:
    ledger_path = root / ledger
    if sha(ledger_path) != expected_sha:
        raise ValueError(f"ledger digest mismatch: {root}")
    expected = parse_ledger(ledger_path)
    actual = {name: digest for name, digest in inventory(root).items() if name != ledger}
    if actual != expected:
        raise ValueError(f"ledger coverage mismatch: {root}")
    return expected


def verify_base() -> tuple[dict, dict[str, str]]:
    verify_ledger(BASE_RECORDS, BASE_LEDGER_SHA)
    if sha(BASE_RECEIPT) != BASE_RECEIPT_SHA:
        raise ValueError("accepted TCP-state build receipt changed")
    receipt = load_json(BASE_RECEIPT)
    required = {
        "accepted": True,
        "endpoint_execution": False,
        "wan_traffic": False,
        "diagnostic": "wan-tcp-state-qualification",
        "records_ledger_sha256": BASE_LEDGER_SHA,
        "final_source_inventory_sha256": BASE_SOURCE_INVENTORY_SHA,
        "ordinary_source_selection_equal": True,
        "raw_ordinary_proof_receipt_sha256": RAW_PROOF_SHA,
        "byte_credit_ordinary_proof_receipt_sha256": BYTE_PROOF_SHA,
        "reused_server_focused_evidence_ledger_sha256": SERVER_FOCUSED_SHA,
        "agent_source_ref": BASE_CORPUS_REF,
        "server_source_ref": BASE_CORPUS_REF,
    }
    if any(receipt.get(key) != value for key, value in required.items()):
        raise ValueError("accepted TCP-state build receipt semantics changed")
    if sha(BASE_RECORDS / "source-post.json") != BASE_SOURCE_INVENTORY_SHA:
        raise ValueError("accepted TCP-state source inventory changed")
    source_value = load_json(BASE_RECORDS / "source-post.json")
    files = source_value.get("files")
    if (source_value.get("schema_version") != 1 or not isinstance(files, dict)
            or inventory(BASE_SOURCE) != files):
        raise ValueError("accepted TCP-state source corpus changed")
    verify_ledger(BASE_OUTER, BASE_OUTER_SHA)
    return receipt, files


def verify_current_binding() -> dict:
    if sha(CURRENT_BINDING) != CURRENT_BINDING_SHA:
        raise ValueError("current source binding changed")
    parent = CURRENT_BINDING.parent
    verify_ledger(parent, CURRENT_BINDING_LEDGER_SHA)
    value = load_json(CURRENT_BINDING)
    if (value.get("head") != CURRENT_HEAD or value.get("base_source_ref") != BASE_SOURCE_REF
            or value.get("tracked_clean") is not True
            or value.get("production_runtime_equal_to_base") is not True
            or value.get("base_to_head_changed_paths_docs_only") is not True):
        raise ValueError("current source binding semantics changed")
    return value


def verify_overlay(checkpoint: Path, approved: dict) -> dict[str, str]:
    if sha(checkpoint / "SHA256SUMS.txt") != approved["history_checkpoint_manifest_sha256"]:
        raise ValueError("threshold-history checkpoint manifest changed")
    verify_ledger(checkpoint, approved["history_checkpoint_manifest_sha256"])
    overlay_path = checkpoint / "SOURCE-MAP.json"
    if sha(overlay_path) != approved["history_overlay_manifest_sha256"]:
        raise ValueError("threshold-history overlay manifest changed")
    value = load_json(overlay_path)
    entries = value.get("overlay")
    base_files = load_json(BASE_RECORDS / "source-post.json")["files"]
    expected_fields = {
        "schema_version", "accepted_tcp_build_receipt_sha256",
        "accepted_tcp_checkpoint_manifest_sha256", "base_source_ref", "overlay",
    }
    if (set(value) != expected_fields or value.get("schema_version") != 1
            or not isinstance(entries, dict)
            or value.get("base_source_ref") != BASE_CORPUS_REF):
        raise ValueError("threshold-history overlay schema")
    if (value.get("accepted_tcp_build_receipt_sha256") != BASE_RECEIPT_SHA
            or value.get("accepted_tcp_checkpoint_manifest_sha256")
            != "809f30484ea276a20586fec84517fdec9ef84ff58b2c96c9da3ab65b5122a3a0"):
        raise ValueError("threshold-history base build/checkpoint binding changed")
    result = {}
    for name, expected in entries.items():
        name = safe_name(name)
        if not name.startswith(("internal/agent/", "third_party/yamux/")):
            raise ValueError(f"overlay path outside owned packages: {name}")
        if name in result or re.fullmatch(r"[0-9a-f]{64}", str(expected)) is None:
            raise ValueError(f"overlay digest: {name}")
        path = TCP_OVERLAY_ROOT.joinpath(*PurePosixPath(name).parts)
        if not path.resolve().is_relative_to(TCP_OVERLAY_ROOT.resolve()) or sha(path) != expected:
            raise ValueError(f"overlay backing changed: {name}")
        if name in base_files and base_files[name] == expected:
            raise ValueError(f"replacement overlay is byte-identical to its accepted base: {name}")
        result[name] = expected
    payload = {name: digest for name, digest in inventory(TCP_OVERLAY_ROOT).items()
               if name.startswith(("internal/agent/", "third_party/yamux/"))}
    if not result or payload != result:
        raise ValueError("overlay source contains unreviewed files")
    return result


def verify_successor_provenance() -> None:
    verify_ledger(HISTORY_EXTERNAL, HISTORY_EXTERNAL_SHA)
    verify_ledger(VALIDATOR_RUN / "records", VALIDATOR_LEDGER_SHA)
    validator = load_json(VALIDATOR_RUN / "records/RESULT.json")
    if (validator.get("accepted") is not True
            or validator.get("go_execution") is not False
            or validator.get("endpoint_execution") is not False
            or validator.get("wan_traffic") is not False):
        raise ValueError("accepted threshold-history validator contract changed")
    verify_ledger(VALIDATOR_OUTER, VALIDATOR_OUTER_SHA)
    verify_ledger(RUNS_PREP, RUNS_PREP_LEDGER_SHA)
    preparation = load_json(RUNS_PREP / "preparation-result.json")
    if (sha(RUNS_PREP / "preparation-result.json") != RUNS_PREP_RESULT_SHA
            or preparation.get("schema_version") != 1
            or preparation.get("accepted") is not True
            or preparation.get("target") != "tmp/continuation-20261016/wan-tcp-threshold-history-source/build-source-1/runs"
            or preparation.get("mode") != "0o700"
            or preparation.get("empty_after") is not True
            or preparation.get("go_execution") is not False
            or preparation.get("endpoint_execution") is not False
            or preparation.get("wan_traffic") is not False):
        raise ValueError("owned runs-parent preparation changed")


def load_helper():
    if sha(HELPER) != HELPER_SHA:
        raise ValueError("owned process helper changed")
    spec = importlib.util.spec_from_file_location("tcp_build_owned", HELPER)
    if spec is None or spec.loader is None:
        raise ValueError("owned process helper import")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_contract(path: Path) -> dict:
    value = load_json(path)
    required = {"agent", "execution_authorized", "go_commands_executed", "modes",
                "notes", "schema_version", "yamux"}
    if (set(value) != required or value.get("schema_version") != 1
            or value.get("execution_authorized") is not False
            or value.get("go_commands_executed") is not False
            or value.get("modes") != ["normal", "race"]
            or not isinstance(value.get("notes"), list)
            or any(type(note) is not str for note in value["notes"])):
        raise ValueError("focused-test contract schema")
    package_names = {"agent": "p2pstream/internal/agent", "yamux": "github.com/hashicorp/yamux"}
    packages = {}
    for label, package in package_names.items():
        item = value.get(label)
        if type(item) is not dict or set(item) != {"events", "package", "roots"} or item.get("package") != package:
            raise ValueError(f"focused-test package schema: {label}")
        roots, tests = item.get("roots"), item.get("events")
        if (not isinstance(roots, list) or not isinstance(tests, list)
                or len(roots) != len(set(roots)) or len(tests) != len(set(tests))
                or set(roots) != {name for name in tests if "/" not in name}):
            raise ValueError(f"focused-test cardinality: {package}")
        if any(re.fullmatch(r"Test[A-Za-z0-9_]+", name) is None for name in roots):
            raise ValueError(f"focused-test root: {package}")
        if any(name.split("/", 1)[0] not in roots for name in tests):
            raise ValueError(f"focused-test child: {package}")
        packages[package] = {"roots": roots, "all_tests": tests}
    return packages


def verify_producer_plan(path: Path, base_path: Path, packages: dict) -> None:
    value = load_json(path)
    expected_fields = {
        "actions", "endpoint_or_traffic", "execution_authorized",
        "new_agent_all_tests_name_count", "new_agent_all_tests_names",
        "new_agent_expected_json_events", "new_agent_roots", "new_agent_subtests",
        "normal_and_race_required", "ordinary_selected_source_equality_required",
        "retained_tcp_focused_test_plan_sha256", "schema_version",
    }
    if (set(value) != expected_fields or value.get("schema_version") != 1
            or value.get("actions") != ["run", "pass"]
            or value.get("endpoint_or_traffic") is not False
            or value.get("execution_authorized") is not False
            or value.get("normal_and_race_required") is not True
            or value.get("ordinary_selected_source_equality_required") is not True
            or value.get("retained_tcp_focused_test_plan_sha256") != sha(base_path)):
        raise ValueError("producer focused-test plan schema/binding changed")
    roots = value.get("new_agent_roots")
    tests = value.get("new_agent_all_tests_names")
    subtests = value.get("new_agent_subtests")
    if (not isinstance(roots, list) or not isinstance(tests, list) or not isinstance(subtests, dict)
            or len(roots) != len(set(roots)) or len(tests) != len(set(tests))
            or value.get("new_agent_all_tests_name_count") != len(tests)
            or value.get("new_agent_expected_json_events") != 2 * len(tests)
            or set(subtests) != set(roots)
            or set(roots) != {name for name in tests if "/" not in name}):
        raise ValueError("producer focused-test plan cardinality changed")
    reconstructed = []
    for root in roots:
        children = subtests.get(root)
        if (not isinstance(children, list) or len(children) != len(set(children))
                or any(type(child) is not str or not child for child in children)):
            raise ValueError(f"producer focused-test subtests changed: {root}")
        reconstructed.append(root)
        reconstructed.extend(f"{root}/{child}" for child in children)
    if reconstructed != tests:
        raise ValueError("producer focused-test order differs from roots/subtests")
    base = load_contract(base_path)
    expected_agent_roots = base["p2pstream/internal/agent"]["roots"] + roots
    expected_agent_tests = base["p2pstream/internal/agent"]["all_tests"] + tests
    if (packages["p2pstream/internal/agent"]["roots"] != expected_agent_roots
            or packages["p2pstream/internal/agent"]["all_tests"] != expected_agent_tests
            or packages["github.com/hashicorp/yamux"] != base["github.com/hashicorp/yamux"]):
        raise ValueError("combined focused-test plan differs from retained plus producer tests")


def audit_go_json(path: Path, package: str, expected_tests: list[str], report: Path) -> bool:
    expected = set(expected_tests)
    actions = {name: [] for name in expected_tests}
    unexpected, rejected = [], []
    package_passes = total = 0
    with path.open("rb") as stream:
        for line_number, line in enumerate(stream, 1):
            total += len(line)
            if total > MAX_STREAM or len(line) > MAX_LINE or not line.endswith(b"\n"):
                raise ValueError(f"bounded Go JSON violation line {line_number}")
            event = json.loads(line)
            if event.get("Package") != package:
                rejected.append({"line": line_number, "reason": "package", "value": event.get("Package")})
                continue
            action, test = event.get("Action"), event.get("Test")
            if test is None:
                if action == "pass":
                    package_passes += 1
                elif action in ("fail", "skip"):
                    rejected.append({"line": line_number, "reason": "package_terminal", "action": action})
                continue
            if test not in expected:
                unexpected.append({"line": line_number, "test": test, "action": action})
            elif action in ("run", "pass", "fail", "skip"):
                actions[test].append(action)
                if action in ("fail", "skip"):
                    rejected.append({"line": line_number, "reason": "test_terminal", "test": test, "action": action})
    accepted = (package_passes == 1 and not unexpected and not rejected
                and all(actions[name] == ["run", "pass"] for name in expected_tests))
    write_json(report, {"schema_version": 1, "accepted": accepted, "package": package,
                        "expected_tests": expected_tests, "actions": actions,
                        "package_passes": package_passes, "unexpected": unexpected,
                        "rejected": rejected, "stream_bytes": total})
    return accepted


def selected_source(go_list: dict, package_dir: Path) -> dict[str, dict[str, str]]:
    if go_list.get("Incomplete") is True or go_list.get("Error") is not None:
        raise ValueError(f"incomplete go list: {go_list.get('ImportPath')}")
    result = {}
    for field in SELECTED_FIELDS:
        values = go_list.get(field, [])
        if not isinstance(values, list) or len(values) != len(set(values)):
            raise ValueError(f"go list {field} malformed")
        mapped = {}
        for name in values:
            name = safe_name(name)
            if len(PurePosixPath(name).parts) != 1:
                raise ValueError(f"go list selected nested path: {name}")
            mapped[name] = sha(package_dir / name)
        result[field] = mapped
    return result


def publish_last(path: Path, value: dict) -> None:
    encoded = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    temporary = path.with_name("." + path.name + ".tmp")
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    os.link(temporary, path, follow_symlinks=False)
    os.unlink(temporary)


def main() -> int:
    if len(sys.argv) != 3:
        raise SystemExit("usage: run-audited-threshold-history-build.py FRESH_OUTPUT APPROVED-INPUTS.json")
    output = Path(sys.argv[1]).resolve()
    approved_path = Path(sys.argv[2]).resolve(strict=True)
    checkpoint = Path(__file__).resolve().parent
    if output.exists() or output.parent != RUNS.resolve() or not RUNS.is_dir() or RUNS.is_symlink():
        raise SystemExit("fresh direct output required")
    approved = load_json(approved_path)
    if set(approved) != APPROVED_FIELDS or approved.get("schema_version") != 1 or approved.get("accepted") is not True:
        raise SystemExit("approved input schema")
    for key in APPROVED_FIELDS - {"schema_version", "accepted"}:
        if re.fullmatch(r"[0-9a-f]{64}", str(approved.get(key, ""))) is None:
            raise SystemExit(f"approved digest: {key}")
    if ("PENDING" in {TCP_CHECKPOINT_SHA, TCP_OVERLAY_SHA, TCP_FOCUSED_PLAN_SHA,
                      BUILD_TEST_PLAN_SHA,
                      HISTORY_EXTERNAL_SHA, VALIDATOR_LEDGER_SHA, VALIDATOR_OUTER_SHA}
            or approved["history_checkpoint_manifest_sha256"] != TCP_CHECKPOINT_SHA
            or approved["history_overlay_manifest_sha256"] != TCP_OVERLAY_SHA
            or approved["history_focused_test_plan_sha256"] != TCP_FOCUSED_PLAN_SHA
            or approved["history_validator_contract_records_ledger_sha256"] != VALIDATOR_LEDGER_SHA
            or approved["history_validator_contract_outer_ledger_sha256"] != VALIDATOR_OUTER_SHA
            or approved["current_source_binding_sha256"] != CURRENT_BINDING_SHA
            or approved["build_expected_tests_sha256"] != BUILD_TEST_PLAN_SHA
            or approved["runs_parent_preparation_ledger_sha256"] != RUNS_PREP_LEDGER_SHA):
        raise SystemExit("threshold-history inputs are not frozen")
    if (sha(checkpoint / "SHA256SUMS.txt") != approved["build_checkpoint_manifest_sha256"]
            or sha(Path(__file__).resolve()) != approved["build_driver_sha256"]):
        raise SystemExit("unapproved build source")
    try:
        verify_ledger(checkpoint, approved["build_checkpoint_manifest_sha256"])
    except BaseException as error:
        raise SystemExit(f"build checkpoint inventory differs: {error}") from error

    output.mkdir(mode=0o700)
    records, source, binaries = output / "records", output / "source", output / "bin"
    records.mkdir(); binaries.mkdir()
    write_text(records / "start-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))
    write_json(records / "approved-inputs.json", approved)
    accepted = False
    issue = None
    helper = None
    source_pre = None
    static_pre = None
    outputs = {}
    components = {}
    expected_stages = {
        "toolchain-version-pre", "go-env", "toolchain-version-post",
        "ordinary-agent", "ordinary-yamux",
        "tagged-agent-normal", "tagged-agent-race",
        "tagged-yamux-normal", "tagged-yamux-race",
        "build-agent", "build-agent-version", "build-server", "build-server-version",
        *{f"go-list-{short}-{corpus}-{mode}"
          for short in ("agent", "yamux") for corpus in ("base", "candidate")
          for mode in ("ordinary", "tagged")},
    }
    try:
        base_receipt, base_files = verify_base()
        current_binding = verify_current_binding()
        overlay = verify_overlay(TCP_CHECKPOINT, approved)
        verify_successor_provenance()
        contract_path = checkpoint / "EXPECTED-TESTS.json"
        producer_contract_path = TCP_CHECKPOINT / "FOCUSED-TEST-PLAN.json"
        if (sha(contract_path) != BUILD_TEST_PLAN_SHA
                or sha(producer_contract_path) != TCP_FOCUSED_PLAN_SHA):
            raise ValueError("focused-test plan binding changed")
        packages = load_contract(contract_path)
        verify_producer_plan(
            producer_contract_path, checkpoint / "BASE-TCP-EXPECTED-TESTS.json", packages)
        components = {
            "base_receipt": BASE_RECEIPT,
            "base_records_ledger": BASE_RECORDS / "SHA256SUMS.txt",
            "base_source_inventory": BASE_RECORDS / "source-post.json",
            "base_outer_ledger": BASE_OUTER / "SHA256SUMS.txt",
            "history_checkpoint": TCP_CHECKPOINT / "SHA256SUMS.txt",
            "history_overlay": TCP_CHECKPOINT / "SOURCE-MAP.json",
            "history_focused_plan": producer_contract_path,
            "current_binding": CURRENT_BINDING,
            "current_binding_ledger": CURRENT_BINDING.parent / "SHA256SUMS.txt",
            "helper": HELPER, "go": GO, "python": PYTHON, "taskset": TASKSET,
            "test_contract": contract_path,
            "history_external_ledger": HISTORY_EXTERNAL / "SHA256SUMS.txt",
            "validator_contract_records_ledger": VALIDATOR_RUN / "records/SHA256SUMS.txt",
            "validator_contract_result": VALIDATOR_RUN / "records/RESULT.json",
            "validator_contract_outer_ledger": VALIDATOR_OUTER / "SHA256SUMS.txt",
            "runs_parent_preparation_ledger": RUNS_PREP / "SHA256SUMS.txt",
            "runs_parent_preparation_result": RUNS_PREP / "preparation-result.json",
        }
        static_pre = {name: sha(path) for name, path in components.items()}
        if sha(GO) != GO_SHA or sha(PYTHON) != PYTHON_SHA or sha(TASKSET) != TASKSET_SHA:
            raise ValueError("pinned tool changed")
        helper = load_helper()
        shutil.copytree(BASE_SOURCE, source, copy_function=shutil.copy2)
        if inventory(source) != base_files:
            raise ValueError("build 5 source materialization changed")
        source_root = TCP_OVERLAY_ROOT
        for name, digest in sorted(overlay.items()):
            origin = source_root.joinpath(*PurePosixPath(name).parts)
            target = source.joinpath(*PurePosixPath(name).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(origin, target)
            if sha(target) != digest:
                raise ValueError(f"overlay copy changed: {name}")
        expected_source = dict(base_files)
        expected_source.update(overlay)
        source_pre = inventory(source)
        if source_pre != expected_source:
            raise ValueError("threshold-history source corpus mismatch")
        if sha(source / "go.mod") != GO_MOD_SHA or sha(source / "go.sum") != GO_SUM_SHA:
            raise ValueError("module files changed")
        write_json(records / "source-pre.json", {"schema_version": 1,
                   "base_source_ref": BASE_SOURCE_REF, "current_head": CURRENT_HEAD,
                   "files": source_pre})
        write_json(records / "corpus.json", {"schema_version": 1, "accepted": True,
                   "base_file_count": len(base_files), "overlay_file_count": len(overlay),
                   "final_file_count": len(source_pre), "overlay": overlay})

        common = {"HOME": "/home/user", "PATH": "/usr/bin:/bin", "GOENV": "off",
                  "GOTOOLCHAIN": "local", "GOWORK": "off", "GOFLAGS": "", "CGO_ENABLED": "1",
                  "GOMAXPROCS": "16", "GOPATH": str(output / "gopath"),
                  "GOMODCACHE": "/home/user/go/pkg/mod", "GOPROXY": "off", "GOSUMDB": "off",
                  "LC_ALL": "C", "TZ": "Europe/Zurich"}
        for directory in (output / "gopath", output / "tmp-normal", output / "tmp-race",
                          output / "gocache-normal", output / "gocache-race"):
            directory.mkdir(mode=0o700)
        normal_env = dict(common, TMPDIR=str(output / "tmp-normal"), GOTMPDIR=str(output / "tmp-normal"), GOCACHE=str(output / "gocache-normal"))
        race_env = dict(common, TMPDIR=str(output / "tmp-race"), GOTMPDIR=str(output / "tmp-race"), GOCACHE=str(output / "gocache-race"))
        write_json(records / "go-environment.json", {"normal": normal_env, "race": race_env})

        def run(name: str, command: list[str], cwd: Path, env: dict, timeout: int) -> None:
            if name not in expected_stages:
                raise ValueError(f"unreviewed command stage: {name}")
            if helper.run(records, name, command, cwd, env, timeout) != 0:
                raise ValueError(f"command failed: {name}")

        run("toolchain-version-pre", [str(GO), "version"], REPO,
            {"HOME": "/home/user", "PATH": "/usr/bin:/bin", "LC_ALL": "C", "TZ": "Europe/Zurich"}, 30)
        if (records / "toolchain-version-pre.stdout.log").read_text().strip() != GO_VERSION:
            raise ValueError("Go version pre")
        run("go-env", [str(GO), "env", "-json", "GOMOD", "GOWORK", "GOENV", "GOTOOLCHAIN",
             "GOMODCACHE", "GOPATH", "GOPROXY", "GOSUMDB"], source, normal_env, 30)

        selection = {}
        package_specs = {
            "agent": ("p2pstream/internal/agent", BASE_SOURCE / "internal/agent", source / "internal/agent",
                      BASE_SOURCE, source, "./internal/agent"),
            "yamux": ("github.com/hashicorp/yamux", BASE_SOURCE / "third_party/yamux", source / "third_party/yamux",
                      BASE_SOURCE / "third_party/yamux", source / "third_party/yamux", "."),
        }
        for short, (import_path, base_dir, candidate_dir, base_cwd, candidate_cwd, package_arg) in package_specs.items():
            for corpus, cwd, package_dir in (("base", base_cwd, base_dir),
                                             ("candidate", candidate_cwd, candidate_dir)):
                for mode, extra in (("ordinary", []), ("tagged", ["-tags=p2pstream_qualification"])):
                    name = f"go-list-{short}-{corpus}-{mode}"
                    run(name, [str(GO), "list", "-json", *extra, package_arg], cwd, normal_env, 60)
                    value = load_json(records / f"{name}.stdout.log")
                    if value.get("ImportPath") != import_path:
                        raise ValueError(f"go list import path: {name}")
                    selection[name] = selected_source(value, package_dir)
            if selection[f"go-list-{short}-base-ordinary"] != selection[f"go-list-{short}-candidate-ordinary"]:
                raise ValueError(f"ordinary selected source changed: {short}")
        selected_delta = {}
        for short in package_specs:
            base = selection[f"go-list-{short}-base-tagged"]
            candidate = selection[f"go-list-{short}-candidate-tagged"]
            changed = {}
            for field in SELECTED_FIELDS:
                names = set(base[field]) | set(candidate[field])
                changed[field] = {name: {"base": base[field].get(name), "candidate": candidate[field].get(name)}
                                  for name in sorted(names) if base[field].get(name) != candidate[field].get(name)}
            selected_delta[short] = changed
        changed_selected = {
            ("internal/agent/" if short == "agent" else "third_party/yamux/") + name
            for short, fields in selected_delta.items() for rows in fields.values() for name in rows
        }
        if changed_selected != set(overlay):
            raise ValueError("tagged selected-source delta differs from reviewed overlay")
        write_json(records / "source-selection.json", {"schema_version": 1, "accepted": True,
                   "ordinary_byte_identical": True, "selection": selection,
                   "tagged_delta": selected_delta, "overlay": overlay})

        for short, (_, _, candidate_dir, _, candidate_cwd, package_arg) in package_specs.items():
            run(f"ordinary-{short}", [str(TASKSET), "-c", "0-15", str(GO), "test", "-json",
                "-count=1", "-timeout=300s", package_arg, "-run", "^$"], candidate_cwd, normal_env, 360)
            if not audit_go_json(records / f"ordinary-{short}.stdout.log",
                                 package_specs[short][0], [], records / f"ordinary-{short}.audit.json"):
                raise ValueError(f"ordinary compile audit: {short}")
            contract = packages[package_specs[short][0]]
            pattern = "^(" + "|".join(re.escape(name) for name in contract["roots"]) + ")$"
            for mode, env in (("normal", normal_env), ("race", race_env)):
                command = [str(TASKSET), "-c", "0-15", str(GO), "test", "-json", "-count=1",
                           "-timeout=300s", "-tags=p2pstream_qualification"]
                if mode == "race":
                    command.append("-race")
                command.extend([package_arg, "-run", pattern])
                name = f"tagged-{short}-{mode}"
                run(name, command, candidate_cwd, env, 360)
                if not audit_go_json(records / f"{name}.stdout.log", package_specs[short][0],
                                     contract["all_tests"], records / f"{name}.audit.json"):
                    raise ValueError(f"focused test audit: {short} {mode}")

        for short in ("agent", "server"):
            binary = binaries / f"current-{short}-wan-tcp-threshold-history-audited.test"
            run(f"build-{short}", [str(TASKSET), "-c", "0-15", str(GO), "test",
                "-tags=p2pstream_qualification", "-c", "-o", str(binary), f"./internal/{short}"],
                source, normal_env, 600)
            run(f"build-{short}-version", [str(GO), "version", "-m", str(binary)], source, normal_env, 30)
            metadata = (records / f"build-{short}-version.stdout.log").read_text()
            if (f": go1.26.6\n\tpath\tp2pstream/internal/{short}.test\n" not in metadata
                    or "\n\tbuild\t-tags=p2pstream_qualification\n" not in metadata):
                raise ValueError(f"binary metadata: {short}")
            if binary.stat().st_size <= 0 or binary.stat().st_mode & 0o111 == 0:
                raise ValueError(f"non-executable binary: {short}")
            outputs[short] = {"path": str(binary.relative_to(output)), "sha256": sha(binary),
                              "mode": oct(binary.stat().st_mode & 0o777),
                              "go_version_m_sha256": sha(records / f"build-{short}-version.stdout.log")}

        run("toolchain-version-post", [str(GO), "version"], REPO,
            {"HOME": "/home/user", "PATH": "/usr/bin:/bin", "LC_ALL": "C", "TZ": "Europe/Zurich"}, 30)
        if (records / "toolchain-version-post.stdout.log").read_text().strip() != GO_VERSION:
            raise ValueError("Go version post")
        write_json(records / "source-post.json", {"schema_version": 1,
                   "base_source_ref": BASE_SOURCE_REF, "current_head": CURRENT_HEAD,
                   "files": inventory(source)})
        statuses = {path.name.removesuffix(".direct.status"): int(path.read_text())
                    for path in records.glob("*.direct.status")}
        if set(statuses) != expected_stages or any(statuses.values()):
            raise ValueError("command status set")
        for name in expected_stages:
            lifecycle = load_json(records / f"{name}.lifecycle.json")
            if (lifecycle.get("direct_status") != 0 or lifecycle.get("direct_child_joined") is not True
                    or lifecycle.get("group_joined") is not True or lifecycle.get("forced_cleanup") is not False
                    or lifecycle.get("timed_out") is not False):
                raise ValueError(f"command lifecycle: {name}")
        write_json(records / "command-results.json", {"schema_version": 1, "accepted": True,
                   "statuses": statuses, "all_groups_joined_without_force": True})
        write_json(records / "input-receipts.json", {"schema_version": 1,
                   "accepted_tcp_build_receipt_sha256": BASE_RECEIPT_SHA,
                   "accepted_tcp_build_records_ledger_sha256": BASE_LEDGER_SHA,
                   "accepted_tcp_source_inventory_sha256": BASE_SOURCE_INVENTORY_SHA,
                   "accepted_tcp_build_outer_ledger_sha256": BASE_OUTER_SHA,
                   "accepted_raw_ordinary_proof_receipt_sha256": base_receipt.get("raw_ordinary_proof_receipt_sha256"),
                   "accepted_byte_credit_ordinary_proof_receipt_sha256": base_receipt.get("byte_credit_ordinary_proof_receipt_sha256"),
                   "reused_server_focused_evidence_ledger_sha256": base_receipt.get("reused_server_focused_evidence_ledger_sha256"),
                   "history_checkpoint_manifest_sha256": TCP_CHECKPOINT_SHA,
                   "history_overlay_manifest_sha256": TCP_OVERLAY_SHA,
                   "history_focused_test_plan_sha256": TCP_FOCUSED_PLAN_SHA,
                   "build_expected_tests_sha256": BUILD_TEST_PLAN_SHA,
                   "current_source_binding_sha256": CURRENT_BINDING_SHA,
                   "current_source_binding_ledger_sha256": CURRENT_BINDING_LEDGER_SHA,
                   "current_source_binding": current_binding,
                   "history_external_ledger_sha256": HISTORY_EXTERNAL_SHA,
                   "accepted_history_validator_contract_records_ledger_sha256": VALIDATOR_LEDGER_SHA,
                   "accepted_history_validator_contract_outer_ledger_sha256": VALIDATOR_OUTER_SHA,
                   "runs_parent_preparation_ledger_sha256": RUNS_PREP_LEDGER_SHA,
                   "runs_parent_preparation_result_sha256": RUNS_PREP_RESULT_SHA})
        accepted = True
    except BaseException as error:
        issue = f"{type(error).__name__}: {error}"
        traceback.print_exc()
    finally:
        checks, errors = {}, {}
        def check(name, function):
            try:
                checks[name] = bool(function())
            except BaseException as error:
                checks[name] = False
                errors[name] = f"{type(error).__name__}: {error}"
        check("checkpoint_unchanged", lambda: verify_ledger(checkpoint, approved["build_checkpoint_manifest_sha256"]) is not None)
        check("static_inputs_unchanged", lambda: static_pre is not None and all(sha(components[name]) == digest for name, digest in static_pre.items()))
        check("accepted_base_unchanged", lambda: verify_base() is not None)
        check("current_binding_unchanged", lambda: verify_current_binding() is not None)
        check("history_overlay_unchanged", lambda: verify_overlay(TCP_CHECKPOINT, approved) is not None)
        check("successor_provenance_unchanged", lambda: verify_successor_provenance() is None)
        check("tools_and_helper_unchanged", lambda: sha(GO) == GO_SHA and sha(PYTHON) == PYTHON_SHA and sha(TASKSET) == TASKSET_SHA and sha(HELPER) == HELPER_SHA)
        check("materialized_source_unchanged", lambda: source_pre is not None and inventory(source) == source_pre)
        check("module_unchanged", lambda: source_pre is not None and sha(source / "go.mod") == GO_MOD_SHA and sha(source / "go.sum") == GO_SUM_SHA)
        check("binaries_unchanged_and_executable", lambda: accepted and set(outputs) == {"agent", "server"} and all(sha(output / item["path"]) == item["sha256"] and oct((output / item["path"]).stat().st_mode & 0o777) == item["mode"] and (output / item["path"]).stat().st_mode & 0o111 != 0 for item in outputs.values()))
        lifecycle_paths = list(records.glob("*.lifecycle.json"))
        observed = {path.name.removesuffix(".lifecycle.json") for path in lifecycle_paths}
        natural = bool(lifecycle_paths) and all(
                  load_json(path).get("owned_group_identity_valid") is True
                  and load_json(path).get("direct_child_joined") is True
                  and load_json(path).get("group_joined") is True
                  and load_json(path).get("forced_cleanup") is False
                  and load_json(path).get("timed_out") is False
                  and load_json(path).get("term_attempted") is False
                  and load_json(path).get("kill_attempted") is False for path in lifecycle_paths)
        status_paths = list(records.glob("*.direct.status"))
        statuses = {path.name.removesuffix(".direct.status"): int(path.read_text())
                    for path in status_paths}
        expected_complete = observed == expected_stages and set(statuses) == expected_stages
        status_success = expected_complete and all(status == 0 for status in statuses.values())
        check("all_groups_joined_without_force", lambda: helper is not None and natural)
        accepted = accepted and all(checks.values()) and status_success
        write_json(records / "FINAL.json", {"schema_version": 1, "accepted": accepted,
                   "issue": issue, "post_checks": checks, "post_errors": errors,
                   "natural_groups_joined": natural, "expected_stages_complete": expected_complete,
                   "status_success": status_success,
                   "endpoint_execution": False, "wan_traffic": False})
        write_text(records / "FINAL.status", "0\n" if accepted else "1\n")
        write_text(records / "end-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))
        lines = []
        for path in sorted(records.rglob("*")):
            if path.is_file() and path.name != "SHA256SUMS.txt":
                lines.append(f"{sha(path)}  {path.relative_to(records).as_posix()}\n")
        write_text(records / "SHA256SUMS.txt", "".join(lines))
        write_text(output / "FINAL", "complete\n")
        if accepted:
            source_ref = f"{BASE_SOURCE_REF}+tcp-threshold-history-corpus-{sha(records / 'source-post.json')}"
            receipt = {"schema_version": 1, "diagnostic": "wan-tcp-threshold-history-qualification",
                       "accepted": True, "diagnostic_only": True, "endpoint_execution": False,
                       "wan_traffic": False, "traffic_run": False, "test_rerun": True,
                       "base_build_receipt_sha256": BASE_RECEIPT_SHA,
                       "base_build_records_ledger_sha256": BASE_LEDGER_SHA,
                       "base_source_inventory_sha256": BASE_SOURCE_INVENTORY_SHA,
                       "base_source_ref": BASE_SOURCE_REF, "current_head": CURRENT_HEAD,
                       "current_source_binding_sha256": CURRENT_BINDING_SHA,
                       "history_checkpoint_manifest_sha256": TCP_CHECKPOINT_SHA,
                       "history_overlay_manifest_sha256": TCP_OVERLAY_SHA,
                       "history_focused_test_plan_sha256": TCP_FOCUSED_PLAN_SHA,
                       "build_expected_tests_sha256": BUILD_TEST_PLAN_SHA,
                       "history_external_ledger_sha256": HISTORY_EXTERNAL_SHA,
                       "accepted_history_validator_contract_records_ledger_sha256": VALIDATOR_LEDGER_SHA,
                       "accepted_history_validator_contract_outer_ledger_sha256": VALIDATOR_OUTER_SHA,
                       "runs_parent_preparation_ledger_sha256": RUNS_PREP_LEDGER_SHA,
                       "runs_parent_preparation_result_sha256": RUNS_PREP_RESULT_SHA,
                       "ordinary_source_selection_sha256": sha(records / "source-selection.json"),
                       "ordinary_source_selection_equal": True,
                       "raw_ordinary_proof_receipt_sha256": load_json(BASE_RECEIPT).get("raw_ordinary_proof_receipt_sha256"),
                       "byte_credit_ordinary_proof_receipt_sha256": load_json(BASE_RECEIPT).get("byte_credit_ordinary_proof_receipt_sha256"),
                       "reused_server_focused_evidence_ledger_sha256": load_json(BASE_RECEIPT).get("reused_server_focused_evidence_ledger_sha256"),
                       "server_binary_sha256": outputs["server"]["sha256"],
                       "agent_binary_sha256": outputs["agent"]["sha256"],
                       "server_source_ref": source_ref, "agent_source_ref": source_ref,
                       "server_binary": outputs["server"], "agent_binary": outputs["agent"],
                       "final_source_inventory_sha256": sha(records / "source-post.json"),
                       "build_checkpoint_manifest_sha256": approved["build_checkpoint_manifest_sha256"],
                       "build_driver_sha256": approved["build_driver_sha256"],
                       "approved_inputs_sha256": sha(records / "approved-inputs.json"),
                       "toolchain_sha256": GO_SHA, "toolchain_version": GO_VERSION,
                       "python_sha256": PYTHON_SHA, "taskset_sha256": TASKSET_SHA,
                       "final_sha256": sha(records / "FINAL.json"),
                       "records_ledger_sha256": sha(records / "SHA256SUMS.txt")}
            publish_last(output / "audited-tcp-threshold-history-build-receipt.json", receipt)
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
