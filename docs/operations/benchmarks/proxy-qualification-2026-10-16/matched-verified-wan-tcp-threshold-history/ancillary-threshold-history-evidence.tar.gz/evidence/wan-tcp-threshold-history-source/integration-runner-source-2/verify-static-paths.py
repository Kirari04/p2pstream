#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, pathlib, stat, sys
root=pathlib.Path(__file__).resolve().parent
integration=root/'integration'
continuation=integration.parents[2]
if continuation.name!='continuation-20261016': raise SystemExit('unexpected continuation root')
paths={
 'mature_sender_root':continuation/'wan-sender-wait-integration-source',
 'capacity_root':continuation/'wan-read-wait-capacity-source',
 'base_runner':continuation/'wan-read-wait-stack-intern-source/integration-source/runs/sustained-matched-protocol-1/preflight/runner-rebuilt.sh',
 'sender_observer_checkpoint':continuation/'wan-sender-wait-source/review/source-checkpoint-9/SHA256SUMS.txt',
 'combined_checkpoint_manifest':continuation/'wan-below-tls-raw-write-source/implementation-source/server-growth/review/combined-integration-source-checkpoint-5/SHA256SUMS.txt',
 'combined_contract_ledger':continuation/'wan-below-tls-raw-write-source/implementation-source/server-growth/runs/combined-contract-attempt-1/records/SHA256SUMS.txt',
 'server_growth_checkpoint':continuation/'wan-below-tls-raw-write-source/implementation-source/server-growth/review/source-checkpoint-3/SHA256SUMS.txt',
 'server_growth_overlay_patch':continuation/'wan-below-tls-raw-write-source/implementation-source/server-growth/review/source-checkpoint-3/SERVER-GROWTH-GO.patch',
 'server_growth_runner_patch':continuation/'wan-below-tls-raw-write-source/implementation-source/server-growth/review/source-checkpoint-3/SERVER-GROWTH-RUNNER.patch',
 'server_growth_focused_receipt':continuation/'wan-below-tls-raw-write-source/runs/server-growth-focused-attempt-1/records/SHA256SUMS.txt',
 'raw_ordinary_proof_receipt':root/'provenance/raw-ordinary-proof-receipt.json',
 'byte_credit_ordinary_proof_receipt':root/'provenance/byte-credit-ordinary-proof-receipt.json',
 'combined_build_receipt':root/'provenance/audited-combined-build-receipt.json',
 'tcp_producer_checkpoint':continuation/'wan-tcp-state-source/implementation-source/integration/review/source-checkpoint-6/SHA256SUMS.txt',
 'tcp_source_map':continuation/'wan-tcp-state-source/implementation-source/integration/review/source-checkpoint-6/SOURCE-MAP.json',
 'tcp_build_records_ledger':continuation/'wan-tcp-state-source/build-source-1/runs/audited-build-attempt-2/records/SHA256SUMS.txt',
 'tcp_build_outer_ledger':continuation/'wan-tcp-state-source/build-source-1/provenance/audited-build-attempt-2-tool-envelope/SHA256SUMS.txt',
 'tcp_validator_contract_ledger':continuation/'wan-tcp-state-source/runner-source-1/runs/tcp-validator-contract-attempt-1/records/SHA256SUMS.txt',
 'tcp_validator_contract_outer':continuation/'wan-tcp-state-source/runner-source-1/provenance/tcp-validator-contract-attempt-1-outer/SHA256SUMS.txt',
 'history_producer_checkpoint':continuation/'wan-tcp-threshold-history-source/implementation-source/review/source-checkpoint-8/SHA256SUMS.txt',
 'history_source_map':continuation/'wan-tcp-threshold-history-source/implementation-source/review/source-checkpoint-8/SOURCE-MAP.json',
 'history_build_records_ledger':continuation/'wan-tcp-threshold-history-source/build-source-1/runs/audited-build-attempt-3/records/SHA256SUMS.txt',
 'history_build_outer_ledger':continuation/'wan-tcp-threshold-history-source/build-source-1/provenance/audited-build-attempt-3-native-envelope/SHA256SUMS.txt',
 'history_validator_checkpoint':continuation/'wan-tcp-threshold-history-source/implementation-source/validator/review/source-checkpoint-2/SHA256SUMS.txt',
 'history_validator_contract_ledger':continuation/'wan-tcp-threshold-history-source/runner-source-1/runs/history-validator-contract-attempt-1/records/SHA256SUMS.txt',
 'history_validator_contract_outer':continuation/'wan-tcp-threshold-history-source/runner-source-1/provenance/history-validator-contract-attempt-1-outer/SHA256SUMS.txt',
 'failed_tiny_run_ledger':continuation/'wan-tcp-threshold-history-source/provenance/tiny-threshold-history-smoke-1-result-review/RUN-SHA256SUMS.txt',
 'failed_tiny_erratum_ledger':continuation/'wan-tcp-threshold-history-source/provenance/tiny-threshold-history-smoke-1-result-review-erratum-1/SHA256SUMS.txt',
 'adapter_checkpoint':continuation/'wan-byte-credit-integration-source/implementation-source/review/source-checkpoint-11/SHA256SUMS.txt',
 'adapter_contract_ledger':continuation/'wan-byte-credit-integration-source/runs/focused-contract-attempt-2/SHA256SUMS.txt',
 'adapter_contract_outer':continuation/'wan-byte-credit-integration-source/provenance/focused-contract-attempt-2-main-tool-envelope/SHA256SUMS.txt',
 'protocol_checkpoint':continuation/'wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle/review/source-checkpoint-5/SHA256SUMS.txt',
 'protocol_focused_ledger':continuation/'wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle/runs/focused-attempt-2/records/SHA256SUMS.txt',
 'protocol_focused_outer':continuation/'wan-below-tls-raw-write-source/implementation-source/byte-credit-recycle/provenance/focused-attempt-2-worker-tool-envelope/SHA256SUMS.txt',
 'runner':integration/'generated/qualify-proxy-agent-growth-wan-below-tls.sh',
 'arm_validator':integration/'validate-wan-below-tls-arm.py',
 'arm_outcome_validator':integration/'validate-arm-outcome.py',
 'copy_validator':integration/'validate-copy-record.py',
 'sender_validator':integration/'validate-sender-wait-snapshot.py',
 'raw_validator':integration/'validate-raw-write-activity.py',
 'growth_validator':integration/'validate-server-receive-growth.py',
 'byte_credit_validator':integration/'validate-byte-credit-recycle.py',
 'tcp_state_validator':integration/'validate-tcp-state.py',
 'closure_validator':integration/'validate-post-join-raw-closure.py',
 'continuation_validator':integration/'validate-h1-continuation.py',
}
expected={
 'base_runner':'e9e453206cd479e1d29b78c05cf4d0eaf0cbaefe3c6ff13f0ba9594235c3bea0',
 'sender_observer_checkpoint':'9f96e06bfd571fdf3550d095e6818b949bff0e3cdd733394e7ce93299e965e30',
 'combined_checkpoint_manifest':'7a5aa90f45d588fc05e58f1968772b7a0accbad295bfecc7470bcb980022aab5',
 'combined_contract_ledger':'d63e8212ba90000f5067c20546a7f9084ae65f0073aa3cb9690c3c0c8615ef37',
 'server_growth_checkpoint':'29e33466c5f79928b4d3805fcf957fb0d49b1eeb1f0c8fba720ff001c7193856',
 'server_growth_overlay_patch':'da47ac7179f6113a6c3a918a19db6ea0a8fd116feff7c893c2123b5fa9779644',
 'server_growth_runner_patch':'f08461837990894b693157a45510b8694749f882ccae8e0b01ce8c818e2e69a3',
 'server_growth_focused_receipt':'2109895c1d9d0d4824f49b9823b034a44693dfa1d8ca05c5340491024fa726ff',
 'raw_ordinary_proof_receipt':'b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d',
 'byte_credit_ordinary_proof_receipt':'6562b975ba8f25d1b7a1a83c323c4c289f62f97b5508421e9e0f2e244c940460',
 'combined_build_receipt':'dae7e3e7e58cd829804b07aea9b063aa6d0233552ae0068d9c38725bed427f13',
 'failed_tiny_run_ledger':'7d18e0427115df2b00f0e3fe13752dd7c9dd278998122e8cb6350968925caeb0',
 'failed_tiny_erratum_ledger':'9c42e66087ff9c4587abdba5a3d4443a2103e286f00b18a7e21357d3abd3d002',
 'adapter_checkpoint':'4b91d78895462b0280ac0915bbf9580e49c864b747a6f231c3065d227f994062',
 'adapter_contract_ledger':'b4253d5b10bbbec2ea1d94b679ded5dea805081c62b2d31c36b3798ea726125a',
 'adapter_contract_outer':'b54598e556246b568ae8fe9bdadac91feda31d9f2a29d44a9e7d9f3a1bebfdc0',
 'protocol_checkpoint':'d315f2e4f49c3b00d714346d5ff38a797c52e7b1874e7d21e7d89679a46d4287',
 'protocol_focused_ledger':'2ebacd83ac4102b008185ed173910c467bc271ca87ada6c4c831f1357fb0ea2e',
 'protocol_focused_outer':'ffcd04d875bcc1d533bd93d2045e113f68a2e9f072643f1eaf96f5270db8126d',
 'runner':'a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad',
 'arm_validator':'0a03f2cdcdabbe0522e9566c247777b6678d9def960e74f983e176d928733840',
 'arm_outcome_validator':'4c4f1c8119aac278b732fadabb72fa08f9249ee9ed003d0b881c5220b74f1eb1',
 'copy_validator':'f1c70a2f347a77975a00330d4d37929700b1a38bac5fa195c3dff02b3f773c26',
 'sender_validator':'25a934047a84c82d41852871047486138fa10fa4e8a1d3db3e867f38ad50e260',
 'raw_validator':'66ff26fcdbfe71143d49b816e448f28ff7de789daba11e02c8d618d11c361bff',
 'growth_validator':'bab8a8def06fc4347b5cfd8e7547c40ca85013fe28892da43c0e365c32dd7477',
 'byte_credit_validator':'e53f911e0362eeae728a55386cce5ebb0eb60a52163df14f8a95d0135aa0c3eb',
 'tcp_state_validator':'b76c169749db53a38b3275fd0d85670b2b07ee35e786cc9669f2f88c603b1056',
 'tcp_producer_checkpoint':'809f30484ea276a20586fec84517fdec9ef84ff58b2c96c9da3ab65b5122a3a0',
 'tcp_source_map':'1211123ced422276abb4156ebd108fb3bec056273b3ddc384448fba283002d33',
 'tcp_build_records_ledger':'3419e3da3b395db795e544aea1c1c59262033ad1827674ecf0dbce1d7200bbd8',
 'tcp_build_outer_ledger':'442ffeb22586ad5179fd18646cbf48097848d0a3d2d8f5e7bc89a7a6bf0af8b0',
 'tcp_validator_contract_ledger':'7cfe27fc04b1f64facac7c323b611a4b04cf608b87b07c20c41e82ac9e8fba67',
 'tcp_validator_contract_outer':'c0a705bb95d39dbeb05a4291b74b449dd65eb4fae6adb44fef2efe5e227e4c24',
 'history_producer_checkpoint':'3f1e9e54d979ba52680b5b16e761df188f9846d3add75a4d7a2a7f1617ccf0b9',
 'history_source_map':'4d74567dcc24618dd841265e8dcbcdb378e63b9e59d25bfcb77e16740af49bdd',
 'history_build_records_ledger':'229a585ca3365ff06223043afcad608fc831fd9958f5f721386285a6c9ee7b1d',
 'history_build_outer_ledger':'5d115157591391a7ff29fef0795d698de91a7e349fd5690155d15fdf44d3efcb',
 'history_validator_checkpoint':'37c184eeffed66424f13dee384d0d0e31856c40892220c59d060308c46da7dc2',
 'history_validator_contract_ledger':'058b0c7b912fe506867262f09f87f4d015ea2049acd3c51ede3d3e7dd8c23dac',
 'history_validator_contract_outer':'fff73fb6e841714e3677c5b694afdfee2f7df7ebc9c64aff1ecb0abc1255040b',
 'closure_validator':'7b5b7962f603ebd7c160fabcdb9d4a78b7699e9866b4ed4172480be25b847eae',
 'continuation_validator':'24f85dbfc5ad165b17416f63772466f790202d1d7194dc4c2e6630e2161dbb9b',
}
expected_modes={
 'raw_ordinary_proof_receipt':0o600,
 'byte_credit_ordinary_proof_receipt':0o600,
 'combined_build_receipt':0o600,
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows={}
for name,path in paths.items():
 if not path.exists():raise SystemExit(f'missing {name}: {path}')
 digest=sha(path) if path.is_file() else None
 if name in expected and digest!=expected[name]:raise SystemExit(f'hash mismatch {name}')
 if name in expected_modes and stat.S_IMODE(path.lstat().st_mode)!=expected_modes[name]:raise SystemExit(f'mode mismatch {name}')
 rows[name]={'path':str(path),'kind':'directory' if path.is_dir() else 'file','sha256':digest}
out=pathlib.Path(sys.argv[1])
if out.exists():raise SystemExit('fresh output required')
out.mkdir(parents=True)
(out/'result.json').write_text(json.dumps({'schema_version':1,'accepted':True,'materialized_integration_dir':str(integration),'continuation_root':str(continuation),'resolved':rows,'endpoint_or_traffic':False},indent=2,sort_keys=True)+'\n')
