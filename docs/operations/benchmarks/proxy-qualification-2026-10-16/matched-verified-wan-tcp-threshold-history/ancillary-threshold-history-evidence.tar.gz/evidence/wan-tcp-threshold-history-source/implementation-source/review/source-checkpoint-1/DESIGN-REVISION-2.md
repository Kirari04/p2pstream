# First-threshold-history design clarifications

This append-only revision controls where it differs from `DESIGN.md`.

The retained bind baseline, last-equal bracket, and first-different bracket are
socket-lifetime state. Authenticated pre-capture refreshes a separate selected
comparison on every armed sequence. That comparison carries the exact sequence,
monotonic arm ordinal, selected TCP_INFO snapshot, and threshold. A mismatch
after a retained transition makes only that interval's explanation unavailable;
it does not replace the first bracket or invalidate the mature byte/TCP trace.
A finite selected pre with no retained transition proves that the first change
escaped raw-write bracketing, permanently stops monitoring, and makes history
integrity inconclusive. An initial selected pre with no change is healthy
`not_reproduced`; a later observed change is separately classified as
`transition_after_selected_pre`. A control owner can close healthy without a
transition.

`beginClose` marks the owner before invoking the underlying Close. Writes that
start after that marker make the mature raw/TCP evidence sticky invalid and do
not reserve either observer. A reservation created before the marker remains
permission to attempt its synchronous capture without holding the owner lock.
Close can race after the permission check; `RawConn.Control` either holds the
descriptor reference for its callback or returns an error. Such a reservation
finishes as sticky `close_race`. The implementation does not claim that a
provider callback can never enter after the underlying Close call begins.

Every raw write increments the socket-lifetime raw ordinal, even after history
has stopped. The 4096 ceiling counts monitored raw-write attempts, while the
retained state remains constant size. Provider counters and duration buckets
count only actual raw-boundary provider invocations. They exclude the preexisting
bind capture, whose snapshot retains its own duration, and identify the subset
of raw captures also used by the selected interval TCP raw-pair totals. A denied
capture permission is not counted as a provider invocation. Reused captures are
physically invoked once and their measured cost is never subtracted from wall
time.

The first differing bracket is classified as one of:

* `between_bind_and_first_write` when the first write's before snapshot already
  differs from bind;
* `between_writes` when a retained equal bracket precedes a later differing
  before snapshot; or
* `across_write_observation` when before equals bind and after differs.

These are discrete observation brackets. They do not identify an atomic kernel
setter or establish causation. In particular, retransmission and CA-state
values do not exclude earlier ECN/CWR or another kernel path, and the current
TCP_INFO schema does not expose enough ECN negotiation state to label the
creator conclusively.

A selected-pre equality is an available explanation only when the decisive
snapshot in the retained bracket completed no later than that pre-capture
started on the same owner-relative monotonic clock. The decisive snapshot is
`Before` for a between-bind/between-write bracket and `After` for an
across-write bracket. An overlap or later decisive capture preserves the first
record and mature evidence but classifies that interval as
`selected_pre_transition_not_strictly_prior`.
