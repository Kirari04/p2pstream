# Bounded runner adapter contract invocation

Run the successor runner checkpoint 2 contract under the unchanged reviewed owned-process helper with the existing 60-second bound and natural-join checks. Exact ordered cases are the prior accepted 68 plus the 17 reviewed full-snapshot/context controls. The exact source checkpoint and contract/allowlist hashes are checked before and after execution. Frozen tiny 1 remains failed and H2 withheld; retained raw fixtures are individually hash-checked regression inputs. No materialization, Go, endpoint, or WAN traffic is included.

Proposed command (only after source approval):

`/usr/bin/python3.14 -I -B review/runner-adapter-contract-invocation-source-1/run-contract.py runner-source-1/runs/runner-adapter-contract-attempt-1`

Paths above are relative to the threshold-history root; execution cwd is the authorized worktree. Output parent runner-source-1/runs already exists.
