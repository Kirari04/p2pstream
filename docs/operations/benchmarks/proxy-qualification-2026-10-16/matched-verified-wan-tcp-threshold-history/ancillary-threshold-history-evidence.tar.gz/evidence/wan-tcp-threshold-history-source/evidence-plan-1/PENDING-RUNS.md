# Pending run additions

- Tiny threshold-history smoke attempt 1 is frozen failed evidence: H1 produced all 16 rows, owner-generation structural joins failed, H2 was withheld, and cleanup was natural. Preserve its 145-file full ledger plus safe selected review/launch/outer artifacts; do not treat it as performance or causal evidence.
- Any corrected tiny successor remains pending source review and separate authorization.
- One sustained 32-transfer observation only if separately authorized and frozen: full-run ledger/review, safe selection, exclusions, outer envelope, and bounded analyses/errata.
