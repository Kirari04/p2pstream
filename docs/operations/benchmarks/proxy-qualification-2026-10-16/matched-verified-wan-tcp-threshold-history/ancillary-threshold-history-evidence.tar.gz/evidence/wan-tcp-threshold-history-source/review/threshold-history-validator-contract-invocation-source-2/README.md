# Threshold-history validator contract invocation source 2

This unexecuted invocation supersedes source 1 and runs the frozen 68-case contract from validator checkpoint 2 under the reviewed owned-process helper. It pins the complete checkpoint, contract, exact ordered case-name allowlist, Python, and helper bytes. It requires Python isolated/no-bytecode mode, exact integer JSON schema/status fields, the exact 68 ordered names with accepted=true, direct status zero, and a natural process-group join; then it rechecks every input before writing the final ledger.

Source 1 and validator checkpoint 1 remain preserved and unexecuted. This invocation runs no Go command, build, endpoint, or WAN traffic. The result output path must be fresh.
