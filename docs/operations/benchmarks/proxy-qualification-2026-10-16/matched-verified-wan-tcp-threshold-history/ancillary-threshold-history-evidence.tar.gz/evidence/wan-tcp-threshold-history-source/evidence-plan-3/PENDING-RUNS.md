# Remaining evidence work

- Freeze/review corrected runner2 final source contracts and exact outer status; accepted materialization2/publication2 are now bound.
- Add separately authorized corrected tiny and sustained32-transfer runs after natural closure, with complete run ledger, reviewed safe selections, launch/outer records, results, summaries, and any append-only errata.
- Extend run-selection registrations only with frozen root and exact full-run ledger SHA-256; retain every failed attempt.
- Snapshot the append-only main review log after its final stage update.
- Bind final candidate map, nonprinting exact-value scan and input allowlist, hash-only omissions and omitted-artifact ledger coverage; reuse independent verifier and negative scan-selection control.
- Parent review precedes archive/compression, tracked changes, commit/push. No merges, release, deployment, live configuration, root-checkout changes, or dev servers.
