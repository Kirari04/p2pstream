# First-threshold-history close and status clarifications

This append-only revision controls where it differs from `DESIGN-REVISION-2.md`.

The physical-close barrier is set only by `qualificationObservedRawConn.Close`
immediately before it calls the underlying physical connection's `Close`. The
outer `qualificationObservedTunnelBody.Close` must not set that barrier before
calling its wrapped close because the wrapped body can be `crypto/tls.Conn`,
whose orderly close synchronously emits `close_notify` through the observed raw
connection before closing that connection. The outer wrapper still calls
`markClosed` after the wrapped close returns. A close-notify raw write before the
physical barrier is a normal monitored write. A raw write beginning after the
physical barrier remains sticky invalid, and a previously reserved capture that
races the physical close remains sticky history-inconclusive.

When selected pre still equals the initial threshold and a retained transition
is observed, the neutral public status is
`transition_observed_with_initial_pre`. It does not assert that the transition
occurred after the selected-pre capture. Only the retained raw-write bracket and
its owner-relative capture coordinates express ordering.
