# Current WAN preparation handoff

Status: stopped under the immediate user model-policy override on 2026-10-17. No owned process is active. No further test, build, endpoint, traffic, implementation, or source edit was started after the override.

## Accepted immutable inputs

- Producer checkpoint cp8: `tmp/continuation-20261016/wan-tcp-threshold-history-source/implementation-source/review/source-checkpoint-8`, manifest `3f1e9e54d979ba52680b5b16e761df188f9846d3add75a4d7a2a7f1617ccf0b9`.
- Accepted build attempt3 receipt: `tmp/continuation-20261016/wan-tcp-threshold-history-source/build-source-1/runs/audited-build-attempt-3/RECEIPT.json`, SHA `dae7e3e7e58cd829804b07aea9b063aa6d0233552ae0068d9c38725bed427f13`.
- Runner checkpoint1: `tmp/continuation-20261016/wan-tcp-threshold-history-source/integration-runner-source-1`, manifest `f4948e2d32747ecd08601f7be2e5f84faa83e7d1325a7bf3f9458165ff3c1dd1`.
- Active materialization: `tmp/continuation-20261016/wan-tcp-threshold-history-source/integration-source-1`.
- Final contract records ledger: `c0eb0f8c3fd43b9c188013615c9f5128209bcbfa747c9df73490a3b5bd53447b`; accepted RESULT SHA `6bc79a51c142af71b7364f257440a19c6ab360cc5bae93cf27b5ba563e9d5787`.
- Tiny launcher source2: `tmp/continuation-20261016/wan-tcp-threshold-history-source/review/tiny-threshold-history-smoke-launch-source-2`, manifest `0f5c39f6af76a338c08e5f35727c899424e3cbad73f0f776f0985d5997948c49`, driver `4ebb7338259fa00f67a53d91f80c1fa2a026c461846c14ef661cc7a1fe671e88`, invocation `adaffc1692c55a097e1f2fb09bfe0857aaf7c2bd5c86502ead69f05313c02742`.

## Tiny attempt1, preserved and rejected

- Run: `tmp/continuation-20261016/wan-tcp-threshold-history-source/integration-source-1/integration/runs/tiny-threshold-history-smoke-1`.
- Native session `99917`; initial chunk `4d5358`; final chunk `bb10a3`; exit `1`; no console output.
- H1 ran 16/16 transfer processes and runner status was zero. Validation status was one. H2 was withheld with status 125. Coordinator and process groups joined naturally without timeout, TERM, KILL, or forced cleanup. No retry occurred.
- Full run ledger: `tmp/continuation-20261016/wan-tcp-threshold-history-source/provenance/tiny-threshold-history-smoke-1-result-review/RUN-SHA256SUMS.txt`, SHA `7d18e0427115df2b00f0e3fe13752dd7c9dd278998122e8cb6350968925caeb0`, exact 145 files / 9,421,218 bytes.
- Review SHA `66b16eb876c532622c802de1eb4ead352ea8063dc60ea33014e1572705e67ce0`; review ledger SHA `063428d18eeacb9b84c9ebf9162dedc3ba9d6e541b1b543f312f47bbc16b3997`.
- Launcher records ledger SHA `cf04cb0d53a0a219bc24de97912493de2ba324dd852bf105a3d48f700c08cf9b`; launcher RESULT SHA `a7b212a3710757e7ad2b1cc5a0a034e7d27469f3146fff479d04c4c51f2fa0da`.
- Native envelope ledger SHA `3cc79b3d86c34da7c77e50890ec7982467bc596727275dc96a408976d5d5aeb4`; metadata SHA `4774939c3d841c6cf4c1f9e4c7e0fc4b5759c22469c19d8cd416ef3982508153`.
- Append-only review erratum: `tmp/continuation-20261016/wan-tcp-threshold-history-source/provenance/tiny-threshold-history-smoke-1-result-review-erratum-1`, ERRATUM SHA `99d7f9a632c30f2bc492474e6e21dd4d2fa5726cbad2d7e9ca0052635b060653`, ledger SHA `9c42e66087ff9c4587abdba5a3d4443a2103e286f00b18a7e21357d3abd3d002`.

## Exact failure and next source boundary

The producer generation data is coherent. For sequences 9, 11, 14, and 15, lanes 0..4 have raw generations `[1,5,3,2,4]`, and every retained `last_equal.owner_generation` exactly matches those values.

Two runner-only validator defects caused the rejection:

1. `integration/validate-sender-wait-snapshot.py` omits `raw_write_activity.generation` from both raw-owner identity dictionaries (the generic-row path around line 252 and selected-row path around line 445). This passes `None` to the threshold-history owner join.
2. `integration/validate-tcp-state.py::validate_live` unconditionally requires `threshold_history.required=true`, even for generic lane 0 control rows where the producer correctly emits `required=false`. The requirement belongs only to selected nonzero DATA context; owner validation already enforces `required == (lane != 0)`.

No producer or binary rebuild is indicated. Do not retry the unchanged runner. The next owner should prepare and review a narrow runner/validator successor with generation propagation in both identity dictionaries plus controls for exact generation match/mismatch, generic lane-0 acceptance, and selected nonzero required behavior. Then use a fresh materialization/contracts/launcher chain and obtain authorization before any new traffic.
