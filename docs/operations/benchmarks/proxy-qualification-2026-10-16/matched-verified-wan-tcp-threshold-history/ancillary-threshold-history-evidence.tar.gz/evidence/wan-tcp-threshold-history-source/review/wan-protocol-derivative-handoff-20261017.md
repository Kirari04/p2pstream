# WAN threshold-history independent-review handoff

Status: stopped on 2026-10-17 by the user model-policy override. No edits to frozen source, no retry, and no additional tests or traffic were performed by this reviewer.

## Last accepted source and offline chain

- Producer checkpoint 8: `implementation-source/review/source-checkpoint-8`, manifest `3f1e9e54d979ba52680b5b16e761df188f9846d3add75a4d7a2a7f1617ccf0b9`.
- Validator checkpoint 2: `implementation-source/validator/review/source-checkpoint-2`, manifest `37c184eeffed66424f13dee384d0d0e31856c40892220c59d060308c46da7dc2`; validator `776140b9267a32ec7b2f3456f02ab570d292cd91a7b9f40d66b1d2f5f146ec90`; accepted 68-case ledger `058b0c7b912fe506867262f09f87f4d015ea2049acd3c51ede3d3e7dd8c23dac`.
- Accepted build attempt 3: `build-source-1/runs/audited-build-attempt-3`; records `229a585ca3365ff06223043afcad608fc831fd9958f5f721386285a6c9ee7b1d`; receipt `dae7e3e7e58cd829804b07aea9b063aa6d0233552ae0068d9c38725bed427f13`; agent `3d6ee99bb47091f8a5986dd0d99d90a27e84c2e78fbd34eac536794e8fa5cd54`; server `67e7eed1317e944be1a54609ed3bcc911f855f7a39e21402695b6d7b6e5a55bb`.
- Runner source 1: `integration-runner-source-1`, manifest `f4948e2d32747ecd08601f7be2e5f84faa83e7d1325a7bf3f9458165ff3c1dd1`; corpus `1f05c410103ce6a38620b53681ddc44ec7606b463c7388ba1ec1ae1036e24a16`.
- Final offline contracts: records `c0eb0f8c3fd43b9c188013615c9f5128209bcbfa747c9df73490a3b5bd53447b`; result `6bc79a51c142af71b7364f257440a19c6ab360cc5bae93cf27b5ba563e9d5787`; outer `9a4373aad3cf12e6470c3763345b03201139e63badb4318dcbd3b820415881b3`.

## Tiny threshold-history smoke 1

- Launcher source 2: `review/tiny-threshold-history-smoke-launch-source-2`; manifest `0f5c39f6af76a338c08e5f35727c899424e3cbad73f0f776f0985d5997948c49`; driver `4ebb7338259fa00f67a53d91f80c1fa2a026c461846c14ef661cc7a1fe671e88`; invocation `adaffc1692c55a097e1f2fb09bfe0857aaf7c2bd5c86502ead69f05313c02742`.
- Run root: `integration-source-1/integration/runs/tiny-threshold-history-smoke-1`.
- Frozen review: `provenance/tiny-threshold-history-smoke-1-result-review`; RUN ledger `7d18e0427115df2b00f0e3fe13752dd7c9dd278998122e8cb6350968925caeb0` (145 files, 9,421,218 bytes); review `66b16eb876c532622c802de1eb4ead352ea8063dc60ea33014e1572705e67ce0`; root ledger `063428d18eeacb9b84c9ebf9162dedc3ba9d6e541b1b543f312f47bbc16b3997`.
- Frozen erratum: `provenance/tiny-threshold-history-smoke-1-result-review-erratum-1`; ERRATUM `99d7f9a632c30f2bc492474e6e21dd4d2fa5726cbad2d7e9ca0052635b060653`; ledger `9c42e66087ff9c4587abdba5a3d4443a2103e286f00b18a7e21357d3abd3d002`.
- Outcome: natural exit 1; H1 runner status 0 with all 16 transfers; validation status 1; H2 withheld; no forced cleanup. This run is invalid qualification evidence and supplies no performance or causal result.

## Exact diagnosed runner defects

1. `integration/validate-sender-wait-snapshot.py` constructs both raw-owner identity dictionaries without `generation` (the general physical-row path and the selected-row path). It passes those dictionaries into `validate-raw-write-activity.validate_live`, whose threshold-history owner join then receives `owner_generation=None`. This creates the repeated `owner generation is not positive` and `last_equal.owner_generation differs from the enclosing raw owner` errors. Actual producer records are coherent; for sequence 9 pre, raw generations by lanes 0..4 are `1,5,3,2,4`, and each present `last_equal.owner_generation` equals its enclosing raw generation.
2. `integration/validate-tcp-state.py::validate_live` unconditionally requires `threshold_history.required is True`, although sender-snapshot validation calls it for every post lane. Lane 0 is the designed control owner and correctly has `required=False`, causing the additional `required is not true for the selected DATA lane` error. Preserve the existing exact owner-lane rule `required == (lane != 0)` and apply the selected-DATA requirement only when selected context is supplied (sequence/selected stream).

The narrow successor should change runner validation only: propagate `raw_write_activity.generation` in both snapshot identity dictionaries, scope the selected-required assertion correctly, and add snapshot-level positive/mismatch controls for matching generation, missing/wrong generation, generic lane-0 post, and selected nonzero lane. No producer or Go binary rebuild is justified by this failure. Preserve the failed run and erratum unchanged.
