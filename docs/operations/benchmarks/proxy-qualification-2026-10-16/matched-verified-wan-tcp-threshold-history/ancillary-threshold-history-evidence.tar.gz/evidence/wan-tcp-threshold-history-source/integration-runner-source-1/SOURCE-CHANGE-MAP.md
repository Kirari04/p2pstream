# Planned source change map (draft)

This map is descriptive and non-executable. Exact paths may be removed if the frozen producer schema allows the same guarantee with fewer changes.

| Path | Exact planned responsibility |
|---|---|
| `integration/validate-tcp-state.py` | Add strict nested threshold-history parsing and conservation to `validate_activity`; expose structural integrity and explanation availability separately from `validate_live`; bind the selected interval's current sequence/epoch and `pre_tcp_info.send_slow_start_threshold` without overwriting persistent history. Preserve every existing TCP-state check. |
| `integration/validate-raw-write-activity.py` | Pass the enclosing raw-owner lane/generation/physical tuple into threshold-history validation at live, boundary, and terminal phases; require terminal sequence-15 retention without changing any mature raw-write gate. |
| `integration/contracts/test-tcp-state-validator.py` | Add producer-shaped controls for first transition, no-transition initial baseline, missing/mismatched later history, control/TLS attribution, terminal retention, identity/order/conservation failures, and per-sequence comparison mismatch. Existing TCP-state cases remain. |
| `integration/validate-wan-below-tls-arm.py` | Retain the existing selected lane/session/tuple/stream and byte-wait joins. Validate persistent-history progression from the authenticated pre drain to the post response, then append one threshold-history explanation object per selected sequence. Structural history defects enter integrity issues; defined explanation-unavailable statuses do not invalidate mature raw/byte/TCP evidence. Add a narrowly worded interpretation with no atomicity, cross-clock, or causal claim. |
| `integration/run-wan-below-tls-arm.sh` | Bind the frozen producer checkpoint/map, accepted build/contract evidence, and changed validator/arm hashes. Add only reviewed provenance keys and keep pre/post equality, self-gates, lifecycle, terminal closure, and response limits unchanged. |
| `integration/run-wan-below-tls-diagnostic.sh` | Mirror the exact new provenance bindings and validator hash gates in the coordinator; preserve continuation rules and H1/H2 schedule. |
| `integration/contracts/test-arm-outcome.py` | Advance the exact named producer/validator hash key set only if additive provenance keys are necessary; assert exact set equality before updating any cardinality. |
| `contracts/test-tcp-state-runner-source.py` | Bind frozen producer payload/schema, history validator behavior, original `(4 << 20) + 1` response read, and oversize fail-closed producer metadata. Preserve generated runner and timed-body hashes. |
| `integration/contracts/test-final-source-bindings.py` | Verify active versus ancestry receipts separately, actual validator self-gate hashes, frozen producer/map, and exact materialized modes/paths. |
| `integration/contracts/run-final-source-contracts.sh` | Invoke the unchanged mature contract chain plus the focused history cases in fresh owned work, with exact statuses and bounded output inventory. |
| `verify-static-paths.py` | Resolve the successor active root and bind exact reviewed producer/build/contract/source inputs without changing mature historical bindings. |
| `SOURCE-CORPUS.json`, `TCP-BINDINGS.json`, `CHECKPOINT.json`, `INPUTS.json`, `README.md`, `STATUS.md` | Final immutable allowlist and provenance after all external hashes exist. They remain draft until then. |

No change is planned to `integration/generated/qualify-proxy-agent-growth-wan-below-tls.sh`, `integration/runner-query-block.sh.txt`, `integration/runner-wrapper-block.sh.txt`, certificate policy, traffic schedule, namespace/process ownership, cleanup, or any prior validator.
