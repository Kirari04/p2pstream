#!/usr/bin/python3.14
"""Read-only preflight for the frozen TCP threshold-history build source."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    if len(sys.argv) != 2:
        raise ValueError("usage: verify-build-source.py APPROVED-INPUTS.json")
    checkpoint = Path(__file__).resolve().parent
    driver_path = checkpoint / "run-audited-threshold-history-build.py"
    approved_path = Path(sys.argv[1]).resolve(strict=True)
    approved = json.loads(approved_path.read_text(encoding="utf-8"))
    expected_fields = {
        "schema_version", "accepted", "build_checkpoint_manifest_sha256",
        "build_driver_sha256", "history_checkpoint_manifest_sha256",
        "history_overlay_manifest_sha256", "history_focused_test_plan_sha256",
        "history_validator_contract_records_ledger_sha256",
        "history_validator_contract_outer_ledger_sha256", "current_source_binding_sha256",
        "build_expected_tests_sha256",
        "runs_parent_preparation_ledger_sha256",
        "history_runtime_schema_carry_sha256",
        "history_validator_checkpoint_manifest_sha256",
        "failed_build_attempt1_records_ledger_sha256",
        "failed_build_attempt2_records_ledger_sha256",
    }
    if (set(approved) != expected_fields or approved.get("schema_version") != 1
            or approved.get("accepted") is not True
            or any(re.fullmatch(r"[0-9a-f]{64}", str(approved.get(key, ""))) is None
                   for key in expected_fields - {"schema_version", "accepted"})):
        raise ValueError("approved input schema differs")
    if sha(checkpoint / "SHA256SUMS.txt") != approved["build_checkpoint_manifest_sha256"]:
        raise ValueError("build checkpoint manifest differs")
    if sha(driver_path) != approved["build_driver_sha256"]:
        raise ValueError("build driver differs")
    spec = importlib.util.spec_from_file_location("reviewed_tcp_build", driver_path)
    if spec is None or spec.loader is None:
        raise ValueError("build driver import failed")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.verify_ledger(checkpoint, approved["build_checkpoint_manifest_sha256"])
    base_receipt, base_files = module.verify_base()
    current = module.verify_current_binding()
    overlay = module.verify_overlay(module.TCP_CHECKPOINT, approved)
    module.verify_successor_provenance()
    local_plan = checkpoint / "EXPECTED-TESTS.json"
    producer_plan = module.TCP_CHECKPOINT / "FOCUSED-TEST-PLAN.json"
    if (sha(local_plan) != module.BUILD_TEST_PLAN_SHA
            or approved["build_expected_tests_sha256"] != module.BUILD_TEST_PLAN_SHA
            or sha(producer_plan) != module.TCP_FOCUSED_PLAN_SHA
            or approved["history_focused_test_plan_sha256"] != module.TCP_FOCUSED_PLAN_SHA):
        raise ValueError("focused plan binding differs")
    packages = module.load_contract(local_plan)
    module.verify_producer_plan(producer_plan, checkpoint / "BASE-TCP-EXPECTED-TESTS.json", packages)
    result = {
        "schema_version": 1,
        "accepted": True,
        "build_checkpoint_manifest_sha256": approved["build_checkpoint_manifest_sha256"],
        "build_driver_sha256": approved["build_driver_sha256"],
        "base_source_file_count": len(base_files),
        "overlay_file_count": len(overlay),
        "agent_root_count": len(packages["p2pstream/internal/agent"]["roots"]),
        "agent_event_count": len(packages["p2pstream/internal/agent"]["all_tests"]),
        "yamux_root_count": len(packages["github.com/hashicorp/yamux"]["roots"]),
        "yamux_event_count": len(packages["github.com/hashicorp/yamux"]["all_tests"]),
        "base_receipt_accepted": base_receipt.get("accepted") is True,
        "current_binding_clean": current.get("tracked_clean") is True,
        "endpoint_execution": False,
        "go_execution": False,
        "wan_traffic": False,
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
