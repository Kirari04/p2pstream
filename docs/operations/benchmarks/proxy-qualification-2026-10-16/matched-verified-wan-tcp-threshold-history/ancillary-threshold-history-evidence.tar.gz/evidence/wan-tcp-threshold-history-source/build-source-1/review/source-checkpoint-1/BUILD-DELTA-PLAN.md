# Build delta plan (draft)

The final producer `SOURCE-MAP.json` is expected to be relative to accepted TCP-state build attempt 2 source ref `8ac4c8df8237e37777ba2fac0da6f949da17bdea+tcp-state-corpus-0595c8e5fa4b19bc6612b409cfe69b7ddd0d4f7fa190a6dc26e27fd610648cd4`.

Current producer report lists the following provisional five paths:

- changed `internal/agent/qualification_raw_write_qualification.go`
- changed `internal/agent/qualification_tcp_state_qualification.go`
- changed `third_party/yamux/qualification_tcp_state.go`
- new `internal/agent/qualification_tcp_threshold_history_qualification.go`
- new `internal/agent/qualification_tcp_threshold_history_qualification_test.go`

The final immutable `SOURCE-MAP.json` is authoritative for both membership and cardinality; an earlier inventory mentioned four modified plus two new paths, so this draft does not hardcode five. Files in the mutable producer work area that are byte-identical to accepted TCP checkpoint 6 must not be repeated in the final overlay. The driver derives the overlay count from the frozen map, verifies the final tagged selected-source delta equals that reviewed overlay, and verifies ordinary agent and Yamux selected-source maps remain byte-identical.

The provisional eight new agent roots are:

- `TestQualificationTCPThresholdHistoryFirstTransition`
- `TestQualificationTCPThresholdHistorySelectedPreClassification`
- `TestQualificationTCPThresholdHistoryFailuresAreSticky`
- `TestQualificationTCPThresholdHistorySharesSelectedRawPairCapturesOnce`
- `TestQualificationTCPThresholdHistoryPersistsAcrossHealthyDrain`
- `TestQualificationTCPThresholdHistoryJSONShape`
- `TestQualificationTCPThresholdHistoryRefreshesThroughArmDrain`
- `TestQualificationTCPThresholdHistoryCloseOrdering`

The current producer count is 30 exact names and 60 run/pass events for these roots and subtests. The final focused plan must enumerate and audit the exact root and subtest event multiset from the frozen producer. Existing affected TCP-state/raw/auth route roots remain; unchanged server-focused evidence is inherited through the accepted TCP build receipt, while fresh server and agent binaries are still required because Yamux/agent tagged source changes.

No full ordinary compiler proof is rerun. Exact normal/tagged `go list` selected-source maps prove the ordinary selection is unchanged, and the accepted raw/byte/TCP proof and build ancestry remain bound by their immutable receipts.
