#!/usr/bin/env bash
set -Eeuo pipefail
exec /usr/bin/env \
  -u P2PSTREAM_QUALIFICATION_PROFILE_DIR \
  -u P2PSTREAM_QUALIFICATION_PROFILE_MODE \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_DIR \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_SEQUENCES \
  -u P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_BEARER \
  /usr/bin/taskset -c 0-15 \
  /usr/bin/bash \
  /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-tcp-threshold-history-source/integration-source-1/integration/run-wan-below-tls-diagnostic.sh \
  --server-binary /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-tcp-threshold-history-source/build-source-1/runs/audited-build-attempt-3/bin/current-server-wan-tcp-threshold-history-audited.test \
  --aggregate-agent-binary /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-tcp-threshold-history-source/build-source-1/runs/audited-build-attempt-3/bin/current-agent-wan-tcp-threshold-history-audited.test \
  --server-source-ref 8ac4c8df8237e37777ba2fac0da6f949da17bdea+tcp-threshold-history-corpus-970b41a3d3bb4ec7f3142e27875b9ba6d951e251b6c0bf6771059fb5ea801dbb \
  --aggregate-agent-source-ref 8ac4c8df8237e37777ba2fac0da6f949da17bdea+tcp-threshold-history-corpus-970b41a3d3bb4ec7f3142e27875b9ba6d951e251b6c0bf6771059fb5ea801dbb \
  --output-dir /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-tcp-threshold-history-source/integration-source-1/integration/runs/tiny-threshold-history-smoke-1 \
  --small-diagnostic
