#!/bin/bash
set -euo pipefail
umask 077

integration_dir=${1:?reviewed integration directory required}
output_dir=${2:?fresh owned output directory required}
[[ ! -e $output_dir ]] || { echo "fresh output directory required" >&2; exit 2; }
mkdir -m 700 "$output_dir"

validator=$integration_dir/validate-tcp-state.py
contract=$integration_dir/contracts/test-tcp-state-validator.py
for input in "$validator" "$contract"; do
  [[ -f $input && ! -L $input ]] || { echo "missing regular source: $input" >&2; exit 2; }
done

status=0
if python3 -I -B "$contract" >"$output_dir/result.json" 2>"$output_dir/stderr.txt"; then
  status=0
else
  status=$?
fi
printf '%s\n' "$status" >"$output_dir/direct.status"
python3 -I -B - "$output_dir/result.json" <<'PY'
import json, pathlib, sys
value = json.loads(pathlib.Path(sys.argv[1]).read_text())
expected_names = ['valid', 'history-not-reproduced', 'history-finite-pre-transition-unobserved', 'history-later-transition-mismatch', 'history-selected-data-attribution', 'history-earlier-data-stream-retained', 'history-exact-attempt-limit', 'history-over-attempt-limit', 'history-attempt-limit-status', 'history-bracket-requires-raw-monotonic', 'history-mismatch-requires-transition', 'history-mismatch-requires-comparison', 'history-mismatch-rejects-initial-pre', 'history-live-healthy-monitoring', 'history-healthy-provider-errors', 'history-record-ordinal-beyond-attempts', 'history-required-owner-lane', 'history-compared-transition-resolves-explanation', 'history-prebind-reason-requires-marker', 'history-no-transition-comparison-is-initial', 'history-counter-overflow-exhausted', 'history-finite-prebind-gap', 'history-initial-bind-rejects-prebind-gap', 'history-finite-bind-requires-prebind-gap', 'history-invalid-bracket-rejects-location', 'history-persistent-progression', 'history-arm-ordinal-jump', 'history-first-transition-overwrite', 'history-retained-transition-freezes-provider-work', 'history-retained-transition-freezes-shared-work', 'history-sticky-failure-freezes-provider-work', 'history-transition-preserves-last-equal', 'history-sticky-failure-freezes-history', 'exact-zero-boundary', 'terminal-retains-sequence-15', 'terminal-history-owner-mismatch', 'interleaved-stream-sample-ids', 'boolean-schema', 'invalid-sticky', 'overflow-sticky', 'record-cap', 'capture-count', 'unsupported-field', 'cursor-change-marker', 'cursor-after-invalid', 'sample-monotonic', 'pair-bracket', 'pair-reverse-link', 'congestion-change', 'entry-congestion-change', 'retry-congestion-change', 'raw-before-congestion-change', 'raw-after-congestion-change', 'last-live-mismatch', 'applied-retry-zero-credit', 'byte-credit-applied-zero-credit', 'sysctl-domain', 'history-boolean-schema', 'history-selected-sequence', 'history-selected-pre-snapshot', 'history-transition-chronology', 'history-provider-count', 'history-shared-provider-count', 'history-owner-generation', 'history-malformed-record-shape', 'history-last-equal-order', 'byte-credit-wait-join', 'selected-stream-join', 'snapshot-pre-generation-match-9', 'snapshot-pair-generation-match-9', 'snapshot-pre-generation-match-11', 'snapshot-pair-generation-match-11', 'snapshot-pre-generation-match-14', 'snapshot-pair-generation-match-14', 'snapshot-pre-generation-match-15', 'snapshot-pair-generation-match-15', 'snapshot-owner-generation-mismatch', 'snapshot-owner-generation-omitted', 'snapshot-owner-generation-boolean', 'snapshot-raw-owner-malformed', 'snapshot-selected-data-required-false', 'generic-control-lane-zero-required-false', 'generic-control-lane-zero-required-true-rejected', 'selected-sequence-requires-data-history', 'selected-stream-requires-data-history']
assert type(value) is dict and type(value.get("schema_version")) is int and value["schema_version"] == 1
assert value.get("accepted") is True and type(value.get("case_count")) is int and value["case_count"] == 85
observed = value.get("cases")
assert type(observed) is list and len(observed) == 85
assert all(type(row) is dict and set(row) == {"name", "accepted"} and row["accepted"] is True for row in observed)
assert [row["name"] for row in observed] == expected_names
PY
exit "$status"
