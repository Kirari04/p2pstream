# TCP threshold-history audited build derivative (draft)

The final driver will copy the accepted TCP-state build attempt 2 source into a fresh owned root, apply only the immutable threshold-history SOURCE-MAP payload, prove ordinary selected Go inputs remain byte-identical, record the exact tagged delta, run the reviewed affected agent and Yamux roots in normal and race modes, and create fresh tagged agent and server binaries.

Accepted raw/byte ordinary proofs and accepted TCP-state build/source ancestry are reused rather than rerun. The new focused run is owned by this driver. Every command has a direct status and owned process-group lifecycle record. Natural joins and zero-status success remain separate; acceptance requires both plus all source/tool/post checks. No endpoint or WAN traffic belongs to this driver.
