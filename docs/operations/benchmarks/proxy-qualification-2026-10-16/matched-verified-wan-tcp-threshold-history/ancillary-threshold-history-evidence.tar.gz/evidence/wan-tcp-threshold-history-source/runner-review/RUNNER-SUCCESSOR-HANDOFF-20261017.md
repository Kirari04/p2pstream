# Threshold-history runner successor handoff

Status: implementation stopped before any source mutation under the parent model-policy instruction. No tests, materialization, endpoints, or traffic were run. `integration-runner-source-1` and `integration-source-1` remain unchanged.

Accepted source baseline:

- Runner checkpoint: `tmp/continuation-20261016/wan-tcp-threshold-history-source/integration-runner-source-1`
- Manifest: `f4948e2d32747ecd08601f7be2e5f84faa83e7d1325a7bf3f9458165ff3c1dd1`
- Corpus: `1f05c410103ce6a38620b53681ddc44ec7606b463c7388ba1ec1ae1036e24a16`
- Generated runner: `a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad`
- Timed body: `b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798`

Preserved failed tiny run:

- Full run ledger: `7d18e0427115df2b00f0e3fe13752dd7c9dd278998122e8cb6350968925caeb0`
- Review ledger: `063428d18eeacb9b84c9ebf9162dedc3ba9d6e541b1b543f312f47bbc16b3997`
- Review erratum ledger: `9c42e66087ff9c4587abdba5a3d4443a2103e286f00b18a7e21357d3abd3d002`
- Review erratum: `99d7f9a632c30f2bc492474e6e21dd4d2fa5726cbad2d7e9ca0052635b060653`

Required narrow successor changes:

1. In `integration/validate-sender-wait-snapshot.py`, add the enclosing raw-write `generation` to both `raw_identity` objects:
   - generic counter validation near current line 251;
   - selected DATA validation near current line 445.
   The value must come from that row's `raw_write_activity.generation` and malformed public shapes must remain fail-closed.
2. In `integration/validate-tcp-state.py::validate_live`, remove the unconditional `threshold_history.required is true` demand for generic lane validation. Preserve `validate_threshold_history_owner`'s exact `required == (lane != 0)` rule. Require `required=true` only in a selected DATA context (sequence/selected stream/waits supplied).
3. Add snapshot-level controls that prove:
   - matching raw owner generation reaches threshold-history validation and is accepted;
   - owner-generation mismatch is rejected;
   - generic control lane 0 with `required=false` is accepted;
   - selected nonzero DATA context with `required=false` is rejected.
4. Cascade only the sender/TCP validator hashes and wrapper/static self-gates that depend on them. Preserve the accepted build/producer/proof receipts, exact workload runner and timed body bytes, and all mature gates.
5. Bind the failed tiny review erratum above in successor lineage. Preserve the original failed run and review unchanged.

Relevant call chain already inspected:

- `integration/validate-sender-wait-snapshot.py::counters` calls raw `validate_live` for all five lanes.
- `integration/validate-sender-wait-snapshot.py::validate_pair` calls raw `validate_live` again for the selected lane.
- `integration/validate-raw-write-activity.py::validate_live` forwards `owner_identity` into `validate-tcp-state.py::validate_live`.
- `integration/validate-tcp-state.py::validate_threshold_history_owner` already enforces positive generation and exact `required == (owner_lane != 0)`.

No successor directory was created.
