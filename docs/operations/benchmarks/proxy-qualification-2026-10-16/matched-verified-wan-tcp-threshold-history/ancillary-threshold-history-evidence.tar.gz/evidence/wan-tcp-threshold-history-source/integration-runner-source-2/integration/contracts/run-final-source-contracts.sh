#!/usr/bin/env bash
set -Eeuo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
source_root=$(realpath "$root/..")
work=${1:?fresh owned work directory is required}
[[ ! -e $work ]] || { echo "contract work directory already exists" >&2; exit 2; }
mkdir -m 0700 "$work"

for source in "$root/run-wan-below-tls-arm.sh" "$root/run-wan-below-tls-diagnostic.sh" \
              "$root/generated/qualify-proxy-agent-growth-wan-below-tls.sh"; do
  bash -n "$source"
done
for source in "$root/validate-wan-below-tls-arm.py" "$root/validate-h1-continuation.py" \
              "$root/validate-arm-outcome.py" \
              "$root/contracts/test-final-source-bindings.py" "$root/contracts/test-h1-continuation.py" \
              "$root/contracts/test-arm-outcome.py" \
              "$source_root/contracts/test-tcp-state-runner-source.py" \
              "$source_root/verify-static-paths.py"; do
  python3 -I -B -c 'import ast, pathlib, sys; ast.parse(pathlib.Path(sys.argv[1]).read_text(), filename=sys.argv[1])' "$source"
done
python3 -I -B "$source_root/verify-static-paths.py" "$work/path-resolution"
python3 -I -B "$root/contracts/test-final-source-bindings.py" \
  "$root/run-wan-below-tls-arm.sh" "$root/run-wan-below-tls-diagnostic.sh" \
  "$root/validate-wan-below-tls-arm.py" "$work/source-bindings.json"
python3 -I -B "$root/contracts/test-h1-continuation.py" \
  "$root/validate-h1-continuation.py" "$work/h1-continuation-cases.json"
python3 -I -B "$root/contracts/test-arm-outcome.py" \
  "$root/run-wan-below-tls-arm.sh" "$root/validate-wan-below-tls-arm.py" \
  "$root/validate-arm-outcome.py" "$work/arm-outcome-cases.json"
python3 -I -B "$source_root/contracts/test-tcp-state-runner-source.py" \
  > "$work/tcp-state-runner-source.json"
bash "$root/contracts/run-tcp-state-contracts.sh" "$root" "$work/tcp-state-contracts"
printf '%s\n' complete > "$work/FINAL"
