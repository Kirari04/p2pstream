# Runner adapter correction and rejected tiny2 handoff

No owned process remains active. Native tiny session25907 joined naturally with exit1 (chunks e10c09,086933,84a5af,ad5661; all output empty). No retry or sustained run occurred. Parent Astra owns diagnosis and further decisions; no additional fix is authorized.

## Completed narrow successor

Frozen integration-runner-source-2: manifest a4176af4c1d9b6594d7ec786688d4792b3e326d799ef3ec03338fbc4c2fe70a5; corpus46486512fdf2ee65a4b6ad4c406056c99b1a58a784063d3f5fcf6b58dc809821; exact38 paths. Both snapshot identity adapters preserve raw generation, selected history requirement is scoped to explicit sequence/stream, exact owner-role rule retained. Generated runner/timed body, producer cp8 and audited binaries unchanged.

Approved focused85 attempt1 passed: records8dbc7bc05629496af95ffecfa0165cd8c3a2856cf74dfe5b4a26407cff20d5f5; native6e8630f92199b27dcd6fccef867abd108fe61a972cfbabf213642ec776d0fdda. Exact prior68 plus17 controls; all five postchecks and natural0.

Materialization2 RESULT6b78ec113a588414707a2a35df795b62ab1f8bb885d12a32338895451ba669a0; publication2 RESULT207acd7c8087a33ac2f58ba2c5576ddbf0fea67558e76547e6418b54887d0691. Final contracts2 records46e52313fc3bf87a06569f3946204a6f43d76dea6e7883ef2282b892d064ace7 exact122; native d96b15d90a297f23d571706db87eaff38d34d5c6ccd16b4a65239ab3ff899899. Exact85 and all mature source checks passed, natural0/seven postchecks.

Tiny3 launcher source: review/tiny-threshold-history-smoke-launch-source-3 manifest5b4fb47170d85274588c5cd334ee76d79b3e53012a7ef6567b5d5f28ecbda0be; driver6091cf35b765068e9c749565c55949b69b824db2bc84b9b1984f34a05bdc045c. Current read-only preflight ledger5b7518e7f4bba35ff2878156d8ad55c3c3f67ae1c5ce027c1b4cbc43f5855af0 passed before the authorized single tiny2.

## Rejected tiny2

Run integration-source-2/integration/runs/tiny-threshold-history-smoke-2. Frozen provenance/tiny-threshold-history-smoke-2-result-review: RUN ledger5e5c7c1d0ae91caff4379fc1bc13fce227ea9a9337247452f54060f17550163f exact271 files/18,688,994 B; REVIEW587cbd834deeb0f6c117c3716a717b2b1c67552fcd0aeb5b3bbd4cc51712b43f; rootledger67ba39f2e71a39b8d6d7d6c86fbeb8278fad01103f241a6edc91a9fceaf176d3. Nativeouter a2f9c47a260bf2153e9e109164082dc75b7bd4273a21d63bd7883d2c7285a798. Launcher records69d7e660556ab61719cdb5ac049fd9f06c3a68ba07a7ab22d2232e24cfd8a7ff; RESULT16a8d8c7c90dd6c8ca5fbbfb5ca7f52af631a64f4014121998f99ecb23aafa02.

H1 all16 rows accepted. H2 all16 rows runner0, validation1. Healthy authenticated terminal drain precedes physical-finalization failures. H2 lane2/gen3 final34/34 succeeds but after capture fails raw_control. Lane4/gen2 final34/0 has write_error and mature outside.error_calls1, plus after raw_control. Both history records closed/inconclusive, captured=false after with no TCP_INFO/CC syscall attempt and blank CC. Validator schema1-only CC comparison reports blank CC differing from baseline; actual algorithm change is not established. The mature outside write failure remains independently real and must not be waived.

Source localization: qualificationObservedRawConn.Close calls beginClose, underlying Conn.Close, markClosed. beginRawWrite rejects preexisting closeStarted via sticky invalidity; captureTCPRawInfoIfPermitted checks reservation/generation/raw equality but no explicit close flags. Finish history checks closeObserved/sessionJoined before incomplete_write/bracket. No exported close timestamps establish exact concurrent ordering or prove TLS close_notify attribution. No source fix or runtime policy change has been made for this failure.

Original tiny1 and erratum remain unchanged, failed1/H2withheld125. No performance or parity gate is cleared by either tiny run. Only authorized worktree used; tracked state remains clean. No merge/release/deploy/live config/dev server.
