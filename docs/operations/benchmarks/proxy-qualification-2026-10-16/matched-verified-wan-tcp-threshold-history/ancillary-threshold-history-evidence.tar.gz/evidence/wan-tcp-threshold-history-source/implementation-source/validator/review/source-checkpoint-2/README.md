# TCP slow-start threshold history validator source checkpoint 2

This immutable source-only checkpoint derives from accepted TCP runner 3 and binds producer checkpoint 6. It supersedes preserved, unexecuted checkpoint 1 by closing fail-closed record bracketing, producer state-table, owner role, finite-bind, exhaustion, provider accounting, persistent-history, and progression gaps. Its frozen contract has 68 exact unique cases listed in `EXPECTED-CONTRACT-CASES.json`.

Persistent historical DATA attribution is validated internally and may belong to an earlier stream; current TCP wait/raw-pair records remain joined to the selected stream. Declared interval explanation gaps remain separate from mature byte-credit, raw-write, and TCP-state integrity.

The fixed 4096 monitored-write limit is enforced exactly. The existing authenticated response bound remains 4 MiB and fails closed on oversize; this checkpoint does not truncate a response or raise the bound. Provider durations cover only provider calls and are not total observer overhead. No cross-clock subtraction, causal conclusion, runtime fix, gate clearance, endpoint execution, or traffic is claimed.

The focused contract is frozen but unexecuted. Production/Yamux files, the workload runner, and the timed `run_transfer` body are absent and unchanged.
