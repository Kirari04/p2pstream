# Threshold-history runner successor 2

This fresh runner successor corrects two validator adapter defects exposed by rejected tiny smoke 1. Both snapshot raw-owner identities now retain the exact raw generation. Generic lane-0 post validation accepts its designed required=false role, while explicit selected sequence or stream context still requires DATA history. All owner-role, positive generation, schema, identity, lifecycle, TLS, bounded response, and fixed performance gates remain.

The exact 38-file allowlist and generated runner/timed transfer bytes are retained. Only validator logic, its focused contracts, and dependent hashes change. Producer checkpoint 8 and audited build attempt 3 are unchanged. The existing 68 focused controls are preserved; 17 additional full snapshot and selected-context controls yield an exact ordered 85-case allowlist. Retained tiny H1 envelopes are individually hash-bound regression fixtures only.

Tiny smoke 1 remains failed (status 1), with H2 withheld (125). Its run ledger and append-only diagnosis erratum are bound in INPUTS, CHECKPOINT, SOURCE-CORPUS, and static path verification. Offline acceptance of corrected adapters does not change that run's disposition or clear any performance gate. No producer or binary rebuild is required.

Source freeze follows parent and independent mutable-source review. Materialization, contracts, and traffic require their separately reviewed invocation chain.
