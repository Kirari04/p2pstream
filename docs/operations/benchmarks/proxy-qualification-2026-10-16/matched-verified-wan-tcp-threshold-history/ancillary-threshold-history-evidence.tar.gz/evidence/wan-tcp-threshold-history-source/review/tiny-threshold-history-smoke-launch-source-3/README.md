# Corrected threshold-history tiny launcher source 3

Launch exactly one fresh tiny H1→H2 smoke from active2 after the two runner adapter corrections and accepted exact85 focused/final contracts. The generated timed runner, queried workload, binaries, source inventory, verified TLS symmetry, 4MiB control limit, 30-second idle, fixed performance floors, environment, taskset, 3600-second owned deadline, natural joins, and sequential H1/H2 behavior are unchanged.

Tiny1 remains rejected status1/H2withheld125. This successor binds its launcher, native envelope, full run/review ledgers and append-only erratum, plus the accepted adapter contract records/native receipt. Offline regression acceptance does not reclassify the failed tiny1. Current build/producer and historical proof receipts remain unchanged.

Proposed command after source approval: `/usr/bin/python3.14 -I -B review/tiny-threshold-history-smoke-launch-source-3/run-tiny-smoke.py provenance/tiny-threshold-history-smoke-2-launch` (paths relative to history root). No traffic has run from this source.
