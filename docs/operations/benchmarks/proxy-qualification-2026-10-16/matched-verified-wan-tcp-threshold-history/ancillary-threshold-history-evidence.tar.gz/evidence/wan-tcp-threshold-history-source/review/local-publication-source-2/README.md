# Local receipt publication successor 2

Publish the unchanged exact three accepted receipts into fresh integration-source-2/provenance, retaining all file hashes, modes, binaries and checks. Only active root, source corpus, and accepted materialization2 bindings differ from publication source1. Focused runner adapter attempt1 passed the exact85 cases offline; original tiny1 remains rejected and H2 withheld. No endpoint or traffic.
