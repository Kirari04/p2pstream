#!/usr/bin/env python3
from __future__ import annotations

import ast
import hashlib
import json
import pathlib
import re
import sys


if len(sys.argv) != 5:
    raise SystemExit("usage: test-final-source-bindings.py ARM COORDINATOR VALIDATOR OUTPUT")
arm_path, coordinator_path, validator_path, output_path = map(pathlib.Path, sys.argv[1:])
if output_path.exists():
    raise SystemExit("fresh output required")
arm = arm_path.read_text()
coordinator = coordinator_path.read_text()
validator_source = validator_path.read_text()
validator_tree = ast.parse(validator_source, filename=str(validator_path))


def sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bound_self_gate(source: str, variable: str, path: pathlib.Path) -> bool:
    found = re.findall(
        rf'''sha256sum "\${re.escape(variable)}"[^\n]*== ([0-9a-f]{{64}})''',
        source,
    )
    return bool(found) and all(value == sha(path) for value in found)
required = None
for node in ast.walk(validator_tree):
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "required_hashes"
                                            for target in node.targets):
        required = ast.literal_eval(node.value)
        break
if not isinstance(required, set):
    raise SystemExit("validator required_hashes set not found")

write_start = arm.find("write_hashes() {")
python_start = arm.find("<<'PY'\n", write_start)
python_end = arm.find("\nPY\n}", python_start)
if min(write_start, python_start, python_end) < 0:
    raise SystemExit("arm write_hashes embedded Python not found")
embedded = arm[python_start + len("<<'PY'\n"):python_end]
tree = ast.parse(embedded, filename=f"{arm_path}:write_hashes")
emitted = None
for node in ast.walk(tree):
    if isinstance(node, ast.Dict):
        keys = [key.value for key in node.keys if isinstance(key, ast.Constant) and isinstance(key.value, str)]
        if "supervisor" in keys and "server_binary" in keys:
            emitted = set(keys)
            break
if not isinstance(emitted, set):
    raise SystemExit("arm emitted hash dictionary not found")

integration = validator_path.parent
self_gates = {
    "arm_validator": bound_self_gate(arm, "validator", integration / "validate-wan-below-tls-arm.py"),
    "arm_outcome_validator": bound_self_gate(arm, "arm_outcome_validator", integration / "validate-arm-outcome.py"),
    "arm_copy_validator": bound_self_gate(arm, "copy_record_validator", integration / "validate-copy-record.py"),
    "arm_sender_validator": bound_self_gate(arm, "sender_snapshot_validator", integration / "validate-sender-wait-snapshot.py"),
    "arm_raw_validator": bound_self_gate(arm, "raw_write_validator", integration / "validate-raw-write-activity.py"),
    "arm_growth_validator": bound_self_gate(arm, "server_growth_validator", integration / "validate-server-receive-growth.py"),
    "arm_byte_credit_validator": bound_self_gate(arm, "byte_credit_validator", integration / "validate-byte-credit-recycle.py"),
    "arm_tcp_state_validator": bound_self_gate(arm, "tcp_state_validator", integration / "validate-tcp-state.py"),
    "arm_closure_validator": bound_self_gate(arm, "raw_closure_validator", integration / "validate-post-join-raw-closure.py"),
    "coordinator_arm_validator": bound_self_gate(coordinator, "validator", integration / "validate-wan-below-tls-arm.py"),
    "coordinator_outcome_validator": bound_self_gate(coordinator, "arm_outcome_validator", integration / "validate-arm-outcome.py"),
    "coordinator_copy_validator": bound_self_gate(coordinator, "copy_record_validator", integration / "validate-copy-record.py"),
    "coordinator_sender_validator": bound_self_gate(coordinator, "snapshot_validator", integration / "validate-sender-wait-snapshot.py"),
    "coordinator_raw_validator": bound_self_gate(coordinator, "raw_write_validator", integration / "validate-raw-write-activity.py"),
    "coordinator_growth_validator": bound_self_gate(coordinator, "server_growth_validator", integration / "validate-server-receive-growth.py"),
    "coordinator_byte_credit_validator": bound_self_gate(coordinator, "byte_credit_validator", integration / "validate-byte-credit-recycle.py"),
    "coordinator_tcp_state_validator": bound_self_gate(coordinator, "tcp_state_validator", integration / "validate-tcp-state.py"),
    "coordinator_closure_validator": bound_self_gate(coordinator, "raw_closure_validator", integration / "validate-post-join-raw-closure.py"),
    "coordinator_continuation_validator": bound_self_gate(coordinator, "continuation_validator", integration / "validate-h1-continuation.py"),
}
pending_byte_credit = "PENDING_" + "BYTE_CREDIT_"

checks = {
    "all_runtime_self_gates_match_materialized_files": all(self_gates.values()),
    "arm_hash_keys_equal_validator_keys": emitted == required,
    "accepted_proof_receipt_exactly_bound": arm.count("b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d") == 1
                                              and coordinator.count("b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d") == 1
                                              and "PENDING_RAW_ORDINARY_PROOF_RECEIPT_SHA256" not in arm + coordinator,
    "accepted_byte_credit_proof_receipt_exactly_bound": arm.count("6562b975ba8f25d1b7a1a83c323c4c289f62f97b5508421e9e0f2e244c940460") == 1
                                              and coordinator.count("6562b975ba8f25d1b7a1a83c323c4c289f62f97b5508421e9e0f2e244c940460") == 1
                                              and pending_byte_credit + "ORDINARY_PROOF_RECEIPT_SHA256" not in arm + coordinator,
    "accepted_build_receipt_exactly_bound": arm.count("dae7e3e7e58cd829804b07aea9b063aa6d0233552ae0068d9c38725bed427f13") == 1
                                              and coordinator.count("dae7e3e7e58cd829804b07aea9b063aa6d0233552ae0068d9c38725bed427f13") == 1
                                              and "PENDING_COMBINED_BUILD_RECEIPT_SHA256" not in arm + coordinator,
    "base_build_ancestry_exactly_bound": arm.count("bcca6079b5de32635701b4a1d5195cd9b9f9e8976d76e48956cea7d396cb7b97") == 1
                                              and coordinator.count("bcca6079b5de32635701b4a1d5195cd9b9f9e8976d76e48956cea7d396cb7b97") == 1
                                              and '.base_build_receipt_sha256 == "bcca6079b5de32635701b4a1d5195cd9b9f9e8976d76e48956cea7d396cb7b97"' in arm
                                              and '.base_build_receipt_sha256 == "bcca6079b5de32635701b4a1d5195cd9b9f9e8976d76e48956cea7d396cb7b97"' in coordinator,
    "threshold_history_evidence_exactly_bound": all(value in arm and value in coordinator for value in (
        "3f1e9e54d979ba52680b5b16e761df188f9846d3add75a4d7a2a7f1617ccf0b9",
        "4d74567dcc24618dd841265e8dcbcdb378e63b9e59d25bfcb77e16740af49bdd",
        "229a585ca3365ff06223043afcad608fc831fd9958f5f721386285a6c9ee7b1d",
        "5d115157591391a7ff29fef0795d698de91a7e349fd5690155d15fdf44d3efcb",
        "37c184eeffed66424f13dee384d0d0e31856c40892220c59d060308c46da7dc2",
        "058b0c7b912fe506867262f09f87f4d015ea2049acd3c51ede3d3e7dd8c23dac",
        "fff73fb6e841714e3677c5b694afdfee2f7df7ebc9c64aff1ecb0abc1255040b")),
    "receipts_use_canonical_published_paths": 'raw_ordinary_proof_receipt="$combined_root/provenance/raw-ordinary-proof-receipt.json"' in arm
                                              and 'byte_credit_ordinary_proof_receipt="$combined_root/provenance/byte-credit-ordinary-proof-receipt.json"' in arm
                                              and 'combined_build_receipt="$combined_root/provenance/audited-combined-build-receipt.json"' in arm
                                              and 'raw_ordinary_proof_receipt="$combined_root/provenance/raw-ordinary-proof-receipt.json"' in coordinator
                                              and 'byte_credit_ordinary_proof_receipt="$combined_root/provenance/byte-credit-ordinary-proof-receipt.json"' in coordinator
                                              and 'combined_build_receipt="$combined_root/provenance/audited-combined-build-receipt.json"' in coordinator,
    "no_internal_final_manifest_cycle": "expected_final_reviewed_manifest" not in arm + coordinator
                                         and "final_reviewed_manifest" not in arm + coordinator,
    "coordinator_executes_continuation_validator": bool(re.search(
        r'python3 -I -B "\$continuation_validator"[\s\\]+"\$output_dir/h1/supervisor-lifecycle.json"', coordinator)),
    "coordinator_does_not_gate_h2_on_arm_accepted": ".accepted == true and .raw_write_final_closure_valid" not in coordinator,
    "historical_cp10_verifier_scoped_to_mature_root": bool(re.search(
        r'"\$reviewed_integration_verifier" "\$reviewed_integration_manifest" "\$mature_sender_root"', coordinator)),
    "timed_runner_hash_bound": "a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad" in arm
                               and "a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad" in coordinator,
}
result = {
    "schema_version": 1,
    "accepted": all(checks.values()),
    "checks": checks,
    "required_hash_key_count": len(required),
    "emitted_hash_key_count": len(emitted),
    "missing_from_arm": sorted(required - emitted),
    "unexpected_from_arm": sorted(emitted - required),
    "check_count": len(checks),
    "self_gates": self_gates,
}
output_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
if not result["accepted"]:
    raise SystemExit("final source binding contract failed")
