//go:build linux && p2pstream_qualification

package agent

import (
	"errors"
	"io"
	"os"
	"syscall"
	"time"

	"github.com/hashicorp/yamux"
)

const qualificationTCPSlowStartAfterIdlePath = "/proc/sys/net/ipv4/tcp_slow_start_after_idle"

func qualificationReadTCPSlowStartAfterIdle() (int, error) {
	file, err := os.Open(qualificationTCPSlowStartAfterIdlePath)
	if err != nil {
		return 0, err
	}
	var value [3]byte
	n, readErr := file.Read(value[:])
	if readErr != nil && !errors.Is(readErr, io.EOF) {
		_ = file.Close()
		return 0, readErr
	}
	var extra [1]byte
	extraN, extraErr := file.Read(extra[:])
	if extraErr != nil && !errors.Is(extraErr, io.EOF) {
		_ = file.Close()
		return 0, extraErr
	}
	if err := file.Close(); err != nil {
		return 0, err
	}
	if extraN != 0 {
		return 0, errors.New("tcp_slow_start_after_idle exceeds its fixed input bound")
	}
	switch string(value[:n]) {
	case "0", "0\n":
		return 0, nil
	case "1", "1\n":
		return 1, nil
	default:
		return 0, errors.New("tcp_slow_start_after_idle is not exactly zero or one")
	}
}

type qualificationTCPStateOwner struct {
	raw                   syscall.RawConn
	bound                 bool
	bindTCPInfo           qualificationTCPInfoSnapshot
	lastLiveTCPInfo       qualificationTCPInfoSnapshot
	tcpSlowStartAfterIdle int
	monotonicOrigin       time.Time

	armed         bool
	transitioning bool
	sequence      string
	ambiguous     bool
	overflow      bool
	invalid       bool

	nextSampleID           uint64
	nextRecordID           uint64
	activeSamples          uint64
	pendingRawClaims       uint64
	activeRawPairs         uint64
	droppedWaitRecords     uint64
	droppedRawPairRecords  uint64
	captureCalls           uint64
	captureErrors          uint64
	captureDuration        qualificationRawWriteDuration
	preTCPInfo             qualificationTCPInfoSnapshot
	preTCPInfoErr          error
	postTCPInfo            qualificationTCPInfoSnapshot
	postTCPInfoErr         error
	waitCount              uint32
	waits                  [yamux.QualificationTCPStateRecordLimit]yamux.QualificationTCPWaitRecord
	rawPairCount           uint32
	rawPairs               [yamux.QualificationTCPStateRecordLimit]yamux.QualificationTCPRawPairRecord
	activeEnvelopeWaitSlot uint32
	activeEnvelopePairSlot uint32
	thresholdHistory       qualificationTCPThresholdHistoryOwner
}

type qualificationTCPRawReservation struct {
	raw        syscall.RawConn
	generation uint64
	pairSlot   uint32
	first      bool
}

func qualificationTCPSequenceValid(sequence string) bool {
	switch sequence {
	case "9", "11", "14", "15":
		return true
	default:
		return false
	}
}

func qualificationTCPRetryClassificationValid(classification string) bool {
	switch classification {
	case "applied_range", "pre_entry_buffered", "stale", "retry_zero_after_advance", "timeout", "shutdown":
		return true
	default:
		return false
	}
}

func qualificationTCPFailure(snapshot qualificationTCPInfoSnapshot, captureErr error) (string, int64) {
	if captureErr == nil {
		if snapshot.FailureStage != "" || snapshot.FailureErrno != 0 {
			return "provider_result_mismatch", 0
		}
		return "", 0
	}
	if snapshot.FailureStage == "" {
		return "provider_error_without_stage", 0
	}
	return snapshot.FailureStage, snapshot.FailureErrno
}

func (owner *qualificationRawWriteOwner) tcpInfoPublicLocked(snapshot qualificationTCPInfoSnapshot, captureErr error) yamux.QualificationTCPInfoSnapshot {
	failureStage, failureErrno := qualificationTCPFailure(snapshot, captureErr)
	result := yamux.QualificationTCPInfoSnapshot{
		SchemaVersion: snapshot.SchemaVersion, Captured: snapshot.Captured,
		CaptureStartedUnixNS: snapshot.CaptureStartedUnixNS, CaptureFinishedUnixNS: snapshot.CaptureFinishedUnixNS,
		CaptureDurationNS: snapshot.CaptureDurationNS,
		TCPInfoAttempted:  snapshot.TCPInfoAttempted, TCPInfoSucceeded: snapshot.TCPInfoSucceeded,
		TCPInfoOptlen: snapshot.TCPInfoOptlen, TCPInfoStructSize: snapshot.TCPInfoStructSize,
		RequiredFieldEndOffset:     snapshot.RequiredFieldEndOffset,
		CongestionControlAttempted: snapshot.CongestionControlAttempted,
		CongestionControlSucceeded: snapshot.CongestionControlSucceeded,
		CongestionControlOptlen:    snapshot.CongestionControlOptlen, CongestionControl: snapshot.CongestionControl,
		FailureStage: failureStage, FailureErrno: failureErrno,
		Availability: yamux.QualificationTCPInfoAvailability{
			State: snapshot.Availability.State, CAState: snapshot.Availability.CAState,
			Retransmits: snapshot.Availability.Retransmits, RTO: snapshot.Availability.RTO,
			SendMSS: snapshot.Availability.SendMSS, Unacked: snapshot.Availability.Unacked,
			Lost: snapshot.Availability.Lost, Retrans: snapshot.Availability.Retrans,
			LastDataSent: snapshot.Availability.LastDataSent, RTT: snapshot.Availability.RTT,
			RTTVariance:            snapshot.Availability.RTTVariance,
			SendSlowStartThreshold: snapshot.Availability.SendSlowStartThreshold,
			SendCongestionWindow:   snapshot.Availability.SendCongestionWnd,
			TotalRetrans:           snapshot.Availability.TotalRetrans, PacingRate: snapshot.Availability.PacingRate,
			BytesAcked: snapshot.Availability.BytesAcked, NotSentBytes: snapshot.Availability.NotSentBytes,
			DeliveryRate: snapshot.Availability.DeliveryRate, BytesSent: snapshot.Availability.BytesSent,
			BytesRetransmitted: snapshot.Availability.BytesRetransmitted,
			SendWindow:         snapshot.Availability.SendWindow, TotalRTO: snapshot.Availability.TotalRTO,
			TotalRTORecoveries: snapshot.Availability.TotalRTORecoveries,
			TotalRTOTime:       snapshot.Availability.TotalRTOTime,
		},
		State: snapshot.State, CAState: snapshot.CAState, Retransmits: snapshot.Retransmits,
		RTOUsec: snapshot.RTOUsec, SendMSS: snapshot.SendMSS, Unacked: snapshot.Unacked,
		Lost: snapshot.Lost, Retrans: snapshot.Retrans, LastDataSentMS: snapshot.LastDataSentMS,
		RTTUsec: snapshot.RTTUsec, RTTVarianceUsec: snapshot.RTTVarianceUsec,
		SendSlowStartThreshold: snapshot.SendSlowStartThreshold,
		SendCongestionWindow:   snapshot.SendCongestionWindow, TotalRetrans: snapshot.TotalRetrans,
		PacingRateBytesPerSecond: snapshot.PacingRateBytesPerSecond, BytesAcked: snapshot.BytesAcked,
		NotSentBytes: snapshot.NotSentBytes, DeliveryRateBytesPerSecond: snapshot.DeliveryRateBytesPerSecond,
		BytesSent: snapshot.BytesSent, BytesRetransmitted: snapshot.BytesRetransmitted,
		SendWindowBytes: snapshot.SendWindowBytes, TotalRTO: snapshot.TotalRTO,
		TotalRTORecoveries: snapshot.TotalRTORecoveries, TotalRTOTimeMS: snapshot.TotalRTOTimeMS,
	}
	origin := owner.tcp.monotonicOrigin
	if !origin.IsZero() && !snapshot.captureStarted.IsZero() && !snapshot.captureFinished.IsZero() &&
		!snapshot.captureStarted.Before(origin) && !snapshot.captureFinished.Before(snapshot.captureStarted) {
		result.CaptureMonotonicValid = true
		result.CaptureStartedMonotonicNS = uint64(snapshot.captureStarted.Sub(origin))
		result.CaptureFinishedMonotonicNS = uint64(snapshot.captureFinished.Sub(origin))
	}
	return result
}

func (owner *qualificationRawWriteOwner) recordTCPCaptureLocked(snapshot qualificationTCPInfoSnapshot, captureErr error) {
	tcp := &owner.tcp
	tcp.captureCalls = qualificationRawAdd(tcp.captureCalls, 1, &tcp.overflow)
	tcp.captureDuration.add(time.Duration(snapshot.CaptureDurationNS), &tcp.overflow)
	if captureErr != nil || !snapshot.Captured {
		tcp.captureErrors = qualificationRawAdd(tcp.captureErrors, 1, &tcp.overflow)
		tcp.ambiguous = true
		tcp.invalid = true
		return
	}
	if tcp.bound && (snapshot.CongestionControl == "" || snapshot.CongestionControl != tcp.bindTCPInfo.CongestionControl) {
		tcp.ambiguous = true
		tcp.invalid = true
		return
	}
	if tcp.lastLiveTCPInfo.captureFinished.IsZero() || snapshot.captureFinished.After(tcp.lastLiveTCPInfo.captureFinished) {
		tcp.lastLiveTCPInfo = snapshot
	}
}

func (owner *qualificationRawWriteOwner) bindTCPState(raw syscall.RawConn, snapshot qualificationTCPInfoSnapshot, slowStartAfterIdle int) bool {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	if raw == nil || !snapshot.Captured || owner.tcp.bound || owner.tcp.raw != nil || (slowStartAfterIdle != 0 && slowStartAfterIdle != 1) {
		owner.tcp.ambiguous = true
		return false
	}
	owner.tcp.raw = raw
	owner.tcp.bound = true
	owner.tcp.bindTCPInfo = snapshot
	owner.tcp.lastLiveTCPInfo = snapshot
	owner.tcp.tcpSlowStartAfterIdle = slowStartAfterIdle
	owner.tcp.monotonicOrigin = snapshot.captureStarted
	owner.bindTCPThresholdHistoryLocked(snapshot)
	return true
}

func (owner *qualificationRawWriteOwner) armTCPInterval(sequence string) bool {
	owner.mu.Lock()
	tcp := &owner.tcp
	if !qualificationTCPSequenceValid(sequence) || !tcp.bound || tcp.raw == nil || owner.closeStarted || owner.closeObserved || owner.sessionJoined ||
		tcp.armed || tcp.transitioning || tcp.waitCount != 0 || tcp.rawPairCount != 0 || tcp.activeSamples != 0 ||
		tcp.pendingRawClaims != 0 || tcp.activeRawPairs != 0 || tcp.ambiguous || tcp.overflow || tcp.invalid {
		tcp.ambiguous = true
		tcp.invalid = true
		owner.mu.Unlock()
		return false
	}
	tcp.transitioning = true
	raw := tcp.raw
	generation := owner.generation
	owner.mu.Unlock()

	snapshot, captureErr := qualificationCaptureTCPInfo(raw)

	owner.mu.Lock()
	defer owner.mu.Unlock()
	tcp = &owner.tcp
	tcp.transitioning = false
	tcp.preTCPInfo = snapshot
	tcp.preTCPInfoErr = captureErr
	owner.recordTCPCaptureLocked(snapshot, captureErr)
	if captureErr != nil || !snapshot.Captured || owner.generation != generation || tcp.raw != raw || owner.closeStarted || owner.closeObserved || owner.sessionJoined || tcp.armed {
		tcp.ambiguous = true
		tcp.invalid = true
		return false
	}
	if snapshot.CongestionControl != tcp.bindTCPInfo.CongestionControl {
		tcp.ambiguous = true
		tcp.invalid = true
		return false
	}
	owner.compareTCPThresholdHistorySelectedPreLocked(sequence, snapshot, captureErr)
	tcp.armed = true
	tcp.sequence = sequence
	return true
}

func (owner *qualificationRawWriteOwner) disarmTCPInterval(sequence string) bool {
	owner.mu.Lock()
	tcp := &owner.tcp
	if !qualificationTCPSequenceValid(sequence) || !tcp.bound || tcp.raw == nil || !tcp.armed || tcp.sequence != sequence ||
		owner.closeStarted || owner.closeObserved || owner.sessionJoined || tcp.transitioning || owner.activeEnvelope || owner.activeRawWrites != 0 || tcp.activeSamples != 0 ||
		tcp.pendingRawClaims != 0 || tcp.activeRawPairs != 0 || tcp.activeEnvelopeWaitSlot != 0 ||
		tcp.activeEnvelopePairSlot != 0 || tcp.ambiguous || tcp.overflow || tcp.invalid || tcp.captureErrors != 0 ||
		tcp.droppedWaitRecords != 0 || tcp.droppedRawPairRecords != 0 {
		tcp.ambiguous = true
		tcp.invalid = true
		owner.mu.Unlock()
		return false
	}
	tcp.transitioning = true
	raw := tcp.raw
	generation := owner.generation
	owner.mu.Unlock()

	snapshot, captureErr := qualificationCaptureTCPInfo(raw)

	owner.mu.Lock()
	defer owner.mu.Unlock()
	tcp = &owner.tcp
	tcp.transitioning = false
	tcp.armed = false
	tcp.postTCPInfo = snapshot
	tcp.postTCPInfoErr = captureErr
	owner.recordTCPCaptureLocked(snapshot, captureErr)
	valid := captureErr == nil && snapshot.Captured && owner.generation == generation && tcp.raw == raw &&
		!owner.closeStarted && !owner.closeObserved && !owner.sessionJoined &&
		snapshot.CongestionControl == tcp.bindTCPInfo.CongestionControl && !tcp.invalid && !tcp.ambiguous && !tcp.overflow &&
		tcp.captureErrors == 0 && tcp.droppedWaitRecords == 0 && tcp.droppedRawPairRecords == 0 &&
		tcp.pendingRawClaims == 0 && tcp.activeRawPairs == 0 &&
		owner.tcpRecordsHealthyLocked()
	if !valid {
		tcp.ambiguous = true
		tcp.invalid = true
		return false
	}
	return true
}

func (owner *qualificationRawWriteOwner) beginTCPWaitSample(kind string, streamID uint32, waitToken uint64, classification string, ordinal, cumulative uint64, credit uint32, observed time.Time) uint64 {
	owner.mu.Lock()
	tcp := &owner.tcp
	if !tcp.armed {
		owner.mu.Unlock()
		return 0
	}
	if owner.closeStarted || owner.closeObserved || owner.sessionJoined || tcp.transitioning || observed.IsZero() || streamID == 0 || waitToken == 0 ||
		(kind != "entry" && kind != "retry") || (kind == "entry" && classification != "pending") ||
		(kind == "retry" && !qualificationTCPRetryClassificationValid(classification)) {
		tcp.ambiguous = true
		tcp.invalid = true
		owner.mu.Unlock()
		return 0
	}
	var record *yamux.QualificationTCPWaitRecord
	if kind == "entry" {
		for i := uint32(0); i < tcp.waitCount; i++ {
			if tcp.waits[i].StreamID == streamID && tcp.waits[i].WaitToken == waitToken {
				tcp.waits[i].Ambiguous = true
				tcp.ambiguous = true
				owner.mu.Unlock()
				return 0
			}
		}
		if tcp.waitCount >= uint32(len(tcp.waits)) {
			tcp.overflow = true
			tcp.droppedWaitRecords = qualificationRawAdd(tcp.droppedWaitRecords, 1, &tcp.overflow)
			owner.mu.Unlock()
			return 0
		}
		tcp.nextRecordID = qualificationRawAdd(tcp.nextRecordID, 1, &tcp.overflow)
		if tcp.nextRecordID == 0 {
			tcp.ambiguous = true
			owner.mu.Unlock()
			return 0
		}
		record = &tcp.waits[tcp.waitCount]
		*record = yamux.QualificationTCPWaitRecord{RecordID: tcp.nextRecordID, StreamID: streamID, WaitToken: waitToken, Active: true}
		tcp.waitCount++
	} else {
		for i := uint32(0); i < tcp.waitCount; i++ {
			candidate := &tcp.waits[i]
			if candidate.StreamID == streamID && candidate.WaitToken == waitToken {
				if record != nil {
					candidate.Ambiguous = true
					record.Ambiguous = true
					tcp.ambiguous = true
					owner.mu.Unlock()
					return 0
				}
				record = candidate
			}
		}
		if record == nil || !record.Entry.Complete || record.Retry.Present || !record.Active {
			if record != nil {
				record.Ambiguous = true
			}
			tcp.ambiguous = true
			owner.mu.Unlock()
			return 0
		}
	}
	var sample *yamux.QualificationTCPStateSample
	if kind == "entry" {
		sample = &record.Entry
	} else {
		sample = &record.Retry
	}
	tcp.nextSampleID = qualificationRawAdd(tcp.nextSampleID, 1, &tcp.overflow)
	if tcp.nextSampleID == 0 {
		record.Ambiguous = true
		tcp.ambiguous = true
		owner.mu.Unlock()
		return 0
	}
	*sample = yamux.QualificationTCPStateSample{
		Present: true, SampleID: tcp.nextSampleID, Kind: kind, Classification: classification,
		Credit: credit, ObservedUnixNS: observed.UnixNano(), CursorBeforeOrdinal: ordinal,
		CursorBeforeCumulative: cumulative,
	}
	if !tcp.monotonicOrigin.IsZero() && !observed.Before(tcp.monotonicOrigin) {
		sample.ObservedMonotonicValid = true
		sample.ObservedMonotonicNS = uint64(observed.Sub(tcp.monotonicOrigin))
	}
	tcp.activeSamples = qualificationRawAdd(tcp.activeSamples, 1, &tcp.overflow)
	raw := tcp.raw
	generation := owner.generation
	sampleID := sample.SampleID
	owner.mu.Unlock()

	snapshot, captureErr := qualificationCaptureTCPInfo(raw)

	owner.mu.Lock()
	defer owner.mu.Unlock()
	tcp = &owner.tcp
	owner.recordTCPCaptureLocked(snapshot, captureErr)
	found := owner.tcpSampleLocked(sampleID)
	if found == nil || owner.generation != generation || tcp.raw != raw || owner.closeStarted || owner.closeObserved || owner.sessionJoined {
		tcp.ambiguous = true
		return sampleID
	}
	found.TCPInfo = owner.tcpInfoPublicLocked(snapshot, captureErr)
	found.CaptureError = captureErr != nil || !snapshot.Captured
	if found.CaptureError {
		record.Ambiguous = true
	}
	return sampleID
}

func (owner *qualificationRawWriteOwner) tcpSampleLocked(sampleID uint64) *yamux.QualificationTCPStateSample {
	for i := uint32(0); i < owner.tcp.waitCount; i++ {
		if owner.tcp.waits[i].Entry.SampleID == sampleID {
			return &owner.tcp.waits[i].Entry
		}
		if owner.tcp.waits[i].Retry.SampleID == sampleID {
			return &owner.tcp.waits[i].Retry
		}
	}
	return nil
}

func (owner *qualificationRawWriteOwner) finishTCPWaitSample(sampleID, ordinal, cumulative uint64, valid bool) {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	tcp := &owner.tcp
	var record *yamux.QualificationTCPWaitRecord
	var sample *yamux.QualificationTCPStateSample
	for i := uint32(0); i < tcp.waitCount; i++ {
		candidate := &tcp.waits[i]
		for _, current := range []*yamux.QualificationTCPStateSample{&candidate.Entry, &candidate.Retry} {
			if current.SampleID != sampleID {
				continue
			}
			if sample != nil {
				candidate.Ambiguous = true
				record.Ambiguous = true
				tcp.ambiguous = true
				return
			}
			record, sample = candidate, current
		}
	}
	if record == nil || sample == nil || sample.Complete || !sample.Present {
		tcp.ambiguous = true
		return
	}
	sample.CursorAfterValid = valid
	sample.CursorAfterOrdinal = ordinal
	sample.CursorAfterCumulative = cumulative
	sample.CursorChanged = ordinal != sample.CursorBeforeOrdinal || cumulative != sample.CursorBeforeCumulative
	sample.Complete = true
	if !valid {
		record.Ambiguous = true
		tcp.ambiguous = true
		tcp.invalid = true
	}
	if tcp.activeSamples == 0 {
		tcp.ambiguous = true
	} else {
		tcp.activeSamples--
	}
	if sample.Kind != "retry" {
		return
	}
	if sample.Classification == "retry_zero_after_advance" || (sample.Classification == "applied_range" && sample.Credit == 0) {
		record.Ambiguous = true
		tcp.ambiguous = true
		tcp.invalid = true
		record.Active = false
		return
	}
	if sample.Classification == "applied_range" && sample.Credit > 0 && !sample.CaptureError {
		for i := uint32(0); i < tcp.waitCount; i++ {
			other := &tcp.waits[i]
			if other != record && other.StreamID == record.StreamID && other.PendingRaw {
				other.Ambiguous = true
				record.Ambiguous = true
				tcp.ambiguous = true
				record.Active = false
				return
			}
		}
		record.PendingRaw = true
		tcp.pendingRawClaims = qualificationRawAdd(tcp.pendingRawClaims, 1, &tcp.overflow)
		return
	}
	record.Active = false
}

func (owner *qualificationRawWriteOwner) markTCPInterveningAllocation(streamID uint32, waitToken uint64) {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	if !owner.tcp.armed {
		return
	}
	found := false
	for i := uint32(0); i < owner.tcp.waitCount; i++ {
		record := &owner.tcp.waits[i]
		if record.StreamID == streamID && record.WaitToken == waitToken && record.PendingRaw {
			if found {
				record.Ambiguous = true
				owner.tcp.ambiguous = true
				return
			}
			record.InterveningAllocation = true
			found = true
		}
	}
	if !found {
		owner.tcp.ambiguous = true
	}
}

func (owner *qualificationRawWriteOwner) beginTCPEnvelopeLocked(streamID uint32, envelopeToken uint64) {
	tcp := &owner.tcp
	if !tcp.armed {
		return
	}
	var slot uint32
	for i := uint32(0); i < tcp.waitCount; i++ {
		record := &tcp.waits[i]
		if !record.PendingRaw || record.StreamID != streamID {
			continue
		}
		if slot != 0 {
			record.Ambiguous = true
			tcp.waits[slot-1].Ambiguous = true
			tcp.ambiguous = true
			return
		}
		slot = i + 1
	}
	if slot == 0 {
		return
	}
	record := &tcp.waits[slot-1]
	record.PendingRaw = false
	record.Claimed = true
	if tcp.pendingRawClaims == 0 {
		tcp.ambiguous = true
	} else {
		tcp.pendingRawClaims--
	}
	tcp.activeEnvelopeWaitSlot = slot
	_ = envelopeToken
}

func (owner *qualificationRawWriteOwner) reserveTCPRawPairLocked() qualificationTCPRawReservation {
	tcp := &owner.tcp
	if !tcp.armed || tcp.activeEnvelopeWaitSlot == 0 {
		return qualificationTCPRawReservation{}
	}
	if tcp.activeEnvelopePairSlot != 0 {
		return qualificationTCPRawReservation{generation: owner.generation, pairSlot: tcp.activeEnvelopePairSlot}
	}
	if tcp.rawPairCount >= uint32(len(tcp.rawPairs)) {
		tcp.overflow = true
		tcp.droppedRawPairRecords = qualificationRawAdd(tcp.droppedRawPairRecords, 1, &tcp.overflow)
		return qualificationTCPRawReservation{}
	}
	wait := &tcp.waits[tcp.activeEnvelopeWaitSlot-1]
	tcp.nextRecordID = qualificationRawAdd(tcp.nextRecordID, 1, &tcp.overflow)
	if tcp.nextRecordID == 0 {
		tcp.ambiguous = true
		return qualificationTCPRawReservation{}
	}
	pair := &tcp.rawPairs[tcp.rawPairCount]
	*pair = yamux.QualificationTCPRawPairRecord{
		RecordID: tcp.nextRecordID, WaitRecordID: wait.RecordID, StreamID: wait.StreamID,
		WaitToken: wait.WaitToken, EnvelopeToken: owner.activeEnvelopeToken, Active: true,
	}
	tcp.rawPairCount++
	tcp.activeRawPairs = qualificationRawAdd(tcp.activeRawPairs, 1, &tcp.overflow)
	tcp.activeEnvelopePairSlot = tcp.rawPairCount
	return qualificationTCPRawReservation{raw: tcp.raw, generation: owner.generation, pairSlot: tcp.rawPairCount, first: true}
}

func (owner *qualificationRawWriteOwner) finishTCPRawWriteLocked(begin qualificationRawWriteBegin, class qualificationRawWriteClass, finished time.Time, before qualificationTCPInfoSnapshot, beforeErr error, after qualificationTCPInfoSnapshot, afterErr error, beforeProviderInvoked, afterProviderInvoked bool) {
	reservation := begin.tcp
	if reservation.pairSlot == 0 || reservation.pairSlot > owner.tcp.rawPairCount {
		return
	}
	pair := &owner.tcp.rawPairs[reservation.pairSlot-1]
	if !reservation.first {
		if class == qualificationRawWriteContained && pair.Committed {
			pair.AdditionalContainedRawWrites = qualificationRawAdd(pair.AdditionalContainedRawWrites, 1, &owner.tcp.overflow)
		} else {
			pair.Ambiguous = true
			owner.tcp.ambiguous = true
			owner.tcp.invalid = true
		}
		return
	}
	if beforeProviderInvoked {
		owner.recordTCPCaptureLocked(before, beforeErr)
	}
	if afterProviderInvoked {
		owner.recordTCPCaptureLocked(after, afterErr)
	}
	if !beforeProviderInvoked || !afterProviderInvoked {
		owner.tcp.ambiguous = true
		owner.tcp.invalid = true
	}
	if owner.tcp.activeRawPairs == 0 {
		owner.tcp.ambiguous = true
	} else {
		owner.tcp.activeRawPairs--
	}
	pair.Active = false
	pair.Before = owner.tcpInfoPublicLocked(before, beforeErr)
	pair.After = owner.tcpInfoPublicLocked(after, afterErr)
	pair.BeforeCaptureError = beforeErr != nil || !before.Captured
	pair.AfterCaptureError = afterErr != nil || !after.Captured
	pair.RawWriteStartedUnixNS = begin.started.UnixNano()
	pair.RawWriteFinishedUnixNS = finished.UnixNano()
	if !owner.tcp.monotonicOrigin.IsZero() && !begin.started.Before(owner.tcp.monotonicOrigin) && !finished.Before(begin.started) {
		pair.RawWriteMonotonicValid = true
		pair.RawWriteStartedMonotonicNS = uint64(begin.started.Sub(owner.tcp.monotonicOrigin))
		pair.RawWriteFinishedMonotonicNS = uint64(finished.Sub(owner.tcp.monotonicOrigin))
	}
	pair.BracketValid = !pair.BeforeCaptureError && !pair.AfterCaptureError &&
		!before.captureFinished.After(begin.started) && !finished.After(after.captureStarted) && pair.RawWriteMonotonicValid
	valid := class == qualificationRawWriteContained && pair.BracketValid && reservation.generation == owner.generation &&
		owner.activeEnvelope && pair.EnvelopeToken == owner.activeEnvelopeToken && reservation.raw == owner.tcp.raw
	pair.Committed = valid
	pair.Ambiguous = !valid
	if owner.tcp.activeEnvelopeWaitSlot == 0 || owner.tcp.activeEnvelopeWaitSlot > owner.tcp.waitCount {
		owner.tcp.ambiguous = true
		return
	}
	wait := &owner.tcp.waits[owner.tcp.activeEnvelopeWaitSlot-1]
	wait.RawPairRecordID = pair.RecordID
	wait.Claimed = false
	wait.Active = false
	if !valid {
		wait.Ambiguous = true
		owner.tcp.ambiguous = true
	}
}

func (owner *qualificationRawWriteOwner) finishTCPEnvelopeLocked() {
	tcp := &owner.tcp
	if tcp.activeEnvelopeWaitSlot == 0 {
		return
	}
	wait := &tcp.waits[tcp.activeEnvelopeWaitSlot-1]
	if tcp.activeEnvelopePairSlot == 0 || wait.RawPairRecordID == 0 || wait.Claimed || wait.Active {
		wait.Ambiguous = true
		tcp.ambiguous = true
	}
	tcp.activeEnvelopeWaitSlot = 0
	tcp.activeEnvelopePairSlot = 0
}

func (owner *qualificationRawWriteOwner) drainTCPStateLocked(outerComplete bool) yamux.QualificationTCPStateActivity {
	tcp := &owner.tcp
	if tcp.ambiguous || tcp.overflow || tcp.captureErrors != 0 || !owner.tcpRecordsHealthyLocked() {
		tcp.invalid = true
	}
	complete := outerComplete && !tcp.armed && !tcp.transitioning && tcp.activeSamples == 0 && tcp.pendingRawClaims == 0 &&
		tcp.activeRawPairs == 0 && tcp.activeEnvelopeWaitSlot == 0 && tcp.activeEnvelopePairSlot == 0 && !tcp.invalid
	result := yamux.QualificationTCPStateActivity{
		SchemaVersion: yamux.QualificationTCPStateSchemaVersion, Enabled: true, Bound: tcp.bound,
		Armed: tcp.armed, Sequence: tcp.sequence, Complete: complete, ResetPerformed: complete, Invalid: tcp.invalid,
		Ambiguous: tcp.ambiguous, Overflow: tcp.overflow, TCPSlowStartAfterIdle: tcp.tcpSlowStartAfterIdle,
		ActiveSamples: tcp.activeSamples, PendingRawClaims: tcp.pendingRawClaims, ActiveRawPairs: tcp.activeRawPairs,
		DroppedWaitRecords: tcp.droppedWaitRecords, DroppedRawPairRecords: tcp.droppedRawPairRecords,
		CaptureCalls: tcp.captureCalls, CaptureErrors: tcp.captureErrors,
		CaptureDuration: qualificationRawDurationSnapshot(tcp.captureDuration),
		BindTCPInfo:     owner.tcpInfoPublicLocked(tcp.bindTCPInfo, nil), LastLiveTCPInfo: owner.tcpInfoPublicLocked(tcp.lastLiveTCPInfo, nil),
		PreTCPInfo:       owner.tcpInfoPublicLocked(tcp.preTCPInfo, tcp.preTCPInfoErr),
		PostTCPInfo:      owner.tcpInfoPublicLocked(tcp.postTCPInfo, tcp.postTCPInfoErr),
		WaitRecords:      make([]yamux.QualificationTCPWaitRecord, tcp.waitCount),
		RawPairs:         make([]yamux.QualificationTCPRawPairRecord, tcp.rawPairCount),
		ThresholdHistory: owner.tcpThresholdHistoryPublicLocked(),
	}
	copy(result.WaitRecords, tcp.waits[:tcp.waitCount])
	copy(result.RawPairs, tcp.rawPairs[:tcp.rawPairCount])
	if complete {
		raw, bound, bind, last, slow, origin, history := tcp.raw, tcp.bound, tcp.bindTCPInfo, tcp.lastLiveTCPInfo, tcp.tcpSlowStartAfterIdle, tcp.monotonicOrigin, tcp.thresholdHistory
		*tcp = qualificationTCPStateOwner{raw: raw, bound: bound, bindTCPInfo: bind, lastLiveTCPInfo: last, tcpSlowStartAfterIdle: slow, monotonicOrigin: origin, thresholdHistory: history}
	}
	return result
}

func (owner *qualificationRawWriteOwner) tcpRecordsHealthyLocked() bool {
	tcp := &owner.tcp
	appliedRecords := uint32(0)
	for i := uint32(0); i < tcp.waitCount; i++ {
		record := &tcp.waits[i]
		if record.Ambiguous || record.Active || record.PendingRaw || record.Claimed ||
			!record.Entry.Present || !record.Entry.Complete || record.Entry.CaptureError ||
			!record.Entry.ObservedMonotonicValid || !record.Entry.TCPInfo.CaptureMonotonicValid || record.Entry.Kind != "entry" ||
			record.Entry.Classification != "pending" || !record.Entry.CursorAfterValid ||
			!record.Retry.Present || !record.Retry.Complete || record.Retry.CaptureError ||
			!record.Retry.ObservedMonotonicValid || !record.Retry.TCPInfo.CaptureMonotonicValid || record.Retry.Kind != "retry" ||
			!record.Retry.CursorAfterValid || !qualificationTCPRetryClassificationValid(record.Retry.Classification) {
			return false
		}
		if record.Retry.Classification == "applied_range" {
			if record.Retry.Credit == 0 || record.RawPairRecordID == 0 {
				return false
			}
			appliedRecords++
		} else if record.RawPairRecordID != 0 {
			return false
		}
	}
	if appliedRecords != tcp.rawPairCount {
		return false
	}
	for i := uint32(0); i < tcp.rawPairCount; i++ {
		pair := &tcp.rawPairs[i]
		if pair.Active || pair.Ambiguous || !pair.Committed || pair.BeforeCaptureError || pair.AfterCaptureError || !pair.BracketValid ||
			!pair.RawWriteMonotonicValid || !pair.Before.CaptureMonotonicValid || !pair.After.CaptureMonotonicValid {
			return false
		}
		matches := 0
		for j := uint32(0); j < tcp.waitCount; j++ {
			wait := &tcp.waits[j]
			if wait.RecordID == pair.WaitRecordID && wait.RawPairRecordID == pair.RecordID &&
				wait.StreamID == pair.StreamID && wait.WaitToken == pair.WaitToken {
				matches++
			}
		}
		if matches != 1 {
			return false
		}
	}
	return true
}

func (body *qualificationObservedTunnelBody) ArmQualificationTCPInterval(sequence string) bool {
	return body != nil && body.owner != nil && body.owner.armTCPInterval(sequence)
}

func (body *qualificationObservedTunnelBody) DisarmQualificationTCPInterval(sequence string) bool {
	return body != nil && body.owner != nil && body.owner.disarmTCPInterval(sequence)
}

func (body *qualificationObservedTunnelBody) BeginQualificationTCPWaitSample(kind string, streamID uint32, waitToken uint64, classification string, ordinal, cumulative uint64, credit uint32, observed time.Time) uint64 {
	if body == nil || body.owner == nil {
		return 0
	}
	return body.owner.beginTCPWaitSample(kind, streamID, waitToken, classification, ordinal, cumulative, credit, observed)
}

func (body *qualificationObservedTunnelBody) FinishQualificationTCPWaitSample(sampleID, ordinal, cumulative uint64, valid bool) {
	if body != nil && body.owner != nil {
		body.owner.finishTCPWaitSample(sampleID, ordinal, cumulative, valid)
	}
}

func (body *qualificationObservedTunnelBody) MarkQualificationTCPInterveningAllocation(streamID uint32, waitToken uint64) {
	if body != nil && body.owner != nil {
		body.owner.markTCPInterveningAllocation(streamID, waitToken)
	}
}
