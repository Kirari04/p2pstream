# TCP threshold-history integration runner source checkpoint 1

This source-only checkpoint extends the accepted TCP-state integration corpus with strict threshold-history structural validation and separately reported explanation availability. It binds the accepted producer checkpoint, audited build, and 68-case offline validator contract while retaining every mature raw-write, byte-credit, TCP-state, lifecycle, TLS, protocol, and performance gate.

The materialized corpus contains exactly 38 allowlisted files. The generated workload runner and timed `run_transfer` body are byte-identical to the accepted predecessor. The authenticated response remains bounded at 4 MiB and fails closed on overflow; no truncation or enlarged transport is introduced.

No endpoint or WAN traffic was executed to create this checkpoint.
