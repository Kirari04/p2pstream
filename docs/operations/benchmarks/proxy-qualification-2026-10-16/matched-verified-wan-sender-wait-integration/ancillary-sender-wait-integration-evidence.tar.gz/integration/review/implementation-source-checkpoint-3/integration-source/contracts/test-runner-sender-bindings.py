#!/usr/bin/env python3
"""No-endpoint source contract for validator and boundary bindings."""

from pathlib import Path
import sys

runner = Path(sys.argv[1]).read_text()

required_once = (
    "--sender-wait-validator) sender_wait_validator=$2; shift 2 ;;",
    "--sender-wait-validator-sha256) sender_wait_validator_sha256=$2; shift 2 ;;",
    "export P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256",
    "P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR=$(realpath \"$sender_wait_validator\")",
    "sender-wait validator changed across namespace re-exec",
    'python3 "$sender_wait_validator" --mode pre --pre "$prefix-pre-sender.json"',
    'measurement_start_valid=true',
    'python3 "$sender_wait_validator" --mode pair --pre "$prefix-pre-sender.json"',
    'python3 "$sender_wait_validator" --mode terminal --terminal "$sender_wait_control_dir/terminal-sender.json"',
    'validation_status:$validation_status',
)
for text in required_once:
    assert runner.count(text) == 1, (text, runner.count(text))

preserve = next(line for line in runner.splitlines() if "exec sudo -n --preserve-env=" in line)
assert "P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR," in preserve
assert "P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256," in preserve

transfer_start = runner.index('( trap - EXIT INT TERM ERR; set -Eeuo pipefail; run_transfer "$@" )')
assert runner.index('--mode pre --pre "$prefix-pre-sender.json"') < transfer_start
assert runner.index('--mode pair --pre "$prefix-pre-sender.json"') > transfer_start

assert 'run_transfer "$@"' in runner
assert "read_wait_trace_dir=" not in runner
