#!/usr/bin/env python3
from pathlib import Path
import sys

source, query_block, wrapper_block, destination = map(Path, sys.argv[1:])
s = source.read_text()
start = s.index('read_wait_trace_dir=${output%.jsonl}.read-wait-traces')
end = s.index('\n\npython3 - "$server_scope_control_dir/runner-owned-namespaces.json"', start)
variables = '''sender_wait_control_dir=${output%.jsonl}.sender-wait-controls
[[ ! -e $sender_wait_control_dir ]] || { echo "sender-wait artifact directory already exists" >&2; exit 2; }
mkdir -m 0700 "$sender_wait_control_dir"
sender_wait_bearer=$(openssl rand -hex 32)
sender_wait_sequences=9,11,14,15
sender_wait_records=${output%.jsonl}.sender-wait-records.jsonl
[[ ! -e $sender_wait_records ]] || { echo "sender-wait record already exists" >&2; exit 2; }
: > "$sender_wait_records"
sender_wait_validator=${P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR:?sender-wait validator is required}
[[ -f $sender_wait_validator ]] || { echo "sender-wait validator is unavailable" >&2; exit 2; }
((smoke_mode == 0)) || { echo "sender-wait diagnostic has only the fixed sustained sequence set" >&2; exit 2; }'''
s = s[:start] + variables + s[end:]
start = s.index('wan_read_wait_control() {')
end = s.index('cgroup_snapshot() {', start)
s = s[:start] + query_block.read_text() + s[end:]
start = s.index('wan_read_wait_should_trace() {')
end = s.index('run_tiny_response() {', start)
s = s[:start] + wrapper_block.read_text() + s[end:]
s = s.replace('run_maybe_traced_transfer ', 'run_maybe_sender_wait_transfer ')
old_server = '''\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE=1 \\
\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_DIR="$read_wait_trace_dir" \\
\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_SEQUENCES="$read_wait_trace_sequences" \\
\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_BEARER="$read_wait_trace_bearer" \\
'''
new_server = '''\t\tP2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT=1 \\
\t\tP2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_SEQUENCES="$sender_wait_sequences" \\
\t\tP2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_BEARER="$sender_wait_bearer" \\
'''
if s.count(old_server) != 1:
    raise SystemExit(f'server trace environment block count {s.count(old_server)}')
s = s.replace(old_server, new_server)
old_agent = '''      P2PSTREAM_QUALIFICATION_AGENT_TUNNELS=4 \\
      GOMAXPROCS=4 \\
'''
new_agent = '''      P2PSTREAM_QUALIFICATION_AGENT_TUNNELS=4 \\
      P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT=1 \\
      P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_SEQUENCES="$sender_wait_sequences" \\
      P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_BEARER="$sender_wait_bearer" \\
      GOMAXPROCS=4 \\
'''
if s.count(old_agent) != 2:
    raise SystemExit(f'agent environment block count {s.count(old_agent)}')
s = s.replace(old_agent, new_agent)
old_terminal = '''\tcgroup_snapshot "$server_pid" > "$server_scope_control_dir/server-cgroup-post-workload.json"
  stop_process "$label-$iteration-agent" "$agent_process_pid" "$agent_stop"
'''
new_terminal = '''\tlocal sender_terminal_status=0
\tset +e
\twan_sender_wait_query agent-drain terminal 15 "$agent_admin" "$sender_wait_control_dir/terminal-sender.json"
\tsender_terminal_status=$?
\tset -e
\tjq -cn --argjson status "$sender_terminal_status" --slurpfile terminal "$sender_wait_control_dir/terminal-sender.json" \\
\t\t'{schema_version:1,diagnostic:"sender-duration",action:"terminal",status:$status,response:($terminal[0] // null)}' \\
\t\t>> "$sender_wait_records"
\tcgroup_snapshot "$server_pid" > "$server_scope_control_dir/server-cgroup-post-workload.json"
  stop_process "$label-$iteration-agent" "$agent_process_pid" "$agent_stop"
'''
if s.count(old_terminal) != 1:
    raise SystemExit(f'terminal insertion point count {s.count(old_terminal)}')
s = s.replace(old_terminal, new_terminal)
destination.write_text(s)
