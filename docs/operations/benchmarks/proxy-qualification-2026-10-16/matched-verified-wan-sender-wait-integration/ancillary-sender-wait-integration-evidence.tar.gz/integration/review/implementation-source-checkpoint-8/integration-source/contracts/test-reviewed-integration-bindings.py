#!/usr/bin/env python3
"""Source contract for the non-self-referential reviewed-corpus binding."""

from pathlib import Path
import sys

if len(sys.argv) != 4:
    raise SystemExit("usage: test-reviewed-integration-bindings.py VERIFIER ARM COORDINATOR")

verifier, arm, coordinator = [Path(path).read_text() for path in sys.argv[1:]]
for required in (
    'manifest["checkpoint_manifest_path"] != "review/implementation-source-checkpoint-8/SHA256SUMS.txt"',
    'manifest["files"] != checkpoint_files',
    'active_sha != expected or frozen_sha != expected',
    'os.O_WRONLY | os.O_CREAT | os.O_EXCL',
):
    if required not in verifier:
        raise SystemExit(f"reviewed-corpus verifier gate missing: {required}")

for name, source in (("arm", arm), ("coordinator", coordinator)):
    for required in (
        'reviewed-integration-source-manifest-cp8.json',
        'implementation-source-checkpoint-8/SHA256SUMS.txt',
        'copy-validator-binding-harness-receipt.json',
        'reviewed_integration_source_manifest_sha256 == $reviewed_manifest',
        'verify-reviewed-integration-manifest.py',
    ):
        if required not in source:
            raise SystemExit(f"{name} reviewed-corpus binding missing: {required}")
    if 'sender_integration_checkpoint_sha256 == "39eac961' in source:
        raise SystemExit(f"{name} still claims checkpoint3 covers the final corpus")
