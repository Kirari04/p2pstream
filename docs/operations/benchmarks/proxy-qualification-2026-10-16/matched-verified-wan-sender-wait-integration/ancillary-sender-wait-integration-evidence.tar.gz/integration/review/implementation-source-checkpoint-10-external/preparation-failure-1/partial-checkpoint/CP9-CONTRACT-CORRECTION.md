# Checkpoint 9 contract correction

Checkpoint 8 is retained unchanged as the first complete source checkpoint for
the copy-record validator path/hash correction. Checkpoint 9 does not change
the generated runner, helper binding, workload, binaries, or endpoint behavior.
It corrects only the no-endpoint review contracts and their checkpoint path
bindings:

1. The sudo preservation check parses comma-separated environment variable
   names and checks exact tokens, so the digest variable does not count as a
   second occurrence of the path variable.
2. The reviewed-source contract checks the historical cp7 build-manifest
   binding and the separate current checkpoint-9 receipt binding explicitly.
3. The helper contract extracts the exact outer and inner binding blocks from
   the generated runner. Six bounded Bash subprocess cases exercise each block
   with a valid, missing, and byte-changed helper. A seventh case executes the
   outer block and the exact export/assignment lines before starting a child
   that executes the inner block, proving both values arrive unchanged. No
   namespace or endpoint is created.

The behavioral contract remains source-only and unexecuted in this checkpoint.
