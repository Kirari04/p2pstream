# Sender-duration integration source checkpoint 7

Source-only, unbuilt, and unexecuted. This checkpoint adds the complete narrow
sender-only arm supervisor, H1-then-H2 coordinator, final arm validator, fixed
small-diagnostic mode, and their no-endpoint contract sources. It does not
start, build, test, or authorize any endpoint.

The generated runner derives from the mature full-production runner. The timed
`run_transfer` is intended to remain byte-identical at 7,350 bytes and SHA-256
`b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798`;
the included static contract is unexecuted. Execution tracing, raw trace
capture, parser, stack interning, and reducer controls are absent. Upstream
HTTP transport trace and bounded response-copy evidence remain inherited.

The strict schema-2 validator now bounds every integer to uint64, the observed
stream ID to positive uint32, and each response to 4 MiB. It enforces bucket
total <= count*max and exact maximum/count/time conservation across exclusive
sub-buckets. Request/capture ordering uses explicit wall-clock start/finish
fields; monotonic request elapsed is retained without mixing clock domains.
It copies normalized rows rather than mutating input envelopes. The arm binds
records in exact order 9,11,14,15,terminal to the actual fixed transfer rows.
Each selected public-handler wall interval must also be enclosed by the
completed pre-control request and the started post-control request using exact
positive uint64 Unix timestamps. This is coarse common-host correlation only;
monotonic durations are not compared across observers and no cause is claimed.

The sustained mode remains 16 transfers per arm, 256 MiB warmup/steady,
three repetitions, 8 MiB pool, 80 ms RTT, and an independent 29.7 MB/s floor
for every download phase. The pre-sustained small mode retains the same 16
transfers and selected sequences, changes only payloads to 4 MiB and pool to
2 MiB, and labels its floor descriptive/non-gating; it is not a qualification
or performance result.

H2 starts only after raw H1 topology, server-scope resource, namespace, and
terminal sender-ledger closure gates prove no residual state. H1 floor or arm
acceptance failure remains preserved and nonzero but does not by itself claim
cleanup failure. Final acceptance still requires both exact arm statuses zero,
both arm attestations accepted, and identical pre/post inputs.

The launcher requires an external reviewed-corpus manifest whose file ledger
exactly equals this checkpoint's manifest and whose digests match both the
frozen checkpoint and the actual executable source tree. The audited build
manifest must bind that external manifest and this checkpoint hash, avoiding a
self-hash inside the frozen corpus.

Execution is blocked. Observer runtime source checkpoint 9 remains immutable;
its final proof evidence is bound separately. A future audited server+agent
build manifest must bind the reviewed integration corpus, observer validation,
the exact generated runner, snapshot validator, runner/control patches,
normal/race results, ordinary proof status zero, and both output binaries. No
such reviewed-corpus manifest, build manifest, or binaries exist here.
