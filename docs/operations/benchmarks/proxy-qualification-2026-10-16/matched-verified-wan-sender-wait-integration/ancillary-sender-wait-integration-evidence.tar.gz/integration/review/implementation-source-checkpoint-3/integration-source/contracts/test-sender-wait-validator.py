#!/usr/bin/env python3
"""Source-only focused contracts for the strict schema-2 validator."""

import copy
import importlib.util
from pathlib import Path
import sys

validator_path = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location("sender_wait_validator", validator_path)
validator = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(validator)


def zero_bucket():
    return {"count": 0, "total_nanoseconds": 0, "max_nanoseconds": 0}


def timing(enabled: bool):
    value = {key: False for key in validator.TIMING_BOOLS}
    value.update({key: 0 for key in validator.TIMING_INTS})
    value.update({key: zero_bucket() for key in validator.DURATION_TOTALS})
    value.update({group: {member: zero_bucket() for member in members}
                  for group, members in validator.OUTCOME_GROUPS.items()})
    value["complete"] = enabled
    value["reset_performed"] = enabled
    return value


def row(lane: int):
    enabled = lane != 0
    value = {
        "lane": lane, "session_identity": f"session-{lane}",
        "local_address": f"local-{lane}", "remote_address": f"remote-{lane}",
        "enabled": enabled, "timing": timing(enabled),
    }
    value.update({key: 0 for key in validator.COUNTER_SCALARS})
    return value


def envelope(action: str):
    return {
        "schema_version": 1, "role": "agent-drain", "action": action, "sequence": 9,
        "request_started_unix_ns": 1, "request_elapsed_ns": 1, "http_status": 200,
        "response_bytes": 1, "error": "", "authorization": "bearer-present",
        "response": {"schema_version": 2, "captured_unix_nano": 1, "capacity": 4096,
                     "dropped_events": 0, "events": [], "send_counters": [row(lane) for lane in validator.ALL_LANES]},
    }


def accepted_pre():
    value = envelope("pre")
    result = validator.validate_pre(value, 9)
    assert result["accepted"] and result["measurement_start_valid"]
    return value


def accepted_pair(pre):
    post = envelope("post")
    selected = post["response"]["send_counters"][1]
    selected.update({"reserved_data_frames": 1, "reserved_payload_bytes": 100,
                     "reserved_allocation_charged_bytes": 4096})
    current = selected["timing"]
    current.update({
        "stream_observed": True, "observed_stream_id": 7,
        "data_enqueued_frames": 1, "data_enqueued_payload_bytes": 100,
        "data_completed_frames": 1, "data_completed_payload_bytes": 100,
        "physical_attempt_frames": 1, "physical_attempt_payload_bytes": 100,
        "physical_attempt_wire_bytes": 112, "physical_written_wire_bytes": 112,
        "physical_success_frames": 1, "physical_success_payload_bytes": 100,
        "physical_success_wire_bytes": 112,
        "data_enqueue_select_total": {"count": 1, "total_nanoseconds": 4, "max_nanoseconds": 4},
        "data_completion_select_total": {"count": 1, "total_nanoseconds": 6, "max_nanoseconds": 6},
        "data_call_total": {"count": 1, "total_nanoseconds": 10, "max_nanoseconds": 10},
        "physical_write_total": {"count": 1, "total_nanoseconds": 5, "max_nanoseconds": 5},
    })
    current["data_enqueue_select_by_outcome"]["accepted"] = copy.deepcopy(current["data_enqueue_select_total"])
    current["data_completion_select_by_outcome"]["success"] = copy.deepcopy(current["data_completion_select_total"])
    current["data_call_by_outcome"]["success"] = copy.deepcopy(current["data_call_total"])
    current["physical_write_by_outcome"]["success"] = copy.deepcopy(current["physical_write_total"])
    result = validator.validate_pair(pre, post, 9)
    assert result["accepted"] and result["selected"]["stream_id"] == 7
    return post


pre = accepted_pre()
post = accepted_pair(pre)

case = copy.deepcopy(pre)
case["response"]["send_counters"][1]["timing"]["pending_credit_decision"] = True
assert not validator.validate_pre(case, 9)["accepted"]

case = copy.deepcopy(pre)
case["response"]["send_counters"][1]["timing"]["active_caller_frames"] = True
assert not validator.validate_pre(case, 9)["accepted"]

case = copy.deepcopy(post)
case["response"]["send_counters"][1]["timing"]["observed_stream_id"] = 0
assert not validator.validate_pair(pre, case, 9)["accepted"]

case = copy.deepcopy(post)
case["response"]["send_counters"][2]["timing"]["physical_attempt_frames"] = 1
assert not validator.validate_pair(pre, case, 9)["accepted"]

case = copy.deepcopy(post)
case["response"]["send_counters"][2]["timing"]["physical_write_by_outcome"]["error"] = {
    "count": 1, "total_nanoseconds": 1, "max_nanoseconds": 1,
}
assert not validator.validate_pair(pre, case, 9)["accepted"]

terminal = envelope("terminal")
assert validator.validate_terminal(terminal, 9)["accepted"]
terminal["response"]["send_counters"][3]["timing"]["complete"] = False
assert not validator.validate_terminal(terminal, 9)["accepted"]
