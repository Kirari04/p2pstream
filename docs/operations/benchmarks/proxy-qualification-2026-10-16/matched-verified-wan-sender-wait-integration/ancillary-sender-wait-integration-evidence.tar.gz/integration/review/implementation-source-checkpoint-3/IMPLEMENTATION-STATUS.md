# Sender-duration integration source checkpoint 3

Source-only, unbuilt, and unexecuted. No supervisor, coordinator, or final arm
validator derivative is included, so this checkpoint cannot launch an endpoint.
It freezes the checkpoint-4 source overlay binding, authenticated test-only
server/agent controls, generated narrow runner, and strict sender validators.

The mature timed `run_transfer` remains intended to be byte-identical at 7,350
bytes and SHA-256 `b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798`;
that audit is planned but has not been executed for this checkpoint. Runtime
execution-trace capture/parser/reducer controls are absent from this cohort.

Checkpoint 3 closes source-review blockers by validating every fixed schema-2
timing field with exact Python types, requiring a positive selected stream ID,
requiring no pending credit decision, rejecting every nested activity field on
nonselected lanes, and providing separate pre, pair, and terminal modes. A
failed pre boundary is recorded before the unchanged timed request and makes
that row permanently unmeasured while preserving the fixed remaining schedule.
The terminal query and strict closure verdict are recorded separately for a
future mandatory arm gate. Validator canonical path and SHA-256 are explicit
runner inputs preserved and rechecked across namespace/sudo re-exec.

Negative contract sources cover pending ownership, bool-as-int, zero stream ID,
nonselected physical/outcome activity, terminal incompleteness, validator input
binding, and the already-reviewed agent/server namespace dispatch. None has
been executed.

Execution remains blocked independently: checkpoint 4 focused validation passed,
but its strict ordinary proof found five real `Session.sendLoop` instruction-byte
differences and a `Stream.write` inliner-cost change. No normalization, rerun,
or waiver is claimed. Checkpoints 1 and 2 remain immutable review history.
