#!/usr/bin/env bash
set -Eeuo pipefail

umask 077
base=/home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-sender-wait-integration-source
build_base=/home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-sender-wait-build-source
bundle="$base/review/sustained-diagnostic-launch-source-2"
preflight="$base/provenance/sustained-sender-wait-1-preflight"
output="$base/integration-source/runs/sustained-sender-wait-1"
invocation="$base/review/sustained-diagnostic-invocation-source-1/INVOCATION.txt"
reviewed_manifest="$base/provenance/reviewed-integration-source-manifest-cp10.json"
verifier="$base/integration-source/verify-reviewed-integration-manifest.py"

[[ ! -e "$preflight" ]] || {
  printf '%s\n' 'preflight evidence path already exists' >&2
  exit 2
}
mkdir -m 0700 "$preflight"

finished=0
finish() {
  local status=$1 result=$2
  printf '%s\n' "$status" > "$preflight/launcher.status"
  printf '%s\n' "$result" > "$preflight/RESULT"
  (
    cd "$preflight"
    find . -type f ! -name SHA256SUMS.txt -print0 \
      | LC_ALL=C sort -z \
      | xargs -0 sha256sum > SHA256SUMS.txt
  )
  finished=1
  exit "$status"
}
on_exit() {
  local status=$?
  if [[ $finished -eq 0 ]]; then
    printf '%s\n' "$status" > "$preflight/launcher.status"
    printf '%s\n' aborted > "$preflight/RESULT"
  fi
}
trap on_exit EXIT

bad=0
check_hash() {
  local label=$1 path=$2 expected=$3 actual status
  status=0
  if [[ ! -f "$path" || -L "$path" ]]; then
    actual=not-a-regular-file
    status=1
  else
    actual=$(sha256sum "$path" | cut -d' ' -f1)
    [[ "$actual" == "$expected" ]] || status=1
  fi
  printf '%s\t%s\t%s\t%s\n' "$label" "$expected" "$actual" "$path" \
    >> "$preflight/hash-checks.tsv"
  printf '%s\n' "$status" > "$preflight/$label.status"
  (( status == 0 )) || bad=1
}
check_exact_file() {
  local label=$1 path=$2 expected=$3 actual status
  status=0
  if [[ ! -f "$path" || -L "$path" ]]; then
    actual=not-a-regular-file
    status=1
  else
    actual=$(cat "$path")
    [[ "$actual" == "$expected" ]] || status=1
  fi
  printf '%s\t%s\t%s\t%s\n' "$label" "$expected" "$actual" "$path" \
    >> "$preflight/value-checks.tsv"
  printf '%s\n' "$status" > "$preflight/$label.status"
  (( status == 0 )) || bad=1
}
check_mode() {
  local label=$1 path=$2 expected=$3 actual status
  status=0
  if [[ ! -f "$path" || -L "$path" ]]; then
    actual=not-a-regular-file
    status=1
  else
    actual=$(stat -c '%a' "$path")
    [[ "$actual" == "$expected" ]] || status=1
  fi
  printf '%s\t%s\t%s\t%s\n' "$label" "$expected" "$actual" "$path" \
    >> "$preflight/mode-checks.tsv"
  printf '%s\n' "$status" > "$preflight/$label.status"
  (( status == 0 )) || bad=1
}

: > "$preflight/hash-checks.tsv"
: > "$preflight/value-checks.tsv"
: > "$preflight/mode-checks.tsv"

check_hash compatibility-receipt \
  "$base/provenance/sender-validator-manifest-correction-receipt.json" \
  e9453df0e13a2c342e8e802712206d991c478f0a36d6f291b10053229de2abc6
check_hash cp10-checkpoint \
  "$base/review/implementation-source-checkpoint-10/SHA256SUMS.txt" \
  b532337700b7e3b17e1debc3a90ef8f786317d58bfb54449bf577616bd1514f3
check_hash reviewed-manifest "$reviewed_manifest" \
  78820279349001e1af0ba24cce843030b795f5e52548bd39548071204cc41ea3
check_hash reviewed-verifier "$verifier" \
  38756d8dfc2e85cfe91a587533f7fbfca43b1951953195b435dd7b49efe83d88
check_hash coordinator \
  "$base/integration-source/run-wan-sender-wait-diagnostic.sh" \
  a15caea9cc1fbbdc7b903ff862e2b38133fbe89cb66826a753d2b89e92e78165
check_hash arm-supervisor \
  "$base/integration-source/run-wan-sender-wait-arm.sh" \
  cbd17e7fc173e59ebc0b3da29a12a13f87933ff373f80ba199ce8e1c7150a503
check_hash generated-runner \
  "$base/integration-source/generated/qualify-proxy-agent-growth-wan-sender-wait.sh" \
  02c1e76bee7fa6bf81f1242761ac7ae533f47b006cac86cda35523344cb05da4
check_hash canonical-validator \
  "$base/integration-source/validate-wan-sender-wait-arm.py" \
  9ae7fa74c6be09706d0b77759b52b696dbc302ffd14b3ba8c6a44b23547a2860
check_hash audited-build-manifest \
  "$base/provenance/audited-server-build-manifest.json" \
  ba1a31b8f54e7cbb4df8dace0990a4aba87fd4462803a31a6e3082810e9e1b2b
check_hash build-records-supplement \
  "$build_base/provenance/audited-build-attempt-1-supplement/RECORDS-SUPPLEMENT-SHA256SUMS.txt" \
  bd74f1e717079b9b9db59a1f0e7114cd13f32e2e6d1a1be1d3211091cf786225
check_hash build-records-supplement-sidecar \
  "$build_base/provenance/audited-build-attempt-1-supplement/RECORDS-SUPPLEMENT-MANIFEST.sha256" \
  5c6139cc725fa93ba2166d87c8ca070c0bcbc94cb76c790c8f68b77cc3b6a9ad
check_hash publication-receipt \
  "$base/provenance/local-publication-receipt.json" \
  3d51f22da466d04a93ce31cac2627ea4bd7213c9a6fb1ff91890a5519c2beb8b
check_hash publication-v2-ledger \
  "$base/provenance/local-publication-attempt-1/PUBLICATION-SHA256SUMS-v2.txt" \
  b76b1eeb1079c9868b27023105d0f5446248dde10c638124842c18301a24176c
check_hash active-cp10-publication \
  "$base/provenance/cp10-active-publication-1/SHA256SUMS.txt" \
  973142fb026a758c594104d4dc1579f246eaa09da6af9989575b6cd7195c339c
check_hash cp10-static-verification \
  "$base/integration-source/runs/cp10-static-verification-1/SHA256SUMS.txt" \
  d3d19790e91f412d050573ebd9b0a15c4bb67fba8cd3a545ca0cebd007192e13
check_hash sustained-invocation "$invocation" \
  c60a7876a16bbc76562a0a172c79c29646e7047cc270392adf6b5c1e6bd262a8
check_hash server-binary \
  "$base/build/bin/current-server-wan-sender-wait-audited.test" \
  f2e6cf390fdcd727b8c7120a6d877dc3a53afe9d8b970aa7b0d7f6cc892a7bdc
check_hash agent-binary \
  "$base/build/bin/current-agent-wan-sender-wait-audited.test" \
  43eadb7664d70f9585887ac824cc7e6dcb55d6fa40731e3888b6fa5a1cc8d74f

check_exact_file cp10-static-direct \
  "$base/integration-source/runs/cp10-static-verification-1/direct.status" 0
check_exact_file cp10-static-result \
  "$base/integration-source/runs/cp10-static-verification-1/RESULT" complete
check_mode build-manifest-mode \
  "$base/provenance/audited-server-build-manifest.json" 600
check_mode server-binary-mode \
  "$base/build/bin/current-server-wan-sender-wait-audited.test" 755
check_mode agent-binary-mode \
  "$base/build/bin/current-agent-wan-sender-wait-audited.test" 755

if [[ -e "$output" ]]; then
  printf '%s\n' 1 > "$preflight/output-absent.status"
  bad=1
else
  printf '%s\n' 0 > "$preflight/output-absent.status"
fi

set +e
/usr/bin/python3 -I -B "$verifier" "$reviewed_manifest" "$base" \
  "$preflight/reviewed-source-verification-pre.json" \
  > "$preflight/reviewed-source-verification-pre.stdout" \
  2> "$preflight/reviewed-source-verification-pre.stderr"
verify_status=$?
set -e
printf '%s\n' "$verify_status" > "$preflight/reviewed-source-verification-pre.status"
if [[ $verify_status -ne 0 ]]; then
  bad=1
elif [[ $(sha256sum "$preflight/reviewed-source-verification-pre.json" | cut -d' ' -f1) != \
  f5e3f2a0fe8bb30975f4554abc3d5c8b73f00b9957cf1d756b42df2d5d66c85a ]]; then
  printf '%s\n' 1 > "$preflight/reviewed-source-verification-pre-output.status"
  bad=1
else
  printf '%s\n' 0 > "$preflight/reviewed-source-verification-pre-output.status"
fi

if [[ $bad -ne 0 ]]; then
  finish 2 preflight-rejected
fi

if [[ -e "$output" ]]; then
  printf '%s\n' 1 > "$preflight/output-absent-final.status"
  finish 2 preflight-rejected
fi
printf '%s\n' 0 > "$preflight/output-absent-final.status"

/usr/bin/python3 -I -B - "$preflight/final-preflight-receipt.json" <<'PY'
import json, os, sys
path = sys.argv[1]
payload = {
    "schema_version": 1,
    "accepted": True,
    "action": "sustained-sender-wait-1-final-preflight",
    "diagnostic": "wan-sender-wait",
    "endpoint_execution_run": False,
    "output_absent": True,
    "output_path": "/home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-sender-wait-integration-source/integration-source/runs/sustained-sender-wait-1",
    "hashes": {
        "cp10_checkpoint": "b532337700b7e3b17e1debc3a90ef8f786317d58bfb54449bf577616bd1514f3",
        "cp10_reviewed_manifest": "78820279349001e1af0ba24cce843030b795f5e52548bd39548071204cc41ea3",
        "cp10_compatibility_receipt": "e9453df0e13a2c342e8e802712206d991c478f0a36d6f291b10053229de2abc6",
        "cp10_static_verification": "d3d19790e91f412d050573ebd9b0a15c4bb67fba8cd3a545ca0cebd007192e13",
        "audited_build_manifest": "ba1a31b8f54e7cbb4df8dace0990a4aba87fd4462803a31a6e3082810e9e1b2b",
        "publication_receipt": "3d51f22da466d04a93ce31cac2627ea4bd7213c9a6fb1ff91890a5519c2beb8b",
        "publication_v2_ledger": "b76b1eeb1079c9868b27023105d0f5446248dde10c638124842c18301a24176c",
        "server_binary": "f2e6cf390fdcd727b8c7120a6d877dc3a53afe9d8b970aa7b0d7f6cc892a7bdc",
        "agent_binary": "43eadb7664d70f9585887ac824cc7e6dcb55d6fa40731e3888b6fa5a1cc8d74f",
        "invocation": "c60a7876a16bbc76562a0a172c79c29646e7047cc270392adf6b5c1e6bd262a8",
        "reviewed_source_verification": "f5e3f2a0fe8bb30975f4554abc3d5c8b73f00b9957cf1d756b42df2d5d66c85a",
    },
    "fixed_mode": {
        "protocol_order": ["h1", "h2"],
        "transfers_per_arm": 16,
        "warmup_mib": 256,
        "steady_mib": 256,
        "transfer_repetitions": 3,
        "required_pool_mib": 8,
        "rtt_ms": 80,
        "sender_sequences": [9, 11, 14, 15],
        "download_floor_bytes_per_second": 29700000,
        "idle_timeout_seconds": 30,
        "server_memory_max_bytes": 4294967296,
        "server_memory_swap_max_bytes": 0,
        "server_cpus": "0-3",
        "agent_cpus": "4-7",
        "load_cpus": "8-15",
    },
}
fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as f:
    json.dump(payload, f, indent=2, sort_keys=True)
    f.write("\n")
PY
printf '%s\n' ready > "$preflight/READY"

set +e
/usr/bin/bash "$invocation" \
  > "$preflight/coordinator.stdout.log" \
  2> "$preflight/coordinator.stderr.log"
coordinator_status=$?
set -e
printf '%s\n' "$coordinator_status" > "$preflight/coordinator.status"

set +e
/usr/bin/python3 -I -B "$verifier" "$reviewed_manifest" "$base" \
  "$preflight/reviewed-source-verification-post.json" \
  > "$preflight/reviewed-source-verification-post.stdout" \
  2> "$preflight/reviewed-source-verification-post.stderr"
post_status=$?
set -e
printf '%s\n' "$post_status" > "$preflight/reviewed-source-verification-post.status"

compare_status=1
if [[ $post_status -eq 0 ]]; then
  set +e
  cmp -s "$preflight/reviewed-source-verification-pre.json" \
    "$preflight/reviewed-source-verification-post.json"
  compare_status=$?
  set -e
fi
printf '%s\n' "$compare_status" > "$preflight/reviewed-source-compare.status"

final_status=$coordinator_status
if [[ $post_status -ne 0 || $compare_status -ne 0 ]]; then
  final_status=70
fi
finish "$final_status" complete
