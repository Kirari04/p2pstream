# Sender-duration small diagnostic attempt 2 preflight

This bundle is source-only and unexecuted. It specifies one fresh H1 then
closure-gated H2 small diagnostic. Astra must review the external tuple below
and explicitly authorize launch; the coordinator's internal self-consistency
checks do not establish that external approval.

The active cp9 shell corpus is bound by checkpoint
`601ffd71333a0476e9a6aef92eb3947604fd91a594d6d4c906d9f1e8a2de3fc0`,
reviewed manifest `fdf2e441f130aac840d2b08cd0b82a7196a71d4dd1519a1c49b6dfcdebfc3fab`,
and accepted helper-compatibility receipt
`11b3f6cfbd1de9a8ff612ef483b127b87e16d4099debc369d5f5db542fc9d53e`.
The latter joins the successful no-endpoint attempt-3 ledger
`e339f8608083bc950185b2e32d09cf6cc49f076972e4c3f0aaa2ec91c138f1ad`
to the unchanged audited build and binary pair.

The historical build manifest remains immutable at
`ba1a31b8f54e7cbb4df8dace0990a4aba87fd4462803a31a6e3082810e9e1b2b`.
Its original cp7 harness fields are still checked against the frozen cp7 files.
The unchanged published server and agent are
`f2e6cf390fdcd727b8c7120a6d877dc3a53afe9d8b970aa7b0d7f6cc892a7bdc`
and `43eadb7664d70f9585887ac824cc7e6dcb55d6fa40731e3888b6fa5a1cc8d74f`.
The accepted publication receipt is `3d51f22da466d04a93ce31cac2627ea4bd7213c9a6fb1ff91890a5519c2beb8b`;
its corrected v2 publication ledger is
`b76b1eeb1079c9868b27023105d0f5446248dde10c638124842c18301a24176c`.
That receipt binds the observer-validation supplement ledger
`bd74f1e717079b9b9db59a1f0e7114cd13f32e2e6d1a1be1d3211091cf786225`
and sidecar `5c6139cc725fa93ba2166d87c8ca070c0bcbc94cb76c790c8f68b77cc3b6a9ad`;
the build manifest independently binds observer proof receipt
`a7fe20645470f4050816fedb14454013a7440db8ea962fd35b768b132097c8e0`
and report `ef9180aa9919410998e3da851ba64d997d81e5cd0dce08e6666e81b47c3c24fe`.

The current coordinator, arm, and generated runner hashes are respectively
`51b77685314288da37568612fae50fd034962794925a815c56d4b1aa93394206`,
`ac2b84506d53a7562dc33d74940362c513f7b71ae0b5a7cc9f22533493b8c77a`,
and `02c1e76bee7fa6bf81f1242761ac7ae533f47b006cac86cda35523344cb05da4`.
The invocation hash is `be5a2f9bb6850258fbe9c83ca1cf6b683607b23834c99f3a0dd2ebc714e0593a`.

The fixed mode remains 16 transfers per arm, 4 MiB warmup and steady payloads,
three repetitions, a 2 MiB pool, 80 ms RTT, selected sequences 9/11/14/15,
verified symmetric public.test TLS, CPUs 0-3/4-7/8-15, server-only 4 GiB with
no swap, and the unchanged 30-second idle policy. The 29.7 MB/s floor is
recorded but is not a performance gate in this small diagnostic. H2 may start
only through the mature H1 cleanup/resource/terminal-ledger continuation gate.
The output path must not exist before launch. No old read-wait trace owner is
enabled.
