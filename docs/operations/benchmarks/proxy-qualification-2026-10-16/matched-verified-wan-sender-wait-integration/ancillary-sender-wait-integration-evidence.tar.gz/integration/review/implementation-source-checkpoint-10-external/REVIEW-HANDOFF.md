# cp10 source review handoff

Review checkpoint `../implementation-source-checkpoint-10/SHA256SUMS.txt`, the strict cp9-to-cp10 diff, candidate/final identical reviewed-corpus manifests, and the new compatibility receipt. cp10 adds one documentation file; changes the canonical validator by exactly four required keys; advances only checkpoint/manifest/receipt paths and corresponding exact receipt predicates in the coordinator, arm, verifier, and static source contract; and updates status prose. Generated runner and all four Go overlay files are byte-identical.

The compatibility receipt preserves the historical cp9 accepted no-endpoint contract as cp9 evidence. It separately binds the reviewed nine-case validator contract and same-closed-evidence H1/H2 offline validation. Both have direct status zero, unchanged inputs, accepted results, and unresolved outer tool-envelope status one with exact command disclosures. The receipt requires outer status one rather than mislabeling it as success.

The sustained invocation is source-only and unexecuted. It omits `--small-diagnostic`; all schedule, floor, TLS, cgroup, CPU, idle, reuse, sender, copy, and lifecycle settings remain inherited. Active cp9 source is not replaced by this checkpoint; publication and traffic require later review.
