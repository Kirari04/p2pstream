# cp10 canonical arm validator correction

cp10 derives from immutable cp9. Its only acceptance-semantic change adds the four provenance keys already emitted by the cp9 runner (`base_cp7_checkpoint`, `base_cp7_reviewed_manifest`, `base_cp7_runner`, and `sender_harness_receipt`) to the canonical arm validator's exact required-key set. The change was first reviewed and executed as the separate offline validator derivative; it accepted both closed 16-row smoke arms without modifying any original artifact.

The remaining cp10 changes only advance checkpoint, externally reviewed manifest, and compatibility-receipt paths. The compatibility receipt distinguishes the accepted historical cp9 no-endpoint contract from the new nine-case offline validator contract and same-evidence H1/H2 offline verification. Both offline commands have direct status zero and unresolved outer tool-envelope status one; cp10 requires both facts exactly and does not call the outer envelopes successful.

The generated runner, runner patch, Go control patch, source overlays, observer proof, endpoint binaries, copy helper, sender snapshot validator, timed `run_transfer`, schedule, TLS policy, resource policy, timeout, pool, floor, reuse, sender, copy, and natural lifecycle gates are unchanged.
