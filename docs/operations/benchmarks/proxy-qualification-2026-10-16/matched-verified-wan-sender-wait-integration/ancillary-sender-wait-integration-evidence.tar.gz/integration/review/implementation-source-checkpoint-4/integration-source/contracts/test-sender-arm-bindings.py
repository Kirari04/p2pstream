#!/usr/bin/env python3
"""No-endpoint source contract for sender arm joins and fixed ordering."""

from pathlib import Path
import sys

source = Path(sys.argv[1]).read_text()
required = (
    'expected_sender_specs = {9: ("retained-warmup", 1), 11: ("steady", 1), 14: ("steady", 2), 15: ("steady", 3)}',
    'sender_record_order != [9, 11, 14, 15, "terminal"]',
    'transfer_row.get("diagnostic_sequence") == sequence',
    'transfer_row.get("measurement_stage") == expected_spec[0]',
    'transfer_row.get("transfer_direction") == "download"',
    'record.get("measurement_start_valid") is True',
    'independent_pair.get("accepted") is True',
    'independent_terminal.get("accepted") is True',
    'independent_terminal.get("closure_valid") is True',
    'actual_control_names != expected_control_names',
    'supervisor.get("sender_evidence", {}).get("terminal_valid") is True',
    '"sender_duration_intervals": sender_intervals',
    '"sender_terminal_closure_valid": terminal_valid',
    '"performance_gate_enabled": not small',
)
missing = [text for text in required if text not in source]
if missing:
    raise SystemExit(f"sender arm join/gate source is incomplete: {missing!r}")
for forbidden in ("trace_reduction", "read-wait-reductions", "run_interned_trace_parser"):
    if forbidden in source:
        raise SystemExit(f"receiver trace dependency remained in sender arm validator: {forbidden}")
