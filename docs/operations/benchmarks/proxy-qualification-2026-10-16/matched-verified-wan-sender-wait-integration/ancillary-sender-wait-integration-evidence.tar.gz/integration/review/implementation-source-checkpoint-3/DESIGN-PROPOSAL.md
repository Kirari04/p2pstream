# Sender-duration matched-protocol diagnostic: narrow integration proposal

Status: source-only proposal. No source overlay, build, test, endpoint, or
traffic execution is authorized by this document. This is a new diagnostic;
it is not an original WAN qualification result and must not be combined with
the completed execution-trace cohort.

## Frozen ancestry

The runtime harness ancestor is the full-production capacity/read-wait
fixture. Its generated runner is
`wan-read-wait-stack-intern-source/integration-source/runs/sustained-matched-protocol-1/preflight/runner-rebuilt.sh`
(SHA-256 `e9e453206cd479e1d29b78c05cf4d0eaf0cbaefe3c6ff13f0ba9594235c3bea0`).
The extracted `run_transfer` function is 7,350 bytes, SHA-256
`b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798`,
and remains byte-for-byte unchanged.

The sender observer ancestor is frozen checkpoint 3 at
`wan-sender-wait-source/review/source-checkpoint-4`, manifest SHA-256
`bd5e8d7ae486e460749ae06fd701ce562e3ef678c872edce014aa08a8fa78b4f`,
base patch SHA-256
`e35020414a624f7105394fb268e9061472cfd2a536380532edc873ffcdc0d96e`,
and design amendment SHA-256
`58ee413e5b2b12e338154292e65cc2d5f85e859633b46009c64028b34e56c6c2`.
Its original design remains SHA-256
`c4333c374a298da0461680b2b2c0426674610a4a0246a16d0767c6d83f103e9e`;
the amendment controls where they differ.

The old allocation drain runner and helper are inventory only. They are
post-only, unauthenticated, and schema version 1, so neither is suitable as a
runtime ancestor. Their useful constraints are the 4 MiB response bound and
fixed lane/ring bounds.

## Minimal runtime shape

Keep the mature full-production fixture, H1-then-H2 fresh-arm topology,
verified public TLS, real DB agent registration/authentication, public reverse
proxy, 8 KiB load reader, 30 second idle policy, four aggregate bulk lanes,
256 MiB conditioning and timed payloads, three steady repetitions, 8 MiB pool,
80 ms RTT, 29.7 MB/s diagnostic download floor, copy records, upstream
connection traces, pool/event/payload checks, server-only 4 GiB/no-swap scope,
and all namespace/process/resource/natural-join gates.

Do not enable or invoke Go execution tracing. Remove the trace Start/Stop,
raw-trace, parser, stack-interning, reducer, and trace-only supervisor gates in
the derivative. Dormant test-only trace code may remain in the source ancestry,
but no trace environment variable or route is enabled. Replace only the
selected wrapper at sustained download sequences 9, 11, 14, and 15 with an
authenticated sender-snapshot wrapper. The fixed schedule and the calls into
the unchanged `run_transfer` remain identical.

The wrapper order for a selected transfer is:

1. Capture and validate the inherited server runtime, exact server cgroup, and
   last-applied adaptive server capacity snapshot.
2. Destructively drain the agent schema-2 sender snapshot for all physical
   sessions. Persist the bounded response/status/provenance envelope before
   validation. Never persist the Authorization value, bearer, or
   secret-bearing request environment.
3. Run the separate pre-boundary validator over the full schema. Only an exact
   complete/reset/zero-active four-lane result starts a measured interval. If
   it fails, mark the row irrevocably unmeasured but run the unchanged timed
   request once so the fixed workload remains complete; never retry or wait.
4. Run the unchanged timed transfer in the already reviewed trap-cleared,
   errexit subshell. Advance the parent sequence exactly once.
5. Immediately drain the agent snapshot again, then capture the inherited
   post runtime/cgroup/capacity state. These are outside the timed load.
6. Append one immutable diagnostic record containing every direct status and
   both raw envelopes. Snapshot validity does not erase or pool a slow row.

The agent snapshot check is diagnostic evidence. A malformed, unavailable,
incomplete, ambiguous, overflowing, or nonconserving snapshot makes the
sender-duration record invalid/inconclusive. It does not turn a slow transfer
healthy, restart the transfer, extend the idle timeout, close transports, or
selectively discard a row. Resource/correctness failures retain the mature
fail-closed behavior. If the timed request itself succeeds, a sender-only
snapshot failure is retained and later makes the arm validator nonzero while
allowing the fixed remaining schedule to finish.

## Authenticated test-only controls

Generate one random 32-byte lowercase-hex bearer per arm. Pass it privately to
the test-only server and agent processes through their owned ephemeral
environments. Both packages independently validate
the exact `Authorization: Bearer <token>` form with length equality and
`subtle.ConstantTimeCompare`. The token and Authorization value are never
persisted in command records, logs, manifests, or exported artifacts. Records
state only that bearer authentication was configured and
whether the request succeeded.

The agent gets a new opt-in loopback-only action such as
`wan_sender_wait_snapshot=drain`, plus an exact configured sequence. It calls
the existing schema-2 `writeExternalQualificationGrowthSnapshot`, which drains
the fixed receive-growth ring and each session's sender counters. In sender
diagnostic mode the legacy unauthenticated `growth_snapshot=drain` action must
be unavailable so another loopback caller cannot reset the same ledger.
Ordinary agent runtime JSON and the non-destructive credit snapshot remain
unchanged. With the diagnostic disabled, the fixture retains its prior
behavior and exposes no sender-duration control route.

The existing server capacity route is currently coupled to the execution-trace
owner and its configured capture map. Enabling that owner without performing
the fixed traces would fail finalization. The narrow correction is a separate
test-only sender diagnostic capacity action using the same bearer and fixed
sequence set while reusing the already reviewed locked
`qualificationWANReadWaitServerCapacity` snapshot function. It neither starts
nor finalizes a tracer and does not register a public route. The old trace
owner and its routes remain untouched and disabled.

Both controls remain on the existing plaintext namespace-loopback admin
listeners. Authentication protects these new destructive/diagnostic actions;
it does not change the truthful security description of the ordinary admin
listener.

## Schema-2 lane and interval contract

Every pre and post response must be schema version 2, below the inherited
4 MiB bound, with the fixed receive-growth capacity 4096, at most 4096 events,
an exact nonnegative dropped-event count, and exactly one control lane 0 plus
bulk lanes 1 through 4. Receive-growth events and their dropped count are
preserved and bounded but do not gate sender-ledger completeness: they are a
separate receive-side ring drained by the existing combined writer. The
control lane is disabled and has zero sender counters. Every bulk lane is
enabled. Lane number, nonempty session identity, local address, and remote
address must match exactly from pre to post for all five entries; no
maximum-counter or other heuristic chooses a lane.

For each bulk lane, the pre drain must report `complete=true`,
`reset_performed=true`, zero active ownership, and
`send_loop_terminated=false`. Prior scalar counts, durations, observed stream,
ambiguity, or overflow are preserved as conditioning history and are not
required to be zero because the complete drain establishes a new interval.
An incomplete pre snapshot is never treated as a reset.

The post response must again contain the same complete lane set and stable
tuples. Exactly one bulk lane may have `stream_observed=true`; it must have one
nonzero observed stream ID and `multiple_streams=false`. The other three bulk
lanes must have no selected-interval counters or observed stream. All four
must report complete/reset, zero active credit/reservation/caller/enqueue/
queued/pre-publication/physical ownership, `ambiguous=false`,
`overflow=false`, and `send_loop_terminated=false`.

For the selected lane, validation is exact:

* reserved, accepted-enqueue, completed, physical-attempt, and
  physical-success frame counts and DATA payload-byte totals are equal and
  positive;
* attempted, written, and successful physical wire-byte totals are equal, and
  wire bytes equal DATA payload bytes plus the fixed Yamux DATA header for
  every frame;
* gather error, abandoned, physical error, and short-write counts and bytes
  are zero;
* enqueue shutdown/timeout and completion error/shutdown/timeout outcomes are
  zero; accepted/success/data-call/physical-success counts match the conserved
  frame count;
* each duration bucket has valid count/total/max values; every total equals
  the sum of its mutually exclusive cause or outcome buckets and every maximum
  is bounded by its total;
* on the all-success interval, DATA-call duration equals enqueue-select plus
  completion-select duration, and physical-write duration does not exceed the
  containing DATA-call duration;
* credit-wait totals equal the exact-cause and selected-outcome sums. Waits may
  be zero; if present, their first/last tokens and counts must be coherent;
* allocation charged bytes are at least DATA payload bytes, are a multiple of
  the pinned 4 KiB aggregate unit, and are no more than payload bytes plus
  `(frames * (4096 - 1))`. They are not equated to HTTP body bytes.

The DATA payload domain includes tunneled HTTP response headers as well as the
response body. Physical wire bytes additionally include Yamux DATA headers.
The independent load result remains exactly 256 MiB. These three domains are
reported and conserved separately.

The observer has no direct public-request-to-Yamux-stream marker. Attribution
is therefore explicitly limited to interval exclusivity: one public load
request at concurrency 1, a reset complete set of all four bulk lanes, stable
session/lane/tuple identities, exactly one observed stream afterward, and no
activity in the other lanes. A valid interval supports descriptive sender
timing for that exclusive interval; it does not prove a causal link or permit
a runtime policy change.

## Incomplete and terminal evidence

Every query attempt is written once before interpretation. An incomplete post
drain does not reset live state and invalidates that selected interval. There
is no polling loop, sleep, transport close, forced cleanup, or idle-time
extension to make it complete.

The next selected transfer's pre drain naturally records whether the retained
state has reached an exact terminal condition; if complete it resets the new
interval, but it never repairs the preceding record. After sequence 15, take
one final authenticated terminal drain immediately before the existing normal
agent stop, with no added wait. It is lifecycle/ledger closure only and cannot
be attributed to sequence 15 if the immediate post drain was incomplete.
Preserve both records. Any terminal incompleteness, terminated send loop,
forced endpoint cleanup, or missing exact process exit remains invalid.
The final terminal envelope is interpreted by a separate terminal-mode schema
validator, and its exact query and validation statuses are mandatory inputs to
the future arm gate rather than inferred from HTTP/schema success.

## Prospective change surface

Use a new sibling source/build and integration directory. Do not copy or edit
the frozen capacity, trace, sender-observer, or executed run directories.
The intended runtime change surface is:

* apply frozen sender checkpoint 4 to a fresh copy of the audited capacity
  source;
* add one small agent test-only bearer/sequence owner and wire the authenticated
  schema-2 drain into `internal/agent/proxy_qualification_external_test.go`;
* add one small server test-only sender control owner and wire only the
  capacity action into `internal/server/proxy_qualification_test.go`, reusing
  the existing locked capacity snapshot implementation;
* derive one runner from the mature reconstructed runner, delete only the
  execution-trace setup/control/parser artifacts, and replace
  `run_maybe_traced_transfer` with the sender wrapper while retaining the exact
  selection predicate and byte-identical `run_transfer`;
* derive the arm supervisor, coordinator, and arm validator by removing their
  trace-reduction bindings and adding exact sender record/status/source/binary
  bindings; and
* add one small strict sender snapshot validator rather than a new harness;
  pass its canonical path and exact SHA-256 as explicit runner inputs and
  preserve/recheck both across namespace and sudo re-exec.

No production file, public handler, protocol setting, frame/buffer size,
credit/refund policy, pool, timeout, adaptive policy, lane selection, or
cleanup schedule changes.

## Hard prerequisites before implementation or execution

1. Checkpoint 4's tagged focused/race contracts and ordinary untagged
   layout/object-code comparison must pass and be immutably bound. This
   proposal does not claim they have run.
2. Astra must approve the separate authenticated server capacity action and
   the no-poll terminal-record rule above.
3. A fresh audited server and agent build is required from the integrated
   source. The old agent binary cannot be reused because it has neither the
   tagged sender observer nor authenticated schema-2 drain.
4. Before endpoint use, focused source contracts must cover exact Bearer
   parsing, wrong/missing token, disabled route, configured sequence, legacy
   drain suppression in diagnostic mode, stable full-lane validation,
   nonzero-prior complete reset, incomplete no-reset, terminal preservation,
   multistream/ambiguity/overflow, every conservation failure, and no-secret
   artifact output.
5. Static reconstruction must prove the timed function hash and fixed schedule
   unchanged, trace controls absent, all inherited TLS/resource/lifecycle
   gates retained, and the new binary/source/helper hashes bound pre/post.

