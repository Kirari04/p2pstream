# Sender-duration integration source checkpoint 1

Source-only, unbuilt, and unexecuted. No supervisor, coordinator, or arm
validator derivative is included yet, so this checkpoint cannot launch an
endpoint. It freezes the reviewed design, the checkpoint-4 source overlay
binding, authenticated test-only server/agent control source, the generated
runner derivative, and the strict per-interval sender validator for independent
source review.

The mature timed `run_transfer` remains 7,350 bytes and SHA-256
`b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798`.
The runner contains no Go execution-trace Start/Stop, raw trace, parser,
canonicalizer, or reducer control. Resource scope names inherited from the
mature supervisor are not execution tracing.

Execution is blocked independently of this source review: checkpoint 4 focused
validation passed, but the strict ordinary proof found five real instruction
byte differences in `Session.sendLoop` and a `Stream.write` inliner-cost change.
No normalization, rerun, or waiver is claimed. This integration must not be
built or run unless Astra resolves that proof failure and later approves a
complete supervisor/coordinator/arm-validator checkpoint.
