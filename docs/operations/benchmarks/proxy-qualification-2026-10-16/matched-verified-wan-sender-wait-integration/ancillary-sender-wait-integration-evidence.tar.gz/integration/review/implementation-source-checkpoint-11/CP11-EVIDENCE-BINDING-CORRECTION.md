# cp11 external evidence binding correction

cp11 preserves the accepted cp10 four-key canonical validator change and adds exact receipt assertions for every external evidence artifact used to justify it: the cp9 contract manifest/result; offline validator contract closure manifest, summary, and outer-envelope disclosure; offline H1/H2 verification closure manifest, summary, both attestations, and outer-envelope disclosure; and the independent artifact-closure ledger/status. This closes the possibility that an altered external receipt retains status booleans while severing evidence hashes.

The cp10 checkpoint, reviewed manifest, and compatibility receipt remain immutable and are explicitly bound as historical predecessor source. The generated runner, Go overlays, endpoint binaries, timed transfer function, protocols, schedule, thresholds, timeouts, pools, TLS behavior, resource containment, and lifecycle gates remain unchanged.
