#!/usr/bin/env python3
"""Verify the externally reviewed sender integration corpus without self-hashing."""

import hashlib
import json
import os
import pathlib
import sys

if len(sys.argv) != 4:
    raise SystemExit("usage: verify-reviewed-integration-manifest.py MANIFEST SOURCE_ROOT OUTPUT")

manifest_path = pathlib.Path(sys.argv[1]).resolve(strict=True)
source_root = pathlib.Path(sys.argv[2]).resolve(strict=True)
output_path = pathlib.Path(sys.argv[3])
if not manifest_path.is_file() or not source_root.is_dir() or output_path.exists():
    raise SystemExit("manifest/source/output path contract failed")

def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def checked_child(root, relative):
    if not isinstance(relative, str) or not relative or relative.startswith("/"):
        raise ValueError("invalid relative path")
    lexical = pathlib.PurePosixPath(relative)
    if lexical.is_absolute() or ".." in lexical.parts or "." in lexical.parts:
        raise ValueError("non-canonical relative path")
    path = root.joinpath(*lexical.parts)
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"not a regular non-symlink file: {relative}")
    if not path.resolve().is_relative_to(root):
        raise ValueError(f"path escapes source root: {relative}")
    return path

manifest = json.loads(manifest_path.read_text())
if set(manifest) != {
    "schema_version", "diagnostic", "checkpoint_manifest_path",
    "checkpoint_manifest_sha256", "files",
}:
    raise SystemExit("reviewed manifest schema changed")
if manifest["schema_version"] != 1 or manifest["diagnostic"] != "wan-sender-wait":
    raise SystemExit("reviewed manifest identity changed")
if manifest["checkpoint_manifest_path"] != "review/implementation-source-checkpoint-11/SHA256SUMS.txt":
    raise SystemExit("reviewed checkpoint path changed")
checkpoint_manifest = checked_child(source_root, manifest["checkpoint_manifest_path"])
if sha(checkpoint_manifest) != manifest["checkpoint_manifest_sha256"]:
    raise SystemExit("reviewed checkpoint manifest hash mismatch")

checkpoint_root = checkpoint_manifest.parent
checkpoint_files = {}
for line in checkpoint_manifest.read_text().splitlines():
    parts = line.split("  ", 1)
    if len(parts) != 2 or len(parts[0]) != 64 or not parts[1].startswith("./"):
        raise SystemExit("malformed checkpoint manifest line")
    relative = parts[1][2:]
    if relative in checkpoint_files:
        raise SystemExit("duplicate checkpoint manifest path")
    checkpoint_files[relative] = parts[0]
if not checkpoint_files or manifest["files"] != checkpoint_files:
    raise SystemExit("external file ledger differs from reviewed checkpoint")

verified = {}
for relative, expected in sorted(checkpoint_files.items()):
    if not isinstance(expected, str) or len(expected) != 64:
        raise SystemExit("invalid expected digest")
    active_path = checked_child(source_root, relative)
    frozen_path = checked_child(checkpoint_root, relative)
    active_sha = sha(active_path)
    frozen_sha = sha(frozen_path)
    if active_sha != expected or frozen_sha != expected:
        raise SystemExit(f"reviewed source bytes changed: {relative}")
    verified[relative] = expected

result = {
    "schema_version": 1,
    "accepted": True,
    "diagnostic": "wan-sender-wait",
    "reviewed_manifest_sha256": sha(manifest_path),
    "checkpoint_manifest_path": manifest["checkpoint_manifest_path"],
    "checkpoint_manifest_sha256": manifest["checkpoint_manifest_sha256"],
    "verified_file_count": len(verified),
    "files": verified,
}
output_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
descriptor = os.open(output_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(descriptor, "w") as output:
    json.dump(result, output, indent=2, sort_keys=True)
    output.write("\n")
