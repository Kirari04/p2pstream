#!/usr/bin/env bash
set -Eeuo pipefail

integration_dir=$(cd "$(dirname "$0")/.." && pwd)
work=${1:?owned fresh work directory required}
real_python=$(command -v python3)
[[ ! -e $work ]] || { echo "work directory must be fresh" >&2; exit 2; }
mkdir -m 0700 -p "$work/bin"

cat > "$work/bin/python3" <<'FAKE'
#!/usr/bin/env bash
set -Eeuo pipefail
script=$1 role=$2 action=$3 sequence=$4 admin=$5 destination=$6 timeout=$7
[[ $script == /dev/fd/3 ]]
source_text=$(cat <&3)
[[ $source_text == *'Authorization'* && $source_text == *'response_bytes'* ]]
bearer=$(cat)
[[ $bearer == aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa ]]
if [[ $role == agent-drain ]]; then
  [[ ${IN_AGENT_NS:-} == 1 ]]
else
  [[ -z ${IN_AGENT_NS:-} ]]
fi
printf '%s\n' "$role $action $sequence $admin $timeout ${IN_AGENT_NS:-host}" >> "$QUERY_DISPATCH_LOG"
if [[ $role == agent-drain ]]; then
  printf '{"schema_version":1,"role":"%s","action":"%s","sequence":%s,"request_started_unix_ns":1,"request_elapsed_ns":1,"http_status":200,"response_bytes":2,"response":{"schema_version":2,"capacity":4096},"error":"","authorization":"bearer-present"}\n' "$role" "$action" "$sequence" > "$destination"
else
  printf '{"schema_version":1,"role":"%s","action":"%s","sequence":%s,"request_started_unix_ns":1,"request_elapsed_ns":1,"http_status":200,"response_bytes":2,"response":{"schema_version":1,"sequence":"%s"},"error":"","authorization":"bearer-present"}\n' "$role" "$action" "$sequence" "$sequence" > "$destination"
fi
FAKE
chmod 0755 "$work/bin/python3"

export PATH="$work/bin:$PATH"
export QUERY_DISPATCH_LOG="$work/dispatch.log"
sender_wait_bearer=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
agent_ns() { IN_AGENT_NS=1 "$@"; }
# shellcheck source=/dev/null
source "$integration_dir/runner-query-block.sh.txt"

wan_sender_wait_query server-capacity pre-capacity 9 http://127.0.0.1:1 "$work/server.json"
wan_sender_wait_query agent-drain pre 9 http://127.0.0.1:2 "$work/agent.json"

[[ $(sed -n '1p' "$work/dispatch.log") == 'server-capacity pre-capacity 9 http://127.0.0.1:1 5 host' ]]
[[ $(sed -n '2p' "$work/dispatch.log") == 'agent-drain pre 9 http://127.0.0.1:2 2 1' ]]
[[ $(wc -l < "$work/dispatch.log") == 2 ]]
"$real_python" - "$work/server.json" "$work/agent.json" <<'PY'
import json, pathlib, sys
server, agent = [json.loads(pathlib.Path(path).read_text()) for path in sys.argv[1:]]
assert server["role"] == "server-capacity" and server["response"]["sequence"] == "9"
assert agent["role"] == "agent-drain" and agent["response"]["schema_version"] == 2
assert server["authorization"] == agent["authorization"] == "bearer-present"
PY
