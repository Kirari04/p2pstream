#!/usr/bin/env python3
"""Strict validator for one authenticated schema-2 sender interval."""

import json
from pathlib import Path
from typing import Any

BULK_LANES = (1, 2, 3, 4)
ALL_LANES = (0, 1, 2, 3, 4)
SCALARS = (
    "reserved_data_frames", "reserved_payload_bytes", "reserved_allocation_charged_bytes",
    "byte_credit_zero_observations", "stream_allocation_zero_observations",
    "session_allocation_zero_observations",
)
ACTIVE = (
    "active_credit_waits", "active_reserved_frames", "active_reserved_payload_bytes",
    "active_reserved_allocation_charged_bytes", "active_caller_frames", "active_caller_payload_bytes",
    "active_enqueue_frames", "active_enqueue_payload_bytes", "active_queued_frames",
    "active_queued_payload_bytes", "claimed_before_publication_frames",
    "claimed_before_publication_bytes", "active_physical_frames", "active_physical_payload_bytes",
)
BAD = (
    "data_gather_error_frames", "data_gather_error_payload_bytes", "data_abandoned_frames",
    "data_abandoned_payload_bytes", "physical_error_frames", "physical_error_payload_bytes",
    "physical_error_attempt_wire_bytes", "physical_error_written_wire_bytes", "physical_short_frames",
    "physical_short_payload_bytes", "physical_short_attempt_wire_bytes", "physical_short_written_wire_bytes",
)
DURATION_KEYS = (
    "credit_wait_total", "data_enqueue_select_total", "data_completion_select_total",
    "data_call_total", "physical_write_total",
)
OUTCOME_GROUPS = {
    "credit_wait_by_cause": ("byte_zero", "stream_allocation_zero", "session_allocation_zero", "stream_and_session_allocation_zero"),
    "credit_wait_by_outcome": ("byte_notify", "aggregate_notify", "shutdown", "timeout"),
    "data_enqueue_select_by_outcome": ("accepted", "shutdown", "timeout"),
    "data_completion_select_by_outcome": ("success", "error", "shutdown", "timeout"),
    "data_call_by_outcome": ("success", "error", "shutdown", "timeout"),
    "physical_write_by_outcome": ("success", "error", "short_write"),
}


def exact_int(value: Any) -> bool:
    return type(value) is int and value >= 0


def bucket(value: Any, path: str, issues: list[str]) -> dict[str, int]:
    if not isinstance(value, dict):
        issues.append(f"{path} is not an object")
        return {"count": 0, "total_nanoseconds": 0, "max_nanoseconds": 0}
    result: dict[str, int] = {}
    for key in ("count", "total_nanoseconds", "max_nanoseconds"):
        current = value.get(key)
        if not exact_int(current):
            issues.append(f"{path}.{key} is not a nonnegative exact integer")
            current = 0
        result[key] = current
    if result["max_nanoseconds"] > result["total_nanoseconds"]:
        issues.append(f"{path} maximum exceeds total")
    if result["count"] == 0 and (result["total_nanoseconds"] != 0 or result["max_nanoseconds"] != 0):
        issues.append(f"{path} has duration without calls")
    return result


def sum_buckets(container: Any, keys: tuple[str, ...], path: str, issues: list[str]) -> dict[str, int]:
    if not isinstance(container, dict):
        issues.append(f"{path} is not an object")
        container = {}
    values = [bucket(container.get(key), f"{path}.{key}", issues) for key in keys]
    return {
        "count": sum(value["count"] for value in values),
        "total_nanoseconds": sum(value["total_nanoseconds"] for value in values),
        "max_nanoseconds": max((value["max_nanoseconds"] for value in values), default=0),
    }


def response(envelope: Any, sequence: int, action: str, issues: list[str]) -> dict[str, Any]:
    if not isinstance(envelope, dict):
        issues.append(f"{action} envelope is not an object")
        return {}
    for key in ("schema_version", "sequence", "http_status", "response_bytes", "request_started_unix_ns", "request_elapsed_ns"):
        if not exact_int(envelope.get(key)):
            issues.append(f"{action} envelope {key} invalid")
    if envelope.get("schema_version") != 1 or envelope.get("sequence") != sequence or envelope.get("action") != action:
        issues.append(f"{action} envelope identity mismatch")
    if envelope.get("http_status") != 200 or envelope.get("error") != "":
        issues.append(f"{action} request failed")
    value = envelope.get("response")
    if not isinstance(value, dict):
        issues.append(f"{action} response is not an object")
        return {}
    if value.get("schema_version") != 2 or value.get("capacity") != 4096:
        issues.append(f"{action} schema or fixed capacity mismatch")
    if not exact_int(value.get("captured_unix_nano")) or value.get("captured_unix_nano", 0) <= 0:
        issues.append(f"{action} capture timestamp invalid")
    events = value.get("events")
    if not isinstance(events, list) or len(events) > 4096:
        issues.append(f"{action} receive-growth events missing or over bound")
    if not exact_int(value.get("dropped_events")):
        issues.append(f"{action} dropped-event count invalid")
    return value


def counters(value: dict[str, Any], action: str, issues: list[str]) -> dict[int, dict[str, Any]]:
    rows = value.get("send_counters")
    if not isinstance(rows, list) or len(rows) != 5:
        issues.append(f"{action} sender counter cardinality is not five")
        return {}
    result: dict[int, dict[str, Any]] = {}
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            issues.append(f"{action} counter {index} is not an object")
            continue
        lane = row.get("lane")
        if type(lane) is not int or lane not in ALL_LANES or lane in result:
            issues.append(f"{action} counter lane invalid or repeated: {lane!r}")
            continue
        result[lane] = row
        for key in ("session_identity", "local_address", "remote_address"):
            if not isinstance(row.get(key), str) or not row[key]:
                issues.append(f"{action} lane {lane} {key} missing")
        for key in SCALARS:
            if not exact_int(row.get(key)):
                issues.append(f"{action} lane {lane} {key} invalid")
        if not isinstance(row.get("timing"), dict):
            issues.append(f"{action} lane {lane} timing missing")
    if tuple(sorted(result)) != ALL_LANES:
        issues.append(f"{action} physical lane set mismatch")
    return result


def validate_timing(timing: dict[str, Any], lane: int, issues: list[str]) -> dict[str, dict[str, int]]:
    prefix = f"post lane {lane}"
    durations = {key: bucket(timing.get(key), f"{prefix}.{key}", issues) for key in DURATION_KEYS}
    sums = {key: sum_buckets(timing.get(key), members, f"{prefix}.{key}", issues) for key, members in OUTCOME_GROUPS.items()}
    pairs = (
        ("credit_wait_total", "credit_wait_by_cause"), ("credit_wait_total", "credit_wait_by_outcome"),
        ("data_enqueue_select_total", "data_enqueue_select_by_outcome"),
        ("data_completion_select_total", "data_completion_select_by_outcome"),
        ("data_call_total", "data_call_by_outcome"), ("physical_write_total", "physical_write_by_outcome"),
    )
    for total_name, sum_name in pairs:
        total, subtotal = durations[total_name], sums[sum_name]
        if (total["count"], total["total_nanoseconds"]) != (subtotal["count"], subtotal["total_nanoseconds"]):
            issues.append(f"{prefix} {total_name} does not conserve through {sum_name}")
    return {**durations, **sums}


def validate_pair(pre_envelope: Any, post_envelope: Any, sequence: int) -> dict[str, Any]:
    issues: list[str] = []
    pre_value = response(pre_envelope, sequence, "pre", issues)
    post_value = response(post_envelope, sequence, "post", issues)
    pre = counters(pre_value, "pre", issues)
    post = counters(post_value, "post", issues)
    for lane in ALL_LANES:
        if lane not in pre or lane not in post:
            continue
        before, after = pre[lane], post[lane]
        for key in ("lane", "session_identity", "local_address", "remote_address"):
            if before.get(key) != after.get(key):
                issues.append(f"lane {lane} pre/post {key} changed")
        if lane == 0:
            if before.get("enabled") is not False or after.get("enabled") is not False:
                issues.append("control-lane sender observer unexpectedly enabled")
            if any(before.get(key) != 0 or after.get(key) != 0 for key in SCALARS):
                issues.append("control-lane sender counters are nonzero")
            continue
        for action, row in (("pre", before), ("post", after)):
            timing = row.get("timing", {})
            if row.get("enabled") is not True:
                issues.append(f"{action} lane {lane} observer disabled")
            if timing.get("complete") is not True or timing.get("reset_performed") is not True:
                issues.append(f"{action} lane {lane} did not complete and reset")
            if timing.get("send_loop_terminated") is not False:
                issues.append(f"{action} lane {lane} send loop terminated")
            for key in ACTIVE:
                if timing.get(key) != 0:
                    issues.append(f"{action} lane {lane} active ownership {key} is nonzero")
    selected = [lane for lane in BULK_LANES if post.get(lane, {}).get("timing", {}).get("stream_observed") is True]
    if len(selected) != 1:
        issues.append(f"post observed stream lane cardinality is {len(selected)}, want one")
    selected_lane = selected[0] if len(selected) == 1 else None
    for lane in BULK_LANES:
        row = post.get(lane)
        if row is None:
            continue
        timing = row.get("timing", {})
        if timing.get("ambiguous") is not False or timing.get("overflow") is not False or timing.get("multiple_streams") is not False:
            issues.append(f"post lane {lane} ambiguity, overflow, or multistream")
        if lane != selected_lane:
            if any(row.get(key) != 0 for key in SCALARS):
                issues.append(f"post nonselected lane {lane} has scalar activity")
            for key in DURATION_KEYS:
                if timing.get(key) != {"count": 0, "total_nanoseconds": 0, "max_nanoseconds": 0}:
                    issues.append(f"post nonselected lane {lane} has {key} activity")
            if timing.get("observed_stream_id") != 0 or timing.get("enqueue_publication_races") != 0:
                issues.append(f"post nonselected lane {lane} has stream activity")
    summary: dict[str, Any] = {"schema_version": 1, "sequence": sequence, "selected_lane": selected_lane, "issues": issues}
    if selected_lane is not None and selected_lane in post:
        row = post[selected_lane]
        timing = row["timing"]
        durations = validate_timing(timing, selected_lane, issues)
        frames = row.get("reserved_data_frames", 0)
        payload = row.get("reserved_payload_bytes", 0)
        charged = row.get("reserved_allocation_charged_bytes", 0)
        frame_fields = ("data_enqueued_frames", "data_completed_frames", "physical_attempt_frames", "physical_success_frames")
        payload_fields = ("data_enqueued_payload_bytes", "data_completed_payload_bytes", "physical_attempt_payload_bytes", "physical_success_payload_bytes")
        if frames <= 0 or any(timing.get(key) != frames for key in frame_fields):
            issues.append("selected lane DATA frame conservation failed")
        if payload <= 0 or any(timing.get(key) != payload for key in payload_fields):
            issues.append("selected lane DATA payload conservation failed")
        wire = timing.get("physical_attempt_wire_bytes")
        if wire != timing.get("physical_written_wire_bytes") or wire != timing.get("physical_success_wire_bytes") or wire != payload + frames * 12:
            issues.append("selected lane physical wire conservation failed")
        if charged < payload or charged % 4096 != 0 or charged > payload + frames * 4095:
            issues.append("selected lane allocation charge bounds failed")
        if any(timing.get(key) != 0 for key in BAD):
            issues.append("selected lane error, abandoned, or short-write counter nonzero")
        success_counts = (
            bucket(timing.get("data_enqueue_select_by_outcome", {}).get("accepted"), "selected.enqueue.accepted", issues)["count"],
            bucket(timing.get("data_completion_select_by_outcome", {}).get("success"), "selected.completion.success", issues)["count"],
            bucket(timing.get("data_call_by_outcome", {}).get("success"), "selected.call.success", issues)["count"],
            bucket(timing.get("physical_write_by_outcome", {}).get("success"), "selected.physical.success", issues)["count"],
        )
        if any(value != frames for value in success_counts):
            issues.append("selected lane successful duration call counts do not equal DATA frames")
        for group, unwanted in (
            ("data_enqueue_select_by_outcome", ("shutdown", "timeout")),
            ("data_completion_select_by_outcome", ("error", "shutdown", "timeout")),
            ("data_call_by_outcome", ("error", "shutdown", "timeout")),
            ("physical_write_by_outcome", ("error", "short_write")),
        ):
            for outcome in unwanted:
                current = bucket(timing.get(group, {}).get(outcome), f"selected.{group}.{outcome}", issues)
                if current != {"count": 0, "total_nanoseconds": 0, "max_nanoseconds": 0}:
                    issues.append(f"selected lane rejected outcome {group}.{outcome} is nonzero")
        if durations["data_call_total"]["total_nanoseconds"] != durations["data_enqueue_select_total"]["total_nanoseconds"] + durations["data_completion_select_total"]["total_nanoseconds"]:
            issues.append("selected lane DATA-call duration does not telescope")
        if durations["physical_write_total"]["total_nanoseconds"] > durations["data_call_total"]["total_nanoseconds"]:
            issues.append("selected lane physical duration exceeds DATA-call duration")
        waits = durations["credit_wait_total"]["count"]
        first, last = timing.get("first_wait_token"), timing.get("last_wait_token")
        if waits == 0:
            if first != 0 or last != 0:
                issues.append("selected lane has tokens without waits")
        elif not exact_int(first) or not exact_int(last) or first <= 0 or last < first or last - first + 1 != waits:
            issues.append("selected lane wait-token range does not conserve")
        causes = timing.get("credit_wait_by_cause", {})
        if row.get("byte_credit_zero_observations") != bucket(causes.get("byte_zero"), "selected.byte_zero", issues)["count"]:
            issues.append("selected lane byte-zero observation count mismatch")
        stream_zero = bucket(causes.get("stream_allocation_zero"), "selected.stream_zero", issues)["count"]
        session_zero = bucket(causes.get("session_allocation_zero"), "selected.session_zero", issues)["count"]
        both_zero = bucket(causes.get("stream_and_session_allocation_zero"), "selected.both_zero", issues)["count"]
        if row.get("stream_allocation_zero_observations") != stream_zero + both_zero:
            issues.append("selected lane stream-allocation-zero count mismatch")
        if row.get("session_allocation_zero_observations") != session_zero + both_zero:
            issues.append("selected lane session-allocation-zero count mismatch")
        races = timing.get("enqueue_publication_races")
        if not exact_int(races) or races > frames:
            issues.append("selected lane publication-race count invalid")
        summary["selected"] = {"lane": selected_lane, "stream_id": timing.get("observed_stream_id"), "frames": frames, "payload_bytes": payload, "wire_bytes": wire, "allocation_charged_bytes": charged, "durations": durations, "enqueue_publication_races": races}
    summary["accepted"] = not issues
    return summary


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--pre", required=True, type=Path)
    parser.add_argument("--post", required=True, type=Path)
    parser.add_argument("--sequence", required=True, type=int)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    try:
        result = validate_pair(json.loads(args.pre.read_text()), json.loads(args.post.read_text()), args.sequence)
    except Exception as error:
        result = {"schema_version": 1, "sequence": args.sequence, "selected_lane": None,
                  "issues": [f"malformed sender snapshot input: {error!r}"], "accepted": False}
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    raise SystemExit(0 if result["accepted"] else 1)


if __name__ == "__main__":
    main()
