//go:build linux

package server

import (
	"crypto/subtle"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
)

const (
	qualificationWANSenderWaitEnv          = "P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT"
	qualificationWANSenderWaitBearerEnv    = "P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_BEARER"
	qualificationWANSenderWaitSequencesEnv = "P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_SEQUENCES"
	qualificationWANSenderWaitSequences    = "9,11,14,15"
)

type qualificationWANSenderWaitOwner struct {
	bearer    string
	sequences map[string]struct{}
}

func qualificationWANSenderWaitOwnerFromEnv() (*qualificationWANSenderWaitOwner, error) {
	return newQualificationWANSenderWaitOwner(
		os.Getenv(qualificationWANSenderWaitEnv),
		os.Getenv(qualificationWANSenderWaitBearerEnv),
		os.Getenv(qualificationWANSenderWaitSequencesEnv),
	)
}

func newQualificationWANSenderWaitOwner(enabled, bearer, sequences string) (*qualificationWANSenderWaitOwner, error) {
	if enabled == "" && bearer == "" && sequences == "" {
		return nil, nil
	}
	if enabled != "1" {
		return nil, errors.New("WAN sender-wait diagnostic requires explicit enablement")
	}
	if !qualificationWANSenderWaitBearerValid(bearer) {
		return nil, errors.New("WAN sender-wait diagnostic bearer must be 32 lowercase-hex bytes")
	}
	if sequences != qualificationWANSenderWaitSequences {
		return nil, errors.New("WAN sender-wait diagnostic requires the fixed sustained sequence set")
	}
	configured := make(map[string]struct{}, 4)
	for _, sequence := range strings.Split(sequences, ",") {
		configured[sequence] = struct{}{}
	}
	return &qualificationWANSenderWaitOwner{bearer: bearer, sequences: configured}, nil
}

func qualificationWANSenderWaitBearerValid(bearer string) bool {
	if len(bearer) != 64 {
		return false
	}
	for _, value := range []byte(bearer) {
		if (value < '0' || value > '9') && (value < 'a' || value > 'f') {
			return false
		}
	}
	return true
}

func (owner *qualificationWANSenderWaitOwner) authorized(r *http.Request) bool {
	if owner == nil || r == nil {
		return false
	}
	authorization := r.Header.Get("Authorization")
	if !strings.HasPrefix(authorization, "Bearer ") {
		return false
	}
	provided := strings.TrimPrefix(authorization, "Bearer ")
	return len(provided) == len(owner.bearer) && subtle.ConstantTimeCompare([]byte(provided), []byte(owner.bearer)) == 1
}

func (owner *qualificationWANSenderWaitOwner) serveServerCapacityHTTP(w http.ResponseWriter, r *http.Request, app *App) {
	if !owner.authorized(r) {
		http.Error(w, "WAN sender-wait authorization failed", http.StatusUnauthorized)
		return
	}
	if r.Method != http.MethodGet || r.URL.Query().Get("wan_sender_wait_server_capacity") != "1" {
		http.Error(w, "invalid WAN sender-wait server capacity action", http.StatusBadRequest)
		return
	}
	sequence := r.URL.Query().Get("sequence")
	if _, configured := owner.sequences[sequence]; !configured {
		http.Error(w, "WAN sender-wait server capacity sequence is unavailable", http.StatusConflict)
		return
	}
	snapshot, err := qualificationWANReadWaitServerCapacity(app, sequence)
	if err != nil {
		http.Error(w, err.Error(), http.StatusServiceUnavailable)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(snapshot)
}

func TestQualificationWANSenderWaitAuthorization(t *testing.T) {
	bearer := strings.Repeat("a1", 32)
	owner, err := newQualificationWANSenderWaitOwner("1", bearer, qualificationWANSenderWaitSequences)
	if err != nil || owner == nil {
		t.Fatalf("create owner: owner=%v err=%v", owner, err)
	}
	for name, authorization := range map[string]string{
		"missing": "", "raw": bearer, "wrong": "Bearer " + strings.Repeat("b2", 32),
	} {
		t.Run(name, func(t *testing.T) {
			request := httptest.NewRequest(http.MethodGet, "/?wan_sender_wait_server_capacity=1&sequence=9", nil)
			request.Header.Set("Authorization", authorization)
			recorder := httptest.NewRecorder()
			owner.serveServerCapacityHTTP(recorder, request, nil)
			if recorder.Code != http.StatusUnauthorized {
				t.Fatalf("status=%d, want %d", recorder.Code, http.StatusUnauthorized)
			}
		})
	}
	for _, invalid := range [][3]string{
		{"", bearer, qualificationWANSenderWaitSequences},
		{"1", strings.Repeat("A1", 32), qualificationWANSenderWaitSequences},
		{"1", bearer, "9,11,13"},
	} {
		if got, err := newQualificationWANSenderWaitOwner(invalid[0], invalid[1], invalid[2]); err == nil || got != nil {
			t.Fatalf("invalid configuration accepted: %#v", invalid)
		}
	}
}
