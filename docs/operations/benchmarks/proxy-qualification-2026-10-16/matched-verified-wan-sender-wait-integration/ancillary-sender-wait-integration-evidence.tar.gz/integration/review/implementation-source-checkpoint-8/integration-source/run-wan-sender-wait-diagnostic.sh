#!/usr/bin/env bash
set -Eeuo pipefail

integration_dir=$(cd "$(dirname "$0")" && pwd)
sender_root=$(realpath "$integration_dir/..")
supervisor="$integration_dir/run-wan-sender-wait-arm.sh"
validator="$integration_dir/validate-wan-sender-wait-arm.py"
snapshot_validator="$integration_dir/validate-sender-wait-snapshot.py"
runner="$integration_dir/generated/qualify-proxy-agent-growth-wan-sender-wait.sh"
runner_generator="$integration_dir/build-runner-source.py"
runner_query_block="$integration_dir/runner-query-block.sh.txt"
runner_wrapper_block="$integration_dir/runner-wrapper-block.sh.txt"
base_runner="$integration_dir/../../wan-read-wait-stack-intern-source/integration-source/runs/sustained-matched-protocol-1/preflight/runner-rebuilt.sh"
sender_runner_patch="$sender_root/SENDER-WAIT-RUNNER.patch"
sender_control_patch="$sender_root/GO-CONTROL-PATCH.diff"
sender_design="$sender_root/DESIGN-PROPOSAL.md"
sender_observer_checkpoint="$integration_dir/../../wan-sender-wait-source/review/source-checkpoint-9/SHA256SUMS.txt"
sender_observer_patch="$integration_dir/../../wan-sender-wait-source/review/source-checkpoint-9/SOURCE-PATCH.diff"
sender_integration_checkpoint="$sender_root/review/implementation-source-checkpoint-8/SHA256SUMS.txt"
reviewed_integration_manifest="$sender_root/provenance/reviewed-integration-source-manifest-cp8.json"
reviewed_integration_verifier="$integration_dir/verify-reviewed-integration-manifest.py"
sender_build_manifest="$sender_root/provenance/audited-server-build-manifest.json"
sender_harness_receipt="$sender_root/provenance/copy-validator-binding-harness-receipt.json"
base_cp7_checkpoint="$sender_root/review/implementation-source-checkpoint-7/SHA256SUMS.txt"
base_cp7_reviewed_manifest="$sender_root/provenance/reviewed-integration-source-manifest.json"
base_cp7_runner="$sender_root/review/implementation-source-checkpoint-7/integration-source/generated/qualify-proxy-agent-growth-wan-sender-wait.sh"
query_dispatch_contract="$integration_dir/contracts/test-query-dispatch.sh"
snapshot_contract="$integration_dir/contracts/test-sender-wait-validator.py"
runner_binding_contract="$integration_dir/contracts/test-runner-sender-bindings.py"
arm_binding_contract="$integration_dir/contracts/test-sender-arm-bindings.py"
server_binary=""
aggregate_agent_binary=""
server_source_ref=""
aggregate_agent_source_ref=""
output_dir=""
size_mode=sustained

while (($#)); do
  case "$1" in
    --server-binary) server_binary=$2; shift 2 ;;
    --aggregate-agent-binary) aggregate_agent_binary=$2; shift 2 ;;
    --server-source-ref) server_source_ref=$2; shift 2 ;;
    --aggregate-agent-source-ref) aggregate_agent_source_ref=$2; shift 2 ;;
    --output-dir) output_dir=$2; shift 2 ;;
    --small-diagnostic) size_mode=small; shift ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done

[[ -x $server_binary && -x $aggregate_agent_binary && -x $supervisor && -x $validator &&
   -f $snapshot_validator && -x $runner && -x $runner_generator ]] || {
  echo "sender diagnostic binaries and harness executables are required" >&2
  exit 2
}
[[ -n $server_source_ref && -n $aggregate_agent_source_ref && -n $output_dir ]] || {
  echo "source refs and output directory are required" >&2
  exit 2
}
server_binary=$(realpath "$server_binary")
aggregate_agent_binary=$(realpath "$aggregate_agent_binary")
for tool in cmp jq openssl python3 sha256sum; do
  command -v "$tool" >/dev/null || { echo "$tool is required" >&2; exit 2; }
done

server_sha=$(sha256sum "$server_binary" | awk '{print $1}')
agent_sha=$(sha256sum "$aggregate_agent_binary" | awk '{print $1}')
[[ $(sha256sum "$base_runner" | awk '{print $1}') == e9e453206cd479e1d29b78c05cf4d0eaf0cbaefe3c6ff13f0ba9594235c3bea0 &&
   $(sha256sum "$sender_observer_checkpoint" | awk '{print $1}') == 9f96e06bfd571fdf3550d095e6818b949bff0e3cdd733394e7ce93299e965e30 &&
   $(sha256sum "$sender_observer_patch" | awk '{print $1}') == 02f5ab266a7c6225dcf242dacb70edcf322cc790420f62e0d9ec8ae1ec11d130 ]] || {
  echo "frozen sender observer, runner base, or integration checkpoint changed" >&2
  exit 2
}
[[ -f $sender_build_manifest && -f $sender_harness_receipt && -f $sender_integration_checkpoint &&
   -f $reviewed_integration_manifest && -f $reviewed_integration_verifier &&
   -f $base_cp7_checkpoint && -f $base_cp7_reviewed_manifest && -x $base_cp7_runner ]] || {
  echo "audited sender-duration build and cp8 harness receipts are unavailable" >&2; exit 2;
}
jq -e --arg server "$server_sha" --arg agent "$agent_sha" --arg server_ref "$server_source_ref" --arg agent_ref "$aggregate_agent_source_ref" \
  --arg base_runner "$(sha256sum "$base_cp7_runner" | awk '{print $1}')" \
  --arg base_checkpoint "$(sha256sum "$base_cp7_checkpoint" | awk '{print $1}')" \
  --arg base_reviewed "$(sha256sum "$base_cp7_reviewed_manifest" | awk '{print $1}')" '
  .diagnostic == "wan-sender-wait" and .diagnostic_only == true and .traffic_run == false and
  .base_source_ref == $server_ref and .aggregate_agent_source_ref == $agent_ref and
  .sender_observer_checkpoint_sha256 == "9f96e06bfd571fdf3550d095e6818b949bff0e3cdd733394e7ce93299e965e30" and
  .sender_observer_patch_sha256 == "02f5ab266a7c6225dcf242dacb70edcf322cc790420f62e0d9ec8ae1ec11d130" and
  .sender_integration_checkpoint_sha256 == $base_checkpoint and
  .reviewed_integration_source_manifest_sha256 == $base_reviewed and
  .source.pre_post_status == 0 and .module.pre_post_status == 0 and .toolchain.pre_post_status == 0 and
  .tests.normal_status == 0 and .tests.race_status == 0 and .ordinary_proof_status == 0 and
  .build.status == 0 and .build.source_compare_status == 0 and
  .runner_sha256 == $base_runner and
  .sender_snapshot_validator_sha256 == "de77c640a72236f4df2d482702ba21cdc225731bb0a0fef3dac14e915ed32da9" and
  .sender_runner_patch_sha256 == "7ea2f679c170e0580832c653afcb64e80fa27da9c8ea613f84092b9994ff6e27" and
  .sender_control_patch_sha256 == "dc60a099541ad9c67d35a5af46d8af2a94e2f277725f53f8e658598dd5515c9f" and
  .output.server_sha256 == $server and .output.agent_sha256 == $agent
' "$sender_build_manifest" >/dev/null || { echo "audited sender-duration build manifest did not bind the requested inputs" >&2; exit 2; }
jq -e --arg build_manifest "$(sha256sum "$sender_build_manifest" | awk '{print $1}')" \
  --arg integration_checkpoint "$(sha256sum "$sender_integration_checkpoint" | awk '{print $1}')" \
  --arg reviewed_manifest "$(sha256sum "$reviewed_integration_manifest" | awk '{print $1}')" \
  --arg runner "$(sha256sum "$runner" | awk '{print $1}')" \
  --arg helper "$(sha256sum "$integration_dir/../../wan-read-wait-capacity-source/validate-copy-record.py" | awk '{print $1}')" \
  --arg server "$server_sha" --arg agent "$agent_sha" '
  .schema_version == 1 and .action == "copy-validator-binding-harness-correction" and
  .diagnostic == "wan-sender-wait" and .accepted == true and
  .base_build_manifest_sha256 == $build_manifest and
  .base_integration_checkpoint_sha256 == "fa0f2237aef78d5253882eef1fc45942446f0d96627efa8e0234161858eedb34" and
  .base_reviewed_manifest_sha256 == "2eee698fdfa8322b42491f3b090ac7f3535c3046d3f3f827460cc142d8c4aca1" and
  .cp8_integration_checkpoint_sha256 == $integration_checkpoint and
  .cp8_reviewed_manifest_sha256 == $reviewed_manifest and .cp8_runner_sha256 == $runner and
  .copy_record_validator_sha256 == $helper and .server_binary_sha256 == $server and .agent_binary_sha256 == $agent and
  .base_source_ref == "8ac4c8df8237e37777ba2fac0da6f949da17bdea" and
  .aggregate_agent_source_ref == "8ac4c8df8237e37777ba2fac0da6f949da17bdea" and
  .sender_observer_checkpoint_sha256 == "9f96e06bfd571fdf3550d095e6818b949bff0e3cdd733394e7ce93299e965e30" and
  .sender_observer_patch_sha256 == "02f5ab266a7c6225dcf242dacb70edcf322cc790420f62e0d9ec8ae1ec11d130" and
  .base_runner_sha256 == "e9e453206cd479e1d29b78c05cf4d0eaf0cbaefe3c6ff13f0ba9594235c3bea0" and
  .sender_control_patch_sha256 == "dc60a099541ad9c67d35a5af46d8af2a94e2f277725f53f8e658598dd5515c9f" and
  .sender_snapshot_validator_sha256 == "de77c640a72236f4df2d482702ba21cdc225731bb0a0fef3dac14e915ed32da9" and
  .contracts.status == 0 and .contracts.source_pre_post_equal == true and
  .unchanged_go_source_and_binaries == true and .endpoint_execution_run == false and .traffic_run == false
' "$sender_harness_receipt" >/dev/null || { echo "cp8 harness correction receipt changed" >&2; exit 2; }

output_dir=$(realpath -m "$output_dir")
allowed_root=$(realpath -m "$integration_dir/runs")
[[ $output_dir == "$allowed_root"/* ]] || { echo "output must remain below $allowed_root" >&2; exit 2; }
[[ ! -e $output_dir ]] || { echo "output directory already exists: $output_dir" >&2; exit 2; }
mkdir -p "$output_dir/tls" "$output_dir/preflight"
python3 "$reviewed_integration_verifier" "$reviewed_integration_manifest" "$sender_root" \
  "$output_dir/preflight/reviewed-integration-source-verification.json"

rebuilt="$output_dir/preflight/runner-rebuilt.sh"
python3 "$runner_generator" "$base_runner" "$runner_query_block" "$runner_wrapper_block" "$rebuilt"
cmp "$rebuilt" "$runner"
printf '%s\n' verified > "$output_dir/preflight/generated-runner-consistency.status"

cert="$output_dir/tls/public.test.crt.pem"
key="$output_dir/tls/public.test.key.pem"
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes \
  -subj /CN=public.test -addext subjectAltName=DNS:public.test -days 1 \
  -keyout "$key" -out "$cert" >/dev/null 2>&1
cert=$(realpath "$cert")
key=$(realpath "$key")
openssl x509 -in "$cert" -noout -checkhost public.test >/dev/null
expected_leaf_sha256=$(openssl x509 -in "$cert" -outform DER | sha256sum | awk '{print $1}')
[[ $expected_leaf_sha256 =~ ^[0-9a-f]{64}$ ]]

write_pair_hashes() {
  local destination=$1
  python3 - "$destination" "$0" "$supervisor" "$validator" "$snapshot_validator" "$runner" \
    "$runner_generator" "$runner_query_block" "$runner_wrapper_block" "$base_runner" \
    "$sender_runner_patch" "$sender_control_patch" "$sender_design" "$sender_observer_checkpoint" \
    "$sender_observer_patch" "$sender_integration_checkpoint" "$reviewed_integration_manifest" "$reviewed_integration_verifier" "$sender_build_manifest" "$sender_harness_receipt" \
    "$base_cp7_checkpoint" "$base_cp7_reviewed_manifest" "$base_cp7_runner" \
    "$query_dispatch_contract" "$snapshot_contract" "$runner_binding_contract" "$arm_binding_contract" \
    "$server_binary" "$aggregate_agent_binary" "$cert" "$key" \
    "$server_source_ref" "$aggregate_agent_source_ref" "$expected_leaf_sha256" "$size_mode" <<'PY'
import hashlib, json, pathlib, sys
destination, *values = sys.argv[1:]
names = (
    "wrapper supervisor validator snapshot_validator runner runner_generator runner_query_block runner_wrapper_block base_runner "
    "sender_runner_patch sender_control_patch sender_design sender_observer_checkpoint sender_observer_patch "
    "sender_integration_checkpoint reviewed_integration_manifest reviewed_integration_verifier sender_build_manifest sender_harness_receipt "
    "base_cp7_checkpoint base_cp7_reviewed_manifest base_cp7_runner query_dispatch_contract snapshot_contract runner_binding_contract arm_binding_contract "
    "server_binary aggregate_agent_binary certificate_pem private_key_pem"
).split()
paths, tail = values[:len(names)], values[len(names):]
server_ref, agent_ref, fingerprint, size_mode = tail
def sha(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()
result = {
    "schema_version": 1, "diagnostic": "wan-sender-wait", "diagnostic_only": True,
    "size_mode": size_mode, "server_source_ref": server_ref,
    "aggregate_agent_source_ref": agent_ref, "expected_leaf_der_sha256": fingerprint,
    "sha256": {name: sha(path) for name, path in zip(names, paths)},
}
pathlib.Path(destination).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
PY
}
write_pair_hashes "$output_dir/pre-hashes.json"

common=(
  --server-binary "$server_binary"
  --aggregate-agent-binary "$aggregate_agent_binary"
  --server-source-ref "$server_source_ref"
  --aggregate-agent-source-ref "$aggregate_agent_source_ref"
  --cert "$cert"
  --key "$key"
  --expected-leaf-sha256 "$expected_leaf_sha256"
)
[[ $size_mode == sustained ]] || common+=(--small-diagnostic)

set +e
"$supervisor" "${common[@]}" --protocol h1 --output-dir "$output_dir/h1" \
  > "$output_dir/h1-supervisor.stdout.log" 2> "$output_dir/h1-supervisor.stderr.log"
h1_status=$?
set -e
printf '%s\n' "$h1_status" > "$output_dir/h1-arm.status"

h1_safe=0
if [[ -f $output_dir/h1/supervisor-lifecycle.json && -f $output_dir/h1/outer-namespaces.json ]] && \
  jq -e '.group_joined == true and .forced == false and
         .server_scope.systemd_run_status == 0 and .server_scope.resource_status == 0 and
         .server_scope.unit_joined == true and .server_scope.unit_query_status == 0 and
         .server_scope.unit_active_state != "failed" and
         .sender_evidence.terminal_status == 0 and .sender_evidence.terminal_validation_status == 0 and
         .sender_evidence.terminal_valid == true' "$output_dir/h1/supervisor-lifecycle.json" >/dev/null && \
  jq -e '.all_private == true and .shell_pid_is_one == true and .python_parent_is_one == true and
         .cgroup_namespace_unchanged == true and .owned.cgroup == .parent.cgroup' \
         "$output_dir/h1/outer-namespaces.json" >/dev/null; then
  h1_safe=1
fi
printf '%s\n' "$h1_safe" > "$output_dir/h1-safe-to-continue.status"

h2_started=0
h2_status=125
if ((h1_safe)); then
  h2_started=1
  set +e
  "$supervisor" "${common[@]}" --protocol h2 --output-dir "$output_dir/h2" \
    > "$output_dir/h2-supervisor.stdout.log" 2> "$output_dir/h2-supervisor.stderr.log"
  h2_status=$?
  set -e
else
  printf '%s\n' "H2 not started because H1 topology, resource, or terminal sender-ledger closure was not proved" \
    > "$output_dir/h2-not-started.txt"
fi
printf '%s\n' "$h2_started" > "$output_dir/h2-started.status"
printf '%s\n' "$h2_status" > "$output_dir/h2-arm.status"
write_pair_hashes "$output_dir/post-hashes.json"

pair_hashes_equal=0
cmp "$output_dir/pre-hashes.json" "$output_dir/post-hashes.json" && pair_hashes_equal=1
python3 - "$output_dir/final-status.json" "$h1_status" "$h1_safe" "$h2_started" "$h2_status" \
  "$pair_hashes_equal" "$size_mode" "$output_dir" <<'PY'
import json, pathlib, sys, time
destination, h1, h1_safe, h2_started, h2, hashes_equal, size_mode, root = sys.argv[1:]
root = pathlib.Path(root)
def accepted(arm):
    path = root / arm / "attestation.json"
    return path.is_file() and json.loads(path.read_text()).get("accepted") is True
value = {
    "schema_version": 1, "diagnostic": "wan-sender-wait", "diagnostic_only": True,
    "size_mode": size_mode, "performance_result": size_mode == "sustained", "order": ["h1", "h2"],
    "same_binaries_both_arms": True, "same_verified_certificate_both_arms": True,
    "fresh_outer_topology_per_started_arm": True,
    "h1": {"status": int(h1), "safe_to_continue": h1_safe == "1", "accepted": accepted("h1")},
    "h2": {"started": h2_started == "1", "status": int(h2), "accepted": accepted("h2")},
    "pre_post_hashes_equal": hashes_equal == "1",
}
value["accepted"] = (value["h1"]["status"] == 0 and value["h1"]["safe_to_continue"] and
                     value["h1"]["accepted"] and value["h2"]["started"] and
                     value["h2"]["status"] == 0 and value["h2"]["accepted"] and
                     value["pre_post_hashes_equal"])
value["finished_unix_nano"] = time.time_ns()
pathlib.Path(destination).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
PY
printf '%s\n' complete > "$output_dir/FINAL"
((h1_status == 0 && h1_safe == 1 && h2_started == 1 && h2_status == 0 && pair_hashes_equal == 1))
