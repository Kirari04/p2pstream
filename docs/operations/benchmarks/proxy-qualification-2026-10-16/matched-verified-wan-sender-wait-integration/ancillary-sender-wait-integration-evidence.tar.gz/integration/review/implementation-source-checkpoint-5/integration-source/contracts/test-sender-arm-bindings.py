#!/usr/bin/env python3
"""No-endpoint source contract for sender arm joins and fixed ordering."""

import ast
from pathlib import Path
import sys

source = Path(sys.argv[1]).read_text()
required = (
    'expected_sender_specs = {9: ("retained-warmup", 1), 11: ("steady", 1), 14: ("steady", 2), 15: ("steady", 3)}',
    'sender_record_order != [9, 11, 14, 15, "terminal"]',
    'transfer_row.get("diagnostic_sequence") == sequence',
    'transfer_row.get("measurement_stage") == expected_spec[0]',
    'transfer_row.get("transfer_direction") == "download"',
    'wall_contained = sender_interval_wall_contained(',
    '"request_wall_interval_contained": wall_contained',
    'record.get("measurement_start_valid") is True',
    'independent_pair.get("accepted") is True',
    'independent_terminal.get("accepted") is True',
    'independent_terminal.get("closure_valid") is True',
    'actual_control_names != expected_control_names',
    'supervisor.get("sender_evidence", {}).get("terminal_valid") is True',
    '"sender_duration_intervals": sender_intervals',
    '"sender_terminal_closure_valid": terminal_valid',
    '"performance_gate_enabled": not small',
)
missing = [text for text in required if text not in source]
if missing:
    raise SystemExit(f"sender arm join/gate source is incomplete: {missing!r}")
for forbidden in ("trace_reduction", "read-wait-reductions", "run_interned_trace_parser"):
    if forbidden in source:
        raise SystemExit(f"receiver trace dependency remained in sender arm validator: {forbidden}")

# Execute only the three pure validation helpers. These fixtures prove behavior,
# rather than merely checking that gate strings occur in the source.
tree = ast.parse(source)
helper_names = {
    "sender_interval_wall_contained",
    "sender_record_order_valid",
    "sender_terminal_record_cardinality_valid",
    "sender_terminal_closure_valid",
}
definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in helper_names]
if {node.name for node in definitions} != helper_names:
    raise SystemExit("pure sender arm validation helpers are incomplete")
namespace = {}
exec(compile(ast.Module(body=definitions, type_ignores=[]), "sender-arm-helpers", "exec"), namespace)

contains = namespace["sender_interval_wall_contained"]
pre = {"request_finished_unix_ns": 100}
post = {"request_started_unix_ns": 200}
copy = {"started_unix_ns": 101, "handler_return_unix_ns": 199}
assert contains(pre, post, copy) is True
assert contains(pre, post, {**copy, "started_unix_ns": 99}) is False
assert contains(pre, post, {**copy, "handler_return_unix_ns": 201}) is False
assert contains(pre, post, {**copy, "started_unix_ns": True}) is False
assert contains(pre, post, {**copy, "handler_return_unix_ns": 1 << 64}) is False

order_valid = namespace["sender_record_order_valid"]
assert order_valid([9, 11, 14, 15, "terminal"]) is True
assert order_valid([9, 14, 11, 15, "terminal"]) is False
assert order_valid([9, 11, 14, "terminal"]) is False
assert order_valid([9, 11, 14, 15, 15, "terminal"]) is False

terminal_cardinality_valid = namespace["sender_terminal_record_cardinality_valid"]
assert terminal_cardinality_valid([{"action": "terminal"}]) is True
assert terminal_cardinality_valid([]) is False
assert terminal_cardinality_valid([{"action": "terminal"}, {"action": "terminal"}]) is False

terminal_valid = namespace["sender_terminal_closure_valid"]
raw = {"response": "bounded"}
validation = {"accepted": True, "closure_valid": True}
record = {
    "diagnostic": "sender-duration", "action": "terminal", "status": 0,
    "validation_status": 0, "valid": True, "response": raw,
    "validation": validation,
}
assert terminal_valid(record, raw, validation, validation) is True
incomplete = {**validation, "closure_valid": False}
assert terminal_valid({**record, "validation": incomplete}, raw, incomplete, incomplete) is False
