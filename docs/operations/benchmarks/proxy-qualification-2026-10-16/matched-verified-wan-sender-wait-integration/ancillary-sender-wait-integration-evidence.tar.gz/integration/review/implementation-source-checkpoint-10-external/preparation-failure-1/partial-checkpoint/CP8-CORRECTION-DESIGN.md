# Checkpoint 8 copy-validator binding correction

Smoke attempt 1 stopped before endpoint creation because the generated runner
changed its working directory to the relocated sender integration root and then
looked for `./validate-copy-record.py`. The mature helper remains at the
capacity-fixture path and was already hashed by the arm supervisor, but that
path was not passed into the runner.

Checkpoint 8 makes only the following runtime-harness correction:

1. The arm passes the canonical mature helper path and its SHA-256 through two
   explicit runner options.
2. Before namespace creation, the runner canonicalizes the path, requires an
   executable regular file, verifies the supplied lowercase SHA-256, and
   exports the resulting path and digest.
3. Both values are named explicitly in the sudo preservation list. After the
   user/network namespace re-exec, the runner independently requires an
   absolute canonical executable regular file and recomputes the digest before
   any topology, endpoint, or transfer setup.
4. The relative lookup is removed. The helper is neither copied nor linked.
   The timed `run_transfer` body and all workload, resource, TLS, sender, copy,
   reuse, floor, and lifecycle policies remain unchanged.

The immutable audited build manifest continues to prove the unchanged Go
source and binary pair. Its historical cp7 runner, checkpoint, and reviewed
manifest fields are checked against the original frozen cp7 files rather than
reinterpreted as cp8 evidence. A new externally reviewed compatibility receipt
at `provenance/copy-validator-binding-harness-receipt.json` must separately bind
the exact original build manifest, original cp7 checkpoint and reviewed
manifest, cp8 checkpoint and reviewed manifest, cp8 runner, mature helper,
unchanged observer/control/snapshot inputs, source refs, binary pair, and an
accepted cp8 no-endpoint contract result. The receipt is absent at this
source-only checkpoint, so execution remains blocked.

The new no-endpoint contract checks the exact option, canonicalization, export,
sudo-preservation, and inner revalidation source bindings. It also exercises a
correct executable helper, a missing helper, and a byte-changed helper in an
owned temporary directory and preserves a bounded JSON result. It does not
create namespaces or endpoints.
