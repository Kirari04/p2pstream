#!/usr/bin/env python3
"""No-endpoint contract for the copy-validator path and hash binding."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

if len(sys.argv) != 5:
    raise SystemExit("usage: test-copy-validator-binding.py RUNNER ARM HELPER FRESH_WORK")
runner_path, arm_path, helper_path, work_path = map(Path, sys.argv[1:])
runner = runner_path.read_text()
arm = arm_path.read_text()

required_once = (
    "--copy-record-validator) copy_record_validator=$2; shift 2 ;;",
    "--copy-record-validator-sha256) copy_record_validator_sha256=$2; shift 2 ;;",
    'copy_record_validator=$(realpath "$copy_record_validator")',
    "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR=$copy_record_validator",
    "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256=$copy_record_validator_sha256",
    "copy_record_validator=${P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR:?copy record validator is required}",
    "copy_record_validator_sha256=${P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256:?copy record validator hash is required}",
    '$(readlink -f "$copy_record_validator") == "$copy_record_validator"',
    "copy record validator changed across namespace re-exec",
)
for value in required_once:
    actual = runner.count(value)
    if actual != 1:
        raise SystemExit(f"runner binding cardinality changed: {value!r} count={actual}")

preserve = next((line for line in runner.splitlines() if "exec sudo -n --preserve-env=" in line), "")
for name in (
    "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR",
    "P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256",
):
    if preserve.count(name) != 1:
        raise SystemExit(f"sudo re-exec does not preserve exactly one {name}")

if "copy_record_validator=./validate-copy-record.py" in runner:
    raise SystemExit("runner retains the relocated relative validator lookup")
for value in (
    '--copy-record-validator "$copy_record_validator"',
    '--copy-record-validator-sha256 "$(sha256sum "$copy_record_validator" | awk \'{print $1}\')"',
):
    if arm.count(value) != 1:
        raise SystemExit(f"arm does not pass exact helper binding: {value!r}")

def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()

def check(path: Path, expected: str) -> tuple[bool, str | None]:
    try:
        canonical = path.resolve(strict=True)
        valid = canonical.is_file() and os.access(canonical, os.X_OK)
        valid = valid and len(expected) == 64 and all(char in "0123456789abcdef" for char in expected)
        valid = valid and digest(canonical) == expected
        return valid, str(canonical)
    except (FileNotFoundError, OSError):
        return False, None

if work_path.exists():
    raise SystemExit("fresh contract work directory is required")
work_path.mkdir(mode=0o700, parents=True)
known_sha = digest(helper_path)
if known_sha != "f1c70a2f347a77975a00330d4d37929700b1a38bac5fa195c3dff02b3f773c26":
    raise SystemExit("mature copy validator hash changed")

correct = work_path / "correct-validator.py"
shutil.copyfile(helper_path, correct)
correct.chmod(0o700)
changed = work_path / "changed-validator.py"
shutil.copyfile(helper_path, changed)
with changed.open("ab") as stream:
    stream.write(b"\n# changed contract fixture\n")
changed.chmod(0o700)
cases = []
for name, path, expected, want in (
    ("correct", correct, known_sha, True),
    ("missing", work_path / "missing-validator.py", known_sha, False),
    ("changed", changed, known_sha, False),
):
    actual, canonical = check(path, expected)
    cases.append({"case": name, "expected": want, "actual": actual, "canonical_path": canonical})
    if type(actual) is not bool or actual is not want:
        raise SystemExit(f"copy-validator binding case failed: {name} expected={want} actual={actual}")

result = {
    "schema_version": 1,
    "accepted": True,
    "case_count": len(cases),
    "helper_sha256": known_sha,
    "static_reexec_binding": True,
    "cases": cases,
}
output = work_path / "summary.json"
with output.open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
