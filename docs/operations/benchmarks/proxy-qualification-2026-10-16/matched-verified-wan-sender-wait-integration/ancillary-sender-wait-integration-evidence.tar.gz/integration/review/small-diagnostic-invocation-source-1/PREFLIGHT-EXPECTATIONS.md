# Sender-duration small diagnostic preflight

This is a source-only launch specification. It does not authorize or record an
execution. The literal command in `INVOCATION.txt` must remain blocked until the
audited build has published both fixed binary paths and the build manifest
expected by the accepted checkpoint-7 coordinator.

## Immutable coordinator inputs

* Coordinator SHA-256: `b16c33b3b792b04730f690edc48ef96cdc02b02b431f3b8f74b8d066d4ad5000`.
* Arm supervisor SHA-256: `c80e29332efa74ac725b5a89a5867e052adc50e2f8cbdc50fd1d014bc49dfd4e`.
* Generated timed runner SHA-256: `404f2edcfdaf39620de3b75195c4e9317b83782565318d3c3ca17bda023fdc1c`.
* Arm validator SHA-256: `69a65e1988ae975f1ae840264a8cf6e6e6aa39a3214e4926022877f253a30d70`.
* Snapshot validator SHA-256: `de77c640a72236f4df2d482702ba21cdc225731bb0a0fef3dac14e915ed32da9`.
* Checkpoint-7 manifest SHA-256: `fa0f2237aef78d5253882eef1fc45942446f0d96627efa8e0234161858eedb34`.
* Reviewed 27-file integration manifest SHA-256: `2eee698fdfa8322b42491f3b090ac7f3535c3046d3f3f827460cc142d8c4aca1`.
* Reviewed-manifest verification SHA-256: `cc02704922903f166d46089956617c63de8a6b478e3db11f23aac6527c268b23`.
* Accepted no-endpoint contract receipt SHA-256: `3c2fe28e32e01e137024761c41f0005af319641f3a22140899f9db880f08da62`.
* Base source reference for both binaries: `8ac4c8df8237e37777ba2fac0da6f949da17bdea`.

Before creating the output directory or any endpoint, the coordinator must find
both fixed binaries executable and must validate
`provenance/audited-server-build-manifest.json`. That manifest must bind the
requested binary hashes, both source references, checkpoint-7, the reviewed
integration manifest, the generated runner and snapshot validator, the sender
source/control patches, normal and race tests, ordinary-code proof, audited
build, and unchanged source/module/toolchain checks. Missing, unhashed, stale,
or self-consistent-but-unapproved inputs must exit 2. The two binaries and the
manifest are intentionally absent from the prospective receipt until the
audited build and publication receive separate review.

## Fixed small-diagnostic behavior

The command pins the inherited affinity to CPUs `0-15`. The unchanged runner
slices that ordered affinity into server `0-3`, agent `4-7`, and load `8-15`;
server and agent each retain `GOMAXPROCS=4`. Each arm uses one aggregate-only
cohort with 16 transfers, 4 MiB warmup and steady payloads, three steady
repetitions, a 2 MiB pool requirement, 80 ms RTT, and selected download
sequences `9,11,14,15`. The `--small-diagnostic` mode is distinct from the old
12/13-row smoke mode. It records the 29.7 MB/s floor but does not classify this
small integration check as a performance result.

The coordinator creates one fresh P-256 certificate with SAN `public.test`,
derives its leaf DER SHA-256 independently, and gives the same verified
certificate to the fresh H1 and H2 arms. H1 runs first. H2 may start only after
H1 proves the mature continuation gates: natural outer-group join, no forced
cleanup, successful finite server-scope/resource checks, natural systemd unit
closure, valid terminal sender-ledger closure, private user/PID/mount/net
topology, PID 1, and unchanged cgroup namespace.

The server alone joins the delegated `MemoryMax=4294967296`,
`MemorySwapMax=0` scope before workload release. Existing adaptive-capacity,
leaf-cgroup, resource-event, payload, TLS/protocol, pool, copy, HTTP trace reuse,
origin-identity, lifecycle, and exact 30-second idle-age checks remain active.
The timed `run_transfer` body remains the accepted 7,350-byte source with
SHA-256 `b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798`.

For selected rows, the server sender-capacity owner and the agent schema-2 drain
owner are enabled with the same process-local random bearer. Server capacity is
queried in the server namespace; agent drain is queried through `agent_ns`.
Only bounded response/status/provenance envelopes persist and contain the fixed
`bearer-present` marker, never the token or Authorization value. The old WAN
read-wait execution-trace environment is explicitly cleared at launch and is
not set by the sender runner; no trace capture or parser/reducer path runs.

The output root must be fresh and remain below the coordinator's `runs`
directory. Pre/post harness, binary, certificate, and key hashes must compare
equal. The private key, bearer, readiness files, and live endpoint state remain
private run artifacts and are not prospective export inputs.
