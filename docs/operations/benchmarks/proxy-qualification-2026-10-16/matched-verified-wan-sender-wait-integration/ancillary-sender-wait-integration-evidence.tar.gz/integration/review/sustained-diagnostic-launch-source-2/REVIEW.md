# Sustained sender-duration launch gate

This source-only launcher is unexecuted. It adds no diagnostic, runner, Go,
binary, timing, topology, or acceptance change. It invokes the exact sustained
command from `sustained-diagnostic-invocation-source-1/INVOCATION.txt` only
after a fail-closed external preflight.

The preflight verifies the exact externally approved cp10 checkpoint,
reviewed manifest, compatibility receipt, active coordinator/arm/runner and
canonical validator, audited build records, publication receipt and corrected
publication ledger, scoped cp10 static result, invocation, binary bytes and
modes. It then runs the reviewed 31-file corpus verifier against both the
active and frozen cp10 bytes into a fresh output and requires the deterministic
accepted result. Any mismatch or pre-existing workload output prevents the
coordinator from starting.

The preflight records only hashes, paths, modes, statuses, and the bounded
review receipt. It records no bearer, Authorization header, certificate key,
readiness content, or process environment. After the coordinator returns it
runs the same corpus verifier again, compares pre/post results, retains the
coordinator's exact status, and makes a source mutation fail with status 70.
The coordinator remains the sole owner of endpoint and cgroup lifecycle.

The prior cp10 static direct statuses are all zero and its source pre/post is
identical. Its surrounding tool envelope returned status one with empty output
and remains separately disclosed as unexplained and non-green; it was not
rerun. The main Astra process will invoke this reviewed launcher with a simple
absolute Bash command and own the outer process/tool envelope.
