#!/usr/bin/env python3
"""Source contract for the non-self-referential reviewed-corpus binding."""

from pathlib import Path
import sys

if len(sys.argv) != 4:
    raise SystemExit("usage: test-reviewed-integration-bindings.py VERIFIER ARM COORDINATOR")

verifier, arm, coordinator = [Path(path).read_text() for path in sys.argv[1:]]
for required in (
    'manifest["checkpoint_manifest_path"] != "review/implementation-source-checkpoint-11/SHA256SUMS.txt"',
    'manifest["files"] != checkpoint_files',
    'active_sha != expected or frozen_sha != expected',
    'os.O_WRONLY | os.O_CREAT | os.O_EXCL',
):
    if required not in verifier:
        raise SystemExit(f"reviewed-corpus verifier gate missing: {required}")

for name, source in (("arm", arm), ("coordinator", coordinator)):
    for required in (
        'reviewed-integration-source-manifest-cp11.json',
        'implementation-source-checkpoint-11/SHA256SUMS.txt',
        'sender-validator-manifest-correction-receipt-cp11.json',
        '.reviewed_integration_source_manifest_sha256 == $base_reviewed',
        '.cp11_integration_checkpoint_sha256 == $integration_checkpoint',
        '.cp11_reviewed_manifest_sha256 == $reviewed_manifest',
        '.cp11_runner_sha256 == $runner',
        '.cp9_contracts.direct_status == 0',
        '.offline_validator_contract.outer_tool_status == 1',
        '.offline_verification.outer_tool_status == 1',
        '.cp9_contracts.manifest_sha256 == "e339f8608083bc950185b2e32d09cf6cc49f076972e4c3f0aaa2ec91c138f1ad"',
        '.offline_validator_contract.closure_manifest_sha256 == "0dba2c08cef3762eabc8a1edcae56e950f4553ee3fb72035feca7c5a87f72aea"',
        '.offline_validator_contract.outer_disclosure_sha256 == "12c9011eb736137d22cb98c132eb54a1c2de274a86d0ac4d1a54e25f27119853"',
        '.offline_verification.h1_attestation_sha256 == "831d254ec6d942226559ae0da00779d6c8d5b0a6e94889c61ee96116c032c5cb"',
        '.offline_verification.h2_attestation_sha256 == "2c9ff14a982ce48ad24e28ee77c22044ad7d0346ee7eef8fde526c9283180b2c"',
        '.independent_artifact_closure.ledger_sha256 == "0da828d0f502885eac89b3dc2b50f44b2766ed10316ac5fbdcf8fc20aeee7f18"',
        '.cp10_receipt_sha256 == "e9453df0e13a2c342e8e802712206d991c478f0a36d6f291b10053229de2abc6"',
        '.cp9_harness_receipt_sha256 == "11b3f6cfbd1de9a8ff612ef483b127b87e16d4099debc369d5f5db542fc9d53e"',
        'verify-reviewed-integration-manifest.py',
    ):
        if required not in source:
            raise SystemExit(f"{name} reviewed-corpus binding missing: {required}")
    if 'sender_integration_checkpoint_sha256 == "39eac961' in source:
        raise SystemExit(f"{name} still claims checkpoint3 covers the final corpus")
