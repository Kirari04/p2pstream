# Sustained sender-duration diagnostic 1

This source-only invocation is unexecuted. It becomes eligible only after external review and exact publication of cp10 checkpoint `b532337700b7e3b17e1debc3a90ef8f786317d58bfb54449bf577616bd1514f3`, reviewed corpus `78820279349001e1af0ba24cce843030b795f5e52548bd39548071204cc41ea3`, and compatibility receipt `e9453df0e13a2c342e8e802712206d991c478f0a36d6f291b10053229de2abc6`. The original cp9 checkpoint, contract receipt, build manifest, smoke artifacts, and rejected attestations remain immutable.

The compatibility receipt records direct status zero and unresolved outer tool-envelope status one for both the nine-case validator contract and corrected same-evidence H1/H2 offline validation. External launch review must bind those nonzero outer records rather than treating the receipt as coordinator-only approval.

The invocation omits `--small-diagnostic`, selecting the existing sustained mode: one H1 arm then closure-gated H2, 16 transfers per arm, 256 MiB warmup and steady payloads, three steady repetitions, 8 MiB required pool, 80 ms RTT, selected sender sequences 9/11/14/15, 29.7 MB/s download floor gating, 30-second idle policy, verified `public.test` TLS, fresh topology and certificate per pair, CPUs 0-3/4-7/8-15, and server-only 4 GiB/no-swap delegated cgroup. The generated runner and timed `run_transfer` remain byte-identical to cp9.

The output path must be absent. The active integration source must exactly match the reviewed cp10 manifest; the unchanged server/agent binaries must hash to `f2e6cf390fdcd727b8c7120a6d877dc3a53afe9d8b970aa7b0d7f6cc892a7bdc` and `43eadb7664d70f9585887ac824cc7e6dcb55d6fa40731e3888b6fa5a1cc8d74f`. No old receiver trace control is enabled. This is diagnostic evidence, not WAN qualification.
