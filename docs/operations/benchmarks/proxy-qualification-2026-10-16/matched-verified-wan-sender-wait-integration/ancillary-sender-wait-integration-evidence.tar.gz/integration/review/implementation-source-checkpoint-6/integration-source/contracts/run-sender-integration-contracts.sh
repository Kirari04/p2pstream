#!/usr/bin/env bash
set -Eeuo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
sender_root=$(realpath "$root/..")
base="$root/../../wan-read-wait-stack-intern-source/integration-source/runs/sustained-matched-protocol-1/preflight/runner-rebuilt.sh"
work=${1:?fresh owned work directory is required}
[[ ! -e $work ]] || { echo "contract work directory already exists" >&2; exit 2; }
mkdir -m 0700 "$work"
for script in \
  "$root/run-wan-sender-wait-arm.sh" \
  "$root/run-wan-sender-wait-diagnostic.sh" \
  "$root/generated/qualify-proxy-agent-growth-wan-sender-wait.sh" \
  "$root/contracts/test-query-dispatch.sh"; do
  bash -n "$script"
done
for source in \
  "$root/validate-sender-wait-snapshot.py" \
  "$root/validate-wan-sender-wait-arm.py" \
  "$root/verify-reviewed-integration-manifest.py" \
  "$root/build-runner-source.py" \
  "$root/contracts/test-sender-wait-validator.py" \
  "$root/contracts/test-runner-sender-bindings.py" \
  "$root/contracts/test-sender-arm-bindings.py" \
  "$root/contracts/test-reviewed-integration-bindings.py"; do
  python3 -I -B -c 'import ast, pathlib, sys; ast.parse(pathlib.Path(sys.argv[1]).read_text(), filename=sys.argv[1])' "$source"
done
python3 -I -B "$root/build-runner-source.py" "$base" "$root/runner-query-block.sh.txt" \
  "$root/runner-wrapper-block.sh.txt" "$work/runner-rebuilt.sh"
cmp "$work/runner-rebuilt.sh" "$root/generated/qualify-proxy-agent-growth-wan-sender-wait.sh"
python3 -I -B "$root/contracts/test-runner-sender-bindings.py" \
  "$root/generated/qualify-proxy-agent-growth-wan-sender-wait.sh" \
  "$root/validate-sender-wait-snapshot.py"
python3 -I -B "$root/contracts/test-sender-wait-validator.py" "$root/validate-sender-wait-snapshot.py"
python3 -I -B "$root/contracts/test-sender-arm-bindings.py" \
  "$root/validate-wan-sender-wait-arm.py" "$work/arm-validator-behavior"
python3 -I -B "$root/contracts/test-reviewed-integration-bindings.py" \
  "$root/verify-reviewed-integration-manifest.py" \
  "$root/run-wan-sender-wait-arm.sh" "$root/run-wan-sender-wait-diagnostic.sh"
bash "$root/contracts/test-query-dispatch.sh" "$work/query-dispatch"
python3 -I -B - "$base" "$root/generated/qualify-proxy-agent-growth-wan-sender-wait.sh" "$work/run-transfer-hashes.json" <<'PY'
import hashlib, json, pathlib, re, sys
base, generated, out = map(pathlib.Path, sys.argv[1:])
def function(source, name):
    text = source.read_text()
    match = re.search(rf'(?m)^{re.escape(name)}\(\) \{{\n', text)
    if not match:
        raise SystemExit(f"missing {name}")
    start = match.start()
    depth = 0
    for pos in range(match.start(), len(text)):
        if text[pos] == "{": depth += 1
        elif text[pos] == "}":
            depth -= 1
            if depth == 0:
                return text[start:pos + 1].encode()
    raise SystemExit(f"unterminated {name}")
values = [function(path, "run_transfer") for path in (base, generated)]
result = {"schema_version": 1, "equal": values[0] == values[1],
          "bytes": len(values[1]), "sha256": hashlib.sha256(values[1]).hexdigest()}
pathlib.Path(out).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
if result != {"schema_version": 1, "equal": True, "bytes": 7350,
              "sha256": "b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798"}:
    raise SystemExit(f"timed transfer changed: {result!r}")
PY
printf '%s\n' complete > "$work/FINAL"
