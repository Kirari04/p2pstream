#!/usr/bin/env python3
from pathlib import Path
import sys

source, query_block, wrapper_block, destination = map(Path, sys.argv[1:])
s = source.read_text()
s = s.replace('''  expected_leaf_sha256=""
  smoke_mode=0''', '''  expected_leaf_sha256=""
  sender_wait_validator=""
  sender_wait_validator_sha256=""
  smoke_mode=0''', 1)
s = s.replace('''      --expected-leaf-sha256) expected_leaf_sha256=$2; shift 2 ;;
      --smoke)''', '''      --expected-leaf-sha256) expected_leaf_sha256=$2; shift 2 ;;
      --sender-wait-validator) sender_wait_validator=$2; shift 2 ;;
      --sender-wait-validator-sha256) sender_wait_validator_sha256=$2; shift 2 ;;
      --smoke)''', 1)
s = s.replace('''  [[ $expected_leaf_sha256 =~ ^[0-9a-f]{64}$ ]] || { echo "--expected-leaf-sha256 must be lowercase SHA-256 hex" >&2; exit 2; }
  mkdir -p''', '''  [[ $expected_leaf_sha256 =~ ^[0-9a-f]{64}$ ]] || { echo "--expected-leaf-sha256 must be lowercase SHA-256 hex" >&2; exit 2; }
  [[ -f $sender_wait_validator && $sender_wait_validator_sha256 =~ ^[0-9a-f]{64}$ ]] || {
    echo "--sender-wait-validator and its lowercase SHA-256 are required" >&2; exit 2;
  }
  [[ $(sha256sum "$sender_wait_validator" | awk '{print $1}') == "$sender_wait_validator_sha256" ]] || {
    echo "sender-wait validator hash mismatch" >&2; exit 2;
  }
  mkdir -p''', 1)
s = s.replace('''  export P2PSTREAM_GROWTH_PROTOCOL P2PSTREAM_GROWTH_CERT P2PSTREAM_GROWTH_KEY P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256
  export P2PSTREAM_GROWTH_SMOKE_MODE''', '''  export P2PSTREAM_GROWTH_PROTOCOL P2PSTREAM_GROWTH_CERT P2PSTREAM_GROWTH_KEY P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256
  export P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256
  export P2PSTREAM_GROWTH_SMOKE_MODE''', 1)
s = s.replace('''  P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256=$expected_leaf_sha256
  P2PSTREAM_GROWTH_SMOKE_MODE''', '''  P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256=$expected_leaf_sha256
  P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR=$(realpath "$sender_wait_validator")
  P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256=$sender_wait_validator_sha256
  P2PSTREAM_GROWTH_SMOKE_MODE''', 1)
s = s.replace('''P2PSTREAM_GROWTH_PROTOCOL,P2PSTREAM_GROWTH_CERT,P2PSTREAM_GROWTH_KEY,P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256,P2PSTREAM_GROWTH_SMOKE_MODE''', '''P2PSTREAM_GROWTH_PROTOCOL,P2PSTREAM_GROWTH_CERT,P2PSTREAM_GROWTH_KEY,P2PSTREAM_GROWTH_EXPECTED_LEAF_SHA256,P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR,P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256,P2PSTREAM_GROWTH_SMOKE_MODE''', 1)
s = s.replace('for tool in ip tc nsenter jq python3 taskset openssl sha256sum',
              'for tool in awk ip tc nsenter jq python3 taskset openssl sha256sum', 1)
start = s.index('read_wait_trace_dir=${output%.jsonl}.read-wait-traces')
end = s.index('\n\npython3 - "$server_scope_control_dir/runner-owned-namespaces.json"', start)
variables = '''sender_wait_control_dir=${output%.jsonl}.sender-wait-controls
[[ ! -e $sender_wait_control_dir ]] || { echo "sender-wait artifact directory already exists" >&2; exit 2; }
mkdir -m 0700 "$sender_wait_control_dir"
sender_wait_bearer=$(openssl rand -hex 32)
sender_wait_sequences=9,11,14,15
sender_wait_records=${output%.jsonl}.sender-wait-records.jsonl
[[ ! -e $sender_wait_records ]] || { echo "sender-wait record already exists" >&2; exit 2; }
: > "$sender_wait_records"
sender_wait_validator=${P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR:?sender-wait validator is required}
sender_wait_validator_sha256=${P2PSTREAM_GROWTH_SENDER_WAIT_VALIDATOR_SHA256:?sender-wait validator hash is required}
[[ -f $sender_wait_validator && $sender_wait_validator_sha256 =~ ^[0-9a-f]{64}$ ]] || {
	echo "sender-wait validator binding is unavailable" >&2; exit 2;
}
[[ $(sha256sum "$sender_wait_validator" | awk '{print $1}') == "$sender_wait_validator_sha256" ]] || {
	echo "sender-wait validator changed across namespace re-exec" >&2; exit 2;
}
((smoke_mode == 0)) || { echo "sender-wait diagnostic has only the fixed sustained sequence set" >&2; exit 2; }'''
s = s[:start] + variables + s[end:]
start = s.index('wan_read_wait_control() {')
end = s.index('cgroup_snapshot() {', start)
s = s[:start] + query_block.read_text() + s[end:]
start = s.index('wan_read_wait_should_trace() {')
end = s.index('run_tiny_response() {', start)
s = s[:start] + wrapper_block.read_text() + s[end:]
s = s.replace('run_maybe_traced_transfer ', 'run_maybe_sender_wait_transfer ')
old_server = '''\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE=1 \\
\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_DIR="$read_wait_trace_dir" \\
\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_SEQUENCES="$read_wait_trace_sequences" \\
\t\tP2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_BEARER="$read_wait_trace_bearer" \\
'''
new_server = '''\t\tP2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT=1 \\
\t\tP2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_SEQUENCES="$sender_wait_sequences" \\
\t\tP2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_BEARER="$sender_wait_bearer" \\
'''
if s.count(old_server) != 1:
    raise SystemExit(f'server trace environment block count {s.count(old_server)}')
s = s.replace(old_server, new_server)
old_agent = '''      P2PSTREAM_QUALIFICATION_AGENT_TUNNELS=4 \\
      GOMAXPROCS=4 \\
'''
new_agent = '''      P2PSTREAM_QUALIFICATION_AGENT_TUNNELS=4 \\
      P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT=1 \\
      P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_SEQUENCES="$sender_wait_sequences" \\
      P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_BEARER="$sender_wait_bearer" \\
      GOMAXPROCS=4 \\
'''
if s.count(old_agent) != 2:
    raise SystemExit(f'agent environment block count {s.count(old_agent)}')
s = s.replace(old_agent, new_agent)
old_terminal = '''\tcgroup_snapshot "$server_pid" > "$server_scope_control_dir/server-cgroup-post-workload.json"
  stop_process "$label-$iteration-agent" "$agent_process_pid" "$agent_stop"
'''
new_terminal = '''\tlocal sender_terminal_status=0 sender_terminal_validation_status=0
\tset +e
\twan_sender_wait_query agent-drain terminal 15 "$agent_admin" "$sender_wait_control_dir/terminal-sender.json"
\tsender_terminal_status=$?
\tpython3 "$sender_wait_validator" --mode terminal --terminal "$sender_wait_control_dir/terminal-sender.json" \\
\t\t--sequence 15 --output "$sender_wait_control_dir/terminal-validation.json"
\tsender_terminal_validation_status=$?
\tset -e
\tjq -cn --argjson status "$sender_terminal_status" --argjson validation_status "$sender_terminal_validation_status" \\
\t\t--slurpfile terminal "$sender_wait_control_dir/terminal-sender.json" \\
\t\t--slurpfile validation "$sender_wait_control_dir/terminal-validation.json" \\
\t\t'{schema_version:1,diagnostic:"sender-duration",action:"terminal",status:$status,
\t\t  validation_status:$validation_status,response:($terminal[0] // null),validation:($validation[0] // null),
\t\t  valid:($status == 0 and $validation_status == 0)}' \\
\t\t>> "$sender_wait_records"
\tcgroup_snapshot "$server_pid" > "$server_scope_control_dir/server-cgroup-post-workload.json"
  stop_process "$label-$iteration-agent" "$agent_process_pid" "$agent_stop"
'''
if s.count(old_terminal) != 1:
    raise SystemExit(f'terminal insertion point count {s.count(old_terminal)}')
s = s.replace(old_terminal, new_terminal)
destination.write_text(s)
