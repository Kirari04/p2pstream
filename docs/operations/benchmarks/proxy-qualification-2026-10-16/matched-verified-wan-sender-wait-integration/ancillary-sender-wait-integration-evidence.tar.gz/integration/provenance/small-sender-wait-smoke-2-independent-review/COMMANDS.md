# Offline review command statuses

- Canonical result-review final ledger: `sha256sum -c --quiet FINAL-SHA256SUMS.txt`, status 0 from the result-review directory.
- Initial canonical run-ledger check used `../../provenance/.../RUN-SHA256SUMS.txt`, status 1 because that relative path was one directory short. It did not inspect or mutate the run.
- Corrected canonical run-ledger check: `sha256sum -c --quiet ../../../provenance/small-sender-wait-smoke-2-result-review/RUN-SHA256SUMS.txt`, status 0 from the run root.
- Independent audit attempt 1: `python3 .../audit.py`, status 1 for the preserved control-lane predicate error described in `REPORT.md`.
- Independent audit revision 2: `python3 .../audit.py`, status 0.

No endpoint, workload, build, test suite, or original validator was run.
