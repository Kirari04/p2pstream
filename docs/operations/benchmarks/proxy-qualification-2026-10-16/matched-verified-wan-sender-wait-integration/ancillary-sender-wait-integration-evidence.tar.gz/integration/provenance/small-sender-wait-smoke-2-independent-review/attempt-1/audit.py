#!/usr/bin/env python3
import hashlib
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[2]
RUN = ROOT / "integration-source/runs/small-sender-wait-smoke-2"
CANONICAL = ROOT / "provenance/small-sender-wait-smoke-2-result-review"
SELECTED = (9, 11, 14, 15)
EXPECTED = [
    *(('warmup', 'download', n) for n in range(1, 5)),
    *(('warmup', 'upload', n) for n in range(1, 5)),
    ('retained-warmup', 'download', 1), ('retained-warmup', 'upload', 1),
    ('steady', 'download', 1), ('steady', 'upload', 1),
    ('steady', 'upload', 2), ('steady', 'download', 2),
    ('steady', 'download', 3), ('steady', 'upload', 3),
]
ACTIVE = (
    "active_credit_waits", "active_reserved_frames", "active_reserved_payload_bytes",
    "active_reserved_allocation_charged_bytes", "active_caller_frames",
    "active_caller_payload_bytes", "active_enqueue_frames", "active_enqueue_payload_bytes",
    "active_queued_frames", "active_queued_payload_bytes", "active_physical_frames",
    "active_physical_payload_bytes",
)
BAD = (
    "data_gather_error_frames", "data_gather_error_payload_bytes",
    "data_abandoned_frames", "data_abandoned_payload_bytes",
    "physical_error_frames", "physical_error_payload_bytes",
    "physical_error_attempt_wire_bytes", "physical_error_written_wire_bytes",
    "physical_short_frames", "physical_short_payload_bytes",
    "physical_short_attempt_wire_bytes", "physical_short_written_wire_bytes",
)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def lines(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]

def check(condition, message, issues):
    if not condition:
        issues.append(message)

def counter_conservation(counter, label, issues):
    timing = counter["timing"]
    frames = counter["reserved_data_frames"]
    payload = counter["reserved_payload_bytes"]
    charged = counter["reserved_allocation_charged_bytes"]
    frame_fields = ("data_enqueued_frames", "data_completed_frames", "physical_attempt_frames", "physical_success_frames")
    payload_fields = ("data_enqueued_payload_bytes", "data_completed_payload_bytes", "physical_attempt_payload_bytes", "physical_success_payload_bytes")
    check(frames > 0 and all(timing[k] == frames for k in frame_fields), f"{label}: frame conservation", issues)
    check(payload > 0 and all(timing[k] == payload for k in payload_fields), f"{label}: payload conservation", issues)
    wire = timing["physical_attempt_wire_bytes"]
    check(wire == timing["physical_written_wire_bytes"] == timing["physical_success_wire_bytes"] == payload + 12 * frames,
          f"{label}: wire conservation", issues)
    check(payload <= charged <= payload + frames * 4095 and charged % 4096 == 0,
          f"{label}: allocation charge bounds", issues)
    check(all(timing[k] == 0 for k in BAD), f"{label}: error/short/abandoned counters", issues)
    check(timing["data_call_total"]["count"] == frames, f"{label}: DATA call count", issues)
    check(timing["physical_write_total"]["count"] == frames, f"{label}: physical write count", issues)
    check(timing["data_call_total"]["total_nanoseconds"] ==
          timing["data_enqueue_select_total"]["total_nanoseconds"] + timing["data_completion_select_total"]["total_nanoseconds"],
          f"{label}: DATA call duration telescope", issues)
    check(timing["physical_write_total"]["total_nanoseconds"] <= timing["data_call_total"]["total_nanoseconds"],
          f"{label}: physical duration exceeds DATA call", issues)
    check(timing["complete"] is True and timing["reset_performed"] is True,
          f"{label}: incomplete/reset missing", issues)
    check(all(timing[k] == 0 for k in ACTIVE), f"{label}: active ownership remains", issues)
    check(timing["ambiguous"] is False and timing["overflow"] is False and
          timing["pending_credit_decision"] is False and timing["send_loop_terminated"] is False,
          f"{label}: ambiguous/overflow/pending/terminal flag", issues)
    return {"frames": frames, "payload_bytes": payload, "wire_bytes": wire,
            "allocation_charged_bytes": charged,
            "credit_wait_ns": timing["credit_wait_total"]["total_nanoseconds"],
            "data_call_ns": timing["data_call_total"]["total_nanoseconds"],
            "physical_write_ns": timing["physical_write_total"]["total_nanoseconds"]}

def audit_arm(arm):
    p = RUN / arm
    issues = []
    rows = lines(p / "results.jsonl")
    check(len(rows) == 16, f"{arm}: result count", issues)
    check([(r["measurement_stage"], r["transfer_direction"], r["repetition"]) for r in rows] == EXPECTED,
          f"{arm}: order", issues)
    major, alpn = (1, "http/1.1") if arm == "h1" else (2, "h2")
    pre = read(p / "pre-hashes.json")
    post = read(p / "post-hashes.json")
    check(pre == post, f"{arm}: pre/post provenance changed", issues)
    leaf = pre["expected_leaf_der_sha256"]
    copies = {}
    row_brief = []
    for seq, row in enumerate(rows, 1):
        check(row["diagnostic_sequence"] == seq, f"{arm}/{seq}: sequence", issues)
        check(row["attempted"] == row["useful_completed"] == 1 and row["errors"] == 0 and row["status_codes"] == {"200": 1},
              f"{arm}/{seq}: request result", issues)
        check(row["configured_payload_bytes"] == 4 * 1024 * 1024, f"{arm}/{seq}: configured payload", issues)
        expected_response = 4 * 1024 * 1024 if row["transfer_direction"] == "download" else 32
        check(row["response_bytes"] == expected_response, f"{arm}/{seq}: response bytes", issues)
        check(row["observed_http_major"] == major and row["observed_origin_http_major"] == 1 and row["public_protocol"] == arm,
              f"{arm}/{seq}: protocol", issues)
        tls = row["wan_response_tls"]
        check(len(tls) == 1 and tls[0]["http_major"] == major and tls[0]["negotiated_alpn"] == alpn and
              tls[0]["peer_leaf_der_sha256"] == leaf, f"{arm}/{seq}: TLS/ALPN/certificate", issues)
        matches = row["response_copy_attribution"]["matches"]
        check(not row["response_copy_attribution"]["overflow"] and len(matches) == 1,
              f"{arm}/{seq}: copy cardinality/overflow", issues)
        if len(matches) == 1:
            copy = matches[0]
            copies[seq] = copy
            body = copy["copy"]
            check(body["complete"] is True and body["read_errors"] == body["write_errors"] == body["short_writes"] == 0,
                  f"{arm}/{seq}: copy completion/errors", issues)
            check(body["upstream_read"]["bytes"] == body["downstream_write"]["bytes"] == expected_response,
                  f"{arm}/{seq}: copy bytes", issues)
            check(copy["handler_elapsed_ns"] > 0 and copy["started_unix_ns"] < copy["handler_return_unix_ns"],
                  f"{arm}/{seq}: copy interval", issues)
        row_brief.append({"sequence": seq, "direction": row["transfer_direction"], "wall_seconds": row["wall_seconds"],
                          "response_bytes": row["response_bytes"]})

    lifecycle = lines(p / "results.lifecycle.jsonl")
    exits = [r for r in lifecycle if r.get("event") == "process-exit"]
    check(len(exits) == 5 and all(r["status"] == 0 and r["forced"] is False and r["group_joined"] is True and
                                  r["invalidates_success"] is False for r in exits), f"{arm}: five natural inner exits", issues)
    supervisor = read(p / "supervisor-lifecycle.json")
    check(supervisor["runner_status"] == 0 and supervisor["group_joined"] is True and supervisor["forced"] is False and
          supervisor["invalidates_success"] is False, f"{arm}: outer runner lifecycle", issues)
    scope = supervisor["server_scope"]
    check(scope["systemd_run_status"] == scope["resource_status"] == scope["unit_query_status"] == 0 and
          scope["unit_joined"] is True and scope["unit_load_state"] == "not-found" and
          scope["unit_active_state"] == "inactive" and scope["unit_sub_state"] == "dead",
          f"{arm}: finite scope lifecycle", issues)
    outer = read(p / "outer-namespaces.json")
    check(outer["all_private"] is True and outer["shell_pid_is_one"] is True and outer["python_parent_is_one"] is True and
          outer["cgroup_namespace_unchanged"] is True, f"{arm}: outer namespace ownership", issues)
    resource = read(p / "server-scope/server-resource-attestation.json")
    check(resource["accepted"] is True and all(resource["checks"].values()), f"{arm}: resource attestation", issues)

    records = lines(p / "results.sender-wait-records.jsonl")
    check([r.get("sequence", r.get("action")) for r in records] == [9, 11, 14, 15, "terminal"],
          f"{arm}: sender record order", issues)
    interval_brief = []
    for record in records[:4]:
        seq = record["sequence"]
        check(record["complete"] is True and record["valid"] is True and record["measurement_start_valid"] is True and
              all(record[k] == 0 for k in ("transfer_status", "sender_pre_status", "sender_pre_validation_status",
                                           "sender_post_status", "sender_validation_status", "pre_resource_status",
                                           "pre_healthy_status", "post_runtime_status", "post_cgroup_status",
                                           "post_capacity_query_status", "post_healthy_status", "resource_status")),
              f"{arm}/{seq}: sender envelope/status", issues)
        before = record["pre_sender"]["request_finished_unix_ns"]
        after = record["post_sender"]["request_started_unix_ns"]
        copy = copies[seq]
        check(before <= copy["started_unix_ns"] <= copy["handler_return_unix_ns"] <= after,
              f"{arm}/{seq}: sender interval does not enclose copy wall interval", issues)
        counters = record["post_sender"]["response"]["send_counters"]
        selected = [c for c in counters if c["enabled"] and c["timing"]["stream_observed"]]
        check(len(selected) == 1, f"{arm}/{seq}: selected lane cardinality", issues)
        if len(selected) == 1:
            c = selected[0]
            stats = counter_conservation(c, f"{arm}/{seq}/lane{c['lane']}", issues)
            check(c["lane"] == record["sender_validation"]["selected_lane"] and
                  c["timing"]["observed_stream_id"] == record["sender_validation"]["selected"]["stream_id"],
                  f"{arm}/{seq}: lane/stream identity", issues)
            check(stats["frames"] == record["sender_validation"]["selected"]["frames"] and
                  stats["payload_bytes"] == record["sender_validation"]["selected"]["payload_bytes"] and
                  stats["wire_bytes"] == record["sender_validation"]["selected"]["wire_bytes"],
                  f"{arm}/{seq}: saved selected summary mismatch", issues)
            stats.update({"sequence": seq, "lane": c["lane"], "stream_id": c["timing"]["observed_stream_id"],
                          "copy_wall_enclosed": True})
            interval_brief.append(stats)
    terminal = records[-1]
    check(terminal["status"] == terminal["validation_status"] == 0 and terminal["valid"] is True and
          terminal["validation"]["accepted"] is True and terminal["validation"]["closure_valid"] is True,
          f"{arm}: terminal sender validation", issues)
    for c in terminal["response"]["response"]["send_counters"]:
        timing = c["timing"]
        check(all(timing[k] == 0 for k in ACTIVE), f"{arm}: terminal lane{c['lane']} active ownership", issues)
        check(timing["complete"] is True and timing["reset_performed"] is True,
              f"{arm}: terminal lane{c['lane']} incomplete/reset missing", issues)

    attestation = read(p / "attestation.json")
    check(attestation["validation_issues"] == ["preflight hash manifest is incomplete"] and
          attestation["classification"] == "observational-complete" and
          attestation["natural_endpoint_and_namespace_statuses"] is True and
          attestation["outer_runner_group_joined"] is True and
          attestation["server_only_delegated_cgroup"] is True and
          attestation["sender_terminal_closure_valid"] is True and
          all(x["valid"] and x["request_wall_interval_contained"] for x in attestation["sender_duration_intervals"]),
          f"{arm}: attestation raw gates/failure scope", issues)
    reuse = [x for x in attestation["reuse_expectations"] if x["kind"] == "same-key-revisit"]
    check([x["sequence"] for x in reuse] == [13, 14, 15, 16] and all(x["satisfied"] and
          x["elapsed_idle_ns"] < 30_000_000_000 and x["httptrace_idle_time_ns"] < 30_000_000_000 and
          x["observed_origin_connection_id"] == x["prior_origin_connection_id"] and
          x["connection_key"] == x["expected_connection_key"] for x in reuse),
          f"{arm}: same-key/same-origin reuse under 30s", issues)

    cleanup = read(p / "supervisor-cleanup.json")
    check(cleanup["forced_supervisor_cleanup"] is False and cleanup["entry_status"] == 1,
          f"{arm}: cleanup record", issues)
    return {
        "accepted_raw_correctness": not issues,
        "issues": issues,
        "rows": len(rows),
        "protocol_major": major,
        "verified_alpn": alpn,
        "inner_natural_exit_count": len(exits),
        "outer_runner_status": supervisor["runner_status"],
        "outer_runner_group_joined": supervisor["group_joined"],
        "forced": supervisor["forced"],
        "resource_peak_bytes": resource["post"]["memory_peak_bytes"],
        "resource_limit_bytes": resource["post"]["memory_max_bytes"],
        "selected_sender_intervals": interval_brief,
        "same_key_reuse_idle_ns": {str(x["sequence"]): x["elapsed_idle_ns"] for x in reuse},
        "arm_validator_status": int((p / "validation.status").read_text().strip()),
        "arm_validator_stderr": (p / "validation.stderr.log").read_text().strip(),
        "cleanup_entry_status": cleanup["entry_status"],
        "cleanup_forced": cleanup["forced_supervisor_cleanup"],
        "row_brief": row_brief,
    }

def main():
    report = {
        "schema_version": 1,
        "scope": "independent closed-artifact raw correctness audit; no validator rerun",
        "run_root": str(RUN.relative_to(ROOT.parent.parent.parent)),
        "canonical_run_ledger_sha256": sha(CANONICAL / "RUN-SHA256SUMS.txt"),
        "canonical_result_audit_v2_sha256": sha(CANONICAL / "RESULT-AUDIT-V2.json"),
        "canonical_final_ledger_sha256": sha(CANONICAL / "FINAL-SHA256SUMS.txt"),
        "arms": {arm: audit_arm(arm) for arm in ("h1", "h2")},
        "interpretation": {
            "throughput": "small diagnostic fixture only; not a sustained performance gate",
            "validator_failure": "preserved status 1 caused by an incomplete exact hash-key set; raw lifecycle and sender evidence are audited separately",
            "cleanup_entry_status": "the later arm-validator failure reaches EXIT cleanup after the runner PID was cleared; supervisor-lifecycle is the authoritative natural runner join record",
            "sender_payload": "Yamux DATA payload includes HTTP response bytes and headers; it is conserved independently from the exact 4 MiB load response",
        },
    }
    report["accepted_raw_correctness"] = all(x["accepted_raw_correctness"] for x in report["arms"].values())
    out = pathlib.Path(__file__).with_name("INDEPENDENT-AUDIT.json")
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    if not report["accepted_raw_correctness"]:
        raise SystemExit(1)

if __name__ == "__main__":
    main()
