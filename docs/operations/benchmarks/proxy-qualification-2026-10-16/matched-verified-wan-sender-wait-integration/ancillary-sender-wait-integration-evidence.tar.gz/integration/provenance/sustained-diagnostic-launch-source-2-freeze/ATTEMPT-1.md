# Source-freeze check attempt 1

The source bundle had already been written and hashed. The check invoked
`sha256sum -c` on its relative-path manifest from the worktree root instead of
from the bundle directory. It returned status 1 with three `No such file or
directory` diagnostics. The launcher was not invoked and no endpoint, build,
test, or traffic ran. The bundle files were not changed by this check.
