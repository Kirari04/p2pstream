#!/usr/bin/env python3
import csv
import hashlib
import json
import os
import pathlib
import sys

if len(sys.argv) != 3:
    raise SystemExit("usage: build_sender_review.py RUN_ROOT REVIEW_ROOT")

run = pathlib.Path(sys.argv[1]).resolve(strict=True)
review = pathlib.Path(sys.argv[2]).resolve(strict=True)

def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def load_json(path):
    with path.open() as f:
        return json.load(f)

def load_jsonl(path):
    with path.open() as f:
        return [json.loads(line) for line in f]

def write_json(name, value):
    path = review / name
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write("\n")

duration_names = (
    "credit_wait_total",
    "data_call_total",
    "data_enqueue_select_total",
    "data_completion_select_total",
    "physical_write_total",
)
selected_sequences = (9, 11, 14, 15)
records = []
arm_summaries = {}

for arm in ("h1", "h2"):
    arm_root = run / arm
    rows = load_jsonl(arm_root / "results.jsonl")
    raw_sender = load_jsonl(arm_root / "results.sender-wait-records.jsonl")
    selected_raw = [row for row in raw_sender if "sequence" in row]
    terminal = [row for row in raw_sender if row.get("action") == "terminal"]
    attestation = load_json(arm_root / "attestation.json")
    if len(rows) != 16 or [row["sequence"] for row in selected_raw] != list(selected_sequences):
        raise SystemExit(f"{arm}: unexpected row or selected-sequence cardinality")
    if len(terminal) != 1:
        raise SystemExit(f"{arm}: unexpected terminal cardinality")

    for raw in selected_raw:
        sequence = raw["sequence"]
        row = rows[sequence - 1]
        validation = raw["sender_validation"]
        selected = validation["selected"]
        lane = selected["lane"]
        counters = [
            item for item in raw["post_sender"]["response"]["send_counters"]
            if item.get("enabled") is True and item.get("lane") == lane
        ]
        if len(counters) != 1:
            raise SystemExit(f"{arm} sequence {sequence}: selected lane cardinality")
        counter = counters[0]
        timing = counter["timing"]
        durations = selected["durations"]
        for name in duration_names:
            if durations[name] != timing[name]:
                raise SystemExit(f"{arm} sequence {sequence}: duration summary mismatch: {name}")

        frame_counts = {
            "selected": selected["frames"],
            "data_enqueued": timing["data_enqueued_frames"],
            "data_completed": timing["data_completed_frames"],
            "physical_attempt": timing["physical_attempt_frames"],
            "physical_success": timing["physical_success_frames"],
        }
        payload_counts = {
            "selected": selected["payload_bytes"],
            "data_enqueued": timing["data_enqueued_payload_bytes"],
            "data_completed": timing["data_completed_payload_bytes"],
            "physical_attempt": timing["physical_attempt_payload_bytes"],
            "physical_success": timing["physical_success_payload_bytes"],
        }
        credit_cause_count = sum(v["count"] for v in timing["credit_wait_by_cause"].values())
        credit_cause_ns = sum(v["total_nanoseconds"] for v in timing["credit_wait_by_cause"].values())
        credit_wake_count = sum(v["count"] for v in timing["credit_wait_by_outcome"].values())
        credit_wake_ns = sum(v["total_nanoseconds"] for v in timing["credit_wait_by_outcome"].values())
        duration_counts = [durations[name]["count"] for name in duration_names[1:]]
        errors = {
            "data_abandoned_frames": timing["data_abandoned_frames"],
            "data_gather_error_frames": timing["data_gather_error_frames"],
            "physical_error_frames": timing["physical_error_frames"],
            "physical_short_frames": timing["physical_short_frames"],
            "enqueue_publication_races": timing["enqueue_publication_races"],
            "claimed_before_publication_frames": timing["claimed_before_publication_frames"],
        }
        conservation = {
            "frame_counts_equal": len(set(frame_counts.values())) == 1,
            "payload_counts_equal": len(set(payload_counts.values())) == 1,
            "duration_counts_equal_frames": all(value == selected["frames"] for value in duration_counts),
            "data_call_equals_enqueue_plus_completion_ns": (
                durations["data_call_total"]["total_nanoseconds"]
                == durations["data_enqueue_select_total"]["total_nanoseconds"]
                + durations["data_completion_select_total"]["total_nanoseconds"]
            ),
            "credit_cause_count_equals_total": credit_cause_count == durations["credit_wait_total"]["count"],
            "credit_cause_ns_equals_total": credit_cause_ns == durations["credit_wait_total"]["total_nanoseconds"],
            "credit_wake_count_equals_total": credit_wake_count == durations["credit_wait_total"]["count"],
            "credit_wake_ns_equals_total": credit_wake_ns == durations["credit_wait_total"]["total_nanoseconds"],
            "physical_wire_attempt_equals_written": (
                timing["physical_attempt_wire_bytes"] == timing["physical_written_wire_bytes"]
                == selected["wire_bytes"]
            ),
            "no_error_short_abandoned_ambiguity_or_overflow": (
                all(value == 0 for value in errors.values())
                and timing["ambiguous"] is False
                and timing["overflow"] is False
                and timing["multiple_streams"] is False
                and timing["pending_credit_decision"] is False
            ),
            "selected_validation_accepted": validation["accepted"] is True and not validation["issues"],
            "measurement_interval_valid": raw["valid"] is True and raw["measurement_start_valid"] is True,
        }
        if not all(conservation.values()):
            raise SystemExit(f"{arm} sequence {sequence}: conservation check failed: {conservation}")

        records.append({
            "protocol": arm,
            "sequence": sequence,
            "stage": raw["stage"],
            "repetition": raw["repetition"],
            "lane": lane,
            "stream_id": selected["stream_id"],
            "wall_seconds": row["wall_seconds"],
            "http_body_bytes": row["response_bytes"],
            "useful_transfer_bytes_per_second": row["useful_transfer_bytes_per_second"],
            "data_payload_bytes": selected["payload_bytes"],
            "data_payload_minus_http_body_bytes": selected["payload_bytes"] - row["response_bytes"],
            "allocation_charged_bytes": selected["allocation_charged_bytes"],
            "allocation_minus_data_payload_bytes": selected["allocation_charged_bytes"] - selected["payload_bytes"],
            "wire_bytes": selected["wire_bytes"],
            "wire_minus_data_payload_bytes": selected["wire_bytes"] - selected["payload_bytes"],
            "frames": selected["frames"],
            "durations": durations,
            "credit_wait_by_cause": timing["credit_wait_by_cause"],
            "credit_wait_by_wake": timing["credit_wait_by_outcome"],
            "credit_observations": {
                "byte_credit_zero": counter["byte_credit_zero_observations"],
                "stream_allocation_zero": counter["stream_allocation_zero_observations"],
                "session_allocation_zero": counter["session_allocation_zero_observations"],
            },
            "frame_counts": frame_counts,
            "payload_counts": payload_counts,
            "physical_wire": {
                "attempt_bytes": timing["physical_attempt_wire_bytes"],
                "written_bytes": timing["physical_written_wire_bytes"],
                "success_bytes": timing["physical_success_wire_bytes"],
            },
            "error_and_race_counts": errors,
            "interval_boundary": raw["interval_boundary"],
            "conservation": conservation,
        })

    arm_summaries[arm] = {
        "attestation_accepted": attestation["accepted"],
        "classification": attestation["classification"],
        "download_phase_classification": attestation["download_phase_classification"],
        "validation_issues": attestation["validation_issues"],
        "sender_terminal_closure_valid": attestation["sender_terminal_closure_valid"],
        "natural_endpoint_and_namespace_statuses": attestation["natural_endpoint_and_namespace_statuses"],
        "outer_runner_group_joined": attestation["outer_runner_group_joined"],
        "runner_status": attestation["runner_status"],
        "results_sha256": sha(arm_root / "results.jsonl"),
        "sender_records_sha256": sha(arm_root / "results.sender-wait-records.jsonl"),
        "lifecycle_sha256": sha(arm_root / "results.lifecycle.jsonl"),
        "attestation_sha256": sha(arm_root / "attestation.json"),
    }

table = {
    "schema_version": 1,
    "diagnostic": "wan-sender-wait",
    "diagnostic_only": True,
    "selected_sequences": list(selected_sequences),
    "records": records,
    "interpretation": {
        "credit_wait": "Observed sender-side credit decision waits, partitioned independently by cause and wake outcome.",
        "data_call": "Whole DATA call interval; it equals enqueue-select plus completion-select for every selected transfer.",
        "completion_select": "Caller completion-select interval; physical write occurs within the send-loop side of this interval but is not equated to it.",
        "physical_write": "Observed conn.Write duration for DATA frames.",
        "http_body_vs_data": "DATA payload includes bytes beyond the 256 MiB HTTP response body; both exact counts are retained and are not described as identical.",
        "causality": "Descriptive interval/exclusivity evidence only; there is no direct request-to-stream marker and no causal runtime-fix claim.",
    },
}
write_json("SENDER-DURATION-TABLE.json", table)
write_json("SUMMARY.json", {
    "schema_version": 1,
    "diagnostic": "wan-sender-wait",
    "accepted": False,
    "arm_summaries": arm_summaries,
    "selected_record_count": len(records),
    "all_selected_sender_records_valid": all(all(r["conservation"].values()) for r in records),
    "run_final_status_sha256": sha(run / "final-status.json"),
})

columns = [
    "protocol", "sequence", "stage", "lane", "stream_id", "wall_seconds",
    "useful_transfer_bytes_per_second", "http_body_bytes", "data_payload_bytes",
    "frames", "credit_wait_count", "credit_wait_total_ns", "credit_wait_max_ns",
    "data_call_total_ns", "enqueue_select_total_ns", "completion_select_total_ns",
    "physical_write_total_ns", "physical_write_max_ns", "wire_bytes",
]
with (review / "SENDER-DURATION-TABLE.csv").open("x", newline="") as f:
    w = csv.DictWriter(f, fieldnames=columns)
    w.writeheader()
    for row in records:
        d = row["durations"]
        w.writerow({
            "protocol": row["protocol"], "sequence": row["sequence"], "stage": row["stage"],
            "lane": row["lane"], "stream_id": row["stream_id"], "wall_seconds": row["wall_seconds"],
            "useful_transfer_bytes_per_second": row["useful_transfer_bytes_per_second"],
            "http_body_bytes": row["http_body_bytes"], "data_payload_bytes": row["data_payload_bytes"],
            "frames": row["frames"], "credit_wait_count": d["credit_wait_total"]["count"],
            "credit_wait_total_ns": d["credit_wait_total"]["total_nanoseconds"],
            "credit_wait_max_ns": d["credit_wait_total"]["max_nanoseconds"],
            "data_call_total_ns": d["data_call_total"]["total_nanoseconds"],
            "enqueue_select_total_ns": d["data_enqueue_select_total"]["total_nanoseconds"],
            "completion_select_total_ns": d["data_completion_select_total"]["total_nanoseconds"],
            "physical_write_total_ns": d["physical_write_total"]["total_nanoseconds"],
            "physical_write_max_ns": d["physical_write_total"]["max_nanoseconds"],
            "wire_bytes": row["wire_bytes"],
        })
