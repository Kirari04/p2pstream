# Receipt review input-path correction

The first `copy-validator-binding-harness-receipt-review` directory is retained
unchanged. Its receipt bytes are correct, but every relative path in its
`INPUT-SHA256SUMS.txt` has one excess parent component and therefore cannot be
verified from that directory. This revision retains the exact receipt and
corrects only those relative input paths. The active runtime receipt is
unchanged.
