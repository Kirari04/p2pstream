#!/usr/bin/env bash
set -Eeuo pipefail
root=/home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-sender-wait-integration-source
launch=\"$root/provenance/small-sender-wait-smoke-2-launch\"
set +e
/usr/bin/bash \"$root/review/small-diagnostic-invocation-source-2/INVOCATION.txt\" >\"$launch/coordinator.stdout.log\" 2>\"$launch/coordinator.stderr.log\"
status=$?
set -e
printf '%s\n' \"$status\" > \"$launch/coordinator.status\"
exit \"$status\"
