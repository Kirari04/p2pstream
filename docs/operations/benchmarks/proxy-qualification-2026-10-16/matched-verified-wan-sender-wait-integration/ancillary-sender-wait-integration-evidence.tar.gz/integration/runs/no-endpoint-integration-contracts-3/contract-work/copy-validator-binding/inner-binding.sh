#!/usr/bin/env bash
set -Eeuo pipefail
copy_record_validator=${P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR:?copy record validator is required}
copy_record_validator_sha256=${P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256:?copy record validator hash is required}
[[ $copy_record_validator == /* && -f $copy_record_validator && -x $copy_record_validator &&
   $copy_record_validator_sha256 =~ ^[0-9a-f]{64}$ ]] || {
	echo "copy record validator binding is unavailable" >&2; exit 2;
}
[[ $(readlink -f "$copy_record_validator") == "$copy_record_validator" ]] || {
	echo "copy record validator path changed across namespace re-exec" >&2; exit 2;
}
[[ $(sha256sum "$copy_record_validator" | awk '{print $1}') == "$copy_record_validator_sha256" ]] || {
	echo "copy record validator changed across namespace re-exec" >&2; exit 2;
}
printf '%s\n%s\n' "$copy_record_validator" "$copy_record_validator_sha256" > "$1"
