#!/usr/bin/env bash
set -Eeuo pipefail
copy_record_validator=$1
copy_record_validator_sha256=$2
inner_script=$3
result=$4
  [[ -n $copy_record_validator && $copy_record_validator_sha256 =~ ^[0-9a-f]{64}$ ]] || {
    echo "--copy-record-validator and its lowercase SHA-256 are required" >&2; exit 2;
  }
  copy_record_validator=$(realpath "$copy_record_validator")
  [[ -f $copy_record_validator && -x $copy_record_validator ]] || {
    echo "copy record validator must be an executable regular file" >&2; exit 2;
  }
  [[ $(sha256sum "$copy_record_validator" | awk '{print $1}') == "$copy_record_validator_sha256" ]] || {
    echo "copy record validator hash mismatch" >&2; exit 2;
  }

  export P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256
  P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR=$copy_record_validator
  P2PSTREAM_GROWTH_COPY_RECORD_VALIDATOR_SHA256=$copy_record_validator_sha256
exec /bin/bash "$inner_script" "$result"
