#!/usr/bin/env bash
set -Eeuo pipefail
root=$(realpath tmp/continuation-20261016/wan-sender-wait-integration-source)
checkpoint="$root/review/implementation-source-checkpoint-6"
run_root="$root/runs/no-endpoint-integration-contracts-1"
verify_active() {
  local destination=$1
  python3 -I -B - "$root" "$checkpoint/SHA256SUMS.txt" "$destination" <<'PY'
import hashlib, json, pathlib, sys
root, manifest, destination = map(pathlib.Path, sys.argv[1:])
rows=[]
accepted=True
for line in manifest.read_text().splitlines():
    expected, relative = line.split("  ", 1)
    if not relative.startswith("./"):
        raise SystemExit("noncanonical checkpoint manifest path")
    relative = relative[2:]
    path = root / relative
    digest = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() and not path.is_symlink() else None
    equal = digest == expected
    accepted = accepted and equal
    rows.append({"path":relative,"expected_sha256":expected,"actual_sha256":digest,"equal":equal})
result={"schema_version":1,"accepted":accepted,"checkpoint_manifest_sha256":hashlib.sha256(manifest.read_bytes()).hexdigest(),"file_count":len(rows),"files":rows}
destination.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
if not accepted:
    raise SystemExit("active source differs from checkpoint")
PY
}
verify_active "$run_root/source-pre.json"
set +e
TMPDIR="$run_root/tmp" /usr/bin/bash "$root/integration-source/contracts/run-sender-integration-contracts.sh" "$run_root/contract-work" \
  >"$run_root/driver.stdout.log" 2>"$run_root/driver.stderr.log"
driver_status=$?
set -e
printf '%s\n' "$driver_status" > "$run_root/driver.status"
set +e
verify_active "$run_root/source-post.json"
source_post_status=$?
set -e
printf '%s\n' "$source_post_status" > "$run_root/source-post.status"
set +e
cmp "$run_root/source-pre.json" "$run_root/source-post.json"
source_compare_status=$?
set -e
printf '%s\n' "$source_compare_status" > "$run_root/source-compare.status"
final_status=$driver_status
((final_status == 0 && source_post_status != 0)) && final_status=$source_post_status
((final_status == 0 && source_compare_status != 0)) && final_status=$source_compare_status
printf '%s\n' "$final_status" > "$run_root/saved-outer.status"
if ((final_status == 0)); then printf '%s\n' complete > "$run_root/FINAL"; fi
exit "$final_status"
