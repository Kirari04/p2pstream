# Offline cp9 hash-manifest validator correction

This source-only derivative adds exactly the four provenance keys emitted by the cp9 arm runner to the validator's exact required-key set: `base_cp7_checkpoint`, `base_cp7_reviewed_manifest`, `base_cp7_runner`, and `sender_harness_receipt`. It makes no other acceptance, payload, protocol, TLS, sender, copy, resource, reuse, lifecycle, timeout, or performance change.

The executable is a uniquely named sibling in `integration-source` so its existing relative imports resolve exactly as in the frozen validator. The original cp9 validator, reviewed 30-file corpus, closed smoke output, and rejected attestations remain unchanged. Any corrected validation writes only a new attestation path.

The focused contract invokes both actual validators against the same closed H1 arm shape. It preserves the original rejection, requires the corrected validator to accept the unchanged complete evidence, and requires rejection for each missing new key, an unsupported extra key, a malformed hash, and a changed pre/post hash. It snapshots all raw inputs before and after.
