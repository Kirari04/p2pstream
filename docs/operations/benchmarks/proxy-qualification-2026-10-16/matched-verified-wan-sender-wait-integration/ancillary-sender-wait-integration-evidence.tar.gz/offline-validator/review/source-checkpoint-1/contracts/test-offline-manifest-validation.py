#!/usr/bin/env python3
import hashlib, json, os, pathlib, subprocess, sys

if len(sys.argv) != 5:
    raise SystemExit("usage: test-offline-manifest-validation.py WORK ORIGINAL CORRECTED CLOSED_H1")
work, original, corrected, arm = map(pathlib.Path, sys.argv[1:])
if work.exists():
    raise SystemExit("work path must be fresh")
work.mkdir(mode=0o700, parents=True)
for path in (original, corrected):
    if not path.is_file() or not os.access(path, os.X_OK):
        raise SystemExit(f"validator unavailable: {path}")
inputs = [arm/name for name in (
    "results.jsonl", "results.lifecycle.jsonl", "results.summary.json", "outer-namespaces.json",
    "supervisor-lifecycle.json", "pre-hashes.json", "post-hashes.json",
)]
if any(not p.is_file() for p in inputs):
    raise SystemExit("closed arm fixture is incomplete")
fixture_before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
extra_keys = ["base_cp7_checkpoint", "base_cp7_reviewed_manifest", "base_cp7_runner", "sender_harness_receipt"]
summary=[]

def run_case(name, validator, mutate, expected_status, expected_accepted, expected_issues):
    case=work/name
    case.mkdir(mode=0o700)
    pre=json.loads((arm/"pre-hashes.json").read_text())
    post=json.loads((arm/"post-hashes.json").read_text())
    mutate(pre,post)
    pre_path=case/"pre.json"; post_path=case/"post.json"; att=case/"attestation.json"
    pre_path.write_text(json.dumps(pre,indent=2,sort_keys=True)+"\n")
    post_path.write_text(json.dumps(post,indent=2,sort_keys=True)+"\n")
    argv=[str(validator),str(arm/"results.jsonl"),str(arm/"results.lifecycle.jsonl"),str(arm/"results.summary.json"),
          str(arm/"outer-namespaces.json"),str(arm/"supervisor-lifecycle.json"),str(pre_path),str(post_path),str(att),"h1","small"]
    cp=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=False)
    (case/"stdout").write_bytes(cp.stdout); (case/"stderr").write_bytes(cp.stderr); (case/"status").write_text(f"{cp.returncode}\n")
    actual=json.loads(att.read_text()) if att.is_file() else None
    actual_accepted=actual.get("accepted") if isinstance(actual,dict) else None
    actual_issues=actual.get("validation_issues") if isinstance(actual,dict) else None
    passed=(cp.returncode==expected_status and actual_accepted is expected_accepted and actual_issues==expected_issues)
    row={"case":name,"expected_status":expected_status,"actual_status":cp.returncode,"expected_accepted":expected_accepted,
         "actual_accepted":actual_accepted,"expected_issues":expected_issues,"actual_issues":actual_issues,"passed":passed}
    summary.append(row)
    if not passed:
        raise SystemExit(json.dumps(row,sort_keys=True))

def same(pre,post):
    return None
issue=["preflight hash manifest is incomplete"]
run_case("original_closed_shape_rejected",original,same,1,False,issue)
run_case("corrected_closed_shape_accepted",corrected,same,0,True,[])
for key in extra_keys:
    def missing(pre,post,key=key):
        pre["sha256"].pop(key); post["sha256"].pop(key)
    run_case(f"missing_{key}",corrected,missing,1,False,issue)
def extra(pre,post):
    pre["sha256"]["unsupported_extra"]="0"*64; post["sha256"]["unsupported_extra"]="0"*64
run_case("unsupported_extra",corrected,extra,1,False,issue)
def malformed(pre,post):
    pre["sha256"]["sender_harness_receipt"]="bad"; post["sha256"]["sender_harness_receipt"]="bad"
run_case("malformed_hash",corrected,malformed,1,False,issue)
def changed(pre,post):
    post["sha256"]["sender_harness_receipt"]="0"*64
run_case("changed_pre_post",corrected,changed,1,False,["binary, source overlay, certificate, or harness hashes changed during the arm"])
fixture_after={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
if fixture_before != fixture_after:
    raise SystemExit("closed fixture changed")
result={"schema_version":1,"accepted":all(x["passed"] for x in summary),"case_count":len(summary),"cases":summary,
        "fixture_pre_post_unchanged":True,"source_scope":"offline validator only; original cp9 validator and closed smoke remain immutable"}
fd=os.open(work/"summary.json",os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,"w") as f: json.dump(result,f,indent=2,sort_keys=True); f.write("\n")
fd=os.open(work/"FINAL",os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,"w") as f: f.write("complete\n")
