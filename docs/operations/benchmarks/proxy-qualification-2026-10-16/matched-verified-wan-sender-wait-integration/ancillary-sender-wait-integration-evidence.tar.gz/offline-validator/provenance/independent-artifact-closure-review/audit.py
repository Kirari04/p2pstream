#!/usr/bin/env python3
import hashlib
import json
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
ROOT = next(p for p in pathlib.Path(__file__).resolve().parents if p.name == "wan-sender-wait-integration-source")
OFFLINE = ROOT / "offline-validator-source"
CHECKPOINT = OFFLINE / "review/source-checkpoint-1"
CONTRACT = OFFLINE / "runs/offline-contract-1"
VERIFY = OFFLINE / "runs/smoke2-offline-verification-1"
RUN = ROOT / "integration-source/runs/small-sender-wait-smoke-2"
RUN_REVIEW = ROOT / "provenance/small-sender-wait-smoke-2-result-review"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def check(ok, message, issues):
    if not ok:
        issues.append(message)

def verify_ledger(path, base):
    count = 0
    total = 0
    for line in path.read_text().splitlines():
        if not line:
            continue
        digest, name = line.split("  ", 1)
        target = (base / name).resolve()
        if not target.is_file() or sha(target) != digest:
            raise ValueError(f"ledger mismatch: {path}: {name}")
        count += 1
        total += target.stat().st_size
    return {"sha256": sha(path), "entries": count, "bytes": total}

def main():
    issues = []
    ledgers = {
        "source_checkpoint": verify_ledger(CHECKPOINT / "SHA256SUMS.txt", CHECKPOINT),
        "contract": verify_ledger(CONTRACT / "FINAL-SHA256SUMS.txt", CONTRACT),
        "offline_verification": verify_ledger(VERIFY / "FINAL-SHA256SUMS.txt", VERIFY),
        "closed_run": verify_ledger(RUN_REVIEW / "RUN-SHA256SUMS.txt", RUN),
        "canonical_result_review": verify_ledger(RUN_REVIEW / "FINAL-SHA256SUMS.txt", RUN_REVIEW),
    }
    expected_ledger_hashes = {
        "source_checkpoint": "6ab37ae85ca1d99e99d0387c1d3a7c99f4647a8517ff31686bfb6354343cbe9f",
        "contract": "9c10da08db3cf37ccedd89972871a2844f22f19376edd14c651195b88950857b",
        "offline_verification": "64da5bd3f06325b2678e93d14f73a5ed8b972383006ad96826d5d62c77c8683a",
        "closed_run": "83770a2a4e978d9be76954753c704c1ab2d511eef096aa8cfcc95646141ccae8",
        "canonical_result_review": "37c4e3d836f2b52542369d1e58526ce0ea86e895251fb90266bdbda77d3b9a31",
    }
    for key, expected in expected_ledger_hashes.items():
        check(ledgers[key]["sha256"] == expected, f"{key} ledger identity", issues)

    key_diff = read(CHECKPOINT / "KEY-DIFF.json")
    expected_extra = ["base_cp7_checkpoint", "base_cp7_reviewed_manifest", "base_cp7_runner", "sender_harness_receipt"]
    check(key_diff == {"schema_version": 1, "required_count": 61, "emitted_count": 65,
                       "missing_from_emitted": [], "extra_in_emitted": expected_extra,
                       "all_emitted_values_sha256_shaped": True}, "exact four-key source scope", issues)
    check(sha(CHECKPOINT / "ORIGINAL-TO-OFFLINE-VALIDATOR.diff") ==
          "df717131968ffefabbb7619983c60d57a130c381ad54e93aae44429dd6d781e2",
          "source diff identity", issues)

    summary = read(CONTRACT / "contract-work/summary.json")
    expected_cases = {
        "original_closed_shape_rejected": (1, False, ["preflight hash manifest is incomplete"]),
        "corrected_closed_shape_accepted": (0, True, []),
        "missing_base_cp7_checkpoint": (1, False, ["preflight hash manifest is incomplete"]),
        "missing_base_cp7_reviewed_manifest": (1, False, ["preflight hash manifest is incomplete"]),
        "missing_base_cp7_runner": (1, False, ["preflight hash manifest is incomplete"]),
        "missing_sender_harness_receipt": (1, False, ["preflight hash manifest is incomplete"]),
        "unsupported_extra": (1, False, ["preflight hash manifest is incomplete"]),
        "malformed_hash": (1, False, ["preflight hash manifest is incomplete"]),
        "changed_pre_post": (1, False, ["binary, source overlay, certificate, or harness hashes changed during the arm"]),
    }
    check(summary["accepted"] is True and summary["case_count"] == 9 and summary["fixture_pre_post_unchanged"] is True,
          "contract summary", issues)
    actual_names = {case["case"] for case in summary["cases"]}
    check(actual_names == set(expected_cases), "contract case set", issues)
    for case in summary["cases"]:
        status, accepted, expected_issues = expected_cases[case["case"]]
        check(case["passed"] is True and case["actual_status"] == case["expected_status"] == status and
              case["actual_accepted"] is case["expected_accepted"] is accepted and
              case["actual_issues"] == case["expected_issues"] == expected_issues,
              f"contract case {case['case']}", issues)
    check((CONTRACT / "driver.status").read_text().strip() == "0" and
          (CONTRACT / "input-compare.status").read_text().strip() == "0", "contract direct statuses", issues)

    verification = read(VERIFY / "verification-summary.json")
    check(verification["accepted"] is True and verification["offline_only"] is True and
          verification["original_artifacts_unchanged"] is True, "verification summary", issues)
    check((VERIFY / "h1.status").read_text().strip() == "0" and
          (VERIFY / "h2.status").read_text().strip() == "0" and
          (VERIFY / "audit.status").read_text().strip() == "0" and
          (VERIFY / "input-compare.status").read_text().strip() == "0", "verification direct statuses", issues)

    manifest = read(ROOT / "provenance/audited-server-build-manifest.json")
    receipt = read(ROOT / "provenance/local-publication-receipt.json")
    server_bin = ROOT / "build/bin/current-server-wan-sender-wait-audited.test"
    agent_bin = ROOT / "build/bin/current-agent-wan-sender-wait-audited.test"
    server_sha, agent_sha = sha(server_bin), sha(agent_bin)
    check(server_sha == "f2e6cf390fdcd727b8c7120a6d877dc3a53afe9d8b970aa7b0d7f6cc892a7bdc" and
          agent_sha == "43eadb7664d70f9585887ac824cc7e6dcb55d6fa40731e3888b6fa5a1cc8d74f",
          "published binary tuple", issues)
    check(manifest["output"]["server_sha256"] == server_sha and manifest["output"]["agent_sha256"] == agent_sha and
          receipt["accepted"] is True and receipt["published"]["server"]["sha256"] == server_sha and
          receipt["published"]["agent"]["sha256"] == agent_sha, "build/publication tuple", issues)

    arms = {}
    for arm, major, alpn in (("h1", 1, "http/1.1"), ("h2", 2, "h2")):
        original = read(RUN / arm / "attestation.json")
        attestation = read(VERIFY / f"{arm}-attestation.json")
        pre = read(RUN / arm / "pre-hashes.json")
        post = read(RUN / arm / "post-hashes.json")
        check(pre == post, f"{arm} raw pre/post equality", issues)
        check(pre["sha256"]["server_binary"] == server_sha and
              pre["sha256"]["aggregate_agent_binary"] == agent_sha and
              pre["sha256"]["sender_build_manifest"] == sha(ROOT / "provenance/audited-server-build-manifest.json"),
              f"{arm} binary/build binding", issues)
        check(attestation["accepted"] is True and attestation["validation_issues"] == [] and
              attestation["classification"] == "observational-complete" and
              attestation["row_count"] == 16 and attestation["runner_status"] == 0 and
              attestation["all_observed_http_major"] == major and attestation["verified_alpn"] == alpn and
              attestation["natural_endpoint_and_namespace_statuses"] is True and
              attestation["outer_runner_group_joined"] is True and
              attestation["server_only_delegated_cgroup"] is True and
              attestation["sender_terminal_closure_valid"] is True and
              all(item["valid"] is True and item["request_wall_interval_contained"] is True
                  for item in attestation["sender_duration_intervals"]), f"{arm} offline attestation gates", issues)
        check(attestation["results_sha256"] == sha(RUN / arm / "results.jsonl") and
              attestation["lifecycle_sha256"] == sha(RUN / arm / "results.lifecycle.jsonl") and
              attestation["summary_sha256"] == sha(RUN / arm / "results.summary.json"),
              f"{arm} raw input binding", issues)
        check(original["accepted"] is False and original["validation_issues"] == ["preflight hash manifest is incomplete"],
              f"{arm} original rejection preserved", issues)
        arms[arm] = {"offline_attestation_sha256": sha(VERIFY / f"{arm}-attestation.json"),
                     "original_attestation_sha256": sha(RUN / arm / "attestation.json"),
                     "accepted": attestation["accepted"], "issues": attestation["validation_issues"]}

    report = {
        "schema_version": 1,
        "accepted_immutable_artifact_scope": not issues,
        "issues": issues,
        "ledgers": ledgers,
        "source_change": {"scope": "exact four required hash keys", "keys": expected_extra,
                          "diff_sha256": sha(CHECKPOINT / "ORIGINAL-TO-OFFLINE-VALIDATOR.diff")},
        "contract": {"case_count": len(summary["cases"]), "accepted": summary["accepted"]},
        "arms": arms,
        "binary_tuple": {"server_sha256": server_sha, "agent_sha256": agent_sha,
                         "build_manifest_sha256": sha(ROOT / "provenance/audited-server-build-manifest.json")},
        "tool_envelope": {
            "contract_original_status": int((CONTRACT / "tool-envelope.status").read_text().strip()),
            "offline_verification_original_status": int((VERIFY / "tool-envelope.status").read_text().strip()),
            "resolved": False,
            "interpretation": "Both original outer tool envelopes returned 1 despite direct/saved status 0 and complete immutable ledgers. The external discrepancy remains unresolved and is not normalized to success.",
        },
        "scope": "artifact closure only; no validator, test, build, endpoint, or workload execution",
    }
    (HERE / "ARTIFACT-CLOSURE-AUDIT.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    if issues:
        raise SystemExit(1)

if __name__ == "__main__":
    main()
