set -uo pipefail
root=offline-validator-source/runs/offline-contract-1
work=$root/contract-work
orig=integration-source/validate-wan-sender-wait-arm.py
fixed=integration-source/validate-wan-sender-wait-arm-offline-cp9.py
driver=offline-validator-source/review/source-checkpoint-1/contracts/test-offline-manifest-validation.py
arm=integration-source/runs/small-sender-wait-smoke-2/h1
if [[ -e $root ]]; then echo 'run root not fresh' >&2; exit 2; fi
mkdir -m 0700 -p "$root"
cat > "$root/COMMAND.txt" <<EOF2
env -u PYTHONOPTIMIZE -u PYTHONPATH PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -B $driver $work $orig $fixed $arm
EOF2
hash_inputs() {
  sha256sum "$orig" "$fixed" "$driver" integration-source/validate-sender-wait-snapshot.py ../wan-read-wait-capacity-source/validate-copy-record.py \
    "$arm/results.jsonl" "$arm/results.lifecycle.jsonl" "$arm/results.summary.json" "$arm/outer-namespaces.json" \
    "$arm/supervisor-lifecycle.json" "$arm/pre-hashes.json" "$arm/post-hashes.json" \
    provenance/small-sender-wait-smoke-2-result-review/RUN-SHA256SUMS.txt \
    offline-validator-source/review/source-checkpoint-1/SHA256SUMS.txt
}
hash_inputs > "$root/input-pre.sha256"
set +e
env -u PYTHONOPTIMIZE -u PYTHONPATH PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -B "$driver" "$work" "$orig" "$fixed" "$arm" >"$root/driver.stdout" 2>"$root/driver.stderr"
status=$?
set -e
printf '%s\n' "$status" > "$root/driver.status"
hash_inputs > "$root/input-post.sha256"
cmp -s "$root/input-pre.sha256" "$root/input-post.sha256"
cmp_status=$?
printf '%s\n' "$cmp_status" > "$root/input-compare.status"
if [[ $status -eq 0 && $cmp_status -eq 0 && -f $work/FINAL ]]; then final=complete; else final=failed; fi
printf '%s\n' "$final" > "$root/RESULT"
(
 cd "$root"
 find . -type f ! -name SHA256SUMS.txt -print0 | LC_ALL=C sort -z | xargs -0 sha256sum
) > "$root/SHA256SUMS.txt"
exit "$status"
