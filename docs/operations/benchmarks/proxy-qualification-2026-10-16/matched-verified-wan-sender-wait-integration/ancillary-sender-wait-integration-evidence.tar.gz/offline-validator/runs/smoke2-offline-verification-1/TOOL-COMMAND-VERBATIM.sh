set -uo pipefail
root=offline-validator-source/runs/smoke2-offline-verification-1
fixed=integration-source/validate-wan-sender-wait-arm-offline-cp9.py
run=integration-source/runs/small-sender-wait-smoke-2
if [[ -e $root ]]; then echo 'run root not fresh' >&2; exit 2; fi
mkdir -m 0700 -p "$root"
cat > "$root/COMMAND.txt" <<EOF2
env -u PYTHONOPTIMIZE -u PYTHONPATH PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -B $fixed RUN/PROTO/results.jsonl RUN/PROTO/results.lifecycle.jsonl RUN/PROTO/results.summary.json RUN/PROTO/outer-namespaces.json RUN/PROTO/supervisor-lifecycle.json RUN/PROTO/pre-hashes.json RUN/PROTO/post-hashes.json OUTPUT/PROTO-attestation.json PROTO small
EOF2
hash_inputs() {
 sha256sum "$fixed" integration-source/validate-wan-sender-wait-arm.py integration-source/validate-sender-wait-snapshot.py ../wan-read-wait-capacity-source/validate-copy-record.py \
  offline-validator-source/review/source-checkpoint-1/SHA256SUMS.txt provenance/small-sender-wait-smoke-2-result-review/RUN-SHA256SUMS.txt \
  "$run/final-status.json" "$run/pre-hashes.json" "$run/post-hashes.json"
 for proto in h1 h2; do
  sha256sum "$run/$proto/results.jsonl" "$run/$proto/results.lifecycle.jsonl" "$run/$proto/results.summary.json" \
   "$run/$proto/outer-namespaces.json" "$run/$proto/supervisor-lifecycle.json" "$run/$proto/pre-hashes.json" "$run/$proto/post-hashes.json" "$run/$proto/attestation.json" \
   "$run/$proto/runner.status" "$run/$proto/validation.status"
 done
}
hash_inputs > "$root/input-pre.sha256"
set +e
env -u PYTHONOPTIMIZE -u PYTHONPATH PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -B "$fixed" \
 "$run/h1/results.jsonl" "$run/h1/results.lifecycle.jsonl" "$run/h1/results.summary.json" "$run/h1/outer-namespaces.json" "$run/h1/supervisor-lifecycle.json" \
 "$run/h1/pre-hashes.json" "$run/h1/post-hashes.json" "$root/h1-attestation.json" h1 small >"$root/h1.stdout" 2>"$root/h1.stderr"
h1_status=$?
printf '%s\n' "$h1_status" > "$root/h1.status"
h2_status=125
if [[ $h1_status -eq 0 ]]; then
 env -u PYTHONOPTIMIZE -u PYTHONPATH PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -B "$fixed" \
  "$run/h2/results.jsonl" "$run/h2/results.lifecycle.jsonl" "$run/h2/results.summary.json" "$run/h2/outer-namespaces.json" "$run/h2/supervisor-lifecycle.json" \
  "$run/h2/pre-hashes.json" "$run/h2/post-hashes.json" "$root/h2-attestation.json" h2 small >"$root/h2.stdout" 2>"$root/h2.stderr"
 h2_status=$?
fi
printf '%s\n' "$h2_status" > "$root/h2.status"
set -e
hash_inputs > "$root/input-post.sha256"
cmp -s "$root/input-pre.sha256" "$root/input-post.sha256"
cmp_status=$?
printf '%s\n' "$cmp_status" > "$root/input-compare.status"
python3 - "$root" "$h1_status" "$h2_status" "$cmp_status" <<'PY'
import json,pathlib,sys
root=pathlib.Path(sys.argv[1]); statuses=list(map(int,sys.argv[2:]))
arms={}
for proto in ('h1','h2'):
 p=root/f'{proto}-attestation.json'
 d=json.loads(p.read_text()) if p.is_file() else None
 arms[proto]={
  'status':int((root/f'{proto}.status').read_text()),
  'attestation_present':p.is_file(),
  'accepted':d.get('accepted') if d else None,
  'issues':d.get('validation_issues') if d else None,
  'row_count':d.get('row_count') if d else None,
  'protocol':d.get('protocol') if d else None,
  'runner_status':d.get('runner_status') if d else None,
  'natural_endpoint_and_namespace_statuses':d.get('natural_endpoint_and_namespace_statuses') if d else None,
  'sender_terminal_closure_valid':d.get('sender_terminal_closure_valid') if d else None,
 }
accepted=(statuses==[0,0,0] and all(v['accepted'] is True and v['issues']==[] and v['row_count']==16 and v['runner_status']==0 and v['natural_endpoint_and_namespace_statuses'] is True and v['sender_terminal_closure_valid'] is True for v in arms.values()))
(root/'verification-summary.json').write_text(json.dumps({'schema_version':1,'accepted':accepted,'offline_only':True,'original_artifacts_unchanged':statuses[2]==0,'arms':arms},indent=2,sort_keys=True)+'\n')
(root/'RESULT').write_text(('complete' if accepted else 'failed')+'\n')
raise SystemExit(0 if accepted else 1)
PY
audit_status=$?
printf '%s\n' "$audit_status" > "$root/audit.status"
(
 cd "$root"
 find . -type f ! -name SHA256SUMS.txt -print0 | LC_ALL=C sort -z | xargs -0 sha256sum
) > "$root/SHA256SUMS.txt"
exit "$audit_status"
