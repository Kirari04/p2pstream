# Raw temporal-occupancy observer implementation intent

Status: source-only checkpoint candidate. No Go build, test, endpoint, or traffic has been run from this implementation.

This component implements only the agent/Yamux below-TLS temporal raw-write observer from design checkpoint 2 (`0dfdb694ea632ae3ec41dc1abe95cea51b4c4cbc6c6dbfb7bdf902aa0a785549`). The independently owned server receive-growth component is excluded. The overlay applies to the audited sender-wait build source recorded in `BASE-SOURCE-PATH.txt`; modified base-file hashes are recorded in `BASE-FILE-SHA256SUMS.txt`.

The tagged fixture clones the existing HTTP transport and wraps `DialContext` below Go TLS. A request-context binding joins that raw connection to the exact 101 response body, lane, later Yamux session identity, and local/remote tuple. No bytes are copied or inspected. The wrapper forwards `net.Conn` and `syscall.Conn` when supported.

The accepted tagged Yamux DATA physical-write bracket opens one fixed observer envelope. Raw-call ownership is reserved before its start timestamp; the timestamp is captured immediately before the underlying `Write`. The envelope end timestamp is captured while holding only the short observer lock after `s.conn.Write` returns, closes the epoch, and is returned unchanged to the existing physical-write ledger. Thus a call that remains active at the end becomes straddling after the epoch closes, while a call that completes before the end lock is necessarily bounded by that returned end timestamp. No observer lock is held across network I/O, TLS/Yamux waits, or another subsystem lock acquisition.

Raw calls conserve attempted/written bytes, calls, and total/max duration independently for success, error, and short-write outcomes within contained, outside, and straddling classes. Envelope payload and wire bytes conserve separately against the existing sender physical ledger. Raw ciphertext bytes are deliberately not equated with either domain. Residual duration is exported only as physical DATA interval minus contained raw occupancy; ambiguity, overlap, active boundary writes, overflow, stream mismatch, or negative conservation invalidates interpretation.

Connection close observation and Yamux session retirement are distinct. `close_observed` is set by the wrapped connection/body close. `session_joined` is set only after the existing `Session.Close` returns from its send-loop join. Persistent owner identity and lifecycle fields survive destructive interval drains.

Ordinary builds receive no-op hook definitions. Exact ordinary instruction/layout/escape proof remains a required validation phase and is not claimed by this source-only checkpoint.

## Terminal lifecycle sidecar

The external fixture requires an absolute fresh `P2PSTREAM_QUALIFICATION_RAW_WRITE_TERMINAL_PATH` when the sender-wait observer is enabled. Its fixed recorder rejects duplicate lanes and reconnect overwrite, retains the exact Session identity, and writes schema 1 only after `RunContext` has returned. The sidecar is complete only with exactly five ordered lane records (0 through 4), no live sessions, and per-record bound, unambiguous, overflow-free, close-observed, session-joined, inactive snapshots. This is separate from the selected transfer drain, which intentionally occurs while sessions remain live.
