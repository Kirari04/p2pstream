#!/usr/bin/python3
import json
from pathlib import Path
source = Path('/home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/final-integration-source/integration/runs/sustained-below-tls-1/h1/results.jsonl')
rows = [json.loads(line) for line in source.read_text().splitlines()]
matches = [row for row in rows if row.get('diagnostic_sequence') == 9]
assert len(matches) == 1
copy = matches[0]['response_copy_attribution']
assert copy['overflow'] is False and copy['sequence'] == '9' and len(copy['matches']) == 1
Path('sequence-9-copy-record.json').write_text(json.dumps(copy['matches'][0], indent=2, sort_keys=True) + '\n')
