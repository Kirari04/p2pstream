#!/usr/bin/env bash
set -Eeuo pipefail
runner=$1
work=$2
[[ -f $runner && ! -e $work ]] || { echo 'usage: test-post-join-raw-finalization.sh RUNNER FRESH_WORK' >&2; exit 2; }
mkdir -m 0700 "$work"
python3 -I -B - "$runner" "$work/finalizer.sh" <<'PY'
import pathlib, sys
source = pathlib.Path(sys.argv[1]).read_text()
start = source.index("finalize_raw_write_after_agent_join() {\n")
end = source.index("\nrun_cohort() {\n", start)
body = source[start:end]
pathlib.Path(sys.argv[2]).write_text("#!/usr/bin/env bash\nset -Eeuo pipefail\n" + body + "\n")
PY
chmod 0700 "$work/finalizer.sh"
cat > "$work/fake-validator.py" <<'PY'
import json, os, pathlib, sys
args = sys.argv[1:]
def value(name): return args[args.index(name) + 1]
if not pathlib.Path(os.environ["STOP_MARKER"]).is_file(): raise SystemExit(19)
out = pathlib.Path(value("--output"))
accepted = os.environ.get("FAKE_VALIDATOR_ACCEPT") == "1"
with out.open("x", encoding="utf-8") as stream:
    json.dump({"schema_version": 1, "mode": "final-closure", "issues": [] if accepted else ["fixture rejection"], "accepted": accepted}, stream)
    stream.write("\n")
raise SystemExit(0 if accepted else 7)
PY
run_case() {
  local name=$1 stop_status=$2 sidecar=$3 validator_accept=$4
  local case_dir="$work/$name"
  mkdir -m 0700 "$case_dir" "$case_dir/controls"
  local terminal="$case_dir/controls/final-raw-write-terminal.json"
  local validation="$case_dir/controls/final-raw-write-validation.json"
  local record="$case_dir/controls/final-raw-write-record.json"
  local marker="$case_dir/stop-returned"
  STOP_STATUS=$stop_status SIDECAR_MODE=$sidecar STOP_MARKER=$marker FAKE_VALIDATOR_ACCEPT=$validator_accept \
  RUNNER=$runner TERMINAL=$terminal VALIDATION=$validation RECORD=$record CONTROL="$case_dir/controls" \
  VALIDATOR="$work/fake-validator.py" FINALIZER="$work/finalizer.sh" bash -Eeuo pipefail <<'SH'
source "$FINALIZER"
raw_write_terminal_path=$TERMINAL
raw_write_validation_path=$VALIDATION
raw_write_record_path=$RECORD
sender_wait_control_dir=$CONTROL
sender_wait_validator=$VALIDATOR
agent_stop_status=0
raw_terminal_file_status=1
raw_final_validation_status=1
stop_process() {
  [[ $1 == fixture-agent && $2 == 123 && $3 == "$CONTROL/stop" ]]
  if [[ $STOP_STATUS != 0 ]]; then return "$STOP_STATUS"; fi
  if [[ $SIDECAR_MODE == valid ]]; then printf '{}\n' > "$TERMINAL"; chmod 0600 "$TERMINAL"; fi
  if [[ $SIDECAR_MODE == invalid-mode ]]; then printf '{}\n' > "$TERMINAL"; chmod 0644 "$TERMINAL"; fi
  : > "$STOP_MARKER"
}
finalize_raw_write_after_agent_join fixture-agent 123 "$CONTROL/stop"
python3 -I -B - "$RECORD" "$STOP_STATUS" "$SIDECAR_MODE" "$FAKE_VALIDATOR_ACCEPT" <<'PY'
import json, pathlib, sys
record = json.loads(pathlib.Path(sys.argv[1]).read_text())
stop, sidecar, accept = int(sys.argv[2]), sys.argv[3], sys.argv[4] == "1"
expected_file = 0 if stop == 0 and sidecar == "valid" else 1
expected_validation = 0 if expected_file == 0 and accept else (7 if expected_file == 0 else 1)
expected_valid = stop == expected_file == expected_validation == 0
actual = (record.get("agent_natural_join_status"), record.get("terminal_file_status"), record.get("validation_status"), record.get("valid"))
expected = (stop, expected_file, expected_validation, expected_valid)
if actual != expected:
    raise SystemExit(f"record outcome changed: actual={actual!r} expected={expected!r}")
PY
SH
}
run_case correct 0 valid 1
run_case missing 0 missing 1
run_case invalid_mode 0 invalid-mode 1
run_case rejected_closure 0 valid 0
run_case join_failure 23 missing 1
python3 -I -B - "$work" <<'PY'
import json, pathlib, sys
root=pathlib.Path(sys.argv[1]); expected={"correct":True,"missing":False,"invalid_mode":False,"rejected_closure":False,"join_failure":False}
actual={name:json.loads((root/name/"controls/final-raw-write-record.json").read_text())["valid"] for name in expected}
if actual != expected: raise SystemExit(f"case outcomes changed: {actual!r}")
(root/"summary.json").write_text(json.dumps({"schema_version":1,"accepted":True,"case_outcomes":actual},indent=2,sort_keys=True)+"\n")
PY
