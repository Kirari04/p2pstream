#!/usr/bin/env python3
"""Run parser contracts and compare only immutable attempt-2 artifacts."""
from __future__ import annotations
import hashlib,importlib.util,json,os,sys,time
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
REPO=Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
COMPONENT=REPO/"tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy-ordinary-proof"
ATTEMPT=COMPONENT/"runs/ordinary-proof-attempt-2"; RECORDS=ATTEMPT/"records"
ATTEMPT_LEDGER_SHA="9df5003a9f64f55d680358741b4041db018b1cd9e5c4490b1de51f9b9748dca3"
CP5=REPO/"tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy/review/raw-occupancy-source-checkpoint-5"
CP5_SHA="997fdd95c02936414608bd8f8ad8ff3de5b0876e315db1cdd3f61f55fc41adcc"
CP5_DRIVER=CP5/"validation-source/run-focused.py"; CP5_DRIVER_SHA="b68aaec8403fb02dd031df1c73fbe37706b92cd57e6c4bb26a3acc01b7d3745d"
HELPER=REPO/"tmp/continuation-20261016/wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"; HELPER_SHA="8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
PYTHON=Path("/usr/bin/python3.14"); PYTHON_SHA="52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"

def sha(path):
 h=hashlib.sha256()
 with Path(path).open("rb") as f:
  for block in iter(lambda:f.read(1<<20),b""): h.update(block)
 return h.hexdigest()
def exact(path,digest):
 path=Path(path)
 if path.is_symlink() or not path.is_file() or sha(path)!=digest: raise ValueError(f"hash mismatch {path}")
def load(name,path,digest):
 exact(path,digest); spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None: raise ValueError(f"cannot import {path}")
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def write_json(path,value):
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,"w") as f: json.dump(value,f,indent=2,sort_keys=True);f.write("\n")
def write_text(path,value):
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,"w") as f:f.write(value)
def inventory(root):
 result={}
 for path in sorted(root.rglob("*")):
  if path.is_symlink(): raise ValueError(f"symlink {path}")
  if path.is_file(): result[path.relative_to(root).as_posix()]=sha(path)
 return result
def verify_attempt():
 exact(RECORDS/"SHA256SUMS.txt",ATTEMPT_LEDGER_SHA)
 for line in (RECORDS/"SHA256SUMS.txt").read_text().splitlines():
  digest,name=line.split("  ",1);pure=PurePosixPath(name)
  if pure.is_absolute() or ".." in pure.parts or name!=pure.as_posix():raise ValueError("unsafe attempt ledger")
  exact(RECORDS.joinpath(*pure.parts),digest)
 final=json.loads((RECORDS/"FINAL.json").read_text())
 if final.get("accepted") is not False or final.get("issue")!="RuntimeError: compare status 1" or final.get("checkpoint_sha256")!="15d484577ec6974f5f8bf8211482634b90ab6f406d9cfcbd611fc0ba7d8c639d" or not all(final.get("post_checks",{}).values()):raise ValueError("attempt2 result changed")
 for side in ("baseline","candidate"):
  expected=json.loads((RECORDS/f"{side}-source-post.json").read_text()).get("files")
  if inventory(ATTEMPT/f"{side}/source")!=expected:raise ValueError(f"attempt2 {side} source changed")
 return final
def main():
 if len(sys.argv)!=3:raise ValueError("usage: run-offline-compare-attempt2.py FRESH_OUTPUT EXPECTED_CHECKPOINT_SHA256")
 output=Path(sys.argv[1]).resolve();expected=sys.argv[2];checkpoint=Path(__file__).resolve().parent
 if output.exists() or output.parent!=(COMPONENT/"runs").resolve():raise ValueError("fresh owned output required")
 output.mkdir(mode=0o700);records=output/"records";records.mkdir(mode=0o700)
 write_text(records/"start-utc",time.strftime("%Y-%m-%dT%H:%M:%SZ\n",time.gmtime()))
 accepted=False;comparison_completed=False;issue=None;driver=None;checkpoint_pre=cp5_pre=None
 try:
  driver=load("cp5_driver",CP5_DRIVER,CP5_DRIVER_SHA);owned=load("owned",HELPER,HELPER_SHA);exact(PYTHON,PYTHON_SHA)
  checkpoint_pre=driver.verify_component(checkpoint,expected);cp5_pre=driver.verify_component(CP5,CP5_SHA);attempt_final=verify_attempt()
  write_json(records/"inputs.json",{"schema_version":1,"checkpoint_sha256":expected,"raw_checkpoint5_sha256":CP5_SHA,"attempt2_ledger_sha256":ATTEMPT_LEDGER_SHA,"attempt2_final":attempt_final,"python_sha256":PYTHON_SHA,"owned_helper_sha256":HELPER_SHA})
  env={"HOME":os.environ["HOME"],"PATH":"/usr/bin:/bin","LC_ALL":"C","TZ":"Europe/Zurich"}
  def run(name,argv,allowed=(0,)):
   status=owned.run(records,name,[str(x) for x in argv],REPO,env,60)
   if status not in allowed:raise RuntimeError(f"{name} status {status}")
   return status
  parser_result=records/"parser-contracts.json"
  run("parser-contracts",[PYTHON,"-I","-B",checkpoint/"test_compiler_parser.py","--output",parser_result])
  parser_audit=json.loads(parser_result.read_text())
  expected_cases={"blank_flags","nosplit_flag","multi_token_flags","exact_symbol_and_data_sets","duplicate_stext_rejected","duplicate_aux_rejected","empty_metadata_rejected"}
  if parser_audit.get("schema_version")!=1 or parser_audit.get("accepted") is not True or set(parser_audit.get("cases",{}))!=expected_cases or not all(parser_audit["cases"].values()):raise ValueError("parser contract audit rejected")
  source_baseline=ATTEMPT/"baseline/source/internal/agent/agent.go";source_candidate=ATTEMPT/"candidate/source/internal/agent/agent.go"
  compare_status=run("compare",[PYTHON,"-I","-B",checkpoint/"compare_agent_ordinary.py",
   "--baseline-objdump",RECORDS/"baseline-objdump.stdout.log","--baseline-nm",RECORDS/"baseline-nm.stdout.log","--baseline-asm",RECORDS/"baseline-asm.stderr.log","--baseline-escape",RECORDS/"baseline-escape.stderr.log","--baseline-layout",RECORDS/"baseline-layout.json","--baseline-source",source_baseline,
   "--candidate-objdump",RECORDS/"candidate-objdump.stdout.log","--candidate-nm",RECORDS/"candidate-nm.stdout.log","--candidate-asm",RECORDS/"candidate-asm.stderr.log","--candidate-escape",RECORDS/"candidate-escape.stderr.log","--candidate-layout",RECORDS/"candidate-layout.json","--candidate-source",source_candidate,"--output",records/"proof"],allowed=(0,1))
  report=json.loads((records/"proof/report.json").read_text())
  report_accepted=report.get("accepted") is True and all(report.get("gates",{}).values())
  if compare_status!=(0 if report_accepted else 1):raise ValueError("comparator status/report mismatch")
  comparison_completed=True;accepted=report_accepted
  if not accepted:issue="ordinary proof rejected"
 except BaseException as error:issue=f"{type(error).__name__}: {error}"
 finally:
  checks={};errors={}
  def check(name,operation):
   try:checks[name]=bool(operation())
   except BaseException as error:checks[name]=False;errors[name]=f"{type(error).__name__}: {error}"
  check("attempt2_unchanged",lambda:verify_attempt() is not None)
  check("checkpoint_unchanged",lambda:driver is not None and checkpoint_pre is not None and driver.verify_component(checkpoint,expected)==checkpoint_pre)
  check("raw_checkpoint5_unchanged",lambda:driver is not None and cp5_pre is not None and driver.verify_component(CP5,CP5_SHA)==cp5_pre)
  check("python_unchanged",lambda:sha(PYTHON)==PYTHON_SHA);check("owned_helper_unchanged",lambda:sha(HELPER)==HELPER_SHA);check("cp5_driver_unchanged",lambda:sha(CP5_DRIVER)==CP5_DRIVER_SHA)
  def joined():
   return all(not json.loads(p.read_text()).get("forced_cleanup") and json.loads(p.read_text()).get("group_joined") is True for p in records.glob("*.lifecycle.json"))
  check("all_started_process_groups_joined_without_force",joined)
  accepted=accepted and all(checks.values())
  write_json(records/"FINAL.json",{"schema_version":1,"accepted":accepted,"comparison_completed":comparison_completed,"issue":issue,"post_checks":checks,"post_errors":errors,"attempt2_ledger_sha256":ATTEMPT_LEDGER_SHA,"endpoint_or_traffic":False})
  write_text(records/"FINAL.status","0\n" if accepted else "1\n");write_text(records/"end-utc",time.strftime("%Y-%m-%dT%H:%M:%SZ\n",time.gmtime()))
  write_text(records/"SHA256SUMS.txt","".join(f"{sha(p)}  {p.relative_to(records).as_posix()}\n" for p in sorted(records.rglob("*")) if p.is_file() and p.name!="SHA256SUMS.txt"))
 return 0 if accepted else 1
if __name__=="__main__":raise SystemExit(main())
