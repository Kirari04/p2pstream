//go:build !p2pstream_qualification

package agent

import (
	"io"
	"net/http"

	"github.com/hashicorp/yamux"
)

type qualificationRawWriteTerminalRecorder struct{}

func newExternalQualificationRawWriteTerminalRecorder(int) (*qualificationRawWriteTerminalRecorder, error) {
	return &qualificationRawWriteTerminalRecorder{}, nil
}

func (*qualificationRawWriteTerminalRecorder) observe(tunnelSessionObservation) {}
func (*qualificationRawWriteTerminalRecorder) write() error                     { return nil }

func installExternalQualificationRawWriteObserver() (func() error, error) {
	return func() error { return nil }, nil
}

func qualificationBindRawWriteRequest(req *http.Request, _ tunnelLaneRegistration) (*http.Request, error) {
	return req, nil
}

func qualificationBindRawWriteBody(_ *http.Request, body io.ReadWriteCloser) (io.ReadWriteCloser, error) {
	return body, nil
}

func qualificationRetireRawWriteSession(_ *yamux.Session) error { return nil }
