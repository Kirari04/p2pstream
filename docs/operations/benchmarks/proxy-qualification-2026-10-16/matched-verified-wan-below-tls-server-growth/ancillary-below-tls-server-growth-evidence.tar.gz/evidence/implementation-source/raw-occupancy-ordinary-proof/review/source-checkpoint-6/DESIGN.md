# Raw-occupancy ordinary-build proof

This source-only proof compares the audited sender-build source with the raw-write
checkpoint-5 overlay in an ordinary build (no `p2pstream_qualification` tag).
It is deliberately limited to the runtime surface changed by that overlay:

* the exact `p2pstream/internal/agent.connectAndServe` text-symbol family;
* compiler frame, stack-map, escape/cost, and machine-code records for that family;
* exact size, alignment, field order, field type, and field offset for `Options`,
  `tunnelSessionObservation`, and `tunnelLaneRegistration`.

Only load addresses, intra-function branch targets, and source positions are
normalized. Instructions, symbol sizes/cardinality, frames, PCDATA/FUNCDATA,
referenced compiler data, escape decisions and costs, and layouts must be equal.
The expected symbol family is fixed to the parent and its seven observed
closures; it is not discovered from candidate output.

The previously accepted Yamux proof is reused, not rerun. The driver verifies
the immutable proof receipt, checkpoint-10 manifest, report, supplement ledger,
supplement sidecar, and outer ledger. This reuse is valid only because the raw
checkpoint adds tagged Yamux files and does not modify ordinary Yamux source.

The layout probe is an identical validation-only file copied into both fresh
materializations. The proof driver must run through the reviewed owned-process
helper, use pinned Go 1.26.6 with offline module/cache settings, preserve every
direct status and lifecycle record, and reject forced cleanup. No endpoint or
network workload is involved.

The driver uses the same fail-closed Go environment and exact root/Yamux
`GOMOD` checks as raw checkpoint 5. Its single-test layout stream is audited by
the checkpoint-5 JSON auditor before extraction. On every exit it records and
checks both materialized source inventories, both frozen checkpoints, all tool
and helper hashes, every accepted prior-proof input, and natural group joins;
the final acceptance bit includes all of those postchecks.

Attempt 1 proved the baseline export, compiler assembly, and escape diagnostics,
then stopped when the ordinary layout test exposed a pre-existing Linux test
whose control test depends on qualification-only declarations while its helper
functions are still required by another ordinary Linux fixture. The resume
driver splits only `TestExternalQualificationWANSenderWaitControl` and its
test-only imports into a `linux && p2pstream_qualification` validation file,
identically in both materializations; the Linux helper definitions remain
available. It binds the exact split diff and both replacement files. It verifies
the complete failed-attempt ledger, outcome, source
inventories, statuses, lifecycles, and three baseline artifact hashes before
copying those successful artifacts. It does not repeat those three baseline
compile operations. Candidate compilation, both fixed layout probes, archive
inspection, and comparison run in the fresh resumed attempt.

Attempt 2 completed all compilation, layouts, `nm`, and `objdump`, then the
comparator rejected valid `STEXT nosplit size=...` headers before comparison.
The corrected parser captures the complete literal flag field and compares it;
it does not discard `nosplit` or any future space-separated flag sequence.
Focused synthetic contracts cover empty, `nosplit`, and multi-token flags plus
duplicate text/data headers and missing stack metadata. A separate offline
driver verifies the entire attempt-2 ledger and both materialized source
inventories, runs those contracts, and consumes only its saved artifacts. A
completed substantive mismatch is retained as comparison status 1 with the
full per-gate report; it is never converted into acceptance.

