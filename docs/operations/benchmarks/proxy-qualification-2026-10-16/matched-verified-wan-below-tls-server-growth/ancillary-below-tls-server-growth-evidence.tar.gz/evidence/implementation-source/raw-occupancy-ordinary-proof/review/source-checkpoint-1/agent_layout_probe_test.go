package agent

import (
	"encoding/json"
	"reflect"
	"testing"
	"unsafe"
)

type ordinaryProofField struct {
	Index     int     `json:"index"`
	Name      string  `json:"name"`
	Type      string  `json:"type"`
	Offset    uintptr `json:"offset"`
	Size      uintptr `json:"size"`
	Align     int     `json:"align"`
	Anonymous bool    `json:"anonymous"`
}

type ordinaryProofType struct {
	Name   string               `json:"name"`
	Size   uintptr              `json:"size"`
	Align  uintptr              `json:"align"`
	Fields []ordinaryProofField `json:"fields"`
}

func ordinaryProofLayout(name string, value any, size, align uintptr) ordinaryProofType {
	typ := reflect.TypeOf(value)
	fields := make([]ordinaryProofField, 0, typ.NumField())
	for index := 0; index < typ.NumField(); index++ {
		field := typ.Field(index)
		fields = append(fields, ordinaryProofField{Index: index, Name: field.Name, Type: field.Type.String(), Offset: field.Offset, Size: field.Type.Size(), Align: field.Type.Align(), Anonymous: field.Anonymous})
	}
	return ordinaryProofType{Name: name, Size: size, Align: align, Fields: fields}
}

func TestQualificationAgentOrdinaryLayoutProbe(t *testing.T) {
	records := []ordinaryProofType{
		ordinaryProofLayout("Options", Options{}, unsafe.Sizeof(Options{}), unsafe.Alignof(Options{})),
		ordinaryProofLayout("tunnelSessionObservation", tunnelSessionObservation{}, unsafe.Sizeof(tunnelSessionObservation{}), unsafe.Alignof(tunnelSessionObservation{})),
		ordinaryProofLayout("tunnelLaneRegistration", tunnelLaneRegistration{}, unsafe.Sizeof(tunnelLaneRegistration{}), unsafe.Alignof(tunnelLaneRegistration{})),
	}
	encoded, err := json.Marshal(records)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("AGENT_ORDINARY_LAYOUT_JSON=%s", encoded)
}
