Source-only and unexecuted. This bounded materializer validates the exact cp8
active source corpus while excluding only the existing `integration/runs` and
`provenance` trees, then atomically installs the exact ten-file cp8-to-cp10
change set. It copies no run, receipt, binary, or provenance artifact. Existing
file modes are preserved; the two added non-executable evidence/contract files
use their reviewed cp10 modes. All eight arm guard paths must remain executable
and retain their exact pre-materialization modes; the previously corrected
sender snapshot helper must specifically remain mode 0755. The resulting active
non-run corpus must equal cp10 exactly.
