# Ordinary code-gate delta classification

The original strict proof remains rejected. Its only failed gate is `code`; `nm`, compiler frame/metadata, referenced compiler data, escape/cost, and layout gates pass.

The code canonicalizations contain exactly eight differences at identical instruction indices and offsets. Every opcode byte string is identical. The differing text is the package-generated relocation target name. The mapping is bijective: four `stmp` symbols and two `typeAssert` symbols. Each paired target section has the same kind, flags, size, initialized bytes, and relocation graph. This supports the inference that moving the exact function body into a separately selected source file renumbered package-global compiler-generated symbols.

This checkpoint does not alter the comparator, accept the ordinary proof, build runtime artifacts, or claim general safety for relocation-name differences. It is a saved-artifact classification for architecture review.
