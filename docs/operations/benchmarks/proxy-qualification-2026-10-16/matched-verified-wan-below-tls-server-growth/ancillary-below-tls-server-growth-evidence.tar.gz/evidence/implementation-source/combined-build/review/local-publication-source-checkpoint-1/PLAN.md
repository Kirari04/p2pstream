# Local receipt publication plan

This operation publishes two exact, already accepted receipt files into the final-integration provenance directory. It does not copy, rebuild, chmod, or execute the audited binaries. Final integration must use the binaries at their original audited-build paths.

Run the frozen script once with `/usr/bin/python3.14 -I -B`, the active worktree as `--worktree-root`, and the fresh directory `combined-build/provenance/local-publication-attempt-1` as `--evidence-dir`. Capture the direct and outer status separately.

Before writing, the script checks the accepted proof/build receipts, both original binaries, their two records ledgers, the independent build-result review, the current-source binding, and final-integration checkpoint 8 (`162ff6e8f6333560e8c89beb3eb2ff74452a55f30ab5593b3435e1e17f89c5aa`). The active final-integration files outside `provenance/` must exactly match that checkpoint. Both receipt destinations and the evidence directory must be absent. Each receipt is created with `O_EXCL|O_NOFOLLOW`, mode `0600`, and exact source bytes; the script then verifies both published hashes and modes and rechecks every source input and the active checkpoint. A successful evidence result is written last. A partial attempt has no accepted result and must be preserved for review rather than retried automatically.

Canonical destinations:

- `final-integration-source/provenance/raw-ordinary-proof-receipt.json` (`b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d`, mode `0600`)
- `final-integration-source/provenance/audited-combined-build-receipt.json` (`472d8abcbb2c36d866e201f32f3c8aab25f8ff478670859fbea57cc174a435c6`, mode `0600`)

Audited binaries remain at:

- `combined-build/runs/audited-build-attempt-1/bin/current-agent-wan-below-tls-audited.test` (`3467c211595b95a5ca21242630f83a976e0d6f9131aac65fa21a50d8739ad94a`, mode `0775`)
- `combined-build/runs/audited-build-attempt-1/bin/current-server-wan-below-tls-audited.test` (`dd604b0ee93ab7d413b88b42cee2028e6cc7eab9e33a3046a0759046b8e9512a`, mode `0775`)

This is local artifact publication only. It starts no endpoints and runs no traffic.
