#!/usr/bin/env python3
"""Materialize and prove the raw observer's ordinary agent build unchanged."""
from __future__ import annotations
import hashlib, importlib.util, json, os, re, shutil, sys, time
from pathlib import Path, PurePosixPath

sys.dont_write_bytecode = True
REPO=Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
COMPONENT=REPO/"tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy-ordinary-proof"
BASE=REPO/"tmp/continuation-20261016/wan-sender-wait-build-source/runs/audited-build-attempt-1/source"
CP5=REPO/"tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy/review/raw-occupancy-source-checkpoint-5"
CP5_SHA="997fdd95c02936414608bd8f8ad8ff3de5b0876e315db1cdd3f61f55fc41adcc"
CP5_DRIVER=CP5/"validation-source/run-focused.py"
CP5_DRIVER_SHA="b68aaec8403fb02dd031df1c73fbe37706b92cd57e6c4bb26a3acc01b7d3745d"
HELPER=REPO/"tmp/continuation-20261016/wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
HELPER_SHA="8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
GO=Path("/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go")
GO_SHA="29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45"
PYTHON=Path("/usr/bin/python3.14")
PYTHON_SHA="52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
TASKSET=Path("/usr/bin/taskset")
TASKSET_SHA="42acb8e233943873f3bf9eeb1e15bd3281498b5603a5b10d0f9bc37067a12d57"
OLD_RECEIPT=REPO/"tmp/continuation-20261016/wan-sender-wait-build-source/runs/audited-build-attempt-1/records/observer-proof-receipt.json"
OLD_RECEIPT_SHA="a7fe20645470f4050816fedb14454013a7440db8ea962fd35b768b132097c8e0"
OLD_REPORT=REPO/"tmp/continuation-20261016/wan-sender-wait-source/validation-attempt-5/outputs/ordinary-proof-v2/report.json"
OLD_REPORT_SHA="ef9180aa9919410998e3da851ba64d997d81e5cd0dce08e6666e81b47c3c24fe"
OLD_CP=REPO/"tmp/continuation-20261016/wan-sender-wait-source/review/source-checkpoint-10/SHA256SUMS.txt"
OLD_CP_SHA="606931a1640153a7317eee7e3eeedd2d039d0720841e6bf62aaf22c65215b5a1"
OLD_EVIDENCE=REPO/"tmp/continuation-20261016/wan-sender-wait-source/validation-attempt-5-outer-evidence"
OLD_SUPPLEMENT=OLD_EVIDENCE/"EVIDENCE-SUPPLEMENT-SHA256SUMS.txt"
OLD_SUPPLEMENT_SHA="d808ad2b7ab903c332239973239f581dd54ba9fdef8ea2d55417697451a09ced"
OLD_SIDECAR=OLD_EVIDENCE/"EVIDENCE-SUPPLEMENT-MANIFEST.sha256"
OLD_SIDECAR_SHA="42e0ec5da0c535bc52d9cbe97945cab02e06c5b080c94a9d032ce843d7dd3568"
OLD_OUTER=OLD_EVIDENCE/"OUTER-SHA256SUMS.txt"
OLD_OUTER_SHA="0f0d6a419ce78ec95ed744702669265e8c6e01818e3a8c0ac80fe02734b74752"
SYMBOL_PATTERN=r"^p2pstream/internal/agent\.connectAndServe($|\.)"

def sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda:f.read(1<<20),b""): h.update(block)
    return h.hexdigest()
def write_json(path,value):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,"w") as f: json.dump(value,f,indent=2,sort_keys=True); f.write("\n")
def write_text(path,value):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,"w") as f: f.write(value)
def load_module(name,path,expected):
    if path.is_symlink() or not path.is_file() or sha(path)!=expected: raise ValueError(f"changed dependency {path}")
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None: raise ValueError(f"cannot import {path}")
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module
def inventory(root):
    result={}
    for path in sorted(root.rglob("*")):
        if path.is_symlink(): raise ValueError(f"symlink {path}")
        if path.is_file(): result[path.relative_to(root).as_posix()]=sha(path)
    return result
def exact(path,expected):
    if path.is_symlink() or not path.is_file() or sha(path)!=expected: raise ValueError(f"hash mismatch {path}")
def verify_old_proof():
    for path,digest in ((OLD_RECEIPT,OLD_RECEIPT_SHA),(OLD_REPORT,OLD_REPORT_SHA),(OLD_CP,OLD_CP_SHA),(OLD_SUPPLEMENT,OLD_SUPPLEMENT_SHA),(OLD_SIDECAR,OLD_SIDECAR_SHA),(OLD_OUTER,OLD_OUTER_SHA)): exact(path,digest)
    receipt=json.loads(OLD_RECEIPT.read_text()); report=json.loads(OLD_REPORT.read_text())
    if receipt.get("accepted") is not True or receipt.get("ordinary_proof_status")!=0 or receipt.get("proof_report_sha256")!=OLD_REPORT_SHA: raise ValueError("old proof receipt rejected")
    if report.get("accepted") is not True or not all(report.get("gates",{}).values()): raise ValueError("old proof report rejected")
    if OLD_SIDECAR.read_text()!=f"{OLD_SUPPLEMENT_SHA}  tmp/continuation-20261016/wan-sender-wait-source/validation-attempt-5-outer-evidence/EVIDENCE-SUPPLEMENT-SHA256SUMS.txt\n": raise ValueError("old proof sidecar content")
    # Revalidate every immutable path named by the accepted supplement.
    for line in OLD_SUPPLEMENT.read_text().splitlines():
        digest,name=line.split("  ",1)
        pure=PurePosixPath(name)
        if pure.is_absolute() or ".." in pure.parts or name!=pure.as_posix(): raise ValueError("unsafe old proof ledger path")
        exact(REPO.joinpath(*pure.parts),digest)
    return receipt
def extract_layout(stream_path,out_path):
    total=0; actions=[]; chunks=[]; package_pass=0
    for raw in stream_path.open("rb"):
        total+=len(raw)
        if total>64<<20 or len(raw)>1<<20 or not raw.endswith(b"\n"): raise ValueError("layout JSON stream bounds")
        event=json.loads(raw)
        if event.get("Package")!="p2pstream/internal/agent": continue
        if event.get("Test")=="TestQualificationAgentOrdinaryLayoutProbe":
            if event.get("Action") in ("run","pass","fail","skip"): actions.append(event["Action"])
            if event.get("Action")=="output": chunks.append(event.get("Output",""))
        elif event.get("Test") is None and event.get("Action")=="pass": package_pass+=1
    joined="".join(chunks); marker="AGENT_ORDINARY_LAYOUT_JSON="
    values=[line.split(marker,1)[1].strip() for line in joined.splitlines() if marker in line]
    if actions!=["run","pass"] or package_pass!=1 or len(values)!=1: raise ValueError("layout test audit")
    parsed=json.loads(values[0]); write_text(out_path,json.dumps(parsed,sort_keys=True,separators=(",",":"))+"\n")
def main():
    if len(sys.argv)!=3: raise ValueError("usage: run-proof.py FRESH_OUTPUT EXPECTED_PROOF_CHECKPOINT_SHA256")
    output=Path(sys.argv[1]).resolve(); expected=sys.argv[2]; checkpoint=Path(__file__).resolve().parent
    if output.exists() or output.parent!=(COMPONENT/"runs").resolve(): raise ValueError("fresh direct owned output required")
    output.mkdir(mode=0o700); records=output/"records"; records.mkdir(mode=0o700)
    write_text(records/"start-utc",time.strftime("%Y-%m-%dT%H:%M:%SZ\n",time.gmtime()))
    accepted=False; issue=None
    base_pre=candidate_pre=baseline_pre=checkpoint_pre=cp5_pre=None
    driver=None
    try:
        driver=load_module("cp5_driver",CP5_DRIVER,CP5_DRIVER_SHA)
        checkpoint_pre=driver.verify_component(checkpoint,expected)
        cp5_pre=driver.verify_component(CP5,CP5_SHA)
        write_json(records/"proof-checkpoint-pre.json",{"manifest_sha256":expected,"files":checkpoint_pre})
        write_json(records/"cp5-checkpoint-pre.json",{"manifest_sha256":CP5_SHA,"files":cp5_pre})
        exact(GO,GO_SHA); exact(PYTHON,PYTHON_SHA); exact(TASKSET,TASKSET_SHA)
        owned=load_module("owned_process",HELPER,HELPER_SHA)
        old_receipt=verify_old_proof()
        expected_base=json.loads((CP5/"validation-source/BASE-INVENTORY.json").read_text()).get("files")
        if inventory(BASE)!=expected_base: raise ValueError("base source changed")
        base_pre=inventory(BASE)
        write_json(records/"base-source-pre.json",{"schema_version":1,"files":base_pre})
        write_json(records/"inputs.json",{"proof_checkpoint_sha256":expected,"cp5_checkpoint_sha256":CP5_SHA,"cp5_driver_sha256":CP5_DRIVER_SHA,"go_sha256":GO_SHA,"python_sha256":PYTHON_SHA,"taskset_sha256":TASKSET_SHA,"owned_helper_sha256":HELPER_SHA,"reused_yamux_proof_receipt":old_receipt,"reused_yamux_proof_receipt_sha256":OLD_RECEIPT_SHA})
        baseline=output/"baseline/source"; candidate=output/"candidate/source"
        shutil.copytree(BASE,baseline,symlinks=False); shutil.copytree(BASE,candidate,symlinks=False)
        for source in sorted((CP5/"overlay").rglob("*")):
            if source.is_symlink(): raise ValueError("overlay symlink")
            if source.is_file():
                destination=candidate/source.relative_to(CP5/"overlay"); destination.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source,destination)
        probe=checkpoint/"agent_layout_probe_test.go"
        for source in (baseline,candidate): shutil.copy2(probe,source/"internal/agent/qualification_raw_ordinary_layout_probe_test.go")
        candidate_pre=inventory(candidate); baseline_pre=inventory(baseline)
        write_json(records/"baseline-source-pre.json",{"schema_version":1,"files":baseline_pre})
        write_json(records/"candidate-source-pre.json",{"schema_version":1,"files":candidate_pre})
        common_env={"HOME":os.environ["HOME"],"PATH":"/usr/bin:/bin","GOENV":"off","GOTOOLCHAIN":"local","GOWORK":"off","GOFLAGS":"","CGO_ENABLED":"1","GOMAXPROCS":"16","GOPATH":str(output/"gopath"),"GOMODCACHE":"/home/user/go/pkg/mod","GOPROXY":"off","GOSUMDB":"off","LC_ALL":"C","TZ":"Europe/Zurich"}
        for path in (output/"gopath",output/"tmp-baseline",output/"tmp-candidate",output/"cache-baseline",output/"cache-candidate"): path.mkdir(mode=0o700)
        write_json(records/"go-environment.json",common_env)
        def side_env(side): return dict(common_env,TMPDIR=str(output/f"tmp-{side}"),GOTMPDIR=str(output/f"tmp-{side}"),GOCACHE=str(output/f"cache-{side}"))
        active_env=side_env("baseline")
        def run(name,argv,cwd,timeout=360,env=None):
            status=owned.run(records,name,[str(x) for x in argv],cwd,active_env if env is None else env,timeout)
            if status!=0: raise RuntimeError(f"{name} status {status}")
        run("go-version",[GO,"version"],REPO,30,active_env)
        if (records/"go-version.stdout.log").read_text().strip()!="go version go1.26.6 linux/amd64": raise ValueError("Go version mismatch")
        for side,source in (("baseline",baseline),("candidate",candidate)):
            active_env=side_env(side)
            for suffix,cwd,want in (("root",source,source/"go.mod"),("yamux",source/"third_party/yamux",source/"third_party/yamux/go.mod")):
                name=f"{side}-go-env-{suffix}"
                run(name,[GO,"env","-json","GOMOD","GOWORK","GOENV","GOTOOLCHAIN","GOMODCACHE","GOPATH","GOPROXY","GOSUMDB"],cwd,30,active_env)
                effective=json.loads((records/f"{name}.stdout.log").read_text())
                expected_env={"GOMOD":str(want),"GOWORK":"off","GOENV":"","GOTOOLCHAIN":"local","GOMODCACHE":"/home/user/go/pkg/mod","GOPATH":str(output/"gopath"),"GOPROXY":"off","GOSUMDB":"off"}
                if effective!=expected_env: raise ValueError(f"effective Go environment changed: {name}")
        archives={}
        for side,source in (("baseline",baseline),("candidate",candidate)):
            active_env=side_env(side)
            run(f"{side}-export",[TASKSET,"-c","0-15",GO,"list","-a","-export","-f","{{.Export}}","./internal/agent"],source)
            export_lines=(records/f"{side}-export.stdout.log").read_text().splitlines()
            if len(export_lines)!=1: raise ValueError("export path cardinality")
            export_path=Path(export_lines[0]); archive=records/f"{side}-agent.a"
            if not export_path.is_file(): raise ValueError("missing export archive")
            shutil.copy2(export_path,archive); archives[side]=archive
            run(f"{side}-asm",[TASKSET,"-c","0-15",GO,"build","-a","-trimpath","-gcflags=p2pstream/internal/agent=-S","./internal/agent"],source)
            run(f"{side}-escape",[TASKSET,"-c","0-15",GO,"build","-a","-trimpath","-gcflags=p2pstream/internal/agent=-m=2","./internal/agent"],source)
            run(f"{side}-layout",[TASKSET,"-c","0-15",GO,"test","-json","-count=1","-timeout=300s","-run","^TestQualificationAgentOrdinaryLayoutProbe$","./internal/agent"],source)
            if not driver.audit_go_json(records/f"{side}-layout.stdout.log",checkpoint/"EXPECTED-LAYOUT-TESTS.json",records/f"{side}-layout.audit.json"):
                raise ValueError(f"exact layout Go JSON audit rejected: {side}")
            extract_layout(records/f"{side}-layout.stdout.log",records/f"{side}-layout.json")
            run(f"{side}-nm",[GO,"tool","nm","-size",archive],source,60)
            run(f"{side}-objdump",[GO,"tool","objdump","-s",SYMBOL_PATTERN,archive],source,60)
        compare=checkpoint/"compare_agent_ordinary.py"; proof=records/"proof"
        active_env=side_env("candidate")
        run("compare",[PYTHON,"-I",compare,
            "--baseline-objdump",records/"baseline-objdump.stdout.log","--baseline-nm",records/"baseline-nm.stdout.log","--baseline-asm",records/"baseline-asm.stderr.log","--baseline-escape",records/"baseline-escape.stderr.log","--baseline-layout",records/"baseline-layout.json","--baseline-source",baseline/"internal/agent/agent.go",
            "--candidate-objdump",records/"candidate-objdump.stdout.log","--candidate-nm",records/"candidate-nm.stdout.log","--candidate-asm",records/"candidate-asm.stderr.log","--candidate-escape",records/"candidate-escape.stderr.log","--candidate-layout",records/"candidate-layout.json","--candidate-source",candidate/"internal/agent/agent.go","--output",proof],REPO,60)
        report=json.loads((proof/"report.json").read_text())
        if report.get("accepted") is not True or not all(report.get("gates",{}).values()): raise ValueError("ordinary proof rejected")
        if inventory(BASE)!=base_pre or inventory(baseline)!=baseline_pre or inventory(candidate)!=candidate_pre: raise ValueError("source changed during proof")
        if driver.verify_component(checkpoint,expected)!=checkpoint_pre or driver.verify_component(CP5,CP5_SHA)!=cp5_pre: raise ValueError("checkpoint changed during proof")
        for lifecycle in records.glob("*.lifecycle.json"):
            value=json.loads(lifecycle.read_text())
            if value.get("forced_cleanup") or value.get("group_joined") is not True or value.get("direct_status")!=0: raise ValueError(f"invalid lifecycle {lifecycle.name}")
        accepted=True
    except BaseException as error:
        issue=f"{type(error).__name__}: {error}"
    finally:
        checks={}; post_errors={}
        def post_check(name,operation):
            try: checks[name]=bool(operation())
            except BaseException as error: checks[name]=False; post_errors[name]=f"{type(error).__name__}: {error}"
        def source_check(name,path,before):
            if before is None: return False
            after=inventory(path)
            target=records/f"{name}-source-post.json"
            if not target.exists(): write_json(target,{"schema_version":1,"files":after})
            return after==before
        def proof_checkpoint_check():
            if checkpoint_pre is None or driver is None: return False
            after=driver.verify_component(checkpoint,expected)
            if not (records/"proof-checkpoint-post.json").exists(): write_json(records/"proof-checkpoint-post.json",{"manifest_sha256":expected,"files":after})
            return after==checkpoint_pre
        def cp5_checkpoint_check():
            if cp5_pre is None or driver is None: return False
            after=driver.verify_component(CP5,CP5_SHA)
            if not (records/"cp5-checkpoint-post.json").exists(): write_json(records/"cp5-checkpoint-post.json",{"manifest_sha256":CP5_SHA,"files":after})
            return after==cp5_pre
        def old_proof_check(): verify_old_proof(); return True
        def lifecycle_check():
            for path in records.glob("*.lifecycle.json"):
                value=json.loads(path.read_text())
                if value.get("forced_cleanup") or value.get("group_joined") is not True:
                    return False
            return True
        post_check("base_source_unchanged",lambda:base_pre is not None and inventory(BASE)==base_pre)
        post_check("baseline_materialized_source_unchanged",lambda:source_check("baseline",output/"baseline/source",baseline_pre))
        post_check("candidate_materialized_source_unchanged",lambda:source_check("candidate",output/"candidate/source",candidate_pre))
        post_check("proof_checkpoint_unchanged",proof_checkpoint_check)
        post_check("raw_checkpoint5_unchanged",cp5_checkpoint_check)
        post_check("go_tool_unchanged",lambda:sha(GO)==GO_SHA)
        post_check("python_tool_unchanged",lambda:sha(PYTHON)==PYTHON_SHA)
        post_check("taskset_tool_unchanged",lambda:sha(TASKSET)==TASKSET_SHA)
        post_check("owned_process_helper_unchanged",lambda:sha(HELPER)==HELPER_SHA)
        post_check("cp5_driver_unchanged",lambda:sha(CP5_DRIVER)==CP5_DRIVER_SHA)
        post_check("reused_yamux_proof_unchanged",old_proof_check)
        post_check("all_started_process_groups_joined_without_force",lifecycle_check)
        accepted=accepted and all(value is True for value in checks.values())
        final={"schema_version":1,"accepted":accepted,"issue":issue,"checkpoint_sha256":expected,"cp5_checkpoint_sha256":CP5_SHA,"reused_yamux_proof_report_sha256":OLD_REPORT_SHA,"post_checks":checks,"post_errors":post_errors,"endpoint_or_traffic":False}
        write_json(records/"FINAL.json",final); write_text(records/"FINAL.status","0\n" if accepted else "1\n"); write_text(records/"end-utc",time.strftime("%Y-%m-%dT%H:%M:%SZ\n",time.gmtime()))
        ledger=[]
        for path in sorted(records.rglob("*")):
            if path.is_file() and path.name!="SHA256SUMS.txt": ledger.append(f"{sha(path)}  {path.relative_to(records).as_posix()}\n")
        write_text(records/"SHA256SUMS.txt","".join(ledger))
    return 0 if accepted else 1
if __name__=="__main__": raise SystemExit(main())
