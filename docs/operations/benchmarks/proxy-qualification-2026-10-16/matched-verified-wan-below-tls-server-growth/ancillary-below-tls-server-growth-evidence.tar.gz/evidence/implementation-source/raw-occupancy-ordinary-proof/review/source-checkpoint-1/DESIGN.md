# Raw-occupancy ordinary-build proof

This source-only proof compares the audited sender-build source with the raw-write
checkpoint-5 overlay in an ordinary build (no `p2pstream_qualification` tag).
It is deliberately limited to the runtime surface changed by that overlay:

* the exact `p2pstream/internal/agent.connectAndServe` text-symbol family;
* compiler frame, stack-map, escape/cost, and machine-code records for that family;
* exact size, alignment, field order, field type, and field offset for `Options`,
  `tunnelSessionObservation`, and `tunnelLaneRegistration`.

Only load addresses, intra-function branch targets, and source positions are
normalized. Instructions, symbol sizes/cardinality, frames, PCDATA/FUNCDATA,
referenced compiler data, escape decisions and costs, and layouts must be equal.
The expected symbol family is fixed to the parent and its seven observed
closures; it is not discovered from candidate output.

The previously accepted Yamux proof is reused, not rerun. The driver verifies
the immutable proof receipt, checkpoint-10 manifest, report, supplement ledger,
supplement sidecar, and outer ledger. This reuse is valid only because the raw
checkpoint adds tagged Yamux files and does not modify ordinary Yamux source.

The layout probe is an identical validation-only file copied into both fresh
materializations. The proof driver must run through the reviewed owned-process
helper, use pinned Go 1.26.6 with offline module/cache settings, preserve every
direct status and lifecycle record, and reject forced cleanup. No endpoint or
network workload is involved.

