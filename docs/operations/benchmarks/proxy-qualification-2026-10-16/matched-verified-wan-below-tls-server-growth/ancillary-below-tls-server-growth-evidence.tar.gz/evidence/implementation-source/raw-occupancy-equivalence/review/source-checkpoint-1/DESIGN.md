# Saved-artifact generated-reference equivalence supplement

Status: source only. The original strict ordinary report remains `accepted:false` because six package-generated symbol names differ. This checkpoint does not change runtime source, the strict comparator, build tags, tests, binaries, endpoints, or WAN traffic.

The supplement permits only the exact evidence-derived bijection of six generated targets at the exact eight differing `connectAndServe` instruction sites. It requires identical symbol and instruction cardinality, offsets, opcode bytes, all instruction text outside the mapped generated target, complete target section kind/flags/size/initialized bytes/relocation graph, and the complete incoming occurrence graph. Both mutable type-assert caches must remain distinct and exclusively referenced by `connectAndServe`. The result separately states `ordinary_untagged_code_and_referents_equivalent:true` and `strict_generated_symbol_names_equal:false`.

Focused contracts retain the real positive artifacts and reject changed target bytes, section type, section size, target relocation, aliased target, changed instruction site, a new unmapped difference, and a foreign incoming owner. No arbitrary mapping is accepted through arguments or configuration.

`run-equivalence.py` verifies the complete immutable focused-proof attempt-2 ledger (`0eec1a...`), the isolation checkpoint, Python and reviewed owned-process helper, runs the contracts and proof as bounded naturally joined child groups, and writes the proposed `raw-ordinary-proof-receipt.json`. Publication to the final integration provenance path is a separate reviewed step.
