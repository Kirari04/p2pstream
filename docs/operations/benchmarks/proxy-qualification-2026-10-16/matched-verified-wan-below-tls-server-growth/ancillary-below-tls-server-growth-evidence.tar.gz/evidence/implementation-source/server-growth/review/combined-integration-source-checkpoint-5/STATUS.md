Source-only combined-integration checkpoint 5 candidate. No combined contract, build, endpoint, or WAN execution has occurred.

Checkpoint 1 through checkpoint 4 are preserved unchanged. Checkpoint 5 corrects only the bounded no-endpoint driver evidence closure. The exact five- and nine-case summaries are copied into a ledger-bound record; every regular contract artifact is size-bounded and hashed; the intentional symlink-negative artifact is recorded by lstat path and link target without being followed; and the driver requires the exact four expected natural process-group lifecycle records. The records ledger therefore binds the complete bounded contract evidence rather than only subprocess logs.

The final external receipt must bind the fresh owned copied integration tree and every imported helper path/hash before and after execution. Publication remains blocked on review and execution of this bounded driver and on pending external receipts in INPUTS.json.
