#!/usr/bin/env bash
set -Eeuo pipefail

integration_dir=$(cd "$(dirname "$0")" && pwd)
combined_root=$(realpath "$integration_dir/..")
mature_sender_root=$(realpath "$integration_dir/../../../wan-sender-wait-integration-source")
combined_checkpoint=$(realpath "$integration_dir/../../server-growth/review/combined-integration-source-checkpoint-5")
supervisor="$integration_dir/run-wan-below-tls-arm.sh"
validator="$integration_dir/validate-wan-below-tls-arm.py"
snapshot_validator="$integration_dir/validate-sender-wait-snapshot.py"
raw_write_validator="$integration_dir/validate-raw-write-activity.py"
server_growth_validator="$integration_dir/validate-server-receive-growth.py"
raw_closure_validator="$integration_dir/validate-post-join-raw-closure.py"
copy_record_validator="$integration_dir/validate-copy-record.py"
runner="$integration_dir/generated/qualify-proxy-agent-growth-wan-below-tls.sh"
runner_generator="$integration_dir/build-runner-source.py"
runner_query_block="$integration_dir/runner-query-block.sh.txt"
runner_wrapper_block="$integration_dir/runner-wrapper-block.sh.txt"
base_runner="$integration_dir/../../wan-read-wait-stack-intern-source/integration-source/runs/sustained-matched-protocol-1/preflight/runner-rebuilt.sh"
sender_runner_patch="$mature_sender_root/SENDER-WAIT-RUNNER.patch"
sender_control_patch="$mature_sender_root/GO-CONTROL-PATCH.diff"
sender_design="$mature_sender_root/DESIGN-PROPOSAL.md"
sender_observer_checkpoint="$integration_dir/../../wan-sender-wait-source/review/source-checkpoint-9/SHA256SUMS.txt"
sender_observer_patch="$integration_dir/../../wan-sender-wait-source/review/source-checkpoint-9/SOURCE-PATCH.diff"
sender_integration_checkpoint="$mature_sender_root/review/implementation-source-checkpoint-10/SHA256SUMS.txt"
reviewed_integration_manifest="$mature_sender_root/provenance/reviewed-integration-source-manifest-cp10.json"
reviewed_integration_verifier="$integration_dir/verify-reviewed-integration-manifest.py"
sender_build_manifest="$mature_sender_root/provenance/audited-server-build-manifest.json"
sender_harness_receipt="$mature_sender_root/provenance/sender-validator-manifest-correction-receipt.json"
base_cp7_checkpoint="$mature_sender_root/review/implementation-source-checkpoint-7/SHA256SUMS.txt"
base_cp7_reviewed_manifest="$mature_sender_root/provenance/reviewed-integration-source-manifest.json"
base_cp7_runner="$mature_sender_root/review/implementation-source-checkpoint-7/integration-source/generated/qualify-proxy-agent-growth-wan-sender-wait.sh"
historical_cp10_runner="$mature_sender_root/review/implementation-source-checkpoint-10/integration-source/generated/qualify-proxy-agent-growth-wan-sender-wait.sh"
combined_checkpoint_manifest="$combined_checkpoint/SHA256SUMS.txt"
combined_contract_ledger="$integration_dir/../../server-growth/runs/combined-contract-attempt-1/records/SHA256SUMS.txt"

# These hashes intentionally remain non-hex until independent ordinary proof,
# audited diagnostic builds, and the final reviewed-corpus receipt exist.  The
# source checkpoint is therefore fail-closed and cannot start an endpoint.
expected_raw_ordinary_proof_receipt_sha256=PENDING_RAW_ORDINARY_PROOF_RECEIPT_SHA256
expected_combined_build_receipt_sha256=PENDING_COMBINED_BUILD_RECEIPT_SHA256
expected_final_reviewed_manifest_sha256=PENDING_FINAL_REVIEWED_MANIFEST_SHA256
raw_ordinary_proof_receipt="$combined_root/provenance/raw-ordinary-proof-receipt.json"
combined_build_receipt="$combined_root/provenance/audited-combined-build-receipt.json"
final_reviewed_manifest="$combined_root/provenance/reviewed-final-integration-manifest.json"
query_dispatch_contract="$integration_dir/contracts/test-query-dispatch.sh"
snapshot_contract="$integration_dir/contracts/test-sender-wait-validator.py"
runner_binding_contract="$integration_dir/contracts/test-runner-sender-bindings.py"
arm_binding_contract="$integration_dir/contracts/test-sender-arm-bindings.py"
server_binary=""
aggregate_agent_binary=""
server_source_ref=""
aggregate_agent_source_ref=""
output_dir=""
size_mode=sustained

while (($#)); do
  case "$1" in
    --server-binary) server_binary=$2; shift 2 ;;
    --aggregate-agent-binary) aggregate_agent_binary=$2; shift 2 ;;
    --server-source-ref) server_source_ref=$2; shift 2 ;;
    --aggregate-agent-source-ref) aggregate_agent_source_ref=$2; shift 2 ;;
    --output-dir) output_dir=$2; shift 2 ;;
    --small-diagnostic) size_mode=small; shift ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done

for pending in "$expected_raw_ordinary_proof_receipt_sha256" "$expected_combined_build_receipt_sha256" \
  "$expected_final_reviewed_manifest_sha256"; do
  [[ $pending =~ ^[0-9a-f]{64}$ ]] || {
    echo "final proof/build/reviewed-corpus receipt hashes are pending; endpoint execution is blocked" >&2
    exit 2
  }
done

[[ -x $server_binary && -x $aggregate_agent_binary && -x $supervisor && -x $validator &&
   -f $snapshot_validator && -x $raw_write_validator && -x $server_growth_validator &&
   -x $raw_closure_validator && -x $copy_record_validator && -x $runner && -x $runner_generator ]] || {
  echo "sender diagnostic binaries and harness executables are required" >&2
  exit 2
}
[[ -f $raw_ordinary_proof_receipt && -f $combined_build_receipt && -f $final_reviewed_manifest ]] || {
  echo "final proof/build/reviewed-corpus receipts are unavailable" >&2
  exit 2
}
[[ -n $server_source_ref && -n $aggregate_agent_source_ref && -n $output_dir ]] || {
  echo "source refs and output directory are required" >&2
  exit 2
}
server_binary=$(realpath "$server_binary")
aggregate_agent_binary=$(realpath "$aggregate_agent_binary")
for tool in cmp jq openssl python3 sha256sum; do
  command -v "$tool" >/dev/null || { echo "$tool is required" >&2; exit 2; }
done
[[ $(sha256sum "$raw_ordinary_proof_receipt" | awk '{print $1}') == "$expected_raw_ordinary_proof_receipt_sha256" &&
   $(sha256sum "$combined_build_receipt" | awk '{print $1}') == "$expected_combined_build_receipt_sha256" &&
   $(sha256sum "$final_reviewed_manifest" | awk '{print $1}') == "$expected_final_reviewed_manifest_sha256" ]] || {
  echo "final proof/build/reviewed-corpus receipt hash mismatch" >&2
  exit 2
}

server_sha=$(sha256sum "$server_binary" | awk '{print $1}')
agent_sha=$(sha256sum "$aggregate_agent_binary" | awk '{print $1}')
jq -e '.schema_version == 1 and .diagnostic == "wan-below-tls-raw-write" and
       .accepted == true and .ordinary_untagged_exact == true and
       .endpoint_or_traffic == false' "$raw_ordinary_proof_receipt" >/dev/null || {
  echo "raw ordinary proof receipt was not accepted" >&2; exit 2;
}
jq -e --arg server "$server_sha" --arg agent "$agent_sha" \
  --arg server_ref "$server_source_ref" --arg agent_ref "$aggregate_agent_source_ref" \
  --arg proof "$expected_raw_ordinary_proof_receipt_sha256" '
  .schema_version == 1 and .diagnostic == "wan-below-tls-server-growth" and
  .accepted == true and .diagnostic_only == true and .traffic_run == false and
  .server_binary_sha256 == $server and .agent_binary_sha256 == $agent and
  .server_source_ref == $server_ref and .agent_source_ref == $agent_ref and
  .raw_ordinary_proof_receipt_sha256 == $proof
' "$combined_build_receipt" >/dev/null || {
  echo "combined build receipt did not bind the requested source and binary tuple" >&2; exit 2;
}
[[ $(sha256sum "$base_runner" | awk '{print $1}') == e9e453206cd479e1d29b78c05cf4d0eaf0cbaefe3c6ff13f0ba9594235c3bea0 &&
   $(sha256sum "$sender_observer_checkpoint" | awk '{print $1}') == 9f96e06bfd571fdf3550d095e6818b949bff0e3cdd733394e7ce93299e965e30 &&
   $(sha256sum "$sender_observer_patch" | awk '{print $1}') == 02f5ab266a7c6225dcf242dacb70edcf322cc790420f62e0d9ec8ae1ec11d130 ]] || {
  echo "frozen sender observer, runner base, or integration checkpoint changed" >&2
  exit 2
}
[[ $(sha256sum "$combined_checkpoint_manifest" | awk '{print $1}') == 7a5aa90f45d588fc05e58f1968772b7a0accbad295bfecc7470bcb980022aab5 &&
   $(sha256sum "$combined_contract_ledger" | awk '{print $1}') == d63e8212ba90000f5067c20546a7f9084ae65f0073aa3cb9690c3c0c8615ef37 &&
   $(sha256sum "$runner" | awk '{print $1}') == 3e7edb7eae8a24f83b02904c3b87cfb7a1b9caaa0f179a4afe0fe1d8f51d6eab &&
   $(sha256sum "$validator" | awk '{print $1}') == 5853c80c10b00a90888be0577dab42af340cd3308b3206d3c58faa93223ac42e &&
   $(sha256sum "$snapshot_validator" | awk '{print $1}') == e61ce3e7d1e20ececad3ec6234183df10d7a1f566e682a29e4e88a8c7832bc60 &&
   $(sha256sum "$raw_write_validator" | awk '{print $1}') == e4d1c7fd76773f136a54bfb1dae35a5664258e88e95f1c3706a5fd290d62c90c &&
   $(sha256sum "$server_growth_validator" | awk '{print $1}') == 5e863173071fbf5c64344ad85563cfa15ed827c2b67891b5d420c904f543070f &&
   $(sha256sum "$raw_closure_validator" | awk '{print $1}') == 7b5b7962f603ebd7c160fabcdb9d4a78b7699e9866b4ed4172480be25b847eae &&
   $(sha256sum "$copy_record_validator" | awk '{print $1}') == f1c70a2f347a77975a00330d4d37929700b1a38bac5fa195c3dff02b3f773c26 ]] || {
  echo "combined runner, validators, or accepted no-endpoint contract receipt changed" >&2
  exit 2
}
[[ -f $sender_build_manifest && -f $sender_harness_receipt && -f $sender_integration_checkpoint &&
   -f $reviewed_integration_manifest && -f $reviewed_integration_verifier &&
   -f $base_cp7_checkpoint && -f $base_cp7_reviewed_manifest && -x $base_cp7_runner ]] || {
  echo "audited sender-duration build and cp10 validator receipt are unavailable" >&2; exit 2;
}
jq -e --arg server "f2e6cf390fdcd727b8c7120a6d877dc3a53afe9d8b970aa7b0d7f6cc892a7bdc" --arg agent "43eadb7664d70f9585887ac824cc7e6dcb55d6fa40731e3888b6fa5a1cc8d74f" --arg server_ref "8ac4c8df8237e37777ba2fac0da6f949da17bdea" --arg agent_ref "8ac4c8df8237e37777ba2fac0da6f949da17bdea" \
  --arg base_runner "$(sha256sum "$base_cp7_runner" | awk '{print $1}')" \
  --arg base_checkpoint "$(sha256sum "$base_cp7_checkpoint" | awk '{print $1}')" \
  --arg base_reviewed "$(sha256sum "$base_cp7_reviewed_manifest" | awk '{print $1}')" '
  .diagnostic == "wan-sender-wait" and .diagnostic_only == true and .traffic_run == false and
  .base_source_ref == $server_ref and .aggregate_agent_source_ref == $agent_ref and
  .sender_observer_checkpoint_sha256 == "9f96e06bfd571fdf3550d095e6818b949bff0e3cdd733394e7ce93299e965e30" and
  .sender_observer_patch_sha256 == "02f5ab266a7c6225dcf242dacb70edcf322cc790420f62e0d9ec8ae1ec11d130" and
  .sender_integration_checkpoint_sha256 == $base_checkpoint and
  .reviewed_integration_source_manifest_sha256 == $base_reviewed and
  .source.pre_post_status == 0 and .module.pre_post_status == 0 and .toolchain.pre_post_status == 0 and
  .tests.normal_status == 0 and .tests.race_status == 0 and .ordinary_proof_status == 0 and
  .build.status == 0 and .build.source_compare_status == 0 and
  .runner_sha256 == $base_runner and
  .sender_snapshot_validator_sha256 == "de77c640a72236f4df2d482702ba21cdc225731bb0a0fef3dac14e915ed32da9" and
  .sender_runner_patch_sha256 == "7ea2f679c170e0580832c653afcb64e80fa27da9c8ea613f84092b9994ff6e27" and
  .sender_control_patch_sha256 == "dc60a099541ad9c67d35a5af46d8af2a94e2f277725f53f8e658598dd5515c9f" and
  .output.server_sha256 == $server and .output.agent_sha256 == $agent
' "$sender_build_manifest" >/dev/null || { echo "audited sender-duration build manifest did not bind the requested inputs" >&2; exit 2; }
jq -e --arg build_manifest "$(sha256sum "$sender_build_manifest" | awk '{print $1}')" \
  --arg integration_checkpoint "$(sha256sum "$sender_integration_checkpoint" | awk '{print $1}')" \
  --arg reviewed_manifest "$(sha256sum "$reviewed_integration_manifest" | awk '{print $1}')" \
  --arg runner "$(sha256sum "$historical_cp10_runner" | awk '{print $1}')" \
  --arg helper "$(sha256sum "$integration_dir/../../wan-read-wait-capacity-source/validate-copy-record.py" | awk '{print $1}')" \
  --arg server "f2e6cf390fdcd727b8c7120a6d877dc3a53afe9d8b970aa7b0d7f6cc892a7bdc" --arg agent "43eadb7664d70f9585887ac824cc7e6dcb55d6fa40731e3888b6fa5a1cc8d74f" '
  .schema_version == 1 and .action == "sender-validator-manifest-correction" and
  .diagnostic == "wan-sender-wait" and .accepted == true and
  .base_build_manifest_sha256 == $build_manifest and
  .base_integration_checkpoint_sha256 == "fa0f2237aef78d5253882eef1fc45942446f0d96627efa8e0234161858eedb34" and
  .base_reviewed_manifest_sha256 == "2eee698fdfa8322b42491f3b090ac7f3535c3046d3f3f827460cc142d8c4aca1" and
  .cp10_integration_checkpoint_sha256 == $integration_checkpoint and
  .cp10_reviewed_manifest_sha256 == $reviewed_manifest and .cp10_runner_sha256 == $runner and
  .copy_record_validator_sha256 == $helper and .server_binary_sha256 == $server and .agent_binary_sha256 == $agent and
  .base_source_ref == "8ac4c8df8237e37777ba2fac0da6f949da17bdea" and
  .aggregate_agent_source_ref == "8ac4c8df8237e37777ba2fac0da6f949da17bdea" and
  .sender_observer_checkpoint_sha256 == "9f96e06bfd571fdf3550d095e6818b949bff0e3cdd733394e7ce93299e965e30" and
  .sender_observer_patch_sha256 == "02f5ab266a7c6225dcf242dacb70edcf322cc790420f62e0d9ec8ae1ec11d130" and
  .base_runner_sha256 == "e9e453206cd479e1d29b78c05cf4d0eaf0cbaefe3c6ff13f0ba9594235c3bea0" and
  .sender_control_patch_sha256 == "dc60a099541ad9c67d35a5af46d8af2a94e2f277725f53f8e658598dd5515c9f" and
  .sender_snapshot_validator_sha256 == "de77c640a72236f4df2d482702ba21cdc225731bb0a0fef3dac14e915ed32da9" and
  .cp9_contracts.direct_status == 0 and .cp9_contracts.source_pre_post_equal == true and
  .offline_validator_contract.direct_status == 0 and .offline_validator_contract.input_compare_status == 0 and
  .offline_validator_contract.accepted == true and .offline_validator_contract.outer_tool_status == 1 and
  .offline_verification.h1_status == 0 and .offline_verification.h2_status == 0 and
  .offline_verification.input_compare_status == 0 and .offline_verification.audit_status == 0 and
  .offline_verification.accepted == true and .offline_verification.outer_tool_status == 1 and
  .cp9_integration_checkpoint_sha256 == "601ffd71333a0476e9a6aef92eb3947604fd91a594d6d4c906d9f1e8a2de3fc0" and
  .cp9_reviewed_manifest_sha256 == "fdf2e441f130aac840d2b08cd0b82a7196a71d4dd1519a1c49b6dfcdebfc3fab" and
  .cp9_harness_receipt_sha256 == "11b3f6cfbd1de9a8ff612ef483b127b87e16d4099debc369d5f5db542fc9d53e" and
  .validator_delta_sha256 == "df717131968ffefabbb7619983c60d57a130c381ad54e93aae44429dd6d781e2" and
  .offline_validator_sha256 == "9ae7fa74c6be09706d0b77759b52b696dbc302ffd14b3ba8c6a44b23547a2860" and
  .unchanged_go_source_and_binaries == true and .endpoint_execution_run == false and .traffic_run == false
' "$sender_harness_receipt" >/dev/null || { echo "cp10 validator correction receipt changed" >&2; exit 2; }

output_dir=$(realpath -m "$output_dir")
allowed_root=$(realpath -m "$integration_dir/runs")
[[ $output_dir == "$allowed_root"/* ]] || { echo "output must remain below $allowed_root" >&2; exit 2; }
[[ ! -e $output_dir ]] || { echo "output directory already exists: $output_dir" >&2; exit 2; }
mkdir -p "$output_dir/tls" "$output_dir/preflight"
python3 "$reviewed_integration_verifier" "$reviewed_integration_manifest" "$mature_sender_root" \
  "$output_dir/preflight/historical-cp10-source-verification.json"
python3 "$reviewed_integration_verifier" "$final_reviewed_manifest" "$combined_root" \
  "$output_dir/preflight/final-integration-source-verification.json"

rebuilt="$output_dir/preflight/runner-rebuilt.sh"
python3 "$runner_generator" "$base_runner" "$runner_query_block" "$runner_wrapper_block" "$rebuilt"
cmp "$rebuilt" "$historical_cp10_runner"
printf '%s\n' verified > "$output_dir/preflight/generated-runner-consistency.status"

cert="$output_dir/tls/public.test.crt.pem"
key="$output_dir/tls/public.test.key.pem"
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes \
  -subj /CN=public.test -addext subjectAltName=DNS:public.test -days 1 \
  -keyout "$key" -out "$cert" >/dev/null 2>&1
cert=$(realpath "$cert")
key=$(realpath "$key")
openssl x509 -in "$cert" -noout -checkhost public.test >/dev/null
expected_leaf_sha256=$(openssl x509 -in "$cert" -outform DER | sha256sum | awk '{print $1}')
[[ $expected_leaf_sha256 =~ ^[0-9a-f]{64}$ ]]

write_pair_hashes() {
  local destination=$1
  python3 - "$destination" "$0" "$supervisor" "$validator" "$snapshot_validator" "$raw_write_validator" "$server_growth_validator" "$raw_closure_validator" "$copy_record_validator" "$runner" \
    "$runner_generator" "$runner_query_block" "$runner_wrapper_block" "$base_runner" \
    "$sender_runner_patch" "$sender_control_patch" "$sender_design" "$sender_observer_checkpoint" \
    "$sender_observer_patch" "$sender_integration_checkpoint" "$reviewed_integration_manifest" "$reviewed_integration_verifier" "$sender_build_manifest" "$sender_harness_receipt" \
    "$base_cp7_checkpoint" "$base_cp7_reviewed_manifest" "$base_cp7_runner" \
    "$query_dispatch_contract" "$snapshot_contract" "$runner_binding_contract" "$arm_binding_contract" \
    "$combined_checkpoint_manifest" "$combined_contract_ledger" "$raw_ordinary_proof_receipt" "$combined_build_receipt" "$final_reviewed_manifest" \
    "$server_binary" "$aggregate_agent_binary" "$cert" "$key" \
    "$server_source_ref" "$aggregate_agent_source_ref" "$expected_leaf_sha256" "$size_mode" <<'PY'
import hashlib, json, pathlib, sys
destination, *values = sys.argv[1:]
names = (
    "wrapper supervisor validator snapshot_validator raw_write_validator server_growth_validator raw_closure_validator copy_record_validator runner runner_generator runner_query_block runner_wrapper_block base_runner "
    "sender_runner_patch sender_control_patch sender_design sender_observer_checkpoint sender_observer_patch "
    "sender_integration_checkpoint reviewed_integration_manifest reviewed_integration_verifier sender_build_manifest sender_harness_receipt "
    "base_cp7_checkpoint base_cp7_reviewed_manifest base_cp7_runner query_dispatch_contract snapshot_contract runner_binding_contract arm_binding_contract "
    "combined_checkpoint_manifest combined_contract_ledger raw_ordinary_proof_receipt combined_build_receipt final_reviewed_manifest "
    "server_binary aggregate_agent_binary certificate_pem private_key_pem"
).split()
paths, tail = values[:len(names)], values[len(names):]
server_ref, agent_ref, fingerprint, size_mode = tail
def sha(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()
result = {
    "schema_version": 1, "diagnostic": "wan-below-tls-server-growth", "diagnostic_only": True,
    "size_mode": size_mode, "server_source_ref": server_ref,
    "aggregate_agent_source_ref": agent_ref, "expected_leaf_der_sha256": fingerprint,
    "sha256": {name: sha(path) for name, path in zip(names, paths)},
}
pathlib.Path(destination).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
PY
}
write_pair_hashes "$output_dir/pre-hashes.json"

common=(
  --server-binary "$server_binary"
  --aggregate-agent-binary "$aggregate_agent_binary"
  --server-source-ref "$server_source_ref"
  --aggregate-agent-source-ref "$aggregate_agent_source_ref"
  --cert "$cert"
  --key "$key"
  --expected-leaf-sha256 "$expected_leaf_sha256"
)
[[ $size_mode == sustained ]] || common+=(--small-diagnostic)

set +e
"$supervisor" "${common[@]}" --protocol h1 --output-dir "$output_dir/h1" \
  > "$output_dir/h1-supervisor.stdout.log" 2> "$output_dir/h1-supervisor.stderr.log"
h1_status=$?
set -e
printf '%s\n' "$h1_status" > "$output_dir/h1-arm.status"

h1_safe=0
if [[ -f $output_dir/h1/supervisor-lifecycle.json && -f $output_dir/h1/outer-namespaces.json &&
      -f $output_dir/h1/attestation.json ]] && \
  jq -e '.group_joined == true and .forced == false and
         .server_scope.systemd_run_status == 0 and .server_scope.resource_status == 0 and
         .server_scope.unit_joined == true and .server_scope.unit_query_status == 0 and
         .server_scope.unit_active_state != "failed" and
         .sender_evidence.terminal_status == 0 and .sender_evidence.terminal_validation_status == 0 and
         .sender_evidence.terminal_valid == true and
         .raw_write_evidence.finalization_status == 0 and
         .raw_write_evidence.final_closure_valid == true' "$output_dir/h1/supervisor-lifecycle.json" >/dev/null && \
  jq -e '.all_private == true and .shell_pid_is_one == true and .python_parent_is_one == true and
         .cgroup_namespace_unchanged == true and .owned.cgroup == .parent.cgroup' \
         "$output_dir/h1/outer-namespaces.json" >/dev/null &&
  jq -e '.accepted == true and .raw_write_final_closure_valid == true and
         ([.sender_duration_intervals[] | select(.valid != true or .compound_tuple_join != true)] | length) == 0' \
         "$output_dir/h1/attestation.json" >/dev/null; then
  h1_safe=1
fi
printf '%s\n' "$h1_safe" > "$output_dir/h1-safe-to-continue.status"

h2_started=0
h2_status=125
if ((h1_safe)); then
  h2_started=1
  set +e
  "$supervisor" "${common[@]}" --protocol h2 --output-dir "$output_dir/h2" \
    > "$output_dir/h2-supervisor.stdout.log" 2> "$output_dir/h2-supervisor.stderr.log"
  h2_status=$?
  set -e
else
  printf '%s\n' "H2 not started because H1 topology, resource, or terminal sender-ledger closure was not proved" \
    > "$output_dir/h2-not-started.txt"
fi
printf '%s\n' "$h2_started" > "$output_dir/h2-started.status"
printf '%s\n' "$h2_status" > "$output_dir/h2-arm.status"
write_pair_hashes "$output_dir/post-hashes.json"

pair_hashes_equal=0
cmp "$output_dir/pre-hashes.json" "$output_dir/post-hashes.json" && pair_hashes_equal=1
python3 - "$output_dir/final-status.json" "$h1_status" "$h1_safe" "$h2_started" "$h2_status" \
  "$pair_hashes_equal" "$size_mode" "$output_dir" <<'PY'
import json, pathlib, sys, time
destination, h1, h1_safe, h2_started, h2, hashes_equal, size_mode, root = sys.argv[1:]
root = pathlib.Path(root)
def accepted(arm):
    path = root / arm / "attestation.json"
    return path.is_file() and json.loads(path.read_text()).get("accepted") is True
value = {
    "schema_version": 1, "diagnostic": "wan-below-tls-server-growth", "diagnostic_only": True,
    "size_mode": size_mode, "performance_result": size_mode == "sustained", "order": ["h1", "h2"],
    "same_binaries_both_arms": True, "same_verified_certificate_both_arms": True,
    "fresh_outer_topology_per_started_arm": True,
    "h1": {"status": int(h1), "safe_to_continue": h1_safe == "1", "accepted": accepted("h1")},
    "h2": {"started": h2_started == "1", "status": int(h2), "accepted": accepted("h2")},
    "pre_post_hashes_equal": hashes_equal == "1",
}
value["accepted"] = (value["h1"]["status"] == 0 and value["h1"]["safe_to_continue"] and
                     value["h1"]["accepted"] and value["h2"]["started"] and
                     value["h2"]["status"] == 0 and value["h2"]["accepted"] and
                     value["pre_post_hashes_equal"])
value["finished_unix_nano"] = time.time_ns()
pathlib.Path(destination).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
PY
printf '%s\n' complete > "$output_dir/FINAL"
((h1_status == 0 && h1_safe == 1 && h2_started == 1 && h2_status == 0 && pair_hashes_equal == 1))
