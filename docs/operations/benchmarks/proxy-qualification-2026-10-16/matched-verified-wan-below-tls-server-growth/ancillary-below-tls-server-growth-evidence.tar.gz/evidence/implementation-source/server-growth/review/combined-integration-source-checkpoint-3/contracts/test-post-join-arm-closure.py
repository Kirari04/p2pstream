#!/usr/bin/env python3
"""Exercise the arm's exact post-agent-join closure validator without endpoints."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import pathlib
import sys

if len(sys.argv) != 4:
    raise SystemExit("usage: test-post-join-arm-closure.py VALIDATOR_MODULE FRESH_WORK OUTPUT")
module_path = pathlib.Path(sys.argv[1]).resolve()
work = pathlib.Path(sys.argv[2]).resolve()
output = pathlib.Path(sys.argv[3]).resolve()
if work.exists() or output.exists() or output.parent != work.parent:
    raise SystemExit("fresh sibling work/output paths are required")
work.mkdir(mode=0o700)
spec = importlib.util.spec_from_file_location("post_join_raw_closure_validator", module_path)
if spec is None or spec.loader is None:
    raise SystemExit("closure validator cannot be imported")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class FixtureValidator:
    def __init__(self, accepted: bool):
        self.accepted = accepted
    def validate_final_closure(self, terminal, control_directory):
        del terminal, control_directory
        return {"schema_version": 1, "mode": "final-closure",
                "issues": [] if self.accepted else ["fixture rejection"],
                "accepted": self.accepted}

def write_json(path: pathlib.Path, value) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")

def artifact(path: pathlib.Path) -> dict[str, object]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
            size += len(block)
    return {"path": str(path), "size": size, "sha256": digest.hexdigest()}

def run_case(name: str) -> bool:
    directory = work / name
    directory.mkdir(mode=0o700)
    terminal = directory / "final-raw-write-terminal.json"
    validation = directory / "final-raw-write-validation.json"
    record = directory / "final-raw-write-record.json"
    accepted = name != "invalid_closure"
    if name == "symlink":
        target = directory / "terminal-target.json"
        write_json(target, {"fixture": name})
        terminal.symlink_to(target.name)
    elif name != "missing":
        write_json(terminal, {"fixture": name})
    saved = {"schema_version": 1, "mode": "final-closure",
             "issues": [] if accepted else ["fixture rejection"], "accepted": accepted}
    write_json(validation, saved)
    if name == "oversized_terminal":
        with terminal.open("r+b") as stream:
            stream.seek((4 << 20) + 1)
            stream.write(b" ")
    if name == "oversized_validation":
        with validation.open("r+b") as stream:
            stream.seek((4 << 20) + 1)
            stream.write(b" ")
    terminal_entry = artifact(terminal) if terminal.exists() else None
    value = {
        "schema_version": 1, "diagnostic": "raw-write-final-closure",
        "agent_natural_join_status": False if name == "status_false" else 0,
        "terminal_file_status": 0, "validation_status": 0,
        "terminal_artifact": terminal_entry,
        "validation_artifact": artifact(validation), "valid": True,
    }
    write_json(record, value)
    if name == "changed_hash":
        with terminal.open("a", encoding="utf-8") as stream:
            stream.write(" \n")
    if name == "invalid_mode":
        terminal.chmod(0o644)
    result = module.validate_post_join_raw_closure(directory, FixtureValidator(accepted))
    expected = name == "valid"
    actual = result.get("accepted") is True
    if actual != expected:
        raise SystemExit(f"{name}: accepted={actual!r}, expected={expected!r}, result={result!r}")
    return actual

names = ("valid", "changed_hash", "status_false", "missing", "invalid_closure", "invalid_mode", "symlink", "oversized_terminal", "oversized_validation")
outcomes = {name: run_case(name) for name in names}
summary = {"schema_version": 1, "accepted": outcomes == {name: name == "valid" for name in names},
           "case_count": len(outcomes), "case_outcomes": outcomes}
if summary["accepted"] is not True:
    raise SystemExit(f"case outcomes changed: {outcomes!r}")
write_json(output, summary)
