# Source checkpoint status

This directory is source-only. No validator, contract, Go test, build, endpoint,
or traffic command has run from this checkpoint.

The derivative preserves the exact sender validator base, binds raw occupancy
runtime-source checkpoint 3, adds one strict raw activity module and final closure mode, and
provides two unexecuted focused contract drivers. The current source supersedes
raw-validator source checkpoints 3 and 4 after review found invalid zero-DATA
fixtures, missing no-DATA/final straddling rejection, incomplete sender
composition coverage, and missing positive-envelope and closure-identity gates.
Integration into the combined
runner, arm validator, and final gate remains separately owned and must bind
this checkpoint by hash.
