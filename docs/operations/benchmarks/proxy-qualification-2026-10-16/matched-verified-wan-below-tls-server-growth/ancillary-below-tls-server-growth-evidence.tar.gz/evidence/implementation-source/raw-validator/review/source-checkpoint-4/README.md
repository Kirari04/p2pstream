# Raw-write validator source

This source-only derivative extends the exact sender snapshot validator whose
SHA-256 is recorded in `BASE-SENDER-VALIDATOR-SHA256.txt`. It is bound to the
frozen raw-occupancy runtime-source checkpoint 3 recorded in
`RAW-SCHEMA-CHECKPOINT-SHA256.txt`.

`integration/validate-raw-write-activity.py` validates the schema-1 raw-write
activity object, its unsigned bounds, duration and outcome conservation,
identity, quiescent boundaries, and the distinction between Yamux DATA
envelopes and raw writes outside those envelopes. A control-lane or
non-selected lane may retain successful outside-envelope TLS/control writes;
it must not contain a Yamux DATA envelope. Pre and terminal snapshots may
retain earlier completed activity, so they are not required to be zero.

`integration/validate-sender-wait-snapshot.py` retains every strict schema-2
sender validation gate and adds raw activity to each of the five lane records.
For the selected download it joins lane, exact non-placeholder connection
tuple, stream ID, DATA frame count, payload bytes, and Yamux framed plaintext
bytes. The pre/post and final closure gates separately bind the raw-owner
generation. It rejects raw errors, short writes, ambiguity, overlap, concurrent raw
writes, generation changes, straddling writes, or missing contained raw calls.

The `final-closure` mode reads the fixed pre/post/terminal sender records and a
separate `P2PSTREAM_QUALIFICATION_RAW_WRITE_TERMINAL_PATH` sidecar written after
the agent RunContext has joined. It requires exactly five ordered, unique lane
records; stable session/generation/tuple identity; complete reset snapshots;
observed connection close and session join; no active ownership; and no DATA
envelopes after the terminal reset. Successful outside-envelope close traffic
is retained rather than erased.

`contracts/run-raw-write-validator-contracts.py` and
`contracts/test-sender-raw-integration.py` are proposed focused offline
contract drivers for the raw schema and the preserved sender-validator
composition. The latter constructs persistent pre, pair, terminal, and final
closure inputs and representative fail-closed mutations. This checkpoint does
not claim that either has run. A later run
must preserve the exact driver, stdout, stderr, direct status, outer tool
envelope, and source pre/post hashes.

The validator does not identify TLS record type, ciphertext, syscall timing,
kernel residence, delivery, or TCP/NIC completion. It does not convert raw
connection bytes into causal credit for the original WAN performance gate.
