#!/usr/bin/env python3
"""Verify the narrow connectAndServe tag split against immutable inputs."""
from __future__ import annotations
import argparse, hashlib, json, stat
from pathlib import Path

EXPECTED_RAW_CP5_MANIFEST_SHA256 = "997fdd95c02936414608bd8f8ad8ff3de5b0876e315db1cdd3f61f55fc41adcc"
EXPECTED_BASE_AGENT_SHA256 = "db72d5947cae3f6c841a039947d288f72d6d64d04f97c7518b4107e0a31ad733"
EXPECTED_RAW_AGENT_SHA256 = "6273ca3bb9c398cd1337fa39b933d537c205b1cb247c34801dc9878e89881237"
MAX_FILE = 8 << 20

def sha(path: Path) -> str:
    info=path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size>MAX_FILE:
        raise ValueError(f"invalid file {path}")
    return hashlib.sha256(path.read_bytes()).hexdigest()

def extract(source: str) -> tuple[str,int,int]:
    marker="func connectAndServe("
    start=source.find(marker)
    if start<0 or source.find(marker,start+1)>=0:
        raise ValueError("connectAndServe declaration cardinality")
    brace=source.find("{",start); depth=0; state="normal"; escape=False; i=brace
    while i<len(source):
        c=source[i]; n=source[i+1] if i+1<len(source) else ""
        if state=="line":
            if c=="\n": state="normal"
        elif state=="block":
            if c=="*" and n=="/": state="normal"; i+=1
        elif state in ("string","rune"):
            if escape: escape=False
            elif c=="\\": escape=True
            elif (state=="string" and c=='"') or (state=="rune" and c=="'"): state="normal"
        elif state=="raw":
            if c=="`": state="normal"
        else:
            if c=="/" and n=="/": state="line"; i+=1
            elif c=="/" and n=="*": state="block"; i+=1
            elif c=='"': state="string"
            elif c=="'": state="rune"
            elif c=="`": state="raw"
            elif c=="{": depth+=1
            elif c=="}":
                depth-=1
                if depth==0: return source[start:i+1]+"\n",start,i+2
        i+=1
    raise ValueError("unterminated connectAndServe")

def files(root: Path) -> set[str]:
    result=set()
    for path in root.rglob("*"):
        info=path.lstat()
        if stat.S_ISLNK(info.st_mode): raise ValueError(f"symlink {path}")
        if stat.S_ISREG(info.st_mode): result.add(path.relative_to(root).as_posix())
        elif not stat.S_ISDIR(info.st_mode): raise ValueError(f"special path {path}")
    return result

def verify_manifest(root: Path) -> None:
    manifest=root/"SHA256SUMS.txt"
    if sha(manifest)!=EXPECTED_RAW_CP5_MANIFEST_SHA256: raise ValueError("raw cp5 manifest hash")
    seen=set()
    for line in manifest.read_text().splitlines():
        digest,rel=line.split("  ",1)
        if rel in seen or rel=="SHA256SUMS.txt": raise ValueError("raw manifest entry")
        seen.add(rel)
        if sha(root/rel)!=digest: raise ValueError(f"raw manifest mismatch {rel}")

def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument("--checkpoint",type=Path,required=True)
    p.add_argument("--raw-cp5",type=Path,required=True)
    p.add_argument("--base-source",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    a=p.parse_args()
    if a.output.exists(): raise ValueError("fresh output required")
    verify_manifest(a.raw_cp5)
    overlay=a.checkpoint/"overlay"; raw_overlay=a.raw_cp5/"overlay"
    actual=files(overlay); original=files(raw_overlay)
    additions={"internal/agent/connect_and_serve_ordinary.go","internal/agent/connect_and_serve_qualification.go"}
    if actual != original|additions: raise ValueError("overlay file set")
    changed={"internal/agent/agent.go"}
    for rel in sorted(original-changed):
        if sha(overlay/rel)!=sha(raw_overlay/rel): raise ValueError(f"unexpected delta {rel}")
    base_agent=a.base_source/"internal/agent/agent.go"; raw_agent=raw_overlay/"internal/agent/agent.go"
    if sha(base_agent)!=EXPECTED_BASE_AGENT_SHA256 or sha(raw_agent)!=EXPECTED_RAW_AGENT_SHA256:
        raise ValueError("agent input hash")
    base_text=base_agent.read_text(); raw_text=raw_agent.read_text()
    base_body,_,_=extract(base_text); raw_body,start,end=extract(raw_text)
    shared=raw_text[:start]+raw_text[end:]
    if shared.count('\t"strconv"\n')!=1: raise ValueError("strconv derivation")
    shared=shared.replace('\t"strconv"\n','',1)
    if (overlay/"internal/agent/agent.go").read_text()!=shared: raise ValueError("shared agent derivation")
    ordinary=(overlay/"internal/agent/connect_and_serve_ordinary.go").read_text()
    tagged=(overlay/"internal/agent/connect_and_serve_qualification.go").read_text()
    if not ordinary.startswith("//go:build !p2pstream_qualification\n") or extract(ordinary)[0]!=base_body:
        raise ValueError("ordinary body")
    if not tagged.startswith("//go:build p2pstream_qualification\n") or extract(tagged)[0]!=raw_body:
        raise ValueError("tagged body")
    if "func connectAndServe(" in (overlay/"internal/agent/agent.go").read_text():
        raise ValueError("shared declaration")
    body_provenance={
        "schema_version":1,
        "base_source_root":"tmp/continuation-20261016/wan-sender-wait-build-source/runs/audited-build-attempt-1/source",
        "raw_checkpoint_5":"tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy/review/raw-occupancy-source-checkpoint-5",
        "base_agent_go_sha256":sha(base_agent),
        "raw_checkpoint_5_agent_go_sha256":sha(raw_agent),
        "ordinary_connect_and_serve_sha256":hashlib.sha256(base_body.encode()).hexdigest(),
        "ordinary_connect_and_serve_bytes":len(base_body.encode()),
        "ordinary_connect_and_serve_lines":base_body.count("\n"),
        "qualification_connect_and_serve_sha256":hashlib.sha256(raw_body.encode()).hexdigest(),
        "qualification_connect_and_serve_bytes":len(raw_body.encode()),
        "qualification_connect_and_serve_lines":raw_body.count("\n"),
        "shared_agent_derivation":"raw checkpoint-5 agent.go with exact connectAndServe declaration removed and sole now-unused strconv import removed",
    }
    if json.loads((a.checkpoint/"BODY-PROVENANCE.json").read_text())!=body_provenance:
        raise ValueError("body provenance")
    a.output.mkdir()
    result={"schema_version":1,"accepted":True,"base_agent_sha256":sha(base_agent),"raw_agent_sha256":sha(raw_agent),"ordinary_body_sha256":hashlib.sha256(base_body.encode()).hexdigest(),"ordinary_body_lines":base_body.count("\n"),"tagged_body_sha256":hashlib.sha256(raw_body.encode()).hexdigest(),"tagged_body_lines":raw_body.count("\n"),"body_provenance_sha256":sha(a.checkpoint/"BODY-PROVENANCE.json"),"overlay_files":len(actual)}
    (a.output/"result.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    return 0
if __name__=="__main__": raise SystemExit(main())
