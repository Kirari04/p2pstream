#!/usr/bin/env python3
"""Fail-closed comparison of the ordinary agent runtime surface."""
from __future__ import annotations
import argparse, hashlib, json, re, stat
from pathlib import Path

MAX_INPUT = 128 << 20
PREFIX = "p2pstream/internal/agent.connectAndServe"
EXPECTED = tuple([PREFIX] + [f"{PREFIX}.func{i}" for i in range(1, 7)] + [f"{PREFIX}.func5.1"])
EXPECTED = tuple(sorted(EXPECTED))
LAYOUTS = ("Options", "tunnelSessionObservation", "tunnelLaneRegistration")
TEXT = re.compile(r"^TEXT (?P<name>\S+)\(SB\)(?: .*)?$")
OBJ = re.compile(r"^\s+(?P<src>\S+:\d+)\s+(?P<addr>0x[0-9a-f]+)\s+(?P<bytes>[0-9a-f]+)\s+(?P<asm>.*?)\s*$")
STEXT = re.compile(r"^(?P<name>\S+) STEXT (?P<flags>(?:\S+ )*)size=(?P<size>\d+) args=(?P<args>0x[0-9a-f]+) locals=(?P<locals>0x[0-9a-f]+) funcid=(?P<funcid>0x[0-9a-f]+) align=(?P<align>0x[0-9a-f]+)$")
AUX = re.compile(r"^(?P<name>\S+) SRODATA (?P<header>.*)$")
DIAG = re.compile(r"^p2pstream/internal/agent/(?P<file>[^:]+):(?P<line>\d+):(?P<col>\d+): (?P<text>.*)$")
SOURCE_POS = re.compile(r"p2pstream/internal/agent/[^:]+:\d+:\d+")
SOURCE_PARENS = re.compile(r"\s+\(p2pstream/internal/agent/[^:]+:\d+\)")
REF = re.compile(r"(?P<name>(?:gclocals·[^\s,]+|p2pstream/internal/agent\.[^\s,]+))\(SB\)")
HEX = re.compile(r"0x[0-9a-f]+")

def read(path: Path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_INPUT: raise ValueError(f"unbounded input {path}")
    raw = path.read_bytes()
    return raw.decode(), hashlib.sha256(raw).hexdigest()

def objdump(text):
    raw, current = {}, None
    for line in text.splitlines():
        match = TEXT.match(line)
        if match:
            current = match.group("name")
            if current in raw: raise ValueError(f"duplicate objdump symbol {current}")
            raw[current] = []
            continue
        if current is None: continue
        if not line: current = None; continue
        row = OBJ.match(line)
        if not row: raise ValueError(f"unparsed objdump line: {line!r}")
        raw[current].append((int(row.group("addr"),16), row.group("bytes"), row.group("asm")))
    if tuple(sorted(raw)) != EXPECTED: raise ValueError(f"objdump symbol set {sorted(raw)}")
    result = {}
    for name, rows in raw.items():
        if not rows: raise ValueError(f"empty symbol {name}")
        base = rows[0][0]; end = max(a + len(b)//2 for a,b,_ in rows)
        def target(m):
            value = int(m.group(),16)
            return f"<FUNC+0x{value-base:x}>" if base <= value <= end else m.group()
        result[name] = [{"offset":a-base,"bytes":b,"asm":HEX.sub(target,s)} for a,b,s in rows]
    return result

def nm(text):
    result = {}
    for line in text.splitlines():
        fields = line.split(None,3)
        if len(fields) != 4 or fields[3] not in EXPECTED: continue
        if fields[3] in result or fields[2] != "T": raise ValueError(f"invalid nm row {line!r}")
        result[fields[3]] = {"size":int(fields[1]),"kind":fields[2]}
    if tuple(sorted(result)) != EXPECTED: raise ValueError(f"nm symbol set {sorted(result)}")
    return result

def compiler(text):
    lines=text.splitlines(); data={}
    for i,line in enumerate(lines):
        match=AUX.match(line)
        if not match: continue
        if match.group("name") in data: raise ValueError(f"duplicate compiler data symbol {match.group('name')}")
        block=[line]; j=i+1
        while j<len(lines) and (not lines[j] or lines[j].startswith("\t")): block.append(lines[j]); j+=1
        data[match.group("name")]=block
    records={}; referenced=set()
    for i,line in enumerate(lines):
        head=STEXT.match(line)
        if not head or head.group("name") not in EXPECTED: continue
        if head.group("name") in records: raise ValueError(f"duplicate compiler text symbol {head.group('name')}")
        metadata=[]; frame=None; j=i+1
        while j<len(lines):
            candidate=lines[j]
            if STEXT.match(candidate) or (candidate and not candidate.startswith("\t")): break
            normalized=SOURCE_PARENS.sub("",candidate)
            if "\tTEXT\t" in normalized: frame=normalized.split("\tTEXT\t",1)[1]
            if "\tFUNCDATA\t" in normalized or "\tPCDATA\t" in normalized:
                metadata.append(normalized.strip()); referenced.update(m.group("name") for m in REF.finditer(normalized))
            j+=1
        if frame is None: raise ValueError(f"missing frame {head.group('name')}")
        if not metadata: raise ValueError(f"empty stack metadata {head.group('name')}")
        records[head.group("name")]={"flags":head.group("flags").rstrip(),"size":int(head.group("size")),"args":head.group("args"),"locals":head.group("locals"),"funcid":head.group("funcid"),"align":head.group("align"),"frame":frame,"stack_metadata":metadata}
    if tuple(sorted(records)) != EXPECTED: raise ValueError(f"compiler symbol set {sorted(records)}")
    missing=referenced-set(data)
    if missing: raise ValueError(f"missing compiler data {sorted(missing)}")
    return records,{name:data[name] for name in sorted(referenced)}

def function_span(source):
    marker="func connectAndServe("
    offset=source.find(marker)
    if offset<0 or source.find(marker,offset+1)>=0: raise ValueError("connectAndServe declaration cardinality")
    line=source.count("\n",0,offset)+1; start=line; depth=0; seen=False; state="normal"; escape=False; i=offset
    while i<len(source):
        c=source[i]; n=source[i+1] if i+1<len(source) else ""
        if c=="\n": line+=1
        if state=="line":
            if c=="\n": state="normal"
        elif state=="block":
            if c=="*" and n=="/": state="normal"; i+=1
        elif state in ("string","rune"):
            if escape: escape=False
            elif c=="\\": escape=True
            elif (state=="string" and c=='"') or (state=="rune" and c=="'"): state="normal"
        elif state=="raw":
            if c=="`": state="normal"
        else:
            if c=="/" and n=="/": state="line"; i+=1
            elif c=="/" and n=="*": state="block"; i+=1
            elif c=='"': state="string"
            elif c=="'": state="rune"
            elif c=="`": state="raw"
            elif c=="{": depth+=1; seen=True
            elif c=="}":
                depth-=1
                if seen and depth==0: return start,line
        i+=1
    raise ValueError("unterminated connectAndServe")

def escapes(text, start, end):
    result=[]; current=None
    for line in text.splitlines():
        match=DIAG.match(line)
        if not match: current=None; continue
        body=match.group("text")
        if not body[:1].isspace():
            number=int(match.group("line"))
            if match.group("file")!="agent.go" or not start<=number<=end: current=None; continue
            current=[SOURCE_POS.sub("<SOURCE-POSITION>",body)]; result.append(current)
        elif current is not None: current.append(SOURCE_POS.sub("<SOURCE-POSITION>",body))
    if not result: raise ValueError("no escape/cost records for connectAndServe")
    return sorted(result,key=lambda x:"\n".join(x))

def layout(text):
    value=json.loads(text)
    if not isinstance(value,list) or tuple(row.get("name") for row in value)!=LAYOUTS: raise ValueError("layout type set/order")
    required={"index","name","type","offset","size","align","anonymous"}
    for row in value:
        fields=row.get("fields")
        if not isinstance(fields,list) or [f.get("index") for f in fields]!=list(range(len(fields))) or any(set(f)!=required for f in fields): raise ValueError("layout fields")
    return value

def main():
    p=argparse.ArgumentParser()
    for side in ("baseline","candidate"):
        for kind in ("objdump","nm","asm","escape","layout","source"): p.add_argument(f"--{side}-{kind}",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True); a=p.parse_args()
    if a.output.exists(): raise ValueError("fresh output required")
    a.output.mkdir()
    parsed={}; hashes={}; provenance={}
    for side in ("baseline","candidate"):
        values={}
        for kind in ("objdump","nm","asm","escape","layout","source"):
            values[kind],hashes[f"{side}_{kind}"]=read(getattr(a,f"{side}_{kind}"))
        start,end=function_span(values["source"])
        comp,compdata=compiler(values["asm"])
        parsed[side]={"nm":nm(values["nm"]),"code":objdump(values["objdump"]),"compiler":comp,"compiler_data":compdata,"escape":escapes(values["escape"],start,end),"layout":layout(values["layout"])}
        provenance[side]={"agent_go_sha256":hashes[f"{side}_source"],"connect_and_serve_span":[start,end]}
        (a.output/f"{side}-canonical.json").write_text(json.dumps(parsed[side],indent=2,sort_keys=True)+"\n")
    gates={key:parsed["baseline"][key]==parsed["candidate"][key] for key in ("nm","code","compiler","compiler_data","escape","layout")}
    report={"schema_version":1,"accepted":all(gates.values()),"gates":gates,"expected_symbols":EXPECTED,"expected_layouts":LAYOUTS,"input_sha256":hashes,"source_provenance":provenance,"normalization":{"code":"load addresses and intra-function targets only","compiler":"source positions only; frames and referenced data exact","escape":"source positions only; decisions/text/costs exact","nm":"addresses only","layout":"none"}}
    (a.output/"report.json").write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
    return 0 if report["accepted"] else 1

if __name__=="__main__": raise SystemExit(main())
