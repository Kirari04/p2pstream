#!/usr/bin/python3
from __future__ import annotations

import hashlib
import json
import stat
from pathlib import Path

ROOT = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
BASE = ROOT / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source"
OUT = BASE / "combined-build/review/local-publication-result-review-1"

EXPECTED = {
    "publication_source": "6de8fe5aa84aff308aa28e864834efd89f367d1c1cc4c799963cde7c4a36a97a",
    "cp8": "162ff6e8f6333560e8c89beb3eb2ff74452a55f30ab5593b3435e1e17f89c5aa",
    "proof": "b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d",
    "build": "472d8abcbb2c36d866e201f32f3c8aab25f8ff478670859fbea57cc174a435c6",
    "agent": "3467c211595b95a5ca21242630f83a976e0d6f9131aac65fa21a50d8739ad94a",
    "server": "dd604b0ee93ab7d413b88b42cee2028e6cc7eab9e33a3046a0759046b8e9512a",
    "build_ledger": "9d89e974120f0a2b28c03dac1d1d5ed7031999b7b69dbcf875fabdc53a2cd96f",
    "proof_ledger": "20e69805d80384f76be0df0f83d92f9445d9181d1931f9016a9d0503a506cc6b",
    "build_review": "c49173028c00e3134b0a9f60fd97aceca757725f5522f7230d2533a8de1f6a7e",
    "proof_review": "e9e92c4448ba5ff948980e0ecea8c4353abbe97875a8e661367beb17d035fbfd",
    "source_binding": "968516dcd3234db502b392b98cf1945de28b901e9a5fd547cdcae275cc3271b2",
}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def check(path: Path, expected: str, mode: int | None = None) -> None:
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink(), path
    assert sha(path) == expected, path
    if mode is not None:
        assert stat.S_IMODE(info.st_mode) == mode, (path, oct(stat.S_IMODE(info.st_mode)))


publication = BASE / "combined-build/provenance/local-publication-attempt-1"
final_root = BASE / "final-integration-source"
build_run = BASE / "combined-build/runs/audited-build-attempt-1"
proof_run = BASE / "raw-occupancy-equivalence/runs/offline-equivalence-attempt-1/records"
cp8 = BASE / "server-growth/review/final-integration-source-checkpoint-8"

inputs = {
    "publication_source": BASE / "combined-build/review/local-publication-source-checkpoint-1/SHA256SUMS.txt",
    "cp8": cp8 / "SHA256SUMS.txt",
    "proof": proof_run / "raw-ordinary-proof-receipt.json",
    "build": build_run / "audited-combined-build-receipt.json",
    "agent": build_run / "bin/current-agent-wan-below-tls-audited.test",
    "server": build_run / "bin/current-server-wan-below-tls-audited.test",
    "build_ledger": build_run / "records/SHA256SUMS.txt",
    "proof_ledger": proof_run / "SHA256SUMS.txt",
    "build_review": BASE / "combined-build/review/independent-build-result-review-1/SHA256SUMS.txt",
    "proof_review": BASE / "raw-occupancy-equivalence/review/offline-equivalence-attempt-1-result-review/SHA256SUMS.txt",
    "source_binding": BASE / "combined-build/provenance/main-current-source-binding/binding.json",
}
for name, path in inputs.items():
    check(path, EXPECTED[name], 0o775 if name in {"agent", "server"} else None)

proof_copy = final_root / "provenance/raw-ordinary-proof-receipt.json"
build_copy = final_root / "provenance/audited-combined-build-receipt.json"
check(proof_copy, EXPECTED["proof"], 0o600)
check(build_copy, EXPECTED["build"], 0o600)
assert proof_copy.read_bytes() == inputs["proof"].read_bytes()
assert build_copy.read_bytes() == inputs["build"].read_bytes()
assert {p.name for p in publication.iterdir()} == {"START.json", "publication-result.json"}
assert {p.name for p in (final_root / "provenance").iterdir()} == {
    "raw-ordinary-proof-receipt.json", "audited-combined-build-receipt.json"
}

start = json.loads((publication / "START.json").read_text())
result = json.loads((publication / "publication-result.json").read_text())
assert start["schema_version"] == 1
assert start["binary_policy"] == "reuse_original_audited_build_paths_no_copy"
assert result["schema_version"] == 1 and result["accepted"] is True
assert result["endpoint_execution"] is False and result["wan_traffic"] is False
assert result["published_receipts"]["proof_receipt"]["sha256"] == EXPECTED["proof"]
assert result["published_receipts"]["build_receipt"]["sha256"] == EXPECTED["build"]
assert result["audited_binaries"]["agent_binary"]["sha256"] == EXPECTED["agent"]
assert result["audited_binaries"]["server_binary"]["sha256"] == EXPECTED["server"]
assert result["audited_binaries"]["agent_binary"]["copied"] is False
assert result["audited_binaries"]["server_binary"]["copied"] is False
assert start["started_utc"] <= result["finished_utc"]

expected_active = {}
for line in (cp8 / "SHA256SUMS.txt").read_text().splitlines():
    value, name = line.split("  ", 1)
    if name != "CHECKPOINT.json":
        expected_active[name] = value
active_names = {
    str(path.relative_to(final_root))
    for path in final_root.rglob("*")
    if path.is_file() and not str(path.relative_to(final_root)).startswith("provenance/")
}
assert active_names == set(expected_active)
for name, value in expected_active.items():
    check(final_root / name, value)

report = {
    "schema_version": 1,
    "accepted": True,
    "publication_result_sha256": sha(publication / "publication-result.json"),
    "publication_start_sha256": sha(publication / "START.json"),
    "publication_source_checkpoint_sha256": EXPECTED["publication_source"],
    "final_integration_checkpoint_sha256": EXPECTED["cp8"],
    "active_non_provenance_file_count": len(active_names),
    "published_receipts_exact_bytes": True,
    "published_receipts_mode_0600": True,
    "audited_binaries_reused_not_copied": True,
    "audited_binary_mode": "0o775",
    "all_bound_inputs_unchanged": True,
    "endpoint_execution": False,
    "wan_traffic": False,
    "main_native_tool_metadata": {
        "preledger_chunk_id": "ab7976",
        "preledger_status": 0,
        "preledger_observation": "sha256sum --check verified all three checkpoint entries",
        "invocation_chunk_id": "1a2923",
        "invocation_status": 0,
        "invocation_wall_time_seconds": 0.202947189,
        "invocation_output": "",
        "disclosure": "chunk IDs and execution metadata were reported by main; no full external tool transcript exists in the filesystem",
    },
}
(OUT / "REVIEW.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
