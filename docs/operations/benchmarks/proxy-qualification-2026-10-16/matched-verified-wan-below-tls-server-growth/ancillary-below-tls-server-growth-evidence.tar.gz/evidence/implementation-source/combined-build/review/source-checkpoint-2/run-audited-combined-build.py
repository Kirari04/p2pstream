#!/usr/bin/env python3
"""Materialize and build the reviewed below-TLS diagnostic corpus once."""
from __future__ import annotations
import hashlib,importlib.util,json,os,re,shutil,sys,time
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
REPO=Path('/home/user/.codex/worktrees/astra-proxy-performance/p2pstream')
CONT=REPO/'tmp/continuation-20261016'
COMP=CONT/'wan-below-tls-raw-write-source/implementation-source/combined-build'
RUNS=COMP/'runs'
BASE_RUN=CONT/'wan-sender-wait-build-source/runs/audited-build-attempt-1'
BASE_SOURCE=BASE_RUN/'source';BASE_INVENTORY=BASE_RUN/'records/source-pre.json'
BASE_INVENTORY_SHA='a54eab59cc0d5c8b04519c0d8589e6d0f1dc9ab0d4005eeb977c334f2aadeca2'
BASE_RESULT_LEDGER=BASE_RUN/'ATTEMPT-RESULT-SHA256SUMS.txt';BASE_RESULT_LEDGER_SHA='daf117185bba11f27ff09e1ff796cf7f5e73729431d91d32422e89d628c5056b'
BASE_SUPPLEMENT=CONT/'wan-sender-wait-build-source/provenance/audited-build-attempt-1-supplement/RECORDS-SUPPLEMENT-SHA256SUMS.txt';BASE_SUPPLEMENT_SHA='bd74f1e717079b9b9db59a1f0e7114cd13f32e2e6d1a1be1d3211091cf786225'
BASE_SUPPLEMENT_SIDECAR=BASE_SUPPLEMENT.with_name('RECORDS-SUPPLEMENT-MANIFEST.sha256');BASE_SUPPLEMENT_SIDECAR_SHA='5c6139cc725fa93ba2166d87c8ca070c0bcbc94cb76c790c8f68b77cc3b6a9ad'
RAW_RUNTIME=CONT/'wan-below-tls-raw-write-source/implementation-source/raw-occupancy/review/raw-occupancy-source-checkpoint-3';RAW_RUNTIME_SHA='4474770be44e933572b79ece0d5db970f3a27f8792a41c27adc31269230b6bab'
RAW_ISOLATION=CONT/'wan-below-tls-raw-write-source/implementation-source/raw-occupancy-connect-isolation/review/source-checkpoint-5';RAW_ISOLATION_SHA='85afe09e358fd3b9f9277ec6bc8de42ea4fae59a646f5810b0d5dfa3d3cc6d6c'
SERVER=CONT/'wan-below-tls-raw-write-source/implementation-source/server-growth/review/source-checkpoint-3';SERVER_SHA='29e33466c5f79928b4d3805fcf957fb0d49b1eeb1f0c8fba720ff001c7193856'
INTEGRATION=CONT/'wan-below-tls-raw-write-source/implementation-source/server-growth/review/final-integration-source-checkpoint-4';INTEGRATION_SHA='1a72d835ee7d79a9ca4d12bdcf8bdbbbfdf32a1104d43ce36d6ba9ad9b54329e'
PROOF_RECORDS=CONT/'wan-below-tls-raw-write-source/implementation-source/raw-occupancy-equivalence/runs/offline-equivalence-attempt-1/records';PROOF_LEDGER_SHA='20e69805d80384f76be0df0f83d92f9445d9181d1931f9016a9d0503a506cc6b';PROOF_RECEIPT_SHA='b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d'
RAW_FOCUSED=CONT/'wan-below-tls-raw-write-source/implementation-source/raw-occupancy/runs/raw-focused-attempt-1/records';RAW_FOCUSED_SHA='26b6e59c6a4911328b1684221ba41779c7f4aa7aafbf516c253628916d70a656'
SERVER_FOCUSED=CONT/'wan-below-tls-raw-write-source/runs/server-growth-focused-attempt-1/records';SERVER_FOCUSED_SHA='2109895c1d9d0d4824f49b9823b034a44693dfa1d8ca05c5340491024fa726ff'
COMBINED=CONT/'wan-below-tls-raw-write-source/implementation-source/server-growth/runs/combined-contract-attempt-1/records';COMBINED_SHA='d63e8212ba90000f5067c20546a7f9084ae65f0073aa3cb9690c3c0c8615ef37'
HELPER=CONT/'wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py';HELPER_SHA='8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440'
GO=Path('/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go');GO_SHA='29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45';GO_VERSION='go version go1.26.6 linux/amd64'
SOURCE_REF='8ac4c8df8237e37777ba2fac0da6f949da17bdea';GO_MOD_SHA='165d373cd30192573bfd30e0f0997b393c433368d3ac01df8b178aaf4bdb5d65';GO_SUM_SHA='7e451e21339534258c770d5d4669cffd5c126d38e91026e09f35fa93c89173f2'
EXPECTED_INPUTS={'schema_version','accepted','build_checkpoint_manifest_sha256','build_driver_sha256'}
def sha(p):
 p=Path(p);st=p.lstat()
 if p.is_symlink() or not p.is_file():raise ValueError(f'unsafe file {p}')
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def load_json(p):return json.loads(Path(p).read_text())
def write_json(p,v):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def write_text(p,v):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:f.write(v)
def safe_name(n,allow_dot=False):
 if allow_dot:
  if not n.startswith('./') or n.startswith('././'):raise ValueError(f'bad dot path {n}')
  n=n[2:]
 q=PurePosixPath(n)
 if not n or n!=q.as_posix() or q.is_absolute() or '.' in q.parts or '..' in q.parts:raise ValueError(f'unsafe path {n}')
 return n
def inventory(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink():raise ValueError(f'symlink {p}')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def parse_ledger(path,allow_dot=False):
 out={}
 for line in path.read_text().splitlines():
  d,n=line.split('  ',1);n=safe_name(n,allow_dot)
  if re.fullmatch(r'[0-9a-f]{64}',d) is None or n in out:raise ValueError(f'bad ledger {path}')
  out[n]=d
 if not out:raise ValueError(f'empty ledger {path}')
 return out
def verify_ledger(root,ledger,exact=False,exclude=()):
 for n,d in ledger.items():
  p=root.joinpath(*PurePosixPath(n).parts)
  if not p.resolve().is_relative_to(root.resolve()) or sha(p)!=d:raise ValueError(f'ledger mismatch {n}')
 if exact:
  actual={k:v for k,v in inventory(root).items() if k not in set(exclude)}
  if actual!=ledger:raise ValueError(f'ledger coverage mismatch {root}')
def verify_component(root,digest,allow_dot=False):
 manifest=root/'SHA256SUMS.txt'
 if sha(manifest)!=digest:raise ValueError(f'component manifest {root}')
 ledger=parse_ledger(manifest,allow_dot);verify_ledger(root,ledger,True,('SHA256SUMS.txt',));return ledger
def verify_repo_ledger(path,digest,absolute=False):
 if sha(path)!=digest:raise ValueError(f'evidence ledger {path}')
 seen=set()
 for line in path.read_text().splitlines():
  d,n=line.split('  ',1)
  if re.fullmatch(r'[0-9a-f]{64}',d) is None or n in seen:raise ValueError(f'bad evidence ledger {path}')
  seen.add(n)
  p=Path(n) if absolute else REPO.joinpath(*PurePosixPath(safe_name(n)).parts)
  if absolute and (not p.is_absolute() or not p.resolve().is_relative_to(REPO)):raise ValueError(f'unsafe absolute evidence {n}')
  if sha(p)!=d:raise ValueError(f'evidence mismatch {n}')
def verify_result(root,digest,final_name):
 if sha(root/'SHA256SUMS.txt')!=digest:raise ValueError(f'result ledger {root}')
 ledger=parse_ledger(root/'SHA256SUMS.txt',next(iter((root/'SHA256SUMS.txt').read_text().splitlines())).split('  ',1)[1].startswith('./'))
 verify_ledger(root,ledger,True,('SHA256SUMS.txt',))
 value=load_json(root/final_name)
 if value.get('accepted') is not True or not all(value.get('post_checks',{}).values()):raise ValueError(f'unaccepted result {root}')
 lifecycles=list(root.glob('*.lifecycle.json'))
 if not lifecycles or not all(load_json(p).get('group_joined') is True and load_json(p).get('forced_cleanup') is False and load_json(p).get('direct_status')==0 for p in lifecycles):raise ValueError(f'non-natural evidence lifecycle {root}')
def load_helper():
 if sha(HELPER)!=HELPER_SHA:raise ValueError('owned helper')
 spec=importlib.util.spec_from_file_location('owned_build_helper',HELPER);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def publish_last(path,value):
 data=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode();tmp=path.with_name('.'+path.name+'.tmp')
 fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.rename(tmp,path)
def check_static_inputs():
 verify_component(RAW_RUNTIME,RAW_RUNTIME_SHA)
 verify_component(RAW_ISOLATION,RAW_ISOLATION_SHA)
 verify_component(SERVER,SERVER_SHA,True)
 verify_component(INTEGRATION,INTEGRATION_SHA)
 verify_result(RAW_FOCUSED,RAW_FOCUSED_SHA,'RESULT.json')
 verify_result(SERVER_FOCUSED,SERVER_FOCUSED_SHA,'RESULT.json')
 verify_result(COMBINED,COMBINED_SHA,'FINAL.json')
 if sha(PROOF_RECORDS/'SHA256SUMS.txt')!=PROOF_LEDGER_SHA or sha(PROOF_RECORDS/'raw-ordinary-proof-receipt.json')!=PROOF_RECEIPT_SHA:raise ValueError('proof evidence')
 proof_ledger=parse_ledger(PROOF_RECORDS/'SHA256SUMS.txt');verify_ledger(PROOF_RECORDS,proof_ledger,True,('SHA256SUMS.txt','raw-ordinary-proof-receipt.json'))
 proof=load_json(PROOF_RECORDS/'raw-ordinary-proof-receipt.json')
 if not (proof.get('accepted') is True and proof.get('ordinary_untagged_code_and_referents_equivalent') is True and proof.get('strict_generated_symbol_names_equal') is False and proof.get('strict_proof_accepted') is False and proof.get('records_ledger_sha256')==PROOF_LEDGER_SHA and proof.get('final_sha256')==sha(PROOF_RECORDS/'FINAL.json')):raise ValueError('proof receipt')
 verify_repo_ledger(BASE_RESULT_LEDGER,BASE_RESULT_LEDGER_SHA,True)
 if sha(BASE_SUPPLEMENT)!=BASE_SUPPLEMENT_SHA or sha(BASE_SUPPLEMENT_SIDECAR)!=BASE_SUPPLEMENT_SIDECAR_SHA:raise ValueError('base supplement binding')
 verify_repo_ledger(BASE_SUPPLEMENT,BASE_SUPPLEMENT_SHA)
def main():
 if len(sys.argv)!=3:raise SystemExit('usage: run-audited-combined-build.py FRESH_OUTPUT APPROVED-INPUTS.json')
 out=Path(sys.argv[1]).resolve();approved_path=Path(sys.argv[2]).resolve(strict=True);checkpoint=Path(__file__).resolve().parent
 if out.exists() or out.parent!=RUNS.resolve() or not RUNS.is_dir():raise SystemExit('fresh direct output required')
 approved=load_json(approved_path)
 if set(approved)!=EXPECTED_INPUTS or approved.get('schema_version')!=1 or approved.get('accepted') is not True or any(re.fullmatch(r'[0-9a-f]{64}',str(approved.get(k,''))) is None for k in ('build_checkpoint_manifest_sha256','build_driver_sha256')):raise SystemExit('approved-input schema')
 if sha(checkpoint/'SHA256SUMS.txt')!=approved['build_checkpoint_manifest_sha256'] or sha(Path(__file__).resolve())!=approved['build_driver_sha256']:raise SystemExit('unapproved driver')
 verify_component(checkpoint,approved['build_checkpoint_manifest_sha256'])
 out.mkdir(mode=0o700);records=out/'records';source=out/'source';binaries=out/'bin'
 records.mkdir();binaries.mkdir();write_text(records/'start-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()));write_json(records/'approved-inputs.json',approved)
 accepted=False;issue=None;source_pre=None;helper=None;static_pre=None
 try:
  static_pre={p:sha(p) for p in (GO,HELPER,BASE_INVENTORY,BASE_RESULT_LEDGER,BASE_SUPPLEMENT,BASE_SUPPLEMENT_SIDECAR,RAW_RUNTIME/'SHA256SUMS.txt',RAW_ISOLATION/'SHA256SUMS.txt',SERVER/'SHA256SUMS.txt',INTEGRATION/'SHA256SUMS.txt',PROOF_RECORDS/'SHA256SUMS.txt',PROOF_RECORDS/'raw-ordinary-proof-receipt.json',RAW_FOCUSED/'SHA256SUMS.txt',SERVER_FOCUSED/'SHA256SUMS.txt',COMBINED/'SHA256SUMS.txt')}
  check_static_inputs();helper=load_helper()
  if sha(GO)!=GO_SHA or sha(BASE_INVENTORY)!=BASE_INVENTORY_SHA:raise ValueError('tool/base inventory binding')
  base=load_json(BASE_INVENTORY).get('files')
  if not isinstance(base,dict) or inventory(BASE_SOURCE)!=base:raise ValueError('audited base source changed')
  shutil.copytree(BASE_SOURCE,source,copy_function=shutil.copy2)
  if inventory(source)!=base:raise ValueError('base materialization')
  raw={p.relative_to(RAW_ISOLATION/'overlay').as_posix():sha(p) for p in sorted((RAW_ISOLATION/'overlay').rglob('*')) if p.is_file()}
  server={p.relative_to(SERVER/'overlay').as_posix():sha(p) for p in sorted((SERVER/'overlay').rglob('*')) if p.is_file()}
  if len(raw)!=11 or len(server)!=4 or set(raw)&set(server):raise ValueError('overlay shape/overlap')
  for overlay,files in ((RAW_ISOLATION/'overlay',raw),(SERVER/'overlay',server)):
   for name,digest in files.items():
    src=overlay.joinpath(*PurePosixPath(name).parts);dst=source.joinpath(*PurePosixPath(name).parts);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    if sha(dst)!=digest:raise ValueError(f'overlay copy {name}')
  expected=dict(base);expected.update(raw);expected.update(server);source_pre=inventory(source)
  if source_pre!=expected:raise ValueError('combined corpus exactness')
  write_json(records/'source-pre.json',{'schema_version':1,'base_source_ref':SOURCE_REF,'files':source_pre})
  write_json(records/'corpus.json',{'schema_version':1,'accepted':True,'base_file_count':len(base),'raw_overlay_file_count':len(raw),'server_overlay_file_count':len(server),'final_file_count':len(source_pre),'raw_overlay':raw,'server_overlay':server})
  if sha(source/'go.mod')!=GO_MOD_SHA or sha(source/'go.sum')!=GO_SUM_SHA:raise ValueError('module files')
  write_json(records/'module-pre.json',{'go.mod':GO_MOD_SHA,'go.sum':GO_SUM_SHA})
  common={'HOME':'/home/user','PATH':'/usr/bin:/bin','GOENV':'off','GOTOOLCHAIN':'local','GOWORK':'off','GOFLAGS':'','CGO_ENABLED':'1','GOMAXPROCS':'16','GOPATH':str(out/'gopath'),'GOMODCACHE':'/home/user/go/pkg/mod','GOPROXY':'off','GOSUMDB':'off','LC_ALL':'C','TZ':'UTC','TMPDIR':str(out/'tmp'),'GOCACHE':str(out/'gocache')}
  for p in (out/'gopath',out/'tmp',out/'gocache'):p.mkdir(mode=0o700)
  write_json(records/'go-environment.json',common)
  version_env={'HOME':'/home/user','PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC'}
  if helper.run(records,'toolchain-version-pre',[str(GO),'version'],REPO,version_env,30)!=0 or (records/'toolchain-version-pre.stdout.log').read_text().strip()!=GO_VERSION:raise ValueError('Go version pre')
  if helper.run(records,'go-env',[str(GO),'env','-json','GOMOD','GOWORK','GOENV','GOTOOLCHAIN','GOMODCACHE','GOPATH','GOPROXY','GOSUMDB'],source,common,30)!=0:raise ValueError('go env')
  gev=load_json(records/'go-env.stdout.log')
  expected_env={'GOMOD':str(source/'go.mod'),'GOWORK':'off','GOENV':'','GOTOOLCHAIN':'local','GOMODCACHE':'/home/user/go/pkg/mod','GOPATH':str(out/'gopath'),'GOPROXY':'off','GOSUMDB':'off'}
  if gev!=expected_env:raise ValueError('effective Go env')
  outputs={}
  for short,pkg in (('agent','./internal/agent'),('server','./internal/server')):
   binary=binaries/f'current-{short}-wan-below-tls-audited.test'
   if helper.run(records,f'build-{short}',['/usr/bin/taskset','-c','0-15',str(GO),'test','-tags=p2pstream_qualification','-c','-o',str(binary),pkg],source,common,600)!=0:raise ValueError(f'build {short}')
   if helper.run(records,f'build-{short}-version',[str(GO),'version','-m',str(binary)],source,common,30)!=0:raise ValueError(f'version {short}')
   version_text=(records/f'build-{short}-version.stdout.log').read_text()
   if f': go1.26.6\n\tpath\tp2pstream/internal/{short}.test\n' not in version_text or '\n\tbuild\t-tags=p2pstream_qualification\n' not in version_text:raise ValueError(f'binary Go metadata {short}')
   if binary.stat().st_size<=0 or binary.stat().st_mode&0o111==0:raise ValueError(f'non-executable binary {short}')
   outputs[short]={'path':str(binary.relative_to(out)),'sha256':sha(binary),'mode':oct(binary.stat().st_mode&0o777),'go_version_m_sha256':sha(records/f'build-{short}-version.stdout.log')}
  if helper.run(records,'toolchain-version-post',[str(GO),'version'],REPO,version_env,30)!=0 or (records/'toolchain-version-post.stdout.log').read_text().strip()!=GO_VERSION:raise ValueError('Go version post')
  write_json(records/'source-post.json',{'schema_version':1,'base_source_ref':SOURCE_REF,'files':inventory(source)})
  write_json(records/'module-post.json',{'go.mod':sha(source/'go.mod'),'go.sum':sha(source/'go.sum')})
  statuses={p.name.removesuffix('.direct.status'):int(p.read_text()) for p in records.glob('*.direct.status')}
  expected_status={'toolchain-version-pre','go-env','build-agent','build-agent-version','build-server','build-server-version','toolchain-version-post'}
  if set(statuses)!=expected_status or any(statuses.values()):raise ValueError('command status set')
  lifecycle={name:load_json(records/f'{name}.lifecycle.json') for name in expected_status}
  if not all(v.get('group_joined') is True and v.get('forced_cleanup') is False and v.get('direct_status')==0 for v in lifecycle.values()):raise ValueError('command lifecycle')
  write_json(records/'command-results.json',{'schema_version':1,'accepted':True,'statuses':statuses,'all_groups_joined_without_force':True})
  accepted=True
 except BaseException as e:issue=f'{type(e).__name__}: {e}'
 finally:
  checks={}
  def chk(n,f):
   try:checks[n]=bool(f())
   except BaseException:checks[n]=False
  chk('checkpoint_unchanged',lambda:verify_component(checkpoint,approved['build_checkpoint_manifest_sha256']) is not None)
  chk('static_inputs_unchanged',lambda:static_pre is not None and all(sha(p)==d for p,d in static_pre.items()) and (check_static_inputs() is None))
  chk('go_unchanged',lambda:sha(GO)==GO_SHA)
  chk('helper_unchanged',lambda:sha(HELPER)==HELPER_SHA)
  chk('base_source_unchanged',lambda:sha(BASE_INVENTORY)==BASE_INVENTORY_SHA and inventory(BASE_SOURCE)==load_json(BASE_INVENTORY).get('files'))
  chk('materialized_source_unchanged',lambda:source_pre is not None and inventory(source)==source_pre)
  chk('module_unchanged',lambda:source_pre is not None and sha(source/'go.mod')==GO_MOD_SHA and sha(source/'go.sum')==GO_SUM_SHA)
  chk('all_groups_joined_without_force',lambda:helper is not None and all(load_json(p).get('group_joined') is True and load_json(p).get('forced_cleanup') is False for p in records.glob('*.lifecycle.json')))
  accepted=accepted and all(checks.values())
  write_json(records/'FINAL.json',{'schema_version':1,'accepted':accepted,'issue':issue,'post_checks':checks,'endpoint_execution':False,'wan_traffic':False,'test_rerun':False})
  write_text(records/'FINAL.status','0\n' if accepted else '1\n');write_text(records/'end-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
  lines=[]
  for p in sorted(records.rglob('*')):
   if p.is_file() and p.name!='SHA256SUMS.txt':lines.append(f'{sha(p)}  {p.relative_to(records).as_posix()}\n')
  write_text(records/'SHA256SUMS.txt',''.join(lines))
  if accepted:
   source_post_sha=sha(records/'source-post.json');combined_ref=f'{SOURCE_REF}+corpus-{source_post_sha}'
   receipt={'schema_version':1,'diagnostic':'wan-below-tls-server-growth','accepted':True,'diagnostic_only':True,'endpoint_execution':False,'wan_traffic':False,'traffic_run':False,'server_binary_sha256':outputs['server']['sha256'],'agent_binary_sha256':outputs['agent']['sha256'],'server_source_ref':combined_ref,'agent_source_ref':combined_ref,'raw_ordinary_proof_receipt_sha256':PROOF_RECEIPT_SHA,'raw_runtime_checkpoint_sha256':RAW_RUNTIME_SHA,'raw_isolation_checkpoint_sha256':RAW_ISOLATION_SHA,'server_growth_checkpoint_sha256':SERVER_SHA,'integration_checkpoint_sha256':INTEGRATION_SHA,'base_source_ref':SOURCE_REF,'base_source_inventory_sha256':BASE_INVENTORY_SHA,'final_source_inventory_sha256':source_post_sha,'raw_focused_evidence_ledger_sha256':RAW_FOCUSED_SHA,'server_focused_evidence_ledger_sha256':SERVER_FOCUSED_SHA,'combined_contract_evidence_ledger_sha256':COMBINED_SHA,'test_rerun':False,'build_tags':['p2pstream_qualification'],'toolchain_sha256':GO_SHA,'toolchain_version':GO_VERSION,'build_checkpoint_manifest_sha256':approved['build_checkpoint_manifest_sha256'],'build_driver_sha256':approved['build_driver_sha256'],'approved_inputs_sha256':sha(records/'approved-inputs.json'),'server_binary':outputs['server'],'agent_binary':outputs['agent'],'final_sha256':sha(records/'FINAL.json'),'records_ledger_sha256':sha(records/'SHA256SUMS.txt')}
   publish_last(out/'audited-combined-build-receipt.json',receipt)
 return 0 if accepted else 1
if __name__=='__main__':raise SystemExit(main())
