#!/usr/bin/env python3
"""Owned offline driver over immutable focused-proof attempt 2 artifacts."""
from __future__ import annotations
import hashlib,importlib.util,json,os,re,sys,time
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
REPO=Path('/home/user/.codex/worktrees/astra-proxy-performance/p2pstream')
COMP=REPO/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy-equivalence'
INPUT=REPO/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy-connect-isolation/runs/focused-proof-attempt-2/records';INPUT_SHA='0eec1a471f80e8d8cc4873ebf786e2005bb17df88e9430378e6848025609e770'
CP5=REPO/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy-connect-isolation/review/source-checkpoint-5';CP5_SHA='85afe09e358fd3b9f9277ec6bc8de42ea4fae59a646f5810b0d5dfa3d3cc6d6c'
HELPER=REPO/'tmp/continuation-20261016/wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py';HELPER_SHA='8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440'
PYTHON=Path('/usr/bin/python3.14');PYTHON_SHA='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'
def sha(path):
 path=Path(path);st=path.lstat()
 if path.is_symlink() or not path.is_file() or st.st_size>128<<20:raise ValueError(f'unsafe input {path}')
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def write_json(path,value):
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
def write_text(path,value):
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:f.write(value)
def publish_json_last(path,value):
 data=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
 temporary=path.with_name('.'+path.name+'.tmp')
 fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:
  f.write(data);f.flush();os.fsync(f.fileno())
 os.rename(temporary,path)
def inventory(root):
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink():raise ValueError(f'symlink {p}')
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def verify_component(root,digest):
 if sha(root/'SHA256SUMS.txt')!=digest:raise ValueError('component manifest')
 expected={}
 for line in (root/'SHA256SUMS.txt').read_text().splitlines():
  d,n=line.split('  ',1);pure=PurePosixPath(n)
  if n!=pure.as_posix() or pure.is_absolute() or '..' in pure.parts or n in expected:raise ValueError('component path')
  expected[n]=d
 actual={k:v for k,v in inventory(root).items() if k!='SHA256SUMS.txt'}
 if actual!=expected:raise ValueError('component coverage')
 return actual
def verify_input():
 if sha(INPUT/'SHA256SUMS.txt')!=INPUT_SHA:raise ValueError('input ledger')
 for line in (INPUT/'SHA256SUMS.txt').read_text().splitlines():
  d,n=line.split('  ',1);p=PurePosixPath(n)
  if n!=p.as_posix() or p.is_absolute() or '..' in p.parts or sha(INPUT.joinpath(*p.parts))!=d:raise ValueError('input evidence')
def load(path,digest):
 if sha(path)!=digest:raise ValueError('helper hash')
 spec=importlib.util.spec_from_file_location('owned',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def main():
 if len(sys.argv)!=3:raise ValueError('usage: run-equivalence.py FRESH_OUTPUT EXPECTED_CHECKPOINT_SHA256')
 out=Path(sys.argv[1]).resolve();expected=sys.argv[2];checkpoint=Path(__file__).resolve().parent;runs=(COMP/'runs').resolve()
 if out.exists() or out.parent!=runs or not runs.is_dir():raise ValueError('fresh direct output')
 out.mkdir(mode=0o700);records=out/'records';records.mkdir(mode=0o700);write_text(records/'start-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
 accepted=False;issue=None;pre=cp5pre=None;owned=None;receipt=None
 try:
  pre=verify_component(checkpoint,expected);cp5pre=verify_component(CP5,CP5_SHA);verify_input();owned=load(HELPER,HELPER_SHA)
  if sha(PYTHON)!=PYTHON_SHA:raise ValueError('Python hash')
  strict=json.loads((INPUT/'proof/report.json').read_text());final=json.loads((INPUT/'FINAL.json').read_text())
  if strict.get('accepted') is not False or final.get('accepted') is not False or not all(final.get('post_checks',{}).values()):raise ValueError('saved disposition')
  env={'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'Europe/Zurich'}
  status=owned.run(records,'contracts',[str(PYTHON),'-I','-B',str(checkpoint/'test_equivalence.py'),'--analyzer',str(checkpoint/'prove_equivalence.py'),'--input-root',str(INPUT),'--output',str(records/'contracts')],REPO,env,60)
  if status!=0 or json.loads((records/'contracts/result.json').read_text()).get('accepted') is not True:raise ValueError('contracts')
  status=owned.run(records,'equivalence',[str(PYTHON),'-I','-B',str(checkpoint/'prove_equivalence.py'),'--baseline-asm',str(INPUT/'baseline-asm.stderr.log'),'--candidate-asm',str(INPUT/'candidate-asm.stderr.log'),'--baseline-canonical',str(INPUT/'proof/baseline-canonical.json'),'--candidate-canonical',str(INPUT/'proof/candidate-canonical.json'),'--strict-report',str(INPUT/'proof/report.json'),'--output',str(records/'equivalence')],REPO,env,60)
  result=json.loads((records/'equivalence/result.json').read_text())
  if status!=0 or result.get('accepted') is not True or result.get('ordinary_untagged_code_and_referents_equivalent') is not True or result.get('strict_generated_symbol_names_equal') is not False:raise ValueError('equivalence')
  receipt={'schema_version':1,'diagnostic':'wan-below-tls-raw-write','accepted':True,'ordinary_untagged_code_and_referents_equivalent':True,'strict_generated_symbol_names_equal':False,'strict_proof_accepted':False,'supplemental_reference_equivalence_accepted':True,'endpoint_execution':False,'endpoint_or_traffic':False,'wan_traffic':False,'focused_proof_attempt_2_ledger_sha256':INPUT_SHA,'isolation_checkpoint_sha256':CP5_SHA,'equivalence_checkpoint_sha256':expected,'strict_report_sha256':sha(INPUT/'proof/report.json'),'equivalence_result_sha256':sha(records/'equivalence/result.json'),'contract_result_sha256':sha(records/'contracts/result.json')}
  accepted=True
 except BaseException as e:issue=f'{type(e).__name__}: {e}'
 finally:
  checks={}
  def chk(name,fn):
   try:checks[name]=bool(fn())
   except BaseException:checks[name]=False
  chk('checkpoint_unchanged',lambda:pre is not None and verify_component(checkpoint,expected)==pre);chk('isolation_checkpoint_unchanged',lambda:cp5pre is not None and verify_component(CP5,CP5_SHA)==cp5pre);chk('input_unchanged',lambda:(verify_input() is None));chk('python_unchanged',lambda:sha(PYTHON)==PYTHON_SHA);chk('helper_unchanged',lambda:sha(HELPER)==HELPER_SHA)
  chk('groups_joined_without_force',lambda:{p.name for p in records.glob('*.lifecycle.json')}=={'contracts.lifecycle.json','equivalence.lifecycle.json'} and all(json.loads(p.read_text()).get('group_joined') is True and not json.loads(p.read_text()).get('forced_cleanup') and json.loads(p.read_text()).get('direct_status')==0 for p in records.glob('*.lifecycle.json')))
  accepted=accepted and all(checks.values());write_json(records/'FINAL.json',{'schema_version':1,'accepted':accepted,'issue':issue,'post_checks':checks,'endpoint_or_traffic':False});write_text(records/'FINAL.status','0\n' if accepted else '1\n');write_text(records/'end-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
  lines=[]
  for p in sorted(records.rglob('*')):
   if p.is_file() and p.name!='SHA256SUMS.txt':lines.append(f'{sha(p)}  {p.relative_to(records).as_posix()}\n')
  write_text(records/'SHA256SUMS.txt',''.join(lines))
  if accepted:
   receipt['final_sha256']=sha(records/'FINAL.json');receipt['records_ledger_sha256']=sha(records/'SHA256SUMS.txt')
   # This atomic rename is deliberately the final fallible operation. A failed
   # attempt therefore cannot leave an accepted authoritative receipt behind.
   publish_json_last(records/'raw-ordinary-proof-receipt.json',receipt)
 return 0 if accepted else 1
if __name__=='__main__':raise SystemExit(main())
