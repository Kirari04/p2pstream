# Proposed focused validation (not executed)

Pinned toolchain: `/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go` (Go 1.26.6). Materialization must use a fresh owned ext4 source/cache root, `GOPROXY=off`, the existing pinned module cache, and exact source pre/post manifests. Main should launch the reviewed driver and capture native outer status.

Ready focused tests in the overlay:

1. `TestQualificationRawWriteActualWrapperBlockedErrorAndShort`
2. `TestQualificationRawWriteBindingRejectsMissingDuplicateAndCustomTLSDialer`
3. `TestQualificationRawWriteTLS101PathSharesPhysicalInterval`
4. `TestQualificationRawWriteOutcomeDurationsConserveSuccessErrorShort`
5. `TestQualificationRawWriteEnvelopeRejectsBoundaryActiveAndStraddling`
6. `TestQualificationRawWriteDrainRetainsLiveOwnershipAndPublishesJoin`
7. `TestQualificationRawWriteStartTimestampMustBeInsideEnvelope`
8. `TestQualificationRawWriteInvalidBoundariesOverflowGenerationAndZeroRaw`
9. `TestQualificationRawWriteConcurrentProtocolWriteUsesTemporalClassification`

Proposed exact focused pattern:

```text
^TestQualificationRawWrite(ActualWrapperBlockedErrorAndShort|BindingRejectsMissingDuplicateAndCustomTLSDialer|TLS101PathSharesPhysicalInterval|OutcomeDurationsConserveSuccessErrorShort|EnvelopeRejectsBoundaryActiveAndStraddling|DrainRetainsLiveOwnershipAndPublishesJoin|StartTimestampMustBeInsideEnvelope|InvalidBoundariesOverflowGenerationAndZeroRaw|ConcurrentProtocolWriteUsesTemporalClassification)$
```

Run the exact pattern once normally and once with `-race`, retaining `go test -json` and requiring one ordered `[run, pass]` pair for each of the exact nine roots and eleven declared subtests, exactly one package pass, no skip/fail/unexpected name, direct status 0, natural process-group join, and unchanged source hashes. The TLS 101 control uses an in-process TLS HTTP/1.1 upgrade and real Yamux client/server DATA path; it does not start a product endpoint or WAN workload.

Before any diagnostic binary is accepted, also run the exact nineteen existing aggregate-sender roots and six declared subtests in normal/race modes under the same event and lifecycle gates. The reviewed driver imports the already audited owned-process helper by exact hash, applies `taskset 0-15`, sets Go's test timeout to 300 seconds inside a 360-second owned-group bound, and checks both root and nested Yamux module identities. Then compare ordinary baseline/candidate builds with identical settings: exact relevant symbol cardinality, code bytes with only addresses/relocations normalized, stack metadata and referenced compiler-data bytes, full per-function escape diagnostics/costs, and relevant type layouts/offsets. The prior sender proof may be reused only for bytes and records whose inputs remain identical; `Session.sendLoop`, `connectAndServe`, and the new ordinary hooks require new bound evidence. No full ordinary proof should run before architecture review of this checkpoint.
