#!/usr/bin/env python3
"""Run the two frozen raw-validator contracts once in an owned process group."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import traceback


REPO = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
COMPONENT = REPO / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-validator/review/source-checkpoint-5"
COMPONENT_MANIFEST_SHA = "81a1ce231ba5ffeb8a3aed891c0ad7ee43f0f20b7aecba886f299171aeeaa6d7"
OWNED_HELPER = REPO / "tmp/continuation-20261016/wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
OWNED_HELPER_SHA = "8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
PYTHON = Path("/usr/bin/python3")
PYTHON_SHA = "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
RAW_CASES = {
    "malformed-live-none": False,
    "malformed-live-list": False,
    "malformed-live-integer": False,
    "selected-valid": True,
    "selected-multiple-contained-writes": True,
    "conditioning-multiple-streams-retained": True,
    "conditioning-straddling-rejected": False,
    "control-outside-write-retained": True,
    "control-straddling-rejected": False,
    "unknown-field": False,
    "bool-as-int": False,
    "active-complete": False,
    "joined-without-close": False,
    "stream-without-envelope": False,
    "wire-below-payload": False,
    "yamux-placeholder-tuple": False,
    "wrapped-yamux-placeholder-tuple": False,
    "maximum-mismatch": False,
    "residual-mismatch": False,
    "selected-stream-mismatch": False,
    "selected-multiple-streams": False,
    "selected-zero-contained": False,
    "selected-zero-contained-bytes": False,
    "selected-physical-duration-count-mismatch": False,
    "selected-physical-duration-total-mismatch": False,
    "selected-physical-duration-maximum-mismatch": False,
    "positive-envelope-zero-bytes": False,
    "per-outcome-overwrite-hidden-by-short-deficit": False,
    "raw-error": False,
    "raw-short": False,
    "final-closure-valid": True,
    "final-closure-missing-lane": False,
    "final-closure-reconnect": False,
    "final-closure-history-straddling": False,
    "final-closure-history-zero-generation": False,
    "final-closure-history-empty-session": False,
    "final-closure-history-raw-lane-mismatch": False,
    "final-closure-control-not-aggregate": False,
    "final-closure-active": False,
    "final-closure-straddling": False,
    "final-closure-zero-generation": False,
    "final-closure-data": False,
}
SENDER_CASES = {
    "valid-pre": True,
    "valid-pair": True,
    "missing-raw-field": False,
    "placeholder-tuple": False,
    "raw-stream-mismatch": False,
    "raw-wire-mismatch": False,
    "raw-physical-duration-count-mismatch": False,
    "raw-physical-duration-total-mismatch": False,
    "raw-physical-duration-maximum-mismatch": False,
    "nonselected-data": False,
    "valid-terminal": True,
    "valid-final-closure": True,
    "final-closure-straddling": False,
}
SENDER_INPUTS = {
    *(f"sequence-{sequence}-{action}-sender.json"
      for sequence in (9, 11, 14, 15) for action in ("pre", "post")),
    "terminal-sender.json",
    "final-raw-write-terminal.json",
}


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def write_text(path: Path, value: str) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        stream.write(value)


def inventory(root: Path) -> dict[str, str]:
    if not root.is_dir() or root.is_symlink():
        raise ValueError(f"unsafe inventory root: {root}")
    result = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"symlink in immutable input: {path}")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha(path)
    return result


def load_owned_helper():
    if sha(OWNED_HELPER) != OWNED_HELPER_SHA:
        raise ValueError("owned-process helper changed")
    spec = importlib.util.spec_from_file_location("reviewed_owned_process", OWNED_HELPER)
    if spec is None or spec.loader is None:
        raise ValueError("owned-process helper import failed")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_component() -> dict[str, str]:
    manifest = COMPONENT / "SHA256SUMS.txt"
    if sha(manifest) != COMPONENT_MANIFEST_SHA:
        raise ValueError("raw-validator checkpoint manifest changed")
    expected = {}
    for line in manifest.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        if len(digest) != 64 or not relative or relative.startswith("/") or ".." in Path(relative).parts:
            raise ValueError("malformed raw-validator checkpoint manifest")
        if relative in expected:
            raise ValueError("duplicate raw-validator checkpoint path")
        expected[relative] = digest
    actual = inventory(COMPONENT)
    manifest_digest = actual.pop("SHA256SUMS.txt", None)
    if manifest_digest != COMPONENT_MANIFEST_SHA or actual != expected:
        raise ValueError("raw-validator checkpoint inventory changed")
    return {"SHA256SUMS.txt": manifest_digest, **actual}


def fixed_inputs() -> dict[str, str]:
    return {
        "raw_validator_checkpoint_manifest": sha(COMPONENT / "SHA256SUMS.txt"),
        "owned_process_helper": sha(OWNED_HELPER),
        "python_interpreter": sha(PYTHON),
    }


def verify_lifecycle(records: Path, name: str) -> None:
    value = json.loads((records / f"{name}.lifecycle.json").read_text(encoding="utf-8"))
    expected = {
        "owned_group_identity_valid": True,
        "direct_child_joined": True,
        "timed_out": False,
        "term_attempted": False,
        "kill_attempted": False,
        "forced_cleanup": False,
        "group_joined": True,
        "direct_status": 0,
        "wait_returncode": 0,
    }
    for key, wanted in expected.items():
        if value.get(key) != wanted:
            raise ValueError(f"{name} lifecycle {key} differs: {value.get(key)!r}")
    if (records / f"{name}.direct.status").read_text(encoding="utf-8") != "0\n":
        raise ValueError(f"{name} direct status changed")


def audit_cases(path: Path, expected: dict[str, bool], label: str) -> None:
    value = json.loads(path.read_text(encoding="utf-8"))
    cases = value.get("cases")
    if value.get("schema_version") != 1 or value.get("accepted") is not True:
        raise ValueError(f"{label} result is not accepted schema 1")
    if type(cases) is not list or value.get("case_count") != len(expected) or len(cases) != len(expected):
        raise ValueError(f"{label} case cardinality changed")
    got = {}
    for case in cases:
        if type(case) is not dict or type(case.get("name")) is not str or case["name"] in got:
            raise ValueError(f"{label} case shape or uniqueness changed")
        got[case["name"]] = case
    if set(got) != set(expected):
        raise ValueError(f"{label} case names changed")
    for name, expected_acceptance in expected.items():
        case = got[name]
        if (case.get("expected_accepted", case.get("expected")) is not expected_acceptance
                or case.get("actual_accepted", case.get("actual")) is not expected_acceptance
                or case.get("passed") is not True
                or type(case.get("issues")) is not list):
            raise ValueError(f"{label} case outcome changed: {name}")


def main() -> int:
    if len(sys.argv) != 2:
        raise ValueError("usage: run-focused-contracts.py FRESH_OUTPUT")
    output = Path(sys.argv[1]).resolve()
    if output.exists() or not output.parent.is_dir():
        raise ValueError("output must be fresh below an existing parent")
    output.mkdir(mode=0o700)
    stat = output.stat()
    if stat.st_uid != os.geteuid() or stat.st_mode & 0o022:
        raise ValueError("output must be euid-owned and not group/world writable")
    records = output / "records"
    records.mkdir(mode=0o700)
    accepted = False
    issue = None
    component_pre = None
    try:
        if sys.flags.isolated != 1 or not sys.dont_write_bytecode:
            raise ValueError("driver requires Python -I -B")
        if sha(PYTHON) != PYTHON_SHA:
            raise ValueError("reviewed Python interpreter changed")
        component_pre = verify_component()
        write_json(records / "component-source-pre.json", component_pre)
        inputs_pre = fixed_inputs()
        write_json(records / "fixed-inputs-pre.json", inputs_pre)
        owned = load_owned_helper()
        environment = {
            "HOME": "/home/user", "PATH": "/usr/bin:/bin", "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONHASHSEED": "0", "LC_ALL": "C", "TZ": "Europe/Zurich",
        }
        write_json(records / "environment.json", environment)
        commands = (
            ("raw-validator-contract", [str(PYTHON), "-I", "-B",
             str(COMPONENT / "contracts/run-raw-write-validator-contracts.py")]),
            ("sender-composition-contract", [str(PYTHON), "-I", "-B",
             str(COMPONENT / "contracts/test-sender-raw-integration.py"),
             str(COMPONENT / "integration/validate-sender-wait-snapshot.py"),
             str(records / "sender-composition.json")]),
        )
        for name, command in commands:
            status = owned.run(records, name, command, REPO, environment, 30)
            if status != 0:
                raise ValueError(f"focused contract failed: {name}")
            verify_lifecycle(records, name)
        audit_cases(records / "raw-validator-contract.stdout.log", RAW_CASES, "raw validator")
        audit_cases(records / "sender-composition.json", SENDER_CASES, "sender composition")
        sender_result = json.loads((records / "sender-composition.json").read_text(encoding="utf-8"))
        if set(sender_result.get("preserved_inputs", [])) != SENDER_INPUTS:
            raise ValueError("sender composition preserved-input names changed")
        sender_inputs = records / "sender-composition.inputs"
        if set(inventory(sender_inputs)) != SENDER_INPUTS:
            raise ValueError("sender composition input inventory changed")
        write_json(records / "sender-composition-inputs.json", inventory(sender_inputs))
        accepted = True
    except BaseException as error:
        issue = f"{type(error).__name__}: {error}"
        traceback.print_exc()
    finally:
        checks = {}
        try:
            component_post = verify_component()
            write_json(records / "component-source-post.json", component_post)
            inputs_post = fixed_inputs()
            write_json(records / "fixed-inputs-post.json", inputs_post)
            checks["component_source_unchanged"] = component_pre is not None and component_post == component_pre
            checks["fixed_inputs_unchanged"] = "inputs_pre" in locals() and inputs_post == inputs_pre
            checks["owned_process_helper_unchanged"] = inputs_post["owned_process_helper"] == OWNED_HELPER_SHA
            checks["python_interpreter_unchanged"] = inputs_post["python_interpreter"] == PYTHON_SHA
            accepted = accepted and all(value is True for value in checks.values())
        except BaseException as final_error:
            accepted = False
            checks["finalization_error"] = f"{type(final_error).__name__}: {final_error}"
        write_json(records / "RESULT.json", {
            "schema_version": 1,
            "accepted": accepted,
            "issue": issue,
            "expected_case_counts": {"raw_validator": len(RAW_CASES), "sender_composition": len(SENDER_CASES)},
            "post_checks": checks,
        })
        write_text(records / "final.status", "0\n" if accepted else "1\n")
        with (records / "SHA256SUMS.txt").open("x", encoding="utf-8") as stream:
            for path in sorted(records.rglob("*")):
                if path.is_file() and path.name != "SHA256SUMS.txt":
                    stream.write(f"{sha(path)}  ./{path.relative_to(records).as_posix()}\n")
        write_text(output / "FINAL", "complete\n")
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
