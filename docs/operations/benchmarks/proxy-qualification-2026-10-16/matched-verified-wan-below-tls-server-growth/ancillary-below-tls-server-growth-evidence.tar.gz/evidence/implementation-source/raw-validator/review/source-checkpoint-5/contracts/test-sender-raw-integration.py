#!/usr/bin/env python3
"""Behavioral source contract for the sender/raw validator composition.

The source checkpoint does not execute this file. A reviewed contract run must
pass the frozen sender derivative path and preserve the exact output/status.
"""

import copy
import importlib.util
import json
from pathlib import Path
import sys


if len(sys.argv) != 3:
    raise SystemExit("usage: test-sender-raw-integration.py VALIDATOR OUTPUT")
validator_path, output_path = map(Path, sys.argv[1:])
spec = importlib.util.spec_from_file_location("sender_raw_validator", validator_path.resolve())
assert spec is not None and spec.loader is not None
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)


def bucket(count=0, total=0, maximum=0):
    return {"count": count, "total_nanoseconds": total, "max_nanoseconds": maximum}


def raw_class(calls=0, attempted=0, written=0, total=0, maximum=0):
    return {
        "calls": calls, "attempt_bytes": attempted, "written_bytes": written,
        "duration": bucket(calls, total, maximum),
        "success_duration": bucket(calls, total, maximum),
        "error_duration": bucket(), "short_duration": bucket(),
        "success_calls": calls, "error_calls": 0, "short_calls": 0,
        "success_attempt_bytes": attempted, "success_written_bytes": written,
        "error_attempt_bytes": 0, "error_written_bytes": 0,
        "short_attempt_bytes": 0, "short_written_bytes": 0,
    }


def raw_activity(lane, *, stream=0, frames=0, payload=0, wire=0, selected=False,
                 close=False, joined=False):
    contained_calls = 2 if selected else 0
    contained_total = 5 if selected else 0
    return {
        "schema_version": 1, "enabled": True, "complete": True, "reset_performed": True,
        "bound": True, "close_observed": close, "session_joined": joined,
        "ambiguous": False, "overflow": False, "lane": lane, "generation": lane + 1,
        "local_address": f"127.0.0.1:{10000 + lane}",
        "remote_address": f"127.0.0.1:{20000 + lane}",
        "stream_observed": selected, "observed_stream_id": stream if selected else 0,
        "multiple_streams": False, "active_envelopes": 0, "active_raw_writes": 0,
        "maximum_active_raw_writes": 1 if selected else 0,
        "envelope_count": frames, "envelope_payload_bytes": payload,
        "envelope_wire_bytes": wire, "envelope_zero_raw_calls": 0,
        "envelope_duration": bucket(frames, 10 if selected else 0, 10 if selected else 0),
        "contained_raw_duration": bucket(frames, contained_total, contained_total),
        "residual_duration": bucket(frames, 5 if selected else 0, 5 if selected else 0),
        "boundary_active_raw_writes": 0, "boundary_outside_completions": 0,
        "envelope_overlaps": 0, "owner_generation_changes": 0,
        "contained": raw_class(contained_calls, 128 if selected else 0,
                               128 if selected else 0, contained_total, 3 if selected else 0),
        "outside": raw_class(), "straddling": raw_class(),
    }


def timing(enabled):
    value = {key: False for key in validator.TIMING_BOOLS}
    value.update({key: 0 for key in validator.TIMING_INTS})
    value.update({key: bucket() for key in validator.DURATION_TOTALS})
    value.update({group: {member: bucket() for member in members}
                  for group, members in validator.OUTCOME_GROUPS.items()})
    value["complete"] = enabled
    value["reset_performed"] = enabled
    return value


def row(lane):
    enabled = lane != 0
    raw = raw_activity(lane)
    value = {
        "lane": lane, "session_identity": f"session-{lane}",
        "local_address": raw["local_address"], "remote_address": raw["remote_address"],
        "enabled": enabled, "timing": timing(enabled), "raw_write_activity": raw,
    }
    value.update({key: 0 for key in validator.COUNTER_SCALARS})
    return value


def envelope(action, sequence=9, started=1):
    return {
        "schema_version": 1, "role": "agent-drain", "action": action, "sequence": sequence,
        "request_started_unix_ns": started, "request_finished_unix_ns": started + 1,
        "request_elapsed_ns": 1, "http_status": 200, "response_bytes": 1,
        "error": "", "authorization": "bearer-present",
        "response": {"schema_version": 2, "captured_unix_nano": started,
                     "capacity": 4096, "dropped_events": 0, "events": [],
                     "send_counters": [row(lane) for lane in validator.ALL_LANES]},
    }


pre = envelope("pre")
post = envelope("post", started=2)
selected = post["response"]["send_counters"][1]
selected.update({"reserved_data_frames": 1, "reserved_payload_bytes": 100,
                 "reserved_allocation_charged_bytes": 4096})
selected["raw_write_activity"] = raw_activity(1, stream=7, frames=1,
                                                payload=100, wire=112, selected=True)
current = selected["timing"]
current.update({
    "stream_observed": True, "observed_stream_id": 7,
    "data_enqueued_frames": 1, "data_enqueued_payload_bytes": 100,
    "data_completed_frames": 1, "data_completed_payload_bytes": 100,
    "physical_attempt_frames": 1, "physical_attempt_payload_bytes": 100,
    "physical_attempt_wire_bytes": 112, "physical_written_wire_bytes": 112,
    "physical_success_frames": 1, "physical_success_payload_bytes": 100,
    "physical_success_wire_bytes": 112,
    "data_enqueue_select_total": bucket(1, 4, 4),
    "data_completion_select_total": bucket(1, 6, 6),
    "data_call_total": bucket(1, 10, 10),
    "physical_write_total": bucket(1, 10, 10),
})
current["data_enqueue_select_by_outcome"]["accepted"] = copy.deepcopy(current["data_enqueue_select_total"])
current["data_completion_select_by_outcome"]["success"] = copy.deepcopy(current["data_completion_select_total"])
current["data_call_by_outcome"]["success"] = copy.deepcopy(current["data_call_total"])
current["physical_write_by_outcome"]["success"] = copy.deepcopy(current["physical_write_total"])

cases = []


def check(name, mutate, expected):
    before, after = copy.deepcopy(pre), copy.deepcopy(post)
    mutate(before, after)
    result = validator.validate_pair(before, after, 9)
    cases.append({"name": name, "expected": expected, "actual": result["accepted"],
                  "passed": result["accepted"] is expected, "issues": result["issues"]})


def record(name, expected, result):
    cases.append({"name": name, "expected": expected, "actual": result["accepted"],
                  "passed": result["accepted"] is expected, "issues": result["issues"]})


record("valid-pre", True, validator.validate_pre(copy.deepcopy(pre), 9))
check("valid-pair", lambda before, after: None, True)
check("missing-raw-field", lambda before, after: after["response"]["send_counters"][1].pop("raw_write_activity"), False)
check("placeholder-tuple", lambda before, after: after["response"]["send_counters"][1]["raw_write_activity"].__setitem__("local_address", "yamux:local"), False)
check("raw-stream-mismatch", lambda before, after: after["response"]["send_counters"][1]["raw_write_activity"].__setitem__("observed_stream_id", 9), False)
check("raw-wire-mismatch", lambda before, after: after["response"]["send_counters"][1]["raw_write_activity"].__setitem__("envelope_wire_bytes", 113), False)


def change_physical_duration(before, after, *, count=1, total=10, maximum=10):
    timing_value = after["response"]["send_counters"][1]["timing"]
    replacement = bucket(count, total, maximum)
    timing_value["physical_write_total"] = replacement
    timing_value["physical_write_by_outcome"]["success"] = copy.deepcopy(replacement)


check("raw-physical-duration-count-mismatch",
      lambda before, after: change_physical_duration(before, after, count=2), False)
check("raw-physical-duration-total-mismatch",
      lambda before, after: change_physical_duration(before, after, total=9, maximum=9), False)
check("raw-physical-duration-maximum-mismatch",
      lambda before, after: change_physical_duration(before, after, count=2, maximum=6), False)
check("nonselected-data", lambda before, after: after["response"]["send_counters"][2].__setitem__(
    "raw_write_activity", raw_activity(2, stream=9, frames=1, payload=20, wire=32, selected=True)), False)

terminal = envelope("terminal", started=3)
record("valid-terminal", True, validator.validate_terminal(copy.deepcopy(terminal), 9))

input_directory = output_path.with_suffix(".inputs")
input_directory.mkdir(mode=0o700, parents=False, exist_ok=False)
history = []
for sequence_index, sequence in enumerate(validator.FIXED_SEQUENCES):
    for action_index, action in enumerate(("pre", "post")):
        if sequence == 9 and action == "pre":
            value = copy.deepcopy(pre)
        elif sequence == 9 and action == "post":
            value = copy.deepcopy(post)
        else:
            value = envelope(action, sequence=sequence,
                             started=10 + sequence_index * 4 + action_index * 2)
        name = f"sequence-{sequence}-{action}-sender.json"
        path = input_directory / name
        with path.open("x", encoding="utf-8") as stream:
            json.dump(value, stream, indent=2, sort_keys=True)
            stream.write("\n")
        history.append(name)
terminal_15 = envelope("terminal", sequence=15, started=30)
with (input_directory / "terminal-sender.json").open("x", encoding="utf-8") as stream:
    json.dump(terminal_15, stream, indent=2, sort_keys=True)
    stream.write("\n")
history.append("terminal-sender.json")

final_sidecar = {
    "schema_version": 1, "expected_sessions": 5, "complete": True, "invalid": False,
    "records": [
        {
            "lane": lane, "aggregate": True, "session_identity": f"session-{lane}",
            "raw_write_activity": raw_activity(lane, close=True, joined=True),
        }
        for lane in validator.ALL_LANES
    ],
}
with (input_directory / "final-raw-write-terminal.json").open("x", encoding="utf-8") as stream:
    json.dump(final_sidecar, stream, indent=2, sort_keys=True)
    stream.write("\n")
history.append("final-raw-write-terminal.json")
record("valid-final-closure", True,
       validator.validate_final_closure(copy.deepcopy(final_sidecar), input_directory))
invalid_final = copy.deepcopy(final_sidecar)
invalid_final["records"][1]["raw_write_activity"]["straddling"] = raw_class(1, 8, 8, 2, 2)
invalid_final["records"][1]["raw_write_activity"]["maximum_active_raw_writes"] = 1
record("final-closure-straddling", False,
       validator.validate_final_closure(invalid_final, input_directory))

result = {"schema_version": 1, "case_count": len(cases),
          "accepted": all(case["passed"] for case in cases),
          "preserved_inputs": history, "cases": cases}
with output_path.open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
raise SystemExit(0 if result["accepted"] else 1)
