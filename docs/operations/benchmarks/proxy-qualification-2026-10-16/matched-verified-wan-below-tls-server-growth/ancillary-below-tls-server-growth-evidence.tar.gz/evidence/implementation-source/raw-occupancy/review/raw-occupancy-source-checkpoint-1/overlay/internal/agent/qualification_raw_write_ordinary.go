//go:build !p2pstream_qualification

package agent

import (
	"io"
	"net/http"

	"github.com/hashicorp/yamux"
)

func qualificationBindRawWriteRequest(req *http.Request, _ tunnelLaneRegistration) (*http.Request, error) {
	return req, nil
}

func qualificationBindRawWriteBody(_ *http.Request, body io.ReadWriteCloser) (io.ReadWriteCloser, error) {
	return body, nil
}

func qualificationRetireRawWriteSession(_ *yamux.Session) {}
