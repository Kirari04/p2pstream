#!/usr/bin/env python3
"""Read-only preflight for the immutable build driver's external evidence."""
from __future__ import annotations
import importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
driver=Path(__file__).resolve().with_name('run-audited-combined-build.py')
spec=importlib.util.spec_from_file_location('combined_build_source_preflight',driver)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.check_static_inputs()
print(json.dumps({'schema_version':1,'accepted':True,'build_or_test_run':False,'endpoint_or_traffic':False},sort_keys=True))
