#!/usr/bin/env python3
"""Run the reviewed file-backed capacity serialization contract once."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys


REPO = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
BASE = REPO / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source"
CP8 = BASE / "server-growth/review/final-integration-source-checkpoint-8"
CP10 = BASE / "server-growth/review/final-integration-source-checkpoint-10"
CP10_SHA = "1961587927cf5816347bcc4930412e69668c3c5084c28b3264a4856f86da37d4"
CONTRACT = CP10 / "integration/contracts/test-file-backed-capacity-record.py"
CONTRACT_SHA = "e5dbb2b0295d8e9e71d85ef2731ba111709c84df7af4433085ef3c0979631c39"
OLD_RUNNER = CP8 / "integration/generated/qualify-proxy-agent-growth-wan-below-tls.sh"
OLD_RUNNER_SHA = "3e7edb7eae8a24f83b02904c3b87cfb7a1b9caaa0f179a4afe0fe1d8f51d6eab"
NEW_RUNNER = CP10 / "integration/generated/qualify-proxy-agent-growth-wan-below-tls.sh"
NEW_RUNNER_SHA = "a672ab078d424a59d795c522a40f96da815b8aaa55af6f21fce4eed07a63b1ad"
FAILED = BASE / "final-integration-source/integration/runs/sustained-below-tls-1"
TINY = BASE / "final-integration-source/integration/runs/tiny-below-tls-smoke-3"
FAILED_FREEZE = BASE / "server-growth/review/sustained-below-tls-1-failure-freeze-1/RUN-SHA256SUMS.txt"
FAILED_FREEZE_SHA = "0d2b8fb2dd27f334f98fd37c98b1887385a6ea6b6ad3af5a2aff04f761e56181"
TINY_LEDGER = BASE / "server-growth/review/sustained-final-integration-launch-source-1/SMOKE3-SHA256SUMS.txt"
TINY_LEDGER_SHA = "6a1b60942762de05593c312672cb0d91b2900a239748d444168c1fbbcb2a4706"
HELPER = REPO / "tmp/continuation-20261016/wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
HELPER_SHA = "8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
PYTHON = Path("/usr/bin/python3.14")
JQ = Path("/usr/bin/jq")
BASH = Path("/usr/bin/bash")
FIXTURES = {
    "failed_pre_capacity": (FAILED / "h1/results.sender-wait-controls/sequence-9-pre-capacity.json", "e193b91c17950d18bfb94c4f059711f2cbcfe7c90d06d6372a072c89c6d40f9d"),
    "failed_post_capacity": (FAILED / "h1/results.sender-wait-controls/sequence-9-post-capacity.json", "445ac938851563a30c4a4a9481cd5c332b8c31dde7ebea00e33ac28de4ed4d6f"),
}


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(path: Path, digest: str, executable: bool = False) -> None:
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or path.is_symlink() or sha(path) != digest:
        raise ValueError(f"input changed: {path}")
    if executable and not os.access(path, os.X_OK):
        raise ValueError(f"input is not executable: {path}")


def verify_manifest() -> None:
    require(CP10 / "SHA256SUMS.txt", CP10_SHA)
    expected: dict[str, str] = {}
    for line in (CP10 / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts or name in expected:
            raise ValueError("unsafe cp10 manifest")
        expected[name] = digest
    actual = {path.relative_to(CP10).as_posix(): sha(path) for path in sorted(CP10.rglob("*"))
              if path.is_file() and path.name != "SHA256SUMS.txt" and not path.is_symlink()}
    if actual != expected:
        raise ValueError("cp10 manifest inventory differs")


def load_helper():
    spec = importlib.util.spec_from_file_location("owned_process", HELPER)
    if spec is None or spec.loader is None:
        raise ValueError("owned helper import failed")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    if len(sys.argv) != 2:
        raise ValueError("usage: run-contract.py FRESH_OUTPUT")
    output = Path(sys.argv[1]).resolve()
    if output.exists() or output.is_symlink() or not output.parent.is_dir():
        raise ValueError("output must be fresh")
    output.mkdir(mode=0o700)
    records = output / "records"
    records.mkdir(mode=0o700)
    verify_manifest()
    require(CONTRACT, CONTRACT_SHA)
    require(OLD_RUNNER, OLD_RUNNER_SHA, True)
    require(NEW_RUNNER, NEW_RUNNER_SHA, True)
    require(FAILED_FREEZE, FAILED_FREEZE_SHA)
    require(TINY_LEDGER, TINY_LEDGER_SHA)
    require(HELPER, HELPER_SHA)
    for path in (PYTHON, JQ, BASH):
        if not path.is_file() or path.is_symlink() or not os.access(path, os.X_OK):
            raise ValueError(f"tool differs: {path}")
    for path, digest in FIXTURES.values():
        require(path, digest)
    pre = {name: sha(path) for name, (path, _) in FIXTURES.items()}
    (records / "inputs-pre.json").write_text(json.dumps(pre, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    helper = load_helper()
    work = records / "contract-work"
    status = helper.run(records, "contract", [str(PYTHON), "-I", "-B", str(CONTRACT),
        str(OLD_RUNNER), str(NEW_RUNNER), str(FAILED), str(TINY), str(JQ), str(BASH),
        str(PYTHON), str(work)], REPO,
        {"HOME": "/home/user", "PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C",
         "TZ": "Europe/Zurich", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0"}, 120)

    verify_manifest()
    for path, digest in FIXTURES.values():
        require(path, digest)
    post = {name: sha(path) for name, (path, _) in FIXTURES.items()}
    (records / "inputs-post.json").write_text(json.dumps(post, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    lifecycle = json.loads((records / "contract.lifecycle.json").read_text(encoding="utf-8"))
    summary = json.loads((work / "SUMMARY.json").read_text(encoding="utf-8")) if (work / "SUMMARY.json").is_file() else {}
    natural = (lifecycle.get("direct_child_joined") is True and lifecycle.get("group_joined") is True
               and lifecycle.get("forced_cleanup") is False and lifecycle.get("timed_out") is False
               and lifecycle.get("wait_returncode") == status)
    accepted = status == 0 and natural and pre == post and summary.get("accepted") is True and summary.get("case_count") == 5
    result = {"schema_version": 1, "accepted": accepted, "direct_status": status,
              "natural_group_join": natural, "source_and_fixture_pre_post_equal": pre == post,
              "summary": summary, "endpoint_execution": False, "wan_traffic": False}
    (records / "RESULT.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (records / "final.status").write_text(f"{0 if accepted else 1}\n", encoding="utf-8")
    with (records / "SHA256SUMS.txt").open("x", encoding="utf-8") as stream:
        for path in sorted(records.rglob("*")):
            if path.is_file() and path.name != "SHA256SUMS.txt":
                stream.write(f"{sha(path)}  ./{path.relative_to(records).as_posix()}\n")
    (output / "FINAL").write_text("complete\n", encoding="utf-8")
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
