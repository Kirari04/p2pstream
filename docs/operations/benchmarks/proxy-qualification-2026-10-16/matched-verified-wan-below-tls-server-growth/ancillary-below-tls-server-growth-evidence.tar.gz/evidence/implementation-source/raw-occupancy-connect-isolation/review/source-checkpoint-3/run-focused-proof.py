#!/usr/bin/env python3
"""Focused tagged validation plus candidate-only ordinary proof for the split observer."""
from __future__ import annotations
import hashlib, importlib.util, json, os, re, shutil, sys, time, traceback
from pathlib import Path, PurePosixPath

sys.dont_write_bytecode=True
REPO=Path('/home/user/.codex/worktrees/astra-proxy-performance/p2pstream')
COMPONENT=REPO/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy-connect-isolation'
BASE=REPO/'tmp/continuation-20261016/wan-sender-wait-build-source/runs/audited-build-attempt-1/source'
RAW_CP5=REPO/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy/review/raw-occupancy-source-checkpoint-5'
RAW_CP5_SHA='997fdd95c02936414608bd8f8ad8ff3de5b0876e315db1cdd3f61f55fc41adcc'
RAW_DRIVER=RAW_CP5/'validation-source/run-focused.py'
RAW_DRIVER_SHA='b68aaec8403fb02dd031df1c73fbe37706b92cd57e6c4bb26a3acc01b7d3745d'
RAW_ATTEMPT=REPO/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy/runs/raw-focused-attempt-1/records'
RAW_ATTEMPT_SHA='26b6e59c6a4911328b1684221ba41779c7f4aa7aafbf516c253628916d70a656'
PROOF_CP7=REPO/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy-ordinary-proof/review/source-checkpoint-7'
PROOF_CP7_SHA='772f4f98ab6eb941b5c7c3ebf70ea8577d78ba49df393a3a00c4cdb545a3be5b'
ATTEMPT1=REPO/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy-ordinary-proof/runs/ordinary-proof-attempt-1/records'
ATTEMPT1_SHA='2f846f646790ed8d8457d4b7f0a88be86e786150d2a33054338aace34ea54bd5'
ATTEMPT2=REPO/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy-ordinary-proof/runs/ordinary-proof-attempt-2/records'
ATTEMPT2_SHA='9df5003a9f64f55d680358741b4041db018b1cd9e5c4490b1de51f9b9748dca3'
OFFLINE=REPO/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy-ordinary-proof/runs/offline-compare-attempt-1/records'
OFFLINE_SHA='fe2789da4204f745e5ac14667bab038975df410c9c0b53f253092914fae5dc05'
HELPER=REPO/'tmp/continuation-20261016/wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py'
HELPER_SHA='8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440'
GO=Path('/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go')
GO_SHA='29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45'
PYTHON=Path('/usr/bin/python3.14'); PYTHON_SHA='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'
TASKSET=Path('/usr/bin/taskset'); TASKSET_SHA='42acb8e233943873f3bf9eeb1e15bd3281498b5603a5b10d0f9bc37067a12d57'
SYMBOL_PATTERN=r'^p2pstream/internal/agent\.connectAndServe($|\.)'
BASELINE_HASHES={'baseline-agent.a':'45be9c6e9ae80725320c8b59c79ebf0def4bd370a718d38a600a3f95fd23525c','baseline-asm.stderr.log':'529c2cb02450864eb6e99791d142493164a5baf589c27e460c502abc007a3a39','baseline-escape.stderr.log':'07adef402fe59bf83cacdad7c2916c7f952a4cdf1b21d27f90b16017348ad484','baseline-layout.json':'5bab4f50ee578edfcaaa9c3a7c2d119d8acddd313ae0d9bbf10291f495dd9343','baseline-nm.stdout.log':'80cfd4e90073984c74c98df7efd68b84fe4b00b36e919bd44f45f6bcc805a146','baseline-objdump.stdout.log':'dce1c69d1f5c5a4c4aed2baa7e40d1a38f4758a0cc4da52a73519bd15d4ccd5a'}

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''): h.update(block)
 return h.hexdigest()
def write_json(path,value):
 path.parent.mkdir(mode=0o700,parents=True,exist_ok=True); fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f: json.dump(value,f,indent=2,sort_keys=True); f.write('\n')
def write_text(path,value):
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:f.write(value)
def exact(path,digest):
 path=Path(path)
 if path.is_symlink() or not path.is_file() or sha(path)!=digest: raise ValueError(f'hash mismatch {path}')
def inventory(root):
 root=Path(root)
 if root.is_symlink() or not root.is_dir(): raise ValueError(f'unsafe root {root}')
 result={}
 for path in sorted(root.rglob('*')):
  if path.is_symlink(): raise ValueError(f'symlink {path}')
  if path.is_file(): result[path.relative_to(root).as_posix()]=sha(path)
 return result
def safe_name(name):
 p=PurePosixPath(name)
 if not name or name!=p.as_posix() or p.is_absolute() or '\\' in name or any(x in ('','.','..') for x in p.parts): raise ValueError(f'unsafe ledger path {name!r}')
 return p.as_posix()
def verify_ledger(root,digest):
 root=Path(root); ledger=root/'SHA256SUMS.txt'; exact(ledger,digest); expected={}
 for line in ledger.read_text().splitlines():
  parts=line.split('  ',1)
  if len(parts)!=2 or re.fullmatch(r'[0-9a-f]{64}',parts[0]) is None: raise ValueError(f'malformed ledger {ledger}')
  name=safe_name(parts[1])
  if name in expected: raise ValueError(f'duplicate ledger path {name}')
  expected[name]=parts[0]
 actual={k:v for k,v in inventory(root).items() if k!='SHA256SUMS.txt'}
 if expected!=actual: raise ValueError(f'ledger coverage {ledger}')
 return actual
def load_module(name,path,digest):
 exact(path,digest); spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None: raise ValueError(f'cannot import {path}')
 module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module
def apply_overlay(source,overlay):
 for rel,digest in inventory(overlay).items():
  src=overlay/rel; dst=source/rel; dst.parent.mkdir(mode=0o755,parents=True,exist_ok=True); shutil.copy2(src,dst)
  if sha(dst)!=digest: raise ValueError(f'overlay copy {rel}')
def apply_test_split(source):
 before=source/'internal/agent/proxy_qualification_wan_sender_wait_test.go'
 helper=PROOF_CP7/'validation-overlay/proxy_qualification_wan_sender_wait_test.go'
 control=PROOF_CP7/'validation-overlay/proxy_qualification_wan_sender_wait_control_qualification_test.go'
 shutil.copy2(helper,before); shutil.copy2(control,source/control.name)
 shutil.copy2(PROOF_CP7/'agent_layout_probe_test.go',source/'internal/agent/qualification_raw_ordinary_layout_probe_test.go')
def extract_layout(stream_path,out_path):
 total=0; actions=[]; chunks=[]; package_pass=0
 with stream_path.open('rb') as stream:
  for raw in stream:
   total+=len(raw)
   if total>64<<20 or len(raw)>1<<20 or not raw.endswith(b'\n'): raise ValueError('layout stream bounds')
   event=json.loads(raw)
   if event.get('Package')!='p2pstream/internal/agent': continue
   if event.get('Test')=='TestQualificationAgentOrdinaryLayoutProbe':
    if event.get('Action') in ('run','pass','fail','skip'): actions.append(event['Action'])
    if event.get('Action')=='output': chunks.append(event.get('Output',''))
   elif event.get('Test') is None and event.get('Action')=='pass': package_pass+=1
 joined=''.join(chunks); marker='AGENT_ORDINARY_LAYOUT_JSON='
 values=[line.split(marker,1)[1].strip() for line in joined.splitlines() if marker in line]
 if actions!=['run','pass'] or package_pass!=1 or len(values)!=1: raise ValueError('layout audit')
 write_text(out_path,json.dumps(json.loads(values[0]),sort_keys=True,separators=(',',':'))+'\n')

def main():
 if len(sys.argv)!=3: raise ValueError('usage: run-focused-proof.py FRESH_OUTPUT EXPECTED_CHECKPOINT_SHA256')
 output=Path(sys.argv[1]).resolve(); expected=sys.argv[2]; checkpoint=Path(__file__).resolve().parent
 runs=(COMPONENT/'runs').resolve()
 if output.exists() or output.parent!=runs or not runs.is_dir(): raise ValueError('fresh direct owned output required')
 output.mkdir(mode=0o700); records=output/'records'; records.mkdir(mode=0o700)
 write_text(records/'start-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
 accepted=False; issue=None; raw_driver=owned=None; base_pre=focused_pre=ordinary_pre=checkpoint_pre=raw_cp5_pre=proof_cp7_pre=None
 try:
  raw_driver=load_module('raw_driver',RAW_DRIVER,RAW_DRIVER_SHA); owned=load_module('owned',HELPER,HELPER_SHA)
  checkpoint_pre=raw_driver.verify_component(checkpoint,expected); raw_cp5_pre=raw_driver.verify_component(RAW_CP5,RAW_CP5_SHA); proof_cp7_pre=raw_driver.verify_component(PROOF_CP7,PROOF_CP7_SHA)
  write_json(records/'checkpoint-pre.json',{'manifest_sha256':expected,'files':checkpoint_pre}); write_json(records/'raw-cp5-pre.json',{'manifest_sha256':RAW_CP5_SHA,'files':raw_cp5_pre}); write_json(records/'proof-cp7-pre.json',{'manifest_sha256':PROOF_CP7_SHA,'files':proof_cp7_pre})
  exact(GO,GO_SHA); exact(PYTHON,PYTHON_SHA); exact(TASKSET,TASKSET_SHA)
  verify_ledger(RAW_ATTEMPT,RAW_ATTEMPT_SHA); verify_ledger(ATTEMPT1,ATTEMPT1_SHA); verify_ledger(ATTEMPT2,ATTEMPT2_SHA); verify_ledger(OFFLINE,OFFLINE_SHA)
  raw_result=json.loads((RAW_ATTEMPT/'RESULT.json').read_text()); attempt1=json.loads((ATTEMPT1/'FINAL.json').read_text()); attempt2=json.loads((ATTEMPT2/'FINAL.json').read_text()); offline=json.loads((OFFLINE/'FINAL.json').read_text())
  if raw_result.get('accepted') is not True or raw_result.get('endpoint_or_traffic') is not False: raise ValueError('raw focused receipt')
  if attempt1.get('accepted') is not False or attempt1.get('issue')!='RuntimeError: baseline-layout status 1' or not all(attempt1.get('post_checks',{}).values()): raise ValueError('attempt1 disposition')
  if attempt2.get('accepted') is not False or attempt2.get('issue')!='RuntimeError: compare status 1' or not all(attempt2.get('post_checks',{}).values()): raise ValueError('attempt2 disposition')
  if offline.get('accepted') is not False or offline.get('comparison_completed') is not True or not all(offline.get('post_checks',{}).values()): raise ValueError('offline disposition')
  report=json.loads((OFFLINE/'proof/report.json').read_text())
  if report.get('gates')!={'code':False,'compiler':False,'compiler_data':False,'escape':False,'layout':True,'nm':True}: raise ValueError('strict failure gates changed')
  expected_base=json.loads((RAW_CP5/'validation-source/BASE-INVENTORY.json').read_text()).get('files'); base_pre=inventory(BASE)
  if base_pre!=expected_base: raise ValueError('base source changed')
  write_json(records/'base-source-pre.json',{'schema_version':1,'files':base_pre})
  focused=output/'focused/source'; ordinary=output/'ordinary/source'
  shutil.copytree(BASE,focused,symlinks=False,copy_function=shutil.copy2); shutil.copytree(BASE,ordinary,symlinks=False,copy_function=shutil.copy2)
  apply_overlay(focused,checkpoint/'overlay'); apply_overlay(ordinary,checkpoint/'overlay'); apply_test_split(ordinary)
  focused_pre=inventory(focused); ordinary_pre=inventory(ordinary)
  write_json(records/'focused-source-pre.json',{'schema_version':1,'files':focused_pre}); write_json(records/'ordinary-source-pre.json',{'schema_version':1,'files':ordinary_pre})
  common={'HOME':os.environ['HOME'],'PATH':'/usr/bin:/bin','GOENV':'off','GOTOOLCHAIN':'local','GOWORK':'off','GOFLAGS':'','CGO_ENABLED':'1','GOMAXPROCS':'16','GOPATH':str(output/'gopath'),'GOMODCACHE':'/home/user/go/pkg/mod','GOPROXY':'off','GOSUMDB':'off','LC_ALL':'C','TZ':'Europe/Zurich'}
  for path in (output/'gopath',output/'tmp-normal',output/'tmp-race',output/'tmp-proof',output/'cache-normal',output/'cache-race',output/'cache-proof'): path.mkdir(mode=0o700)
  write_json(records/'go-environment.json',common)
  def env(mode): return dict(common,TMPDIR=str(output/f'tmp-{mode}'),GOTMPDIR=str(output/f'tmp-{mode}'),GOCACHE=str(output/f'cache-{mode}'))
  def run(name,argv,cwd,mode='proof',timeout=360):
   status=owned.run(records,name,[str(x) for x in argv],cwd,env(mode),timeout)
   if status!=0: raise RuntimeError(f'{name} status {status}')
  run('go-version',[GO,'version'],REPO,timeout=30)
  if (records/'go-version.stdout.log').read_text().strip()!='go version go1.26.6 linux/amd64': raise ValueError('Go version')
  for name,cwd,want in (('go-env-root',focused,focused/'go.mod'),('go-env-yamux',focused/'third_party/yamux',focused/'third_party/yamux/go.mod'),('go-env-ordinary',ordinary,ordinary/'go.mod')):
   run(name,[GO,'env','-json','GOMOD','GOWORK','GOENV','GOTOOLCHAIN','GOMODCACHE','GOPATH','GOPROXY','GOSUMDB'],cwd,timeout=30)
   actual=json.loads((records/f'{name}.stdout.log').read_text()); expected_env={'GOMOD':str(want),'GOWORK':'off','GOENV':'','GOTOOLCHAIN':'local','GOMODCACHE':'/home/user/go/pkg/mod','GOPATH':str(output/'gopath'),'GOPROXY':'off','GOSUMDB':'off'}
   if actual!=expected_env: raise ValueError(f'effective Go env {name}')
  run('isolation-source-check',[PYTHON,'-I','-B',checkpoint/'verify-isolation.py','--checkpoint',checkpoint,'--raw-cp5',RAW_CP5,'--base-source',BASE,'--output',records/'isolation-result'],REPO,timeout=60)
  if json.loads((records/'isolation-result/result.json').read_text()).get('accepted') is not True: raise ValueError('isolation source result')
  contract=RAW_CP5/'validation-source/EXPECTED-AGENT-TESTS.json'; package,_,_,pattern=raw_driver.expected_contract(contract)
  if package!='p2pstream/internal/agent': raise ValueError('agent package')
  for mode in ('normal','race'):
   command=[TASKSET,'-c','0-15',GO,'test','-json','-count=1','-timeout=300s','-tags=p2pstream_qualification']
   if mode=='race': command.append('-race')
   command.extend(['./internal/agent','-run',pattern]); run(f'agent-{mode}',command,focused,mode)
   if not raw_driver.audit_go_json(records/f'agent-{mode}.stdout.log',contract,records/f'agent-{mode}.audit.json'): raise ValueError(f'agent {mode} audit')
  reused={}
  for name,digest in BASELINE_HASHES.items():
   src=ATTEMPT2/name; dst=records/name; exact(src,digest); shutil.copy2(src,dst); exact(dst,digest); reused[name]=digest
  write_json(records/'baseline-reuse.json',{'schema_version':1,'attempt1_ledger_sha256':ATTEMPT1_SHA,'attempt2_ledger_sha256':ATTEMPT2_SHA,'artifacts':reused})
  run('candidate-export',[TASKSET,'-c','0-15',GO,'list','-a','-export','-f','{{.Export}}','./internal/agent'],ordinary)
  lines=(records/'candidate-export.stdout.log').read_text().splitlines()
  if len(lines)!=1 or not Path(lines[0]).is_file(): raise ValueError('candidate export')
  shutil.copy2(Path(lines[0]),records/'candidate-agent.a')
  run('candidate-asm',[TASKSET,'-c','0-15',GO,'build','-a','-trimpath','-gcflags=p2pstream/internal/agent=-S','./internal/agent'],ordinary)
  run('candidate-escape',[TASKSET,'-c','0-15',GO,'build','-a','-trimpath','-gcflags=p2pstream/internal/agent=-m=2','./internal/agent'],ordinary)
  run('candidate-layout',[TASKSET,'-c','0-15',GO,'test','-json','-count=1','-timeout=300s','-run','^TestQualificationAgentOrdinaryLayoutProbe$','./internal/agent'],ordinary)
  if not raw_driver.audit_go_json(records/'candidate-layout.stdout.log',PROOF_CP7/'EXPECTED-LAYOUT-TESTS.json',records/'candidate-layout.audit.json'): raise ValueError('layout Go JSON audit')
  extract_layout(records/'candidate-layout.stdout.log',records/'candidate-layout.json')
  run('candidate-nm',[GO,'tool','nm','-size',records/'candidate-agent.a'],ordinary,timeout=60)
  run('candidate-objdump',[GO,'tool','objdump','-s',SYMBOL_PATTERN,records/'candidate-agent.a'],ordinary,timeout=60)
  run('compare',[PYTHON,'-I','-B',checkpoint/'compare_agent_ordinary_split.py',
   '--baseline-objdump',records/'baseline-objdump.stdout.log','--baseline-nm',records/'baseline-nm.stdout.log','--baseline-asm',records/'baseline-asm.stderr.log','--baseline-escape',records/'baseline-escape.stderr.log','--baseline-layout',records/'baseline-layout.json','--baseline-source',BASE/'internal/agent/agent.go',
   '--candidate-objdump',records/'candidate-objdump.stdout.log','--candidate-nm',records/'candidate-nm.stdout.log','--candidate-asm',records/'candidate-asm.stderr.log','--candidate-escape',records/'candidate-escape.stderr.log','--candidate-layout',records/'candidate-layout.json','--candidate-source',ordinary/'internal/agent/connect_and_serve_ordinary.go','--output',records/'proof'],REPO,timeout=60)
  result=json.loads((records/'proof/report.json').read_text())
  if result.get('accepted') is not True or not all(result.get('gates',{}).values()): raise ValueError('ordinary proof rejected')
  accepted=True
 except BaseException as error:
  issue=f'{type(error).__name__}: {error}'; traceback.print_exc()
 finally:
  checks={}; post_errors={}
  def check(name,fn):
   try: checks[name]=bool(fn())
   except BaseException as e: checks[name]=False; post_errors[name]=f'{type(e).__name__}: {e}'
  def source_check(label,path,before):
   if before is None:return False
   after=inventory(path); target=records/f'{label}-source-post.json'
   if not target.exists():write_json(target,{'schema_version':1,'files':after})
   return after==before
  def component_check(label,path,digest,before):
   if before is None or raw_driver is None:return False
   after=raw_driver.verify_component(path,digest); target=records/f'{label}-post.json'
   if not target.exists():write_json(target,{'manifest_sha256':digest,'files':after})
   return after==before
  def ledger_check(path,digest):verify_ledger(path,digest);return True
  def lifecycle_check():
   for path in records.glob('*.lifecycle.json'):
    value=json.loads(path.read_text())
    if value.get('forced_cleanup') or value.get('group_joined') is not True:return False
   return True
  check('base_source_unchanged',lambda:base_pre is not None and inventory(BASE)==base_pre)
  check('focused_source_unchanged',lambda:source_check('focused',output/'focused/source',focused_pre))
  check('ordinary_source_unchanged',lambda:source_check('ordinary',output/'ordinary/source',ordinary_pre))
  check('checkpoint_unchanged',lambda:component_check('checkpoint',checkpoint,expected,checkpoint_pre))
  check('raw_checkpoint5_unchanged',lambda:component_check('raw-cp5',RAW_CP5,RAW_CP5_SHA,raw_cp5_pre))
  check('proof_checkpoint7_unchanged',lambda:component_check('proof-cp7',PROOF_CP7,PROOF_CP7_SHA,proof_cp7_pre))
  check('raw_attempt_unchanged',lambda:ledger_check(RAW_ATTEMPT,RAW_ATTEMPT_SHA))
  check('proof_attempt1_unchanged',lambda:ledger_check(ATTEMPT1,ATTEMPT1_SHA))
  check('proof_attempt2_unchanged',lambda:ledger_check(ATTEMPT2,ATTEMPT2_SHA))
  check('offline_failure_unchanged',lambda:ledger_check(OFFLINE,OFFLINE_SHA))
  check('tools_unchanged',lambda:sha(GO)==GO_SHA and sha(PYTHON)==PYTHON_SHA and sha(TASKSET)==TASKSET_SHA)
  check('helpers_unchanged',lambda:sha(HELPER)==HELPER_SHA and sha(RAW_DRIVER)==RAW_DRIVER_SHA)
  check('all_started_groups_joined_without_force',lifecycle_check)
  accepted=accepted and all(checks.values())
  write_json(records/'FINAL.json',{'schema_version':1,'accepted':accepted,'issue':issue,'checkpoint_sha256':expected,'raw_checkpoint5_sha256':RAW_CP5_SHA,'reused_raw_attempt_sha256':RAW_ATTEMPT_SHA,'reused_proof_attempt1_sha256':ATTEMPT1_SHA,'reused_proof_attempt2_sha256':ATTEMPT2_SHA,'reused_baseline_artifact_sha256':BASELINE_HASHES,'preserved_offline_failure_sha256':OFFLINE_SHA,'post_checks':checks,'post_errors':post_errors,'endpoint_or_traffic':False})
  write_text(records/'FINAL.status','0\n' if accepted else '1\n'); write_text(records/'end-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
  lines=[]
  for path in sorted(records.rglob('*')):
   if path.is_file() and path.name!='SHA256SUMS.txt':lines.append(f'{sha(path)}  {path.relative_to(records).as_posix()}\n')
  write_text(records/'SHA256SUMS.txt',''.join(lines))
 return 0 if accepted else 1
if __name__=='__main__':raise SystemExit(main())
