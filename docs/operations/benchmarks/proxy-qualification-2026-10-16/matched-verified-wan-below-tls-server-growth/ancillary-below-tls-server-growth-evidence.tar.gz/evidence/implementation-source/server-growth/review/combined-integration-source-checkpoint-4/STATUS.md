Source-only combined-integration checkpoint 4 candidate. No combined contract, build, endpoint, or WAN execution has occurred.

Checkpoint 1 through checkpoint 3 are preserved unchanged. Checkpoint 4 adds only the bounded no-endpoint contract driver. It uses the accepted owned-process helper and exact component verifier to run, sequentially, static source reconstruction, runner shell syntax, the five actual finalizer cases, and the nine actual arm-closure cases. It persists exact inputs, summaries, direct statuses, lifecycle joins, immutable pre/post component inventories, and a final ledger. It does not repeat Go, server-growth, raw-validator, raw-runtime, build, endpoint, or WAN checks.

The final external receipt must bind the fresh owned copied integration tree and every imported helper path/hash before and after execution. Publication remains blocked on review and execution of this bounded driver and on pending external receipts in INPUTS.json.
