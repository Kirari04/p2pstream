#!/usr/bin/env python3
"""Prove the exact six generated-symbol bijections in saved ordinary artifacts."""
from __future__ import annotations
import argparse,hashlib,json,os,re,stat
from pathlib import Path
MAX=128<<20
PREFIX='p2pstream/internal/agent.connectAndServe'
EXPECTED_MAP={
 'p2pstream/internal/agent..stmp_20':'p2pstream/internal/agent..stmp_31','p2pstream/internal/agent..stmp_21':'p2pstream/internal/agent..stmp_32','p2pstream/internal/agent..stmp_22':'p2pstream/internal/agent..stmp_33','p2pstream/internal/agent..stmp_23':'p2pstream/internal/agent..stmp_34','p2pstream/internal/agent..typeAssert.0':'p2pstream/internal/agent..typeAssert.14','p2pstream/internal/agent..typeAssert.1':'p2pstream/internal/agent..typeAssert.15'}
RELOC=re.compile(r'(?P<prefix>R_PCREL:)(?P<name>p2pstream/internal/agent\.\.(?:stmp_\d+|typeAssert\.\d+))(?P<suffix>(?:<[^>]+>)?)')
HEADER=re.compile(r'^(?P<name>p2pstream/internal/agent\.\.(?:stmp_\d+|typeAssert\.\d+)) (?P<meta>(?:SRODATA|SDATA).*)$')
TOP=re.compile(r'^(?P<name>\S+) (?P<kind>STEXT|SRODATA|SDATA)(?: |$)')
SOURCE=re.compile(r'\s+\(p2pstream/internal/agent/[^:]+:\d+\)')
def read(path):
 st=path.lstat()
 if not stat.S_ISREG(st.st_mode) or st.st_size>MAX:raise ValueError(f'input bounds {path}')
 raw=path.read_bytes();return raw.decode(),hashlib.sha256(raw).hexdigest()
def sections(text):
 lines=text.splitlines();result={}
 for i,line in enumerate(lines):
  match=HEADER.match(line)
  if not match:continue
  name=match.group('name')
  if name in result:raise ValueError(f'duplicate target section {name}')
  body=[];j=i+1
  while j<len(lines) and (not lines[j] or lines[j].startswith('\t')):body.append(lines[j]);j+=1
  result[name]={'meta':match.group('meta'),'body':body}
 return result
def incoming(text,target):
 pattern=re.compile(r'(?<![A-Za-z0-9_.])'+re.escape(target)+r'(?![A-Za-z0-9_.])');owner=None;result=[]
 for number,line in enumerate(text.splitlines(),1):
  top=TOP.match(line)
  if top:owner=top.group('name')
  if not pattern.search(line) or HEADER.match(line):continue
  result.append({'line':number,'owner':owner,'text':SOURCE.sub('',line).replace(target,'<GENERATED-TARGET>')})
 return result
def analyze(basm,casm,bcan,ccan,strict):
 if strict.get('accepted') is not False or strict.get('gates')!={'code':False,'compiler':True,'compiler_data':True,'escape':True,'layout':True,'nm':True}:raise ValueError('strict proof disposition')
 bsections,csections=sections(basm),sections(casm);pairs=[];mapping={};reverse={};other=[]
 bc,cc=bcan.get('code'),ccan.get('code')
 if not isinstance(bc,dict) or set(bc)!=set(cc):raise ValueError('code symbol set')
 for symbol in sorted(bc):
  if len(bc[symbol])!=len(cc[symbol]):raise ValueError('instruction cardinality')
  for index,(b,c) in enumerate(zip(bc[symbol],cc[symbol])):
   if b==c:continue
   if b.get('offset')!=c.get('offset') or b.get('bytes')!=c.get('bytes'):other.append({'symbol':symbol,'index':index,'baseline':b,'candidate':c});continue
   bm,cm=RELOC.search(b.get('asm','')),RELOC.search(c.get('asm',''))
   bn= bm.group('name') if bm else None; cn=cm.group('name') if cm else None
   norm=lambda value:RELOC.sub(r'\g<prefix><GENERATED-TARGET>\g<suffix>',value)
   if not bm or not cm or norm(b['asm'])!=norm(c['asm']):other.append({'symbol':symbol,'index':index,'baseline':b,'candidate':c});continue
   if bn in mapping and mapping[bn]!=cn or cn in reverse and reverse[cn]!=bn:raise ValueError('non-bijective target mapping')
   mapping[bn]=cn;reverse[cn]=bn;pairs.append({'symbol':symbol,'index':index,'offset':b['offset'],'bytes':b['bytes'],'baseline_target':bn,'candidate_target':cn})
 if mapping!=EXPECTED_MAP or other or len(pairs)!=8:raise ValueError('unexpected instruction delta')
 referents=[]
 for baseline,candidate in EXPECTED_MAP.items():
  bs,cs=bsections.get(baseline),csections.get(candidate)
  if bs is None or cs is None or bs!=cs:raise ValueError(f'target section mismatch {baseline} {candidate}')
  bi,ci=incoming(basm,baseline),incoming(casm,candidate)
  if len(bi)!=len(ci) or [x['owner'] for x in bi]!=[x['owner'] for x in ci] or [x['text'] for x in bi]!=[x['text'] for x in ci]:raise ValueError(f'incoming graph mismatch {baseline} {candidate}')
  if set(x['owner'] for x in bi)!={PREFIX}:raise ValueError(f'foreign incoming owner {baseline}')
  want=2 if '..stmp_' in baseline else 4
  if len(bi)!=want:raise ValueError(f'incoming cardinality {baseline}')
  referents.append({'baseline':baseline,'candidate':candidate,'section':bs,'incoming_reference_count':len(bi),'incoming_owner':PREFIX,'incoming_graph_identical':True})
 return {'schema_version':1,'accepted':True,'strict_proof_accepted':False,'strict_generated_symbol_names_equal':False,'ordinary_untagged_code_and_referents_equivalent':True,'supplemental_reference_equivalence_accepted':True,'instruction_difference_count':8,'instruction_sites':pairs,'target_mapping':EXPECTED_MAP,'target_mapping_bijective':True,'referents':referents,'other_instruction_differences':[],'normalization':'Only the exact six evidence-bound generated target names at the exact eight differing sites; opcode bytes, offsets, all other instruction text, complete target sections, and full incoming graphs remain exact.'}
def main():
 p=argparse.ArgumentParser()
 for side in ('baseline','candidate'):
  p.add_argument(f'--{side}-asm',type=Path,required=True);p.add_argument(f'--{side}-canonical',type=Path,required=True)
 p.add_argument('--strict-report',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 if a.output.exists():raise ValueError('fresh output')
 texts={};hashes={}
 for key,path in [('baseline_asm',a.baseline_asm),('candidate_asm',a.candidate_asm),('baseline_canonical',a.baseline_canonical),('candidate_canonical',a.candidate_canonical),('strict_report',a.strict_report)]:texts[key],hashes[key]=read(path)
 result=analyze(texts['baseline_asm'],texts['candidate_asm'],json.loads(texts['baseline_canonical']),json.loads(texts['candidate_canonical']),json.loads(texts['strict_report']));result['input_sha256']=hashes
 a.output.mkdir();fd=os.open(a.output/'result.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
 return 0
if __name__=='__main__':raise SystemExit(main())
