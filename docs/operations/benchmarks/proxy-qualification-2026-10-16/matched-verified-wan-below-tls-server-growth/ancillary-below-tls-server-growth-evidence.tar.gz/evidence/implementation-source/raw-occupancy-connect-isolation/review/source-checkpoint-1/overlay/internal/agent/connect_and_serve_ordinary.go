//go:build !p2pstream_qualification

package agent

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"

	"github.com/hashicorp/yamux"
	"github.com/rs/zerolog/log"

	"p2pstream/internal/buildinfo"
	"p2pstream/internal/tunnel"
)

func connectAndServe(ctx context.Context, client *http.Client, tunnelURL string, agentPublicID string, agentName string, agentToken string, destinationPolicy *agentDestinationPolicy, maxStreamWindowSizeBytes int64, maxConcurrentRequests int64, adaptiveCapacity bool, capacityRuntime *agentTunnelCapacityRuntime, registrations ...tunnelLaneRegistration) error {
	if ctx == nil {
		ctx = context.Background()
	}
	normalizedMaxConcurrentRequests, err := tunnel.NormalizeMaxConcurrentAgentRequests(maxConcurrentRequests)
	if err != nil {
		return fmt.Errorf("invalid tunnel request limit: %w", err)
	}
	maxConcurrentRequests = normalizedMaxConcurrentRequests
	if capacityRuntime == nil {
		capacityRuntime = newAgentTunnelCapacityRuntime(maxConcurrentRequests, adaptiveCapacity, nil)
	}
	initialWindow, err := tunnel.InitialReceiveWindow(maxStreamWindowSizeBytes)
	if err != nil {
		return err
	}
	serveCtx, cancel := context.WithCancel(ctx)
	defer cancel()

	req, err := http.NewRequestWithContext(serveCtx, http.MethodGet, tunnelURL, nil)
	if err != nil {
		return err
	}
	var registration tunnelLaneRegistration
	if len(registrations) > 0 {
		registration = registrations[0]
		req.Header.Set(tunnel.TunnelGroupHeader, registration.group)
		req.Header.Set(tunnel.TunnelLaneHeader, strconv.Itoa(registration.lane))
	}
	aggregateOffered := registration.offerAggregate()
	aggregateRole := tunnel.TunnelLaneRoleControl
	if registration.lane > 0 {
		aggregateRole = tunnel.TunnelLaneRoleBulk
	}
	var releaseSessionResource func()
	var controlReservation *agentControlSessionReservation
	controlStreamLimit := 0
	reserveLegacySession := func() error {
		resourceBytes, reserveErr := tunnel.AgentLegacySessionResourceBytes(initialWindow)
		if reserveErr != nil {
			return reserveErr
		}
		release, ok := capacityRuntime.tryReserveLegacySessionEnvelope(resourceBytes)
		if !ok {
			return errTunnelSessionResourceUnavailable
		}
		releaseSessionResource = release
		return nil
	}
	if aggregateOffered {
		var resourceBytes int64
		var poolBytes int64
		var metadataBytes int64
		if aggregateRole == tunnel.TunnelLaneRoleControl {
			controlStreamLimit = min(tunnel.NegotiatedControlStreamLimit, agentTunnelCapacityMaximumInt(maxConcurrentRequests))
			resourceBytes, err = tunnel.NegotiatedControlSessionResourceBytesForStreams(initialWindow, controlStreamLimit)
		} else {
			resourceBytes, err = tunnel.AggregateSessionResourceBytes(
				tunnel.DefaultAggregateFlowControlConfig().InitialSessionWindow,
				tunnel.AggregateAcceptBacklogStreams+tunnel.AggregateRejectedStreamLimit,
			)
			poolBytes = int64(yamux.AggregateReceiveWindowMemory(tunnel.DefaultAggregateFlowControlConfig().InitialSessionWindow))
			metadataBytes = resourceBytes - poolBytes
		}
		if err != nil {
			return err
		}
		var ok bool
		if aggregateRole == tunnel.TunnelLaneRoleControl {
			controlReservation, ok = capacityRuntime.tryReserveControlSession(resourceBytes, controlStreamLimit)
			if ok {
				releaseSessionResource = controlReservation.release
			}
		} else {
			releaseSessionResource, ok = capacityRuntime.tryReserveAggregateSessionResource(poolBytes, metadataBytes)
		}
		if !ok && registration.lane == 0 && (registration.negotiation == nil || !registration.negotiation.known.Load()) {
			// Keep the legacy primary/control path available when a new aggregate
			// pool cannot be promised. Bulk lanes never downgrade independently.
			aggregateOffered = false
		} else if !ok {
			return errTunnelSessionResourceUnavailable
		}
	}
	if !aggregateOffered {
		if err := reserveLegacySession(); err != nil {
			return err
		}
	}
	if releaseSessionResource == nil {
		releaseSessionResource = func() {}
	}
	defer func() { releaseSessionResource() }()
	req.Header.Set("Authorization", "Bearer "+agentToken)
	req.Header.Set("X-P2PStream-Agent-ID", agentPublicID)
	req.Header.Set("X-P2PStream-Agent-Name", agentName)
	req.Header.Set("Connection", "Upgrade")
	req.Header.Set("Upgrade", tunnel.UpgradeToken)
	req.Header.Set(tunnel.TunnelVersionHeader, strconv.Itoa(tunnel.ProtocolVersion))
	req.Header.Set(tunnel.TunnelMaxConcurrentStreamsHeader, strconv.FormatInt(maxConcurrentRequests, 10))
	req.Header.Set(tunnel.TunnelAgentVersionHeader, buildinfo.Version)
	req.Header.Set(tunnel.TunnelAgentCommitHeader, buildinfo.Commit)
	if adaptiveCapacity {
		req.Header.Set(tunnel.TunnelCapacityModeHeader, tunnel.TunnelCapacityModeAdaptive)
	} else {
		req.Header.Set(tunnel.TunnelCapacityModeHeader, tunnel.TunnelCapacityModeFixed)
	}
	if aggregateOffered {
		tunnel.SetAggregateFlowControlHeaders(req.Header, aggregateRole, tunnel.DefaultAggregateFlowControlConfig())
	}

	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to dial tunnel: %w", err)
	}
	if resp.StatusCode != http.StatusSwitchingProtocols {
		body := ""
		if resp.Body != nil {
			data, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
			body = strings.TrimSpace(string(data))
			_ = resp.Body.Close()
		}
		if body != "" {
			return fmt.Errorf("agent tunnel upgrade failed: status %d: %s", resp.StatusCode, body)
		}
		return fmt.Errorf("agent tunnel upgrade failed: status %d", resp.StatusCode)
	}
	if got := resp.Header.Get("Upgrade"); !strings.EqualFold(got, tunnel.UpgradeToken) {
		_ = resp.Body.Close()
		return fmt.Errorf("agent tunnel upgrade response header = %q", got)
	}
	flowConfig, responseRole, aggregateNegotiated, err := tunnel.ParseAggregateFlowControlHeaders(resp.Header)
	if err != nil {
		_ = resp.Body.Close()
		return fmt.Errorf("invalid aggregate tunnel response: %w", err)
	}
	if aggregateNegotiated && !aggregateOffered {
		_ = resp.Body.Close()
		return errors.New("server enabled unoffered aggregate tunnel flow control")
	}
	legacyParallelAcknowledged := false
	if !aggregateNegotiated && registration.lane == 0 && registration.group != "" {
		legacyParallelAcknowledged, err = validateLegacyPrimaryAcknowledgment(resp.Header, registration.group)
		if err != nil {
			_ = resp.Body.Close()
			return err
		}
	}
	if aggregateOffered && !aggregateNegotiated {
		if registration.lane > 0 {
			_ = resp.Body.Close()
			return errTunnelLaneUnsupported
		}
		if registration.negotiation != nil && registration.negotiation.known.Load() && registration.negotiation.aggregate.Load() {
			_ = resp.Body.Close()
			return errTunnelGroupDowngrade
		}
	}
	if aggregateNegotiated && (responseRole != aggregateRole || !flowConfig.Equal(tunnel.DefaultAggregateFlowControlConfig())) {
		_ = resp.Body.Close()
		return errors.New("server acknowledged mismatched aggregate tunnel contract")
	}
	responseGroup, responseLane, laneErr := tunnel.ParseTunnelLaneHeaders(resp.Header, aggregateNegotiated)
	if registration.group != "" && (aggregateNegotiated || registration.lane > 0) &&
		(laneErr != nil || responseGroup != registration.group || responseLane != registration.lane) {
		_ = resp.Body.Close()
		if registration.lane == 0 {
			return errTunnelGroupProtocol
		}
		// A server downgrade can occur after the primary initially enabled
		// extra lanes. Do not repeatedly replace its legacy single connection.
		return errTunnelLaneUnsupported
	}
	if aggregateOffered && !aggregateNegotiated {
		releaseSessionResource()
		releaseSessionResource = func() {}
		if err := reserveLegacySession(); err != nil {
			_ = resp.Body.Close()
			return err
		}
	}
	negotiatedMaxConcurrentRequests, err := negotiatedAgentTunnelCapacity(resp.Header, maxConcurrentRequests, adaptiveCapacity)
	if err != nil {
		_ = resp.Body.Close()
		return err
	}
	if aggregateNegotiated && aggregateRole == tunnel.TunnelLaneRoleControl {
		controlStreamLimit = min(tunnel.NegotiatedControlStreamLimit, agentTunnelCapacityMaximumInt(negotiatedMaxConcurrentRequests))
		controlBytes, controlErr := tunnel.NegotiatedControlSessionResourceBytesForStreams(initialWindow, controlStreamLimit)
		if controlErr != nil || controlReservation == nil || !controlReservation.activate(negotiatedMaxConcurrentRequests, controlBytes, controlStreamLimit) {
			_ = resp.Body.Close()
			return errors.New("failed to activate negotiated control resource reservation")
		}
	} else {
		capacityRuntime.setMaximum(negotiatedMaxConcurrentRequests)
	}
	rwc, ok := resp.Body.(io.ReadWriteCloser)
	if !ok {
		_ = resp.Body.Close()
		return fmt.Errorf("agent tunnel response body is %T, want io.ReadWriteCloser", resp.Body)
	}
	serveCtx = context.WithValue(serveCtx, receiveWindowContextKey{}, maxStreamWindowSizeBytes)
	var yamuxConfig *yamux.Config
	if aggregateNegotiated {
		if aggregateRole == tunnel.TunnelLaneRoleControl {
			yamuxConfig, err = tunnel.NewNegotiatedControlYamuxConfig(nil, initialWindow, controlStreamLimit)
		} else {
			yamuxConfig, err = tunnel.NewAggregateYamuxConfig(nil, maxStreamWindowSizeBytes, agentTunnelCapacityMaximumInt(negotiatedMaxConcurrentRequests))
		}
	} else {
		yamuxConfig, err = tunnel.NewAgentLegacyYamuxConfig(nil, initialWindow, agentTunnelCapacityMaximumInt(negotiatedMaxConcurrentRequests))
	}
	if err != nil {
		_ = rwc.Close()
		return fmt.Errorf("invalid tunnel yamux configuration: %w", err)
	}
	session, err := yamux.Client(rwc, yamuxConfig)
	if err != nil {
		_ = rwc.Close()
		return fmt.Errorf("failed to initialize tunnel session: %w", err)
	}
	var aggregateGrowth *tunnel.AggregateReceiveWindowGrowth
	if aggregateNegotiated && aggregateRole == tunnel.TunnelLaneRoleBulk {
		aggregateGrowth = tunnel.NewAggregateReceiveWindowGrowth(session, capacityRuntime.tryReserveAggregateSessionGrowth)
	}
	observerConnected := registration.sessionObserver != nil
	defer func() {
		// Growth leases own attached session slabs and outlive every stream.
		// Return them and the initial session promise only after Close has joined
		// Yamux cleanup. Clear the earlier failure-path defer before publishing
		// the observer disconnect boundary.
		_ = session.Close()
		aggregateGrowth.Release()
		releaseSessionResource()
		releaseSessionResource = func() {}
		if observerConnected {
			registration.sessionObserver(tunnelSessionObservation{
				Lane: registration.lane, Aggregate: aggregateNegotiated, Connected: false, Session: session,
			})
		}
	}()
	if observerConnected {
		registration.sessionObserver(tunnelSessionObservation{
			Lane: registration.lane, Aggregate: aggregateNegotiated, Connected: true, Session: session,
		})
	}
	acknowledgedLane := responseGroup == registration.group && responseLane == registration.lane
	if !aggregateNegotiated && registration.lane == 0 {
		// validateLegacyPrimaryAcknowledgment already accepted either an exact
		// modern echo or the fully absent old single-lane response.
		acknowledgedLane = true
	}
	if registration.group != "" && acknowledgedLane && registration.accepted != nil {
		registration.accepted(aggregateNegotiated, aggregateNegotiated || legacyParallelAcknowledged)
	}

	log.Info().
		Int64("advertised_max_streams", maxConcurrentRequests).
		Int64("negotiated_max_streams", negotiatedMaxConcurrentRequests).
		Bool("adaptive_capacity", adaptiveCapacity).
		Bool("aggregate_flow_control", aggregateNegotiated).
		Msg("Connected tunnel successfully")

	go func() {
		<-serveCtx.Done()
		_ = session.Close()
	}()

	var activeControlReservation *agentControlSessionReservation
	if aggregateNegotiated && aggregateRole == tunnel.TunnelLaneRoleControl {
		activeControlReservation = controlReservation
	}
	if err := serveTunnelSessionWithPolicyCapacityAndResources(serveCtx, session, destinationPolicy, capacityRuntime, aggregateGrowth, !aggregateNegotiated, initialWindow, activeControlReservation); err != nil {
		log.Debug().Err(err).Msg("Tunnel session ended")
		return err
	}
	log.Debug().Msg("Tunnel session ended")
	return nil
}
