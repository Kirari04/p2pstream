//go:build p2pstream_qualification

package agent

import (
	"context"
	"errors"
	"io"
	"math"
	"net"
	"net/http"
	"os"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/hashicorp/yamux"
)

const (
	qualificationRawWriteSchemaVersion = 1
	qualificationRawWriteEnableEnv     = "P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT"
)

type qualificationRawWriteContextKey struct{}

type qualificationRawWriteInstall struct {
	previous  http.RoundTripper
	installed *http.Transport
}

var qualificationRawWriteGlobal struct {
	mu         sync.Mutex
	install    atomic.Pointer[qualificationRawWriteInstall]
	generation atomic.Uint64
}

type qualificationRawWriteBinding struct {
	mu        sync.Mutex
	lane      int
	owner     *qualificationRawWriteOwner
	rawBound  bool
	bodyBound bool
}

type qualificationRawWriteDuration struct {
	count uint64
	total uint64
	max   uint64
}

type qualificationRawWriteClass uint8

const (
	qualificationRawWriteContained qualificationRawWriteClass = iota
	qualificationRawWriteOutside
	qualificationRawWriteStraddling
	qualificationRawWriteClassCount
)

type qualificationRawWriteOutcome uint8

const (
	qualificationRawWriteSuccess qualificationRawWriteOutcome = iota
	qualificationRawWriteError
	qualificationRawWriteShort
)

type qualificationRawWriteClassCounters struct {
	calls               uint64
	attemptBytes        uint64
	writtenBytes        uint64
	duration            qualificationRawWriteDuration
	successDuration     qualificationRawWriteDuration
	errorDuration       qualificationRawWriteDuration
	shortDuration       qualificationRawWriteDuration
	successCalls        uint64
	errorCalls          uint64
	shortCalls          uint64
	successAttemptBytes uint64
	successWrittenBytes uint64
	errorAttemptBytes   uint64
	errorWrittenBytes   uint64
	shortAttemptBytes   uint64
	shortWrittenBytes   uint64
}

type qualificationRawWriteInterval struct {
	ambiguous                  bool
	overflow                   bool
	streamObserved             bool
	streamID                   uint32
	multipleStreams            bool
	maximumActiveRawWrites     uint64
	envelopeCount              uint64
	envelopePayloadBytes       uint64
	envelopeWireBytes          uint64
	envelopeZeroRawCalls       uint64
	envelopeDuration           qualificationRawWriteDuration
	containedRawDuration       qualificationRawWriteDuration
	residualDuration           qualificationRawWriteDuration
	boundaryActiveRawWrites    uint64
	boundaryOutsideCompletions uint64
	envelopeOverlaps           uint64
	ownerGenerationChanges     uint64
	classes                    [qualificationRawWriteClassCount]qualificationRawWriteClassCounters
	lastRawFinished            time.Time
}

type qualificationRawWriteOwner struct {
	mu sync.Mutex

	lane          int
	generation    uint64
	rawBound      bool
	bodyBound     bool
	closeObserved bool
	sessionJoined bool
	localAddress  string
	remoteAddress string

	epoch                  uint64
	nextEnvelopeToken      uint64
	activeEnvelope         bool
	activeEnvelopeToken    uint64
	activeEnvelopeStreamID uint32
	activeEnvelopeStarted  time.Time
	activeEnvelopeCalls    uint64
	activeEnvelopeRawNS    uint64
	activeRawWrites        uint64

	interval qualificationRawWriteInterval
}

type qualificationRawWriteBegin struct {
	started        time.Time
	generation     uint64
	epoch          uint64
	envelopeActive bool
	envelopeToken  uint64
}

type qualificationObservedRawConn struct {
	net.Conn
	owner *qualificationRawWriteOwner
}

type qualificationObservedSyscallRawConn struct {
	*qualificationObservedRawConn
	syscallConn syscall.Conn
}

type qualificationObservedTunnelBody struct {
	io.ReadWriteCloser
	owner *qualificationRawWriteOwner
}

func installExternalQualificationRawWriteObserver() (func() error, error) {
	enabled := os.Getenv(qualificationRawWriteEnableEnv)
	if enabled == "" {
		return func() error { return nil }, nil
	}
	if enabled != "1" {
		return nil, errors.New("raw-write diagnostic requires exact sender-wait enablement")
	}

	qualificationRawWriteGlobal.mu.Lock()
	defer qualificationRawWriteGlobal.mu.Unlock()
	if qualificationRawWriteGlobal.install.Load() != nil {
		return nil, errors.New("raw-write diagnostic transport is already installed")
	}
	base, ok := http.DefaultTransport.(*http.Transport)
	if !ok {
		return nil, errors.New("raw-write diagnostic requires the default HTTP transport")
	}
	if base.DialTLS != nil || base.DialTLSContext != nil || base.DialContext == nil {
		return nil, errors.New("raw-write diagnostic requires the pinned default DialContext and no custom TLS dialer")
	}
	originalDial := base.DialContext
	transport := base.Clone()
	transport.DialContext = func(ctx context.Context, network, address string) (net.Conn, error) {
		conn, err := originalDial(ctx, network, address)
		if err != nil {
			return nil, err
		}
		binding, _ := ctx.Value(qualificationRawWriteContextKey{}).(*qualificationRawWriteBinding)
		if binding == nil {
			return conn, nil
		}
		wrapped, bindErr := binding.bindRaw(conn)
		if bindErr != nil {
			_ = conn.Close()
			return nil, bindErr
		}
		return wrapped, nil
	}
	install := &qualificationRawWriteInstall{previous: http.DefaultTransport, installed: transport}
	qualificationRawWriteGlobal.install.Store(install)
	http.DefaultTransport = transport
	return func() error {
		qualificationRawWriteGlobal.mu.Lock()
		defer qualificationRawWriteGlobal.mu.Unlock()
		current := qualificationRawWriteGlobal.install.Load()
		if current != install || http.DefaultTransport != install.installed {
			return errors.New("raw-write diagnostic transport ownership changed before restore")
		}
		http.DefaultTransport = install.previous
		qualificationRawWriteGlobal.install.Store(nil)
		return nil
	}, nil
}

func qualificationBindRawWriteRequest(req *http.Request, registration tunnelLaneRegistration) (*http.Request, error) {
	if qualificationRawWriteGlobal.install.Load() == nil {
		return req, nil
	}
	if req == nil || registration.lane < 0 {
		return nil, errors.New("raw-write diagnostic received an invalid tunnel request binding")
	}
	generation := qualificationRawWriteGlobal.generation.Add(1)
	if generation == 0 {
		return nil, errors.New("raw-write diagnostic generation overflow")
	}
	owner := &qualificationRawWriteOwner{lane: registration.lane, generation: generation}
	binding := &qualificationRawWriteBinding{lane: registration.lane, owner: owner}
	ctx := context.WithValue(req.Context(), qualificationRawWriteContextKey{}, binding)
	return req.WithContext(ctx), nil
}

func qualificationBindRawWriteBody(req *http.Request, body io.ReadWriteCloser) (io.ReadWriteCloser, error) {
	if qualificationRawWriteGlobal.install.Load() == nil {
		return body, nil
	}
	if req == nil || body == nil {
		return nil, errors.New("raw-write diagnostic received an invalid tunnel body binding")
	}
	binding, _ := req.Context().Value(qualificationRawWriteContextKey{}).(*qualificationRawWriteBinding)
	if binding == nil {
		return nil, errors.New("raw-write diagnostic tunnel request binding is missing")
	}
	binding.mu.Lock()
	defer binding.mu.Unlock()
	if !binding.rawBound || binding.bodyBound || binding.owner == nil {
		return nil, errors.New("raw-write diagnostic tunnel body binding is missing or duplicated")
	}
	binding.bodyBound = true
	binding.owner.mu.Lock()
	binding.owner.bodyBound = true
	binding.owner.mu.Unlock()
	return &qualificationObservedTunnelBody{ReadWriteCloser: body, owner: binding.owner}, nil
}

func qualificationRetireRawWriteSession(session *yamux.Session) {
	if session != nil {
		session.RetireQualificationRawWriteActivity()
	}
}

func (binding *qualificationRawWriteBinding) bindRaw(conn net.Conn) (net.Conn, error) {
	if binding == nil || conn == nil {
		return nil, errors.New("raw-write diagnostic received an invalid raw connection")
	}
	binding.mu.Lock()
	defer binding.mu.Unlock()
	if binding.rawBound || binding.owner == nil || binding.owner.lane != binding.lane {
		return nil, errors.New("raw-write diagnostic raw connection binding is duplicated or mismatched")
	}
	binding.rawBound = true
	owner := binding.owner
	owner.mu.Lock()
	owner.rawBound = true
	owner.localAddress = conn.LocalAddr().String()
	owner.remoteAddress = conn.RemoteAddr().String()
	owner.mu.Unlock()
	base := &qualificationObservedRawConn{Conn: conn, owner: owner}
	if syscallConn, ok := conn.(syscall.Conn); ok {
		return &qualificationObservedSyscallRawConn{qualificationObservedRawConn: base, syscallConn: syscallConn}, nil
	}
	return base, nil
}

func (conn *qualificationObservedRawConn) QualificationUnderlyingConn() net.Conn {
	if conn == nil {
		return nil
	}
	return conn.Conn
}

func (conn *qualificationObservedSyscallRawConn) SyscallConn() (syscall.RawConn, error) {
	if conn == nil || conn.syscallConn == nil {
		return nil, errors.New("raw-write diagnostic syscall connection is unavailable")
	}
	return conn.syscallConn.SyscallConn()
}

func (conn *qualificationObservedRawConn) Write(payload []byte) (int, error) {
	if conn == nil || conn.Conn == nil || conn.owner == nil {
		return 0, net.ErrClosed
	}
	begin := conn.owner.beginRawWrite()
	// This timestamp is the measured raw-write start. Ownership is reserved
	// first so an envelope opening in the gap sees an active boundary write.
	begin.started = time.Now()
	written, err := conn.Conn.Write(payload)
	finished := time.Now()
	conn.owner.finishRawWrite(begin, len(payload), written, err, finished)
	return written, err
}

func (conn *qualificationObservedRawConn) Close() error {
	if conn == nil || conn.Conn == nil {
		return net.ErrClosed
	}
	err := conn.Conn.Close()
	if conn.owner != nil {
		conn.owner.markClosed()
	}
	return err
}

func (body *qualificationObservedTunnelBody) Close() error {
	if body == nil || body.ReadWriteCloser == nil {
		return net.ErrClosed
	}
	err := body.ReadWriteCloser.Close()
	if body.owner != nil {
		body.owner.markClosed()
	}
	return err
}

func (body *qualificationObservedTunnelBody) CloseWrite() error {
	if body == nil || body.ReadWriteCloser == nil {
		return net.ErrClosed
	}
	closer, ok := body.ReadWriteCloser.(interface{ CloseWrite() error })
	if !ok {
		return errors.New("raw-write diagnostic tunnel body does not support CloseWrite")
	}
	return closer.CloseWrite()
}

func (body *qualificationObservedTunnelBody) BeginQualificationRawWriteEnvelope(streamID uint32, payloadBytes, wireBytes uint64, physicalStarted time.Time) uint64 {
	if body == nil || body.owner == nil {
		return 0
	}
	return body.owner.beginEnvelope(streamID, payloadBytes, wireBytes, physicalStarted)
}

func (body *qualificationObservedTunnelBody) FinishQualificationRawWriteEnvelope(token uint64) time.Time {
	if body == nil || body.owner == nil {
		return time.Now()
	}
	return body.owner.finishEnvelopeNow(token)
}

func (body *qualificationObservedTunnelBody) DrainQualificationRawWriteActivity() yamux.QualificationRawWriteActivity {
	if body == nil || body.owner == nil {
		return yamux.QualificationRawWriteActivity{}
	}
	return body.owner.drain()
}

func (body *qualificationObservedTunnelBody) RetireQualificationRawWriteActivity() {
	if body != nil && body.owner != nil {
		body.owner.markSessionJoined()
	}
}

func (owner *qualificationRawWriteOwner) beginRawWrite() qualificationRawWriteBegin {
	owner.mu.Lock()
	owner.activeRawWrites = qualificationRawAdd(owner.activeRawWrites, 1, &owner.interval.overflow)
	if owner.activeRawWrites > owner.interval.maximumActiveRawWrites {
		owner.interval.maximumActiveRawWrites = owner.activeRawWrites
	}
	if owner.activeRawWrites > 1 {
		owner.interval.ambiguous = true
	}
	begin := qualificationRawWriteBegin{
		generation:     owner.generation,
		epoch:          owner.epoch,
		envelopeActive: owner.activeEnvelope,
		envelopeToken:  owner.activeEnvelopeToken,
	}
	owner.mu.Unlock()
	return begin
}

func (owner *qualificationRawWriteOwner) finishRawWrite(begin qualificationRawWriteBegin, attempted, written int, writeErr error, finished time.Time) {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	if owner.activeRawWrites == 0 {
		owner.interval.ambiguous = true
	} else {
		owner.activeRawWrites--
	}
	class := qualificationRawWriteStraddling
	if begin.generation != owner.generation {
		owner.interval.ownerGenerationChanges = qualificationRawAdd(owner.interval.ownerGenerationChanges, 1, &owner.interval.overflow)
	} else if begin.epoch == owner.epoch && begin.envelopeActive && owner.activeEnvelope && begin.envelopeToken == owner.activeEnvelopeToken &&
		!begin.started.Before(owner.activeEnvelopeStarted) {
		class = qualificationRawWriteContained
	} else if begin.epoch == owner.epoch && !begin.envelopeActive && !owner.activeEnvelope {
		class = qualificationRawWriteOutside
	}
	if attempted < 0 || written < 0 || written > attempted || finished.Before(begin.started) {
		owner.interval.ambiguous = true
		attempted = max(attempted, 0)
		written = min(max(written, 0), attempted)
	}
	outcome := qualificationRawWriteSuccess
	if writeErr != nil {
		outcome = qualificationRawWriteError
	} else if written != attempted {
		outcome = qualificationRawWriteShort
	}
	owner.interval.classes[class].record(uint64(attempted), uint64(written), finished.Sub(begin.started), outcome, &owner.interval.overflow)
	if owner.interval.lastRawFinished.IsZero() || finished.After(owner.interval.lastRawFinished) {
		owner.interval.lastRawFinished = finished
	}
}

func (owner *qualificationRawWriteOwner) beginEnvelope(streamID uint32, payloadBytes, wireBytes uint64, physicalStarted time.Time) uint64 {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	if owner.activeEnvelope {
		owner.interval.envelopeOverlaps = qualificationRawAdd(owner.interval.envelopeOverlaps, 1, &owner.interval.overflow)
		owner.interval.ambiguous = true
		return 0
	}
	if physicalStarted.IsZero() || wireBytes < payloadBytes {
		owner.interval.ambiguous = true
		return 0
	}
	owner.nextEnvelopeToken = qualificationRawAdd(owner.nextEnvelopeToken, 1, &owner.interval.overflow)
	if owner.nextEnvelopeToken == 0 {
		owner.interval.ambiguous = true
		return 0
	}
	owner.epoch = qualificationRawAdd(owner.epoch, 1, &owner.interval.overflow)
	owner.activeEnvelope = true
	owner.activeEnvelopeToken = owner.nextEnvelopeToken
	owner.activeEnvelopeStreamID = streamID
	owner.activeEnvelopeStarted = physicalStarted
	owner.activeEnvelopeCalls = owner.interval.classes[qualificationRawWriteContained].calls
	owner.activeEnvelopeRawNS = owner.interval.classes[qualificationRawWriteContained].duration.total
	owner.interval.envelopeCount = qualificationRawAdd(owner.interval.envelopeCount, 1, &owner.interval.overflow)
	owner.interval.envelopePayloadBytes = qualificationRawAdd(owner.interval.envelopePayloadBytes, payloadBytes, &owner.interval.overflow)
	owner.interval.envelopeWireBytes = qualificationRawAdd(owner.interval.envelopeWireBytes, wireBytes, &owner.interval.overflow)
	owner.observeStream(streamID)
	if owner.activeRawWrites != 0 {
		owner.interval.boundaryActiveRawWrites = qualificationRawAdd(owner.interval.boundaryActiveRawWrites, owner.activeRawWrites, &owner.interval.overflow)
		owner.interval.ambiguous = true
	}
	if !owner.interval.lastRawFinished.IsZero() && owner.interval.lastRawFinished.After(physicalStarted) {
		owner.interval.boundaryOutsideCompletions = qualificationRawAdd(owner.interval.boundaryOutsideCompletions, 1, &owner.interval.overflow)
		owner.interval.ambiguous = true
	}
	return owner.activeEnvelopeToken
}

func (owner *qualificationRawWriteOwner) finishEnvelope(token uint64, physicalFinished time.Time) {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	owner.finishEnvelopeLocked(token, physicalFinished)
}

func (owner *qualificationRawWriteOwner) finishEnvelopeNow(token uint64) time.Time {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	physicalFinished := time.Now()
	owner.finishEnvelopeLocked(token, physicalFinished)
	return physicalFinished
}

func (owner *qualificationRawWriteOwner) finishEnvelopeLocked(token uint64, physicalFinished time.Time) {
	if !owner.activeEnvelope || token == 0 || token != owner.activeEnvelopeToken {
		owner.interval.ambiguous = true
		return
	}
	if physicalFinished.Before(owner.activeEnvelopeStarted) {
		owner.interval.ambiguous = true
		physicalFinished = owner.activeEnvelopeStarted
	}
	if owner.activeRawWrites != 0 {
		owner.interval.boundaryActiveRawWrites = qualificationRawAdd(owner.interval.boundaryActiveRawWrites, owner.activeRawWrites, &owner.interval.overflow)
		owner.interval.ambiguous = true
	}
	if !owner.interval.lastRawFinished.IsZero() && owner.interval.lastRawFinished.After(physicalFinished) {
		owner.interval.ambiguous = true
	}
	contained := &owner.interval.classes[qualificationRawWriteContained]
	containedCalls := uint64(0)
	containedNS := uint64(0)
	if contained.calls < owner.activeEnvelopeCalls || contained.duration.total < owner.activeEnvelopeRawNS {
		owner.interval.ambiguous = true
	} else {
		containedCalls = contained.calls - owner.activeEnvelopeCalls
		containedNS = contained.duration.total - owner.activeEnvelopeRawNS
	}
	envelopeDuration := physicalFinished.Sub(owner.activeEnvelopeStarted)
	owner.interval.envelopeDuration.add(envelopeDuration, &owner.interval.overflow)
	if containedNS > math.MaxInt64 {
		owner.interval.overflow = true
		owner.interval.ambiguous = true
	} else {
		owner.interval.containedRawDuration.add(time.Duration(containedNS), &owner.interval.overflow)
	}
	if containedCalls == 0 {
		owner.interval.envelopeZeroRawCalls = qualificationRawAdd(owner.interval.envelopeZeroRawCalls, 1, &owner.interval.overflow)
	}
	if containedNS > uint64(envelopeDuration) || containedNS > math.MaxInt64 {
		owner.interval.ambiguous = true
	} else {
		owner.interval.residualDuration.add(envelopeDuration-time.Duration(containedNS), &owner.interval.overflow)
	}
	owner.activeEnvelope = false
	owner.activeEnvelopeToken = 0
	owner.activeEnvelopeStreamID = 0
	owner.activeEnvelopeStarted = time.Time{}
	owner.activeEnvelopeCalls = 0
	owner.activeEnvelopeRawNS = 0
	owner.epoch = qualificationRawAdd(owner.epoch, 1, &owner.interval.overflow)
}

func (owner *qualificationRawWriteOwner) observeStream(streamID uint32) {
	if !owner.interval.streamObserved {
		owner.interval.streamObserved = true
		owner.interval.streamID = streamID
		return
	}
	if owner.interval.streamID != streamID {
		owner.interval.multipleStreams = true
	}
}

func (owner *qualificationRawWriteOwner) markClosed() {
	owner.mu.Lock()
	owner.closeObserved = true
	if owner.activeEnvelope || owner.activeRawWrites != 0 {
		owner.interval.ambiguous = true
	}
	owner.mu.Unlock()
}

func (owner *qualificationRawWriteOwner) markSessionJoined() {
	owner.mu.Lock()
	owner.sessionJoined = true
	if owner.activeEnvelope || owner.activeRawWrites != 0 {
		owner.interval.ambiguous = true
	}
	owner.mu.Unlock()
}

func (owner *qualificationRawWriteOwner) drain() yamux.QualificationRawWriteActivity {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	complete := !owner.activeEnvelope && owner.activeRawWrites == 0
	result := yamux.QualificationRawWriteActivity{
		SchemaVersion: qualificationRawWriteSchemaVersion,
		Enabled:       true, Complete: complete, ResetPerformed: complete,
		Bound: owner.rawBound && owner.bodyBound, CloseObserved: owner.closeObserved, SessionJoined: owner.sessionJoined,
		Ambiguous: owner.interval.ambiguous, Overflow: owner.interval.overflow,
		Lane: owner.lane, Generation: owner.generation,
		LocalAddress: owner.localAddress, RemoteAddress: owner.remoteAddress,
		StreamObserved: owner.interval.streamObserved, ObservedStreamID: owner.interval.streamID,
		MultipleStreams: owner.interval.multipleStreams,
		ActiveEnvelopes: qualificationRawBoolCount(owner.activeEnvelope), ActiveRawWrites: owner.activeRawWrites,
		MaximumActiveRawWrites:     owner.interval.maximumActiveRawWrites,
		EnvelopeCount:              owner.interval.envelopeCount,
		EnvelopePayloadBytes:       owner.interval.envelopePayloadBytes,
		EnvelopeWireBytes:          owner.interval.envelopeWireBytes,
		EnvelopeZeroRawCalls:       owner.interval.envelopeZeroRawCalls,
		EnvelopeDuration:           qualificationRawDurationSnapshot(owner.interval.envelopeDuration),
		ContainedRawDuration:       qualificationRawDurationSnapshot(owner.interval.containedRawDuration),
		ResidualDuration:           qualificationRawDurationSnapshot(owner.interval.residualDuration),
		BoundaryActiveRawWrites:    owner.interval.boundaryActiveRawWrites,
		BoundaryOutsideCompletions: owner.interval.boundaryOutsideCompletions,
		EnvelopeOverlaps:           owner.interval.envelopeOverlaps,
		OwnerGenerationChanges:     owner.interval.ownerGenerationChanges,
		Contained:                  qualificationRawClassSnapshot(owner.interval.classes[qualificationRawWriteContained]),
		Outside:                    qualificationRawClassSnapshot(owner.interval.classes[qualificationRawWriteOutside]),
		Straddling:                 qualificationRawClassSnapshot(owner.interval.classes[qualificationRawWriteStraddling]),
	}
	if complete {
		owner.interval = qualificationRawWriteInterval{}
	}
	return result
}

func (counters *qualificationRawWriteClassCounters) record(attempted, written uint64, duration time.Duration, outcome qualificationRawWriteOutcome, overflow *bool) {
	counters.calls = qualificationRawAdd(counters.calls, 1, overflow)
	counters.attemptBytes = qualificationRawAdd(counters.attemptBytes, attempted, overflow)
	counters.writtenBytes = qualificationRawAdd(counters.writtenBytes, written, overflow)
	counters.duration.add(duration, overflow)
	switch outcome {
	case qualificationRawWriteSuccess:
		counters.successDuration.add(duration, overflow)
		counters.successCalls = qualificationRawAdd(counters.successCalls, 1, overflow)
		counters.successAttemptBytes = qualificationRawAdd(counters.successAttemptBytes, attempted, overflow)
		counters.successWrittenBytes = qualificationRawAdd(counters.successWrittenBytes, written, overflow)
	case qualificationRawWriteError:
		counters.errorDuration.add(duration, overflow)
		counters.errorCalls = qualificationRawAdd(counters.errorCalls, 1, overflow)
		counters.errorAttemptBytes = qualificationRawAdd(counters.errorAttemptBytes, attempted, overflow)
		counters.errorWrittenBytes = qualificationRawAdd(counters.errorWrittenBytes, written, overflow)
	case qualificationRawWriteShort:
		counters.shortDuration.add(duration, overflow)
		counters.shortCalls = qualificationRawAdd(counters.shortCalls, 1, overflow)
		counters.shortAttemptBytes = qualificationRawAdd(counters.shortAttemptBytes, attempted, overflow)
		counters.shortWrittenBytes = qualificationRawAdd(counters.shortWrittenBytes, written, overflow)
	}
}

func (duration *qualificationRawWriteDuration) add(value time.Duration, overflow *bool) {
	if value < 0 {
		*overflow = true
		return
	}
	nanoseconds := uint64(value)
	duration.count = qualificationRawAdd(duration.count, 1, overflow)
	duration.total = qualificationRawAdd(duration.total, nanoseconds, overflow)
	if nanoseconds > duration.max {
		duration.max = nanoseconds
	}
}

func qualificationRawAdd(current, value uint64, overflow *bool) uint64 {
	if math.MaxUint64-current < value {
		*overflow = true
		return math.MaxUint64
	}
	return current + value
}

func qualificationRawBoolCount(value bool) uint64 {
	if value {
		return 1
	}
	return 0
}

func qualificationRawDurationSnapshot(duration qualificationRawWriteDuration) yamux.QualificationDurationBucket {
	return yamux.QualificationDurationBucket{Count: duration.count, TotalNanoseconds: duration.total, MaxNanoseconds: duration.max}
}

func qualificationRawClassSnapshot(counters qualificationRawWriteClassCounters) yamux.QualificationRawWriteClass {
	return yamux.QualificationRawWriteClass{
		Calls: counters.calls, AttemptBytes: counters.attemptBytes, WrittenBytes: counters.writtenBytes,
		Duration:        qualificationRawDurationSnapshot(counters.duration),
		SuccessDuration: qualificationRawDurationSnapshot(counters.successDuration),
		ErrorDuration:   qualificationRawDurationSnapshot(counters.errorDuration),
		ShortDuration:   qualificationRawDurationSnapshot(counters.shortDuration),
		SuccessCalls:    counters.successCalls, ErrorCalls: counters.errorCalls, ShortCalls: counters.shortCalls,
		SuccessAttemptBytes: counters.successAttemptBytes, SuccessWrittenBytes: counters.successWrittenBytes,
		ErrorAttemptBytes: counters.errorAttemptBytes, ErrorWrittenBytes: counters.errorWrittenBytes,
		ShortAttemptBytes: counters.shortAttemptBytes, ShortWrittenBytes: counters.shortWrittenBytes,
	}
}
