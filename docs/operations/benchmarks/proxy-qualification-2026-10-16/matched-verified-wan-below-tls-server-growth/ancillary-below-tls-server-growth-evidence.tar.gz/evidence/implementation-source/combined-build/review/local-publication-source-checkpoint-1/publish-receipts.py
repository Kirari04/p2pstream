#!/usr/bin/python3
"""Publish the two reviewed receipts without copying the audited binaries."""

from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
import stat
from pathlib import Path


EXPECTED = {
    "proof_receipt": "b9ff8977b934f5a993fa7c29ab0d5b432a9a99d81c6c588c356cb476071a638d",
    "build_receipt": "472d8abcbb2c36d866e201f32f3c8aab25f8ff478670859fbea57cc174a435c6",
    "agent_binary": "3467c211595b95a5ca21242630f83a976e0d6f9131aac65fa21a50d8739ad94a",
    "server_binary": "dd604b0ee93ab7d413b88b42cee2028e6cc7eab9e33a3046a0759046b8e9512a",
    "build_records_ledger": "9d89e974120f0a2b28c03dac1d1d5ed7031999b7b69dbcf875fabdc53a2cd96f",
    "build_result_review": "c49173028c00e3134b0a9f60fd97aceca757725f5522f7230d2533a8de1f6a7e",
    "current_source_binding": "968516dcd3234db502b392b98cf1945de28b901e9a5fd547cdcae275cc3271b2",
    "proof_records_ledger": "20e69805d80384f76be0df0f83d92f9445d9181d1931f9016a9d0503a506cc6b",
    "final_integration_checkpoint": "162ff6e8f6333560e8c89beb3eb2ff74452a55f30ab5593b3435e1e17f89c5aa",
}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def require_file(path: Path, expected: str, mode: int | None = None) -> None:
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or path.is_symlink():
        raise SystemExit(f"not a regular non-symlink file: {path}")
    actual = digest(path)
    if actual != expected:
        raise SystemExit(f"hash mismatch for {path}: {actual}")
    if mode is not None and stat.S_IMODE(info.st_mode) != mode:
        raise SystemExit(
            f"mode mismatch for {path}: {oct(stat.S_IMODE(info.st_mode))}"
        )


def create_bytes(path: Path, content: bytes, mode: int) -> None:
    descriptor = os.open(
        path,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
        mode,
    )
    try:
        with os.fdopen(descriptor, "wb", closefd=False) as output:
            output.write(content)
            output.flush()
            os.fsync(output.fileno())
    finally:
        os.close(descriptor)
    if stat.S_IMODE(path.stat().st_mode) != mode:
        raise SystemExit(f"published mode mismatch: {path}")


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def require_active_checkpoint(checkpoint: Path, active: Path) -> None:
    expected: dict[str, str] = {}
    for line in (checkpoint / "SHA256SUMS.txt").read_text().splitlines():
        value, name = line.split("  ", 1)
        if name == "CHECKPOINT.json":
            continue
        if name.startswith("/") or ".." in Path(name).parts or name in expected:
            raise SystemExit(f"unsafe checkpoint entry: {name}")
        expected[name] = value
    actual_names = {
        str(path.relative_to(active))
        for path in active.rglob("*")
        if path.is_file() and not str(path.relative_to(active)).startswith("provenance/")
    }
    if actual_names != set(expected):
        raise SystemExit("active final-integration inventory differs from checkpoint 8")
    for name, value in expected.items():
        require_file(active / name, value)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--worktree-root", required=True, type=Path)
    parser.add_argument("--evidence-dir", required=True, type=Path)
    arguments = parser.parse_args()

    root = arguments.worktree_root.resolve(strict=True)
    prefix = root / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source"
    build_run = prefix / "combined-build/runs/audited-build-attempt-1"
    proof_run = prefix / "raw-occupancy-equivalence/runs/offline-equivalence-attempt-1/records"
    final_root = prefix / "final-integration-source"

    sources = {
        "proof_receipt": proof_run / "raw-ordinary-proof-receipt.json",
        "build_receipt": build_run / "audited-combined-build-receipt.json",
        "agent_binary": build_run / "bin/current-agent-wan-below-tls-audited.test",
        "server_binary": build_run / "bin/current-server-wan-below-tls-audited.test",
        "build_records_ledger": build_run / "records/SHA256SUMS.txt",
        "build_result_review": prefix / "combined-build/review/independent-build-result-review-1/SHA256SUMS.txt",
        "current_source_binding": prefix / "combined-build/provenance/main-current-source-binding/binding.json",
        "proof_records_ledger": proof_run / "SHA256SUMS.txt",
        "final_integration_checkpoint": prefix / "server-growth/review/final-integration-source-checkpoint-8/SHA256SUMS.txt",
    }
    for name, path in sources.items():
        mode = 0o775 if name in {"agent_binary", "server_binary"} else None
        require_file(path, EXPECTED[name], mode)
    require_active_checkpoint(sources["final_integration_checkpoint"].parent, final_root)

    destinations = {
        "proof_receipt": final_root / "provenance/raw-ordinary-proof-receipt.json",
        "build_receipt": final_root / "provenance/audited-combined-build-receipt.json",
    }
    for destination in destinations.values():
        if destination.exists() or destination.is_symlink():
            raise SystemExit(f"destination is not fresh: {destination}")

    evidence = arguments.evidence_dir
    if evidence.exists() or evidence.is_symlink():
        raise SystemExit(f"evidence directory is not fresh: {evidence}")
    evidence.mkdir(mode=0o700, parents=False)
    create_bytes(
        evidence / "START.json",
        json_bytes(
            {
                "schema_version": 1,
                "started_utc": utc_now(),
                "worktree_root": str(root),
                "sources": {name: str(path) for name, path in sources.items()},
                "destinations": {name: str(path) for name, path in destinations.items()},
                "binary_policy": "reuse_original_audited_build_paths_no_copy",
            }
        ),
        0o600,
    )

    destinations["proof_receipt"].parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    create_bytes(destinations["proof_receipt"], sources["proof_receipt"].read_bytes(), 0o600)
    create_bytes(destinations["build_receipt"], sources["build_receipt"].read_bytes(), 0o600)

    for name, destination in destinations.items():
        require_file(destination, EXPECTED[name], 0o600)
        if destination.read_bytes() != sources[name].read_bytes():
            raise SystemExit(f"published bytes differ: {destination}")
    for name, path in sources.items():
        mode = 0o775 if name in {"agent_binary", "server_binary"} else None
        require_file(path, EXPECTED[name], mode)
    require_active_checkpoint(sources["final_integration_checkpoint"].parent, final_root)

    result = {
        "accepted": True,
        "schema_version": 1,
        "finished_utc": utc_now(),
        "published_receipts": {
            name: {"path": str(destinations[name]), "sha256": EXPECTED[name], "mode": "0o600"}
            for name in sorted(destinations)
        },
        "audited_binaries": {
            name: {"path": str(sources[name]), "sha256": EXPECTED[name], "mode": "0o775", "copied": False}
            for name in ("agent_binary", "server_binary")
        },
        "endpoint_execution": False,
        "wan_traffic": False,
    }
    create_bytes(evidence / "publication-result.json", json_bytes(result), 0o600)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
