# Overlay file list

Modified audited-source files:

- `internal/agent/agent.go`: request/body binding hooks and post-`Session.Close` retirement publication.
- `internal/agent/proxy_qualification_external_test.go`: qualification-only transport observer installation and exact restore.
- `internal/agent/proxy_qualification_credit_snapshot_enabled_test.go`: raw activity nested in the existing authenticated sender-counter drain.
- `third_party/yamux/session_send_loop_qualification.go`: open/close the raw temporal envelope around the existing DATA physical write, sharing its end timestamp.
- `third_party/yamux/qualification_aggregate_send_durations.go`: accept the already-captured end timestamp without changing the default caller.

New tagged/ordinary files:

- `internal/agent/qualification_raw_write_ordinary.go`: ordinary no-op hooks.
- `internal/agent/qualification_raw_write_qualification.go`: fixed owner, transport/body wrappers, classification, conservation, lifecycle, and destructive drain.
- `internal/agent/qualification_raw_write_qualification_test.go`: focused ledger, boundary, retirement, and real TLS 101/Yamux path controls.
- `third_party/yamux/qualification_raw_write_activity.go`: tagged schema and Session observer bridge.

No server control, public handler, runtime policy, flow-control constant, timeout, socket option, runner, validator, or production configuration file is included.
