# Raw-validator focused invocation source

This source-only driver requires its own `/usr/bin/python3 -I -B` invocation and
runs exactly the two frozen raw-validator checkpoint-5 contract sources with
the same flags. It imports the reviewed
owned-process helper by exact SHA-256 and requires a fresh, owner-only output
root.

The run preserves command arguments, stdout, stderr, direct status, and process
group lifecycle for each contract. It audits the exact 42 raw-validator cases
and 13 sender-composition cases, retains the ten nested sender closure inputs,
records complete component and fixed-input hashes before and after, records the
minimal child environment, verifies the helper and interpreter before and
after, and writes a small final checksum ledger. It runs no Go test, build,
endpoint, or traffic command.

This checkpoint only describes the invocation. No contract has been executed
from it. A caller must preserve the outer tool result separately.
