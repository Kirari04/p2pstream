#!/usr/bin/env python3
import ast, hashlib, pathlib, sys
root = pathlib.Path(sys.argv[1])
runner = root / "integration/qualify-proxy-agent-growth-wan-below-tls.sh"
arm = root / "integration/validate-wan-below-tls-arm.py"
for name in ("validate-wan-below-tls-arm.py", "validate-server-receive-growth.py", "validate-copy-record.py", "validate-raw-write-activity.py", "validate-sender-wait-snapshot.py", "validate-post-join-raw-closure.py"):
    ast.parse((root / "integration" / name).read_text())
source = runner.read_text()
start = source.index("run_transfer() {\n")
depth = 0
end = None
for index in range(start, len(source)):
    if source[index] == "{":
        depth += 1
    elif source[index] == "}":
        depth -= 1
        if depth == 0:
            if index + 1 >= len(source) or source[index + 1] != "\n":
                raise SystemExit("timed run_transfer lacks its existing final newline")
            end = index + 2
            break
if end is None:
    raise SystemExit("unterminated run_transfer")
body = source[start:end].encode()
if len(body) != 7350 or hashlib.sha256(body).hexdigest() != "b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798":
    raise SystemExit("timed run_transfer changed")
required = (
    'P2PSTREAM_QUALIFICATION_RAW_WRITE_TERMINAL_PATH="$raw_write_terminal_path"',
    'finalize_raw_write_after_agent_join "$label-$iteration-agent"',
    '--mode final-closure --final-closure "$raw_write_terminal_path"',
    '$(dirname "$raw_write_validator") == $(dirname "$sender_wait_validator")',
)
if any(value not in source for value in required): raise SystemExit("raw finalizer binding missing")
arm_source = arm.read_text()
for value in ("valid = boundary_valid and compound_tuple_join", "validate_post_join_raw_closure", "raw_write_final_closure_valid", "final-raw-write-record.json", "counts encrypted buffers passed below tls.Conn"):
    if value not in arm_source: raise SystemExit(f"arm binding missing: {value}")
print("combined static source accepted")
