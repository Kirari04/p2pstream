#!/usr/bin/env python3
"""Focused, offline contracts for the raw-write validator.

This source is intentionally not executed by the source checkpoint. A later
reviewed validation run must preserve its inputs, output, and exit status.
"""

from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path


VALIDATOR = Path(__file__).resolve().parents[1] / "integration" / "validate-raw-write-activity.py"
SPEC = importlib.util.spec_from_file_location("raw_write_validator", VALIDATOR)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def duration(count: int = 0, total: int = 0, maximum: int = 0) -> dict[str, int]:
    return {"count": count, "total_nanoseconds": total, "max_nanoseconds": maximum}


def raw_class(calls: int = 0, attempted: int = 0, written: int = 0,
              total_ns: int = 0) -> dict[str, object]:
    maximum = total_ns if calls else 0
    return {
        "calls": calls,
        "attempt_bytes": attempted,
        "written_bytes": written,
        "duration": duration(calls, total_ns, maximum),
        "success_duration": duration(calls, total_ns, maximum),
        "error_duration": duration(),
        "short_duration": duration(),
        "success_calls": calls,
        "error_calls": 0,
        "short_calls": 0,
        "success_attempt_bytes": attempted,
        "success_written_bytes": written,
        "error_attempt_bytes": 0,
        "error_written_bytes": 0,
        "short_attempt_bytes": 0,
        "short_written_bytes": 0,
    }


def activity(*, lane: int = 1, generation: int = 7, stream: int = 3,
             frames: int = 2, payload: int = 100, wire: int = 124,
             contained_calls: int = 2, outside_calls: int = 0,
             close: bool = False, joined: bool = False) -> dict[str, object]:
    envelope_ns = 80 if frames else 0
    contained_ns = 50 if frames else 0
    residual_ns = envelope_ns - contained_ns if frames else 0
    contained_bytes = wire if contained_calls else 0
    outside_bytes = 20 if outside_calls else 0
    return {
        "schema_version": 1,
        "enabled": True,
        "complete": True,
        "reset_performed": True,
        "bound": True,
        "close_observed": close,
        "session_joined": joined,
        "ambiguous": False,
        "overflow": False,
        "lane": lane,
        "generation": generation,
        "local_address": f"local-{lane}",
        "remote_address": f"remote-{lane}",
        "stream_observed": frames > 0,
        "observed_stream_id": stream if frames else 0,
        "multiple_streams": False,
        "active_envelopes": 0,
        "active_raw_writes": 0,
        "maximum_active_raw_writes": 1 if contained_calls or outside_calls else 0,
        "envelope_count": frames,
        "envelope_payload_bytes": payload if frames else 0,
        "envelope_wire_bytes": wire if frames else 0,
        "envelope_zero_raw_calls": 0,
        "envelope_duration": duration(frames, envelope_ns, envelope_ns),
        "contained_raw_duration": duration(frames, contained_ns, contained_ns),
        "residual_duration": duration(frames, residual_ns, residual_ns),
        "boundary_active_raw_writes": 0,
        "boundary_outside_completions": 0,
        "envelope_overlaps": 0,
        "owner_generation_changes": 0,
        "contained": raw_class(contained_calls, contained_bytes, contained_bytes, contained_ns),
        "outside": raw_class(outside_calls, outside_bytes, outside_bytes, 10 if outside_calls else 0),
        "straddling": raw_class(),
    }


def no_data(lane: int, *, final: bool = False, outside_calls: int = 0) -> dict[str, object]:
    return activity(lane=lane, stream=0, frames=0, payload=0, wire=0,
                    contained_calls=0, outside_calls=outside_calls,
                    close=final, joined=final)


def identity(value: dict[str, object]) -> dict[str, object]:
    return {key: value[key] for key in ("lane", "local_address", "remote_address")}


def selected(value: dict[str, object]) -> dict[str, object]:
    return {
        "stream_id": value["observed_stream_id"],
        "frames": value["envelope_count"],
        "payload_bytes": value["envelope_payload_bytes"],
        "wire_bytes": value["envelope_wire_bytes"],
    }


def expect(name: str, accepted: bool, got: dict[str, object], rows: list[dict[str, object]]) -> None:
    actual = got.get("accepted") is True
    rows.append({"name": name, "expected_accepted": accepted, "actual_accepted": actual,
                 "passed": actual is accepted, "issues": got.get("issues", [])})


def history() -> list[dict[str, object]]:
    rows = []
    for _ in range(9):
        for lane in range(5):
            raw = no_data(lane)
            rows.append({"lane": lane, "session_identity": f"session-{lane}",
                         "raw_write_activity": raw})
    return rows


def final_sidecar() -> dict[str, object]:
    records = []
    for lane in range(5):
        records.append({"lane": lane, "aggregate": True,
                        "session_identity": f"session-{lane}",
                        "raw_write_activity": no_data(lane, final=True, outside_calls=1)})
    return {"schema_version": 1, "expected_sessions": 5, "complete": True,
            "invalid": False, "records": records}


def main() -> None:
    rows: list[dict[str, object]] = []
    valid = activity()
    expect("selected-valid", True, MODULE.validate_live(valid, identity(valid), "post", selected(valid)), rows)
    multiwrite = activity(frames=1, contained_calls=2)
    expect("selected-multiple-contained-writes", True,
           MODULE.validate_live(multiwrite, identity(multiwrite), "post", selected(multiwrite)), rows)

    conditioning = activity(frames=2)
    conditioning["multiple_streams"] = True
    expect("conditioning-multiple-streams-retained", True,
           MODULE.validate_live(conditioning, identity(conditioning), "pre"), rows)

    straddling = no_data(1)
    straddling["straddling"] = raw_class(1, 20, 20, 10)
    straddling["maximum_active_raw_writes"] = 1
    expect("conditioning-straddling-rejected", False,
           MODULE.validate_live(straddling, identity(straddling), "pre"), rows)

    control = no_data(0, outside_calls=1)
    expect("control-outside-write-retained", True,
           {"accepted": not MODULE.validate_no_data_activity(control, "control"),
            "issues": MODULE.validate_no_data_activity(control, "control")}, rows)

    control_straddling = no_data(0)
    control_straddling["straddling"] = raw_class(1, 20, 20, 10)
    control_straddling["maximum_active_raw_writes"] = 1
    expect("control-straddling-rejected", False,
           {"accepted": not MODULE.validate_no_data_activity(control_straddling, "control"),
            "issues": MODULE.validate_no_data_activity(control_straddling, "control")}, rows)

    mutations = {
        "unknown-field": lambda value: value.update({"unknown": 1}),
        "bool-as-int": lambda value: value.update({"ambiguous": 0}),
        "active-complete": lambda value: value.update({"active_raw_writes": 1}),
        "joined-without-close": lambda value: value.update({"session_joined": True}),
        "stream-without-envelope": lambda value: value.update({"envelope_count": 0}),
        "wire-below-payload": lambda value: value.update({"envelope_wire_bytes": 99}),
        "yamux-placeholder-tuple": lambda value: value.update({"local_address": "yamux:local"}),
        "maximum-mismatch": lambda value: value.update({"maximum_active_raw_writes": 0}),
        "residual-mismatch": lambda value: value["residual_duration"].update({"total_nanoseconds": 31, "max_nanoseconds": 31}),
        "selected-stream-mismatch": lambda value: value.update({"observed_stream_id": 5}),
        "selected-multiple-streams": lambda value: value.update({"multiple_streams": True}),
        "selected-zero-contained": lambda value: value.update({
            "contained": raw_class(), "contained_raw_duration": duration(2, 0, 0),
            "residual_duration": duration(2, 80, 80), "maximum_active_raw_writes": 0,
        }),
        "selected-zero-contained-bytes": lambda value: value.update({
            "contained": raw_class(2, 0, 0, 50),
        }),
    }
    for name, mutate in mutations.items():
        candidate = copy.deepcopy(valid)
        mutate(candidate)
        physical = selected(valid)
        expect(name, False, MODULE.validate_live(candidate, identity(valid), "post", physical), rows)

    error = copy.deepcopy(valid)
    error_class = error["contained"]
    error_class.update({
        "success_calls": 1, "success_attempt_bytes": 62, "success_written_bytes": 62,
        "success_duration": duration(1, 25, 25),
        "error_calls": 1, "error_attempt_bytes": 62, "error_written_bytes": 0,
        "error_duration": duration(1, 25, 25), "written_bytes": 62,
    })
    expect("raw-error", False, MODULE.validate_live(error, identity(error), "post", selected(error)), rows)

    short = copy.deepcopy(valid)
    short_class = short["contained"]
    short_class.update({
        "success_calls": 1, "success_attempt_bytes": 62, "success_written_bytes": 62,
        "success_duration": duration(1, 25, 25),
        "short_calls": 1, "short_attempt_bytes": 62, "short_written_bytes": 61,
        "short_duration": duration(1, 25, 25), "written_bytes": 123,
    })
    expect("raw-short", False, MODULE.validate_live(short, identity(short), "post", selected(short)), rows)

    stable_history = history()
    closure = final_sidecar()
    expect("final-closure-valid", True, MODULE.validate_final_closure(closure, stable_history), rows)
    missing = copy.deepcopy(closure)
    missing["records"].pop()
    expect("final-closure-missing-lane", False, MODULE.validate_final_closure(missing, stable_history), rows)
    changed = copy.deepcopy(closure)
    changed["records"][2]["session_identity"] = "replacement"
    expect("final-closure-reconnect", False, MODULE.validate_final_closure(changed, stable_history), rows)
    history_straddling = copy.deepcopy(stable_history)
    history_straddling[0]["raw_write_activity"]["straddling"] = raw_class(1, 20, 20, 10)
    history_straddling[0]["raw_write_activity"]["maximum_active_raw_writes"] = 1
    expect("final-closure-history-straddling", False,
           MODULE.validate_final_closure(closure, history_straddling), rows)
    ordinary = copy.deepcopy(closure)
    ordinary["records"][0]["aggregate"] = False
    expect("final-closure-control-not-aggregate", False,
           MODULE.validate_final_closure(ordinary, stable_history), rows)
    active = copy.deepcopy(closure)
    active["records"][3]["raw_write_activity"]["active_raw_writes"] = 1
    expect("final-closure-active", False, MODULE.validate_final_closure(active, stable_history), rows)
    final_straddling = copy.deepcopy(closure)
    final_straddling["records"][3]["raw_write_activity"]["straddling"] = raw_class(1, 20, 20, 10)
    final_straddling["records"][3]["raw_write_activity"]["maximum_active_raw_writes"] = 1
    expect("final-closure-straddling", False,
           MODULE.validate_final_closure(final_straddling, stable_history), rows)
    final_data = copy.deepcopy(closure)
    final_data["records"][4]["raw_write_activity"] = activity(
        lane=4, close=True, joined=True)
    expect("final-closure-data", False, MODULE.validate_final_closure(final_data, stable_history), rows)

    result = {"schema_version": 1, "case_count": len(rows), "accepted": all(row["passed"] for row in rows),
              "cases": rows}
    print(json.dumps(result, indent=2, sort_keys=True))
    raise SystemExit(0 if result["accepted"] else 1)


if __name__ == "__main__":
    main()
