#!/usr/bin/env python3
"""Focused contracts for exact STEXT flag and duplicate handling."""
from __future__ import annotations
import importlib.util
from pathlib import Path

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("comparator",HERE/"compare_agent_ordinary.py")
if spec is None or spec.loader is None: raise RuntimeError("cannot import comparator")
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)

def fixture(flags_by_name=None):
    flags_by_name=flags_by_name or {}
    lines=[]
    for index,name in enumerate(module.EXPECTED):
        flags=flags_by_name.get(name,"")
        flag_text=f"{flags} " if flags else ""
        lines.extend([
            f"{name} STEXT {flag_text}size={index+1} args=0x0 locals=0x0 funcid=0x0 align=0x0",
            f"\t0x0000 00000 (p2pstream/internal/agent/agent.go:1)\tTEXT\t{name}(SB), NOSPLIT|NOFRAME|ABIInternal, $0-0",
            "\t0x0000 00000 (p2pstream/internal/agent/agent.go:1)\tFUNCDATA\t$0, gclocals·fixture(SB)",
            "\t0x0000 00000 (p2pstream/internal/agent/agent.go:1)\tRET",
        ])
    lines.extend(["gclocals·fixture SRODATA dupok size=8","\t0x0000 00 00 00 00 00 00 00 00"])
    return "\n".join(lines)+"\n"

def reject(text, expected):
    try: module.compiler(text)
    except ValueError as error:
        if expected not in str(error): raise
    else: raise AssertionError(f"accepted malformed fixture: {expected}")

def main():
    flags={module.EXPECTED[0]:"nosplit",module.EXPECTED[1]:"dupok nosplit"}
    records,data=module.compiler(fixture(flags))
    assert records[module.EXPECTED[0]]["flags"]=="nosplit"
    assert records[module.EXPECTED[1]]["flags"]=="dupok nosplit"
    assert records[module.EXPECTED[2]]["flags"]==""
    assert set(records)==set(module.EXPECTED) and data
    duplicate_text=fixture()+fixture().splitlines()[0]+"\n"
    reject(duplicate_text,"duplicate compiler text symbol")
    reject(fixture()+"gclocals·fixture SRODATA dupok size=8\n", "duplicate compiler data symbol")
    missing=fixture().replace("\t0x0000 00000 (p2pstream/internal/agent/agent.go:1)\tFUNCDATA\t$0, gclocals·fixture(SB)\n","",1)
    reject(missing,"empty stack metadata")
    print("compiler parser contracts: PASS")
    return 0
if __name__=="__main__": raise SystemExit(main())
