#!/usr/bin/python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
RUN = ROOT / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/final-integration-source/integration/runs/tiny-below-tls-smoke-3"
OUT = ROOT / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/combined-build/review/tiny-smoke-3-measurement-review-1"
SEQUENCES = [9, 11, 14, 15]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bucket_total(value: dict) -> int:
    return value["total_nanoseconds"]


arms = {}
inputs = {}
for arm, protocol in (("h1", "h1"), ("h2", "h2")):
    arm_root = RUN / arm
    attestation_path = arm_root / "attestation.json"
    records_path = arm_root / "results.sender-wait-records.jsonl"
    terminal_path = arm_root / "results.sender-wait-controls/final-raw-write-terminal.json"
    inputs[f"{arm}_attestation"] = sha(attestation_path)
    inputs[f"{arm}_records"] = sha(records_path)
    inputs[f"{arm}_terminal"] = sha(terminal_path)
    attestation = json.loads(attestation_path.read_text())
    assert attestation["accepted"] is True
    assert attestation["protocol"] == protocol and attestation["row_count"] == 16
    assert attestation["size_mode"] == "small" and attestation["performance_gate_enabled"] is False
    assert attestation["natural_endpoint_and_namespace_statuses"] is True
    assert attestation["outer_runner_group_joined"] is True
    assert attestation["sender_terminal_closure_valid"] is True
    assert attestation["raw_write_final_closure_valid"] is True
    assert attestation["integrity_issues"] == [] and attestation["validation_issues"] == []

    records = [json.loads(line) for line in records_path.read_text().splitlines()]
    interval_records = [entry for entry in records if isinstance(entry.get("sender_validation"), dict)]
    assert [entry["sequence"] for entry in interval_records] == SEQUENCES
    growth_by_sequence = {entry["sequence"]: entry for entry in attestation["server_receive_growth_intervals"]}
    assert sorted(growth_by_sequence) == SEQUENCES
    rows = []
    for entry in interval_records:
        sequence = entry["sequence"]
        selected = entry["sender_validation"]["selected"]
        lane, stream_id = selected["lane"], selected["stream_id"]
        assert entry["valid"] is True and entry["sender_validation"]["accepted"] is True
        counters = [value for value in entry["post_sender"]["response"]["send_counters"] if value["lane"] == lane]
        assert len(counters) == 1
        timing = counters[0]["timing"]
        raw = selected["raw_write_activity"]
        assert raw["accepted"] is True and raw["issues"] == []
        assert raw["bools"]["complete"] is True and raw["bools"]["reset_performed"] is True
        assert raw["bools"]["ambiguous"] is False and raw["bools"]["overflow"] is False
        assert raw["bools"]["multiple_streams"] is False
        ints = raw["ints"]
        assert ints["lane"] == lane and ints["observed_stream_id"] == stream_id
        assert ints["active_envelopes"] == 0 and ints["active_raw_writes"] == 0
        assert ints["boundary_active_raw_writes"] == 0 and ints["boundary_outside_completions"] == 0
        assert ints["envelope_overlaps"] == 0 and ints["owner_generation_changes"] == 0
        assert ints["maximum_active_raw_writes"] == 1 and ints["envelope_zero_raw_calls"] == 0
        assert ints["envelope_count"] == selected["frames"]
        assert ints["envelope_payload_bytes"] == selected["payload_bytes"]
        assert ints["envelope_wire_bytes"] == selected["wire_bytes"]
        envelope_ns = bucket_total(raw["durations"]["envelope_duration"])
        contained_ns = bucket_total(raw["durations"]["contained_raw_duration"])
        residual_ns = bucket_total(raw["durations"]["residual_duration"])
        physical_ns = bucket_total(selected["durations"]["physical_write_total"])
        assert envelope_ns == physical_ns and contained_ns + residual_ns == envelope_ns
        assert raw["classes"]["contained"]["scalars"]["calls"] > 0
        assert raw["classes"]["outside"]["scalars"]["calls"] > 0
        assert raw["classes"]["straddling"]["scalars"]["calls"] == 0
        assert raw["classes"]["contained"]["scalars"]["attempt_bytes"] > selected["wire_bytes"]

        cause = timing["credit_wait_by_cause"]
        cause_ns = {name: bucket_total(value) for name, value in cause.items()}
        credit_ns = bucket_total(selected["durations"]["credit_wait_total"])
        assert sum(cause_ns.values()) == credit_ns
        assert cause_ns["session_allocation_zero"] == 0
        assert cause_ns["stream_and_session_allocation_zero"] == 0
        assert timing["physical_error_frames"] == 0 and timing["physical_short_frames"] == 0

        growth = growth_by_sequence[sequence]
        assert growth["accepted"] is True and growth["post_dropped_events"] == 0
        assert growth["selected_event_count"] == len(growth["selected_events"]) > 0
        identity = growth["selected_identity"]
        assert identity["lane"] == lane and identity["stream_id"] == stream_id
        sender_interval = next(value for value in attestation["sender_duration_intervals"] if value["sequence"] == sequence)
        assert sender_interval["compound_tuple_join"] is True
        assert sender_interval["server_local_address"] == identity["local_address"]
        assert sender_interval["server_remote_address"] == identity["remote_address"]
        assert sender_interval["agent_raw_local_address"] == identity["remote_address"]
        assert sender_interval["agent_raw_remote_address"] == identity["local_address"]
        snapshots = [value for value in entry["post_server_capacity"]["server_receive_growth"]["credit_snapshot"]["sessions"] if value["lane"] == lane]
        assert len(snapshots) == 1
        streams = [value for value in snapshots[0]["snapshot"]["streams"] if value["id"] == stream_id]
        assert len(streams) == 1
        outcomes = {}
        for event in growth["selected_events"]:
            outcomes[event["outcome"]] = outcomes.get(event["outcome"], 0) + 1
        rows.append({
            "sequence": sequence, "stage": entry["stage"], "lane": lane, "stream_id": stream_id,
            "credit_wait_ns": credit_ns, "credit_wait_by_cause_ns": cause_ns,
            "enqueue_ns": bucket_total(selected["durations"]["data_enqueue_select_total"]),
            "completion_ns": bucket_total(selected["durations"]["data_completion_select_total"]),
            "physical_ns": physical_ns, "contained_raw_ns": contained_ns, "residual_ns": residual_ns,
            "frames": selected["frames"], "contained_raw_calls": raw["classes"]["contained"]["scalars"]["calls"],
            "outside_raw_calls": raw["classes"]["outside"]["scalars"]["calls"],
            "straddling_raw_calls": 0, "growth_events": outcomes,
            "post_byte_receive_limit": streams[0]["byte_receive_limit"],
            "post_allocation_receive_limit": streams[0]["allocation_receive_limit"],
            "compound_tuple_join": True,
        })

    terminal = json.loads(terminal_path.read_text())
    assert terminal["complete"] is True and terminal["invalid"] is False
    assert terminal["expected_sessions"] == 5 and [value["lane"] for value in terminal["records"]] == [0, 1, 2, 3, 4]
    for value in terminal["records"]:
        raw = value["raw_write_activity"]
        assert value["aggregate"] is True
        assert raw["complete"] and raw["reset_performed"] and raw["close_observed"] and raw["session_joined"]
        assert not raw["ambiguous"] and not raw["overflow"]
        assert raw["active_envelopes"] == 0 and raw["active_raw_writes"] == 0
    arms[arm] = {"accepted": True, "selected_rows": rows, "terminal_sessions": 5}

final_status = json.loads((RUN / "final-status.json").read_text())
assert final_status["accepted"] is True and final_status["performance_result"] is False
assert final_status["same_binaries_both_arms"] is True
assert final_status["same_verified_certificate_both_arms"] is True
assert final_status["pre_post_hashes_equal"] is True
inputs["final_status"] = sha(RUN / "final-status.json")

report = {
    "schema_version": 1,
    "accepted": True,
    "scope": "semantic validity of new sender/raw/server-growth fields in the closed 4 MiB tiny cohort",
    "performance_result": False,
    "issues": [],
    "inputs": inputs,
    "arms": arms,
    "interpretation": [
        "All eight selected rows contain nonempty, exactly joined sender, raw-write, and server receive-growth evidence.",
        "Credit waits dominate these tiny-row sender intervals; contained raw-write and physical-write totals are only millisecond-scale. This validates discrimination, not WAN performance or causality.",
        "Sequence 15 reuses lane 3 after sequence 11 and shows no stream-allocation wait or grown event in either arm, while the other selected rows include receive growth. This is direction-history evidence only.",
        "Raw attempt bytes are TLS ciphertext-domain values and intentionally exceed Yamux wire bytes; outside calls are retained, while all straddling and boundary ambiguity counters are zero.",
    ],
}
(OUT / "REVIEW.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
