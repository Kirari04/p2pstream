#!/usr/bin/env bash
set -euo pipefail

root=/home/user/.codex/worktrees/astra-proxy-performance/p2pstream
checkpoint="$root/tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/combined-build/review/local-publication-source-checkpoint-1"
evidence="$root/tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/combined-build/provenance/local-publication-attempt-1"

exec /usr/bin/python3.14 -I -B "$checkpoint/publish-receipts.py" \
  --worktree-root "$root" \
  --evidence-dir "$evidence"
