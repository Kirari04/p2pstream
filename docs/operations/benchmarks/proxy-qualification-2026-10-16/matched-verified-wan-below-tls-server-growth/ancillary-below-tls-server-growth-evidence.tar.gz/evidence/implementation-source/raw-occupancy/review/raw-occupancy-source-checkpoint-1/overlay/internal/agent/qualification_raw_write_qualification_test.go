//go:build p2pstream_qualification

package agent

import (
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/hashicorp/yamux"

	"p2pstream/internal/tunnel"
)

func TestQualificationRawWriteTLS101PathSharesPhysicalInterval(t *testing.T) {
	t.Setenv(qualificationRawWriteEnableEnv, "1")
	serverSession := make(chan *yamux.Session, 1)
	serverError := make(chan error, 1)
	management := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Connection") != "Upgrade" || r.Header.Get("Upgrade") != tunnel.UpgradeToken {
			http.Error(w, "missing upgrade", http.StatusBadRequest)
			return
		}
		hijacker, ok := w.(http.Hijacker)
		if !ok {
			serverError <- errors.New("TLS response does not support hijack")
			return
		}
		conn, rw, err := hijacker.Hijack()
		if err != nil {
			serverError <- err
			return
		}
		if _, err := fmt.Fprintf(rw, "HTTP/1.1 101 Switching Protocols\r\nConnection: Upgrade\r\nUpgrade: %s\r\n\r\n", tunnel.UpgradeToken); err != nil {
			_ = conn.Close()
			serverError <- err
			return
		}
		if err := rw.Flush(); err != nil {
			_ = conn.Close()
			serverError <- err
			return
		}
		config, err := tunnel.NewAggregateYamuxConfig(nil, tunnel.DefaultMaxStreamWindowSizeBytes, 4)
		if err != nil {
			_ = conn.Close()
			serverError <- err
			return
		}
		session, err := yamux.Server(conn, config)
		if err != nil {
			_ = conn.Close()
			serverError <- err
			return
		}
		serverSession <- session
	}))
	t.Cleanup(management.Close)

	previousTransport := http.DefaultTransport
	transport := management.Client().Transport.(*http.Transport).Clone()
	transport.DialContext = (&net.Dialer{}).DialContext
	http.DefaultTransport = transport
	t.Cleanup(func() { http.DefaultTransport = previousTransport })
	restore, err := installExternalQualificationRawWriteObserver()
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if err := restore(); err != nil {
			t.Errorf("restore raw-write observer: %v", err)
		}
	})

	req, err := http.NewRequestWithContext(t.Context(), http.MethodGet, management.URL, nil)
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Connection", "Upgrade")
	req.Header.Set("Upgrade", tunnel.UpgradeToken)
	req, err = qualificationBindRawWriteRequest(req, tunnelLaneRegistration{lane: 1})
	if err != nil {
		t.Fatal(err)
	}
	client, err := managementTunnelHTTPClient(&http.Client{Transport: http.DefaultTransport})
	if err != nil {
		t.Fatal(err)
	}
	response, err := client.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	if response.StatusCode != http.StatusSwitchingProtocols {
		t.Fatalf("upgrade status = %d", response.StatusCode)
	}
	body, ok := response.Body.(io.ReadWriteCloser)
	if !ok {
		t.Fatalf("upgrade body = %T", response.Body)
	}
	body, err = qualificationBindRawWriteBody(req, body)
	if err != nil {
		t.Fatal(err)
	}
	clientConfig, err := tunnel.NewAggregateYamuxConfig(nil, tunnel.DefaultMaxStreamWindowSizeBytes, 4)
	if err != nil {
		t.Fatal(err)
	}
	clientSession, err := yamux.Client(body, clientConfig)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = clientSession.Close() })
	var peer *yamux.Session
	select {
	case peer = <-serverSession:
	case err := <-serverError:
		t.Fatal(err)
	case <-t.Context().Done():
		t.Fatal(t.Context().Err())
	}
	t.Cleanup(func() { _ = peer.Close() })

	accepted := make(chan *yamux.Stream, 1)
	acceptError := make(chan error, 1)
	go func() {
		stream, err := peer.AcceptStream()
		if err != nil {
			acceptError <- err
			return
		}
		accepted <- stream
	}()
	stream, err := clientSession.OpenStream()
	if err != nil {
		t.Fatal(err)
	}
	defer stream.Close()
	var peerStream *yamux.Stream
	select {
	case peerStream = <-accepted:
	case err := <-acceptError:
		t.Fatal(err)
	case <-t.Context().Done():
		t.Fatal(t.Context().Err())
	}
	defer peerStream.Close()
	payload := make([]byte, 32*1024)
	readDone := make(chan error, 1)
	go func() {
		_, err := io.ReadFull(peerStream, make([]byte, len(payload)))
		readDone <- err
	}()
	if written, err := stream.Write(payload); err != nil || written != len(payload) {
		t.Fatalf("stream write = %d, %v", written, err)
	}
	select {
	case err := <-readDone:
		if err != nil {
			t.Fatal(err)
		}
	case <-t.Context().Done():
		t.Fatal(t.Context().Err())
	}

	got := clientSession.DrainQualificationRawWriteActivity()
	if !got.Complete || got.Ambiguous || got.Overflow || !got.Bound || got.Lane != 1 || got.EnvelopeCount == 0 || got.Contained.Calls == 0 {
		t.Fatalf("TLS 101 raw activity = %+v", got)
	}
	if got.EnvelopePayloadBytes < uint64(len(payload)) || got.EnvelopeWireBytes < got.EnvelopePayloadBytes {
		t.Fatalf("TLS 101 envelope bytes = %+v", got)
	}
	if got.EnvelopeDuration.TotalNanoseconds != got.ContainedRawDuration.TotalNanoseconds+got.ResidualDuration.TotalNanoseconds {
		t.Fatalf("TLS 101 duration conservation = %+v", got)
	}
	if err := clientSession.Close(); err != nil {
		t.Fatal(err)
	}
	clientSession.RetireQualificationRawWriteActivity()
	joined := clientSession.DrainQualificationRawWriteActivity()
	if !joined.CloseObserved || !joined.SessionJoined || !joined.Complete {
		t.Fatalf("TLS 101 terminal lifecycle = %+v", joined)
	}
}

func TestQualificationRawWriteOutcomeDurationsConserveSuccessErrorShort(t *testing.T) {
	owner := &qualificationRawWriteOwner{lane: 2, generation: 7, rawBound: true, bodyBound: true}
	base := time.Unix(0, 1_000_000)

	token := owner.beginEnvelope(11, 32, 44, base)
	contained := owner.beginRawWrite()
	contained.started = base.Add(time.Microsecond)
	owner.finishRawWrite(contained, 12, 12, nil, base.Add(4*time.Microsecond))
	owner.finishEnvelope(token, base.Add(8*time.Microsecond))

	short := owner.beginRawWrite()
	short.started = base.Add(9 * time.Microsecond)
	owner.finishRawWrite(short, 10, 6, nil, base.Add(14*time.Microsecond))
	errorWrite := owner.beginRawWrite()
	errorWrite.started = base.Add(15 * time.Microsecond)
	owner.finishRawWrite(errorWrite, 9, 2, errors.New("test write failure"), base.Add(22*time.Microsecond))

	got := owner.drain()
	if !got.Complete || !got.ResetPerformed || got.Ambiguous || got.Overflow {
		t.Fatalf("snapshot state = %+v", got)
	}
	if got.Contained.SuccessCalls != 1 || got.Contained.SuccessDuration.Count != 1 || got.Contained.SuccessDuration.TotalNanoseconds != 3_000 {
		t.Fatalf("contained success = %+v", got.Contained)
	}
	if got.Outside.ShortCalls != 1 || got.Outside.ShortDuration.Count != 1 || got.Outside.ShortDuration.TotalNanoseconds != 5_000 {
		t.Fatalf("outside short = %+v", got.Outside)
	}
	if got.Outside.ErrorCalls != 1 || got.Outside.ErrorDuration.Count != 1 || got.Outside.ErrorDuration.TotalNanoseconds != 7_000 {
		t.Fatalf("outside error = %+v", got.Outside)
	}
	if got.Contained.Duration.TotalNanoseconds != got.Contained.SuccessDuration.TotalNanoseconds+got.Contained.ErrorDuration.TotalNanoseconds+got.Contained.ShortDuration.TotalNanoseconds {
		t.Fatalf("contained duration outcomes do not conserve: %+v", got.Contained)
	}
	if got.Outside.Duration.TotalNanoseconds != got.Outside.SuccessDuration.TotalNanoseconds+got.Outside.ErrorDuration.TotalNanoseconds+got.Outside.ShortDuration.TotalNanoseconds {
		t.Fatalf("outside duration outcomes do not conserve: %+v", got.Outside)
	}
}

func TestQualificationRawWriteEnvelopeRejectsBoundaryActiveAndStraddling(t *testing.T) {
	owner := &qualificationRawWriteOwner{lane: 1, generation: 3, rawBound: true, bodyBound: true}
	base := time.Unix(0, 2_000_000)
	straddler := owner.beginRawWrite()
	straddler.started = base
	token := owner.beginEnvelope(9, 64, 76, base.Add(time.Microsecond))
	owner.finishRawWrite(straddler, 8, 8, nil, base.Add(3*time.Microsecond))
	owner.finishEnvelope(token, base.Add(4*time.Microsecond))

	got := owner.drain()
	if !got.Complete || !got.Ambiguous || got.BoundaryActiveRawWrites != 1 || got.Straddling.Calls != 1 || got.Contained.Calls != 0 {
		t.Fatalf("straddling snapshot = %+v", got)
	}
}

func TestQualificationRawWriteDrainRetainsLiveOwnershipAndPublishesJoin(t *testing.T) {
	owner := &qualificationRawWriteOwner{lane: 4, generation: 5, rawBound: true, bodyBound: true}
	base := time.Unix(0, 3_000_000)
	active := owner.beginRawWrite()
	active.started = base

	first := owner.drain()
	if first.Complete || first.ResetPerformed || first.ActiveRawWrites != 1 {
		t.Fatalf("live drain = %+v", first)
	}
	owner.finishRawWrite(active, 4, 4, nil, base.Add(time.Microsecond))
	owner.markClosed()
	beforeJoin := owner.drain()
	if !beforeJoin.CloseObserved || beforeJoin.SessionJoined {
		t.Fatalf("pre-join lifecycle = %+v", beforeJoin)
	}
	owner.markSessionJoined()
	afterJoin := owner.drain()
	if !afterJoin.CloseObserved || !afterJoin.SessionJoined || !afterJoin.Complete {
		t.Fatalf("joined lifecycle = %+v", afterJoin)
	}
}

func TestQualificationRawWriteStartTimestampMustBeInsideEnvelope(t *testing.T) {
	owner := &qualificationRawWriteOwner{lane: 1, generation: 1, rawBound: true, bodyBound: true}
	base := time.Unix(0, 4_000_000)
	token := owner.beginEnvelope(3, 16, 28, base.Add(2*time.Microsecond))
	raw := owner.beginRawWrite()
	// Model a raw ownership reservation that preceded the envelope even though
	// its bookkeeping lock completed after the envelope opened.
	raw.started = base
	owner.finishRawWrite(raw, 2, 2, nil, base.Add(3*time.Microsecond))
	owner.finishEnvelope(token, base.Add(4*time.Microsecond))
	got := owner.drain()
	if got.Contained.Calls != 0 || got.Straddling.Calls != 1 {
		t.Fatalf("timestamp enclosure classification = %+v", got)
	}
}
