# Overlay file list

Modified audited-source files:

- `internal/agent/agent.go`: request/body binding hooks and post-`Session.Close` retirement publication.
- `internal/agent/proxy_qualification_external_test.go`: qualification-only transport observer installation, exact restore, session-observer terminal recording, and post-RunContext sidecar write.
- `internal/agent/proxy_qualification_credit_snapshot_enabled_test.go`: raw activity nested in the existing authenticated sender-counter drain.
- `third_party/yamux/session_send_loop_qualification.go`: open/close the raw temporal envelope around the existing DATA physical write, sharing its end timestamp.
- `third_party/yamux/qualification_aggregate_send_durations.go`: accept the already-captured end timestamp without changing the default caller.

New tagged/ordinary files:

- `internal/agent/qualification_raw_write_ordinary.go`: ordinary no-op hooks.
- `internal/agent/qualification_raw_write_qualification.go`: fixed owner, transport/body wrappers with exact raw tuple forwarding, classification, conservation, lifecycle, terminal sidecar, and destructive drain.
- `internal/agent/qualification_raw_write_qualification_test.go`: focused ledger, boundary, retirement, and real TLS 101/Yamux path controls.
- `third_party/yamux/qualification_raw_write_activity.go`: tagged schema and Session observer bridge.

No server control, public handler, runtime policy, flow-control constant, timeout, socket option, runner, validator, or production configuration file is included.

Validation-only source:

- `validation-source/BASE-INVENTORY.json`: full immutable audited-base file inventory.
- `validation-source/EXPECTED-AGENT-TESTS.json`: exact nine root and known subtest event set.
- `validation-source/EXPECTED-YAMUX-TESTS.json`: exact nineteen affected sender roots.
- `validation-source/run-focused.py`: fresh-copy, offline, bounded-process normal/race driver for main-owned execution after review.
