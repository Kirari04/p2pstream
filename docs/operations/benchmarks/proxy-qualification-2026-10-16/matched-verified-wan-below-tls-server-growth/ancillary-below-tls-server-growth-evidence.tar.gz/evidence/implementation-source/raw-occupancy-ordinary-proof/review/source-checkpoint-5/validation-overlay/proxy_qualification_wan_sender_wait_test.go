//go:build linux

package agent

import (
	"crypto/subtle"
	"errors"
	"net/http"
	"os"
	"strings"
)

const (
	externalQualificationWANSenderWaitEnv          = "P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT"
	externalQualificationWANSenderWaitBearerEnv    = "P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_BEARER"
	externalQualificationWANSenderWaitSequencesEnv = "P2PSTREAM_QUALIFICATION_WAN_SENDER_WAIT_SEQUENCES"
	externalQualificationWANSenderWaitSequences    = "9,11,14,15"
)

type externalQualificationWANSenderWaitOwner struct {
	bearer    string
	sequences map[string]struct{}
}

func externalQualificationWANSenderWaitOwnerFromEnv() (*externalQualificationWANSenderWaitOwner, error) {
	return newExternalQualificationWANSenderWaitOwner(
		os.Getenv(externalQualificationWANSenderWaitEnv),
		os.Getenv(externalQualificationWANSenderWaitBearerEnv),
		os.Getenv(externalQualificationWANSenderWaitSequencesEnv),
	)
}

func newExternalQualificationWANSenderWaitOwner(enabled, bearer, sequences string) (*externalQualificationWANSenderWaitOwner, error) {
	if enabled == "" && bearer == "" && sequences == "" {
		return nil, nil
	}
	if enabled != "1" {
		return nil, errors.New("WAN sender-wait diagnostic requires explicit enablement")
	}
	if !externalQualificationWANSenderWaitBearerValid(bearer) {
		return nil, errors.New("WAN sender-wait diagnostic bearer must be 32 lowercase-hex bytes")
	}
	if sequences != externalQualificationWANSenderWaitSequences {
		return nil, errors.New("WAN sender-wait diagnostic requires the fixed sustained sequence set")
	}
	configured := make(map[string]struct{}, 4)
	for _, sequence := range strings.Split(sequences, ",") {
		configured[sequence] = struct{}{}
	}
	return &externalQualificationWANSenderWaitOwner{bearer: bearer, sequences: configured}, nil
}

func externalQualificationWANSenderWaitBearerValid(bearer string) bool {
	if len(bearer) != 64 {
		return false
	}
	for _, value := range []byte(bearer) {
		if (value < '0' || value > '9') && (value < 'a' || value > 'f') {
			return false
		}
	}
	return true
}

func (owner *externalQualificationWANSenderWaitOwner) authorized(r *http.Request) bool {
	if owner == nil || r == nil {
		return false
	}
	authorization := r.Header.Get("Authorization")
	if !strings.HasPrefix(authorization, "Bearer ") {
		return false
	}
	provided := strings.TrimPrefix(authorization, "Bearer ")
	return len(provided) == len(owner.bearer) && subtle.ConstantTimeCompare([]byte(provided), []byte(owner.bearer)) == 1
}

func (owner *externalQualificationWANSenderWaitOwner) serveDrainHTTP(w http.ResponseWriter, r *http.Request, sessions *externalQualificationSessionRegistry) {
	if !owner.authorized(r) {
		http.Error(w, "WAN sender-wait authorization failed", http.StatusUnauthorized)
		return
	}
	if r.Method != http.MethodGet || r.URL.Query().Get("wan_sender_wait_snapshot") != "drain" {
		http.Error(w, "invalid WAN sender-wait action", http.StatusBadRequest)
		return
	}
	sequence := r.URL.Query().Get("sequence")
	if _, configured := owner.sequences[sequence]; !configured {
		http.Error(w, "WAN sender-wait sequence is unavailable", http.StatusConflict)
		return
	}
	writeExternalQualificationGrowthSnapshot(w, sessions)
}
