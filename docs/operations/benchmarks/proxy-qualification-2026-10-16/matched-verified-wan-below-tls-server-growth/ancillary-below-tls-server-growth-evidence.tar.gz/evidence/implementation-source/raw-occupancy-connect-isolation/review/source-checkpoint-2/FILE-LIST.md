# Checkpoint files

- `overlay/`: complete raw checkpoint-5 overlay with the narrow `connectAndServe` split.
- `BODY-PROVENANCE.json`: immutable input and extracted-body hashes.
- `RAW-CP5-TO-ISOLATION.diff`: complete raw checkpoint-5 overlay to this overlay.
- `compare_agent_ordinary_split.py`: strict comparator with explicit source-file binding for escape records.
- `COMPARATOR-CP7-TO-SPLIT.diff`: exact comparator checkpoint-7 delta.
- `verify-isolation.py`: bounded source-only derivation verifier.
- `IMPLEMENTATION-INTENT.md`: scope and non-claims.
- `PROOF-PLAN.md`: proposed no-baseline-rebuild focused validation.
- `run-focused-proof.py`: reviewed-helper candidate-only focused/proof driver source; not executed.
