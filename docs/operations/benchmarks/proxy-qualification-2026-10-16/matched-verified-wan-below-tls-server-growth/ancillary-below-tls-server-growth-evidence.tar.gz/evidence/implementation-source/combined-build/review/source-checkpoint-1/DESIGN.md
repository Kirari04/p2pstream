# Audited combined below-TLS diagnostic build

Status: source only; no build, test, endpoint, or traffic has been run by this checkpoint.

The driver reconstructs the immutable audited sender-diagnostic corpus, applies exactly the eleven-file raw observer isolation overlay and disjoint four-file server-growth overlay, and compiles only the tagged agent and server test binaries. It reuses the accepted raw normal/race, server normal/race, combined static/closure contract, and ordinary generated-reference equivalence evidence; it does not rerun those unchanged suites.

The pinned Go 1.26.6 tool runs offline with explicit module/cache/work settings, CPUs 0-15, owned ext4 temporary/cache roots, and the reviewed bounded process-group helper. All seven commands must exit zero and join naturally. The final corpus, module files, inputs, toolchain, and helper are checked before and after. The flat build receipt is atomically published last only after `FINAL.json` and the records ledger close; it binds both binaries, the exact combined source inventory, component evidence, and the supplemental proof receipt while retaining no endpoint or WAN claim.
