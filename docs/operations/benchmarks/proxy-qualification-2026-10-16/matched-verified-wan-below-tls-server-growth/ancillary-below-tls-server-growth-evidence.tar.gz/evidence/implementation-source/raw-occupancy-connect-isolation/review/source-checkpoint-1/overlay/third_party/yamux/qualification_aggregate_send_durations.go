//go:build p2pstream_qualification

package yamux

import "time"

// claimQualificationQueuedData transfers DATA ownership to the send goroutine.
// A channel receiver may win the scheduling race before the caller publishes
// acceptance. That operation remains owned in a fixed pre-publication counter,
// and the cumulative race count describes why physical work may overlap the
// caller's enqueue-select interval. Queue and lock semantics remain unchanged.
func (c *qualificationAggregateSendCounters) claimQualificationQueuedData(payload uint64) bool {
	if c.activeQueuedFrames != 0 && c.activeQueuedPayloadBytes >= payload {
		c.activeQueuedFrames--
		c.activeQueuedPayloadBytes -= payload
		return true
	}
	if c.activeEnqueueFrames != 0 && c.activeEnqueuePayloadBytes >= payload {
		c.activeEnqueueFrames--
		c.activeEnqueuePayloadBytes -= payload
		qualificationIncrement(&c.claimedBeforePublicationFrames, &c.overflow)
		qualificationAddUint64(&c.claimedBeforePublicationBytes, payload, &c.overflow)
		qualificationIncrement(&c.enqueuePublicationRaces, &c.overflow)
		return true
	}
	c.ambiguous = true
	return false
}

func (s *Session) finishQualificationGatherError(streamID uint32, payloadBytes int) {
	if s == nil || s.aggregate == nil || payloadBytes < 0 {
		return
	}
	a := s.aggregate
	a.mu.Lock()
	defer a.mu.Unlock()
	c := &a.qualification
	c.observeStream(streamID)
	payload := uint64(payloadBytes)
	if !c.claimQualificationQueuedData(payload) {
		return
	}
	qualificationIncrement(&c.dataCompletedFrames, &c.overflow)
	qualificationAddUint64(&c.dataCompletedPayloadBytes, payload, &c.overflow)
	qualificationIncrement(&c.dataGatherErrorFrames, &c.overflow)
	qualificationAddUint64(&c.dataGatherErrorPayloadBytes, payload, &c.overflow)
}

func (s *Session) beginQualificationPhysicalDataWrite(streamID uint32, payloadBytes, wireBytes int) qualificationDataSendWait {
	if s == nil || s.aggregate == nil || payloadBytes < 0 || wireBytes < 0 ||
		uint64(wireBytes) != uint64(payloadBytes)+uint64(headerSize) {
		return qualificationDataSendWait{}
	}
	a := s.aggregate
	a.mu.Lock()
	defer a.mu.Unlock()
	c := &a.qualification
	c.observeStream(streamID)
	payload := uint64(payloadBytes)
	if !c.claimQualificationQueuedData(payload) {
		return qualificationDataSendWait{}
	}
	qualificationIncrement(&c.activePhysicalFrames, &c.overflow)
	qualificationAddUint64(&c.activePhysicalPayloadBytes, payload, &c.overflow)
	qualificationIncrement(&c.physicalAttemptFrames, &c.overflow)
	qualificationAddUint64(&c.physicalAttemptPayloadBytes, payload, &c.overflow)
	qualificationAddUint64(&c.physicalAttemptWireBytes, uint64(wireBytes), &c.overflow)
	return qualificationDataSendWait{
		started: time.Now(), streamID: streamID, payloadBytes: payload, wireBytes: uint64(wireBytes), valid: true,
	}
}

func (s *Session) finishQualificationPhysicalDataWrite(wait qualificationDataSendWait, outcome qualificationPhysicalWriteOutcome, wireBytes, written int) {
	s.finishQualificationPhysicalDataWriteAt(wait, outcome, wireBytes, written, time.Now())
}

func (s *Session) finishQualificationPhysicalDataWriteAt(wait qualificationDataSendWait, outcome qualificationPhysicalWriteOutcome, wireBytes, written int, finished time.Time) {
	if !wait.valid || s == nil || s.aggregate == nil {
		return
	}
	a := s.aggregate
	a.mu.Lock()
	defer a.mu.Unlock()
	c := &a.qualification
	c.observeStream(wait.streamID)
	if outcome >= qualificationPhysicalWriteOutcomeCount || wireBytes < 0 || uint64(wireBytes) != wait.wireBytes ||
		written < 0 || written > wireBytes ||
		(outcome == qualificationPhysicalWriteSuccess && written != wireBytes) ||
		(outcome == qualificationPhysicalWriteShort && written == wireBytes) ||
		c.activePhysicalFrames == 0 || c.activePhysicalPayloadBytes < wait.payloadBytes {
		c.ambiguous = true
		return
	}
	c.activePhysicalFrames--
	c.activePhysicalPayloadBytes -= wait.payloadBytes
	qualificationIncrement(&c.dataCompletedFrames, &c.overflow)
	qualificationAddUint64(&c.dataCompletedPayloadBytes, wait.payloadBytes, &c.overflow)
	qualificationAddUint64(&c.physicalWrittenWireBytes, uint64(written), &c.overflow)
	duration := finished.Sub(wait.started)
	c.physicalWriteTotal.add(duration, &c.overflow)
	c.physicalWriteByOutcome[outcome].add(duration, &c.overflow)
	switch outcome {
	case qualificationPhysicalWriteSuccess:
		qualificationIncrement(&c.physicalSuccessFrames, &c.overflow)
		qualificationAddUint64(&c.physicalSuccessPayloadBytes, wait.payloadBytes, &c.overflow)
		qualificationAddUint64(&c.physicalSuccessWireBytes, uint64(wireBytes), &c.overflow)
	case qualificationPhysicalWriteError:
		qualificationIncrement(&c.physicalErrorFrames, &c.overflow)
		qualificationAddUint64(&c.physicalErrorPayloadBytes, wait.payloadBytes, &c.overflow)
		qualificationAddUint64(&c.physicalErrorAttemptWireBytes, uint64(wireBytes), &c.overflow)
		qualificationAddUint64(&c.physicalErrorWrittenWireBytes, uint64(written), &c.overflow)
	case qualificationPhysicalWriteShort:
		qualificationIncrement(&c.physicalShortFrames, &c.overflow)
		qualificationAddUint64(&c.physicalShortPayloadBytes, wait.payloadBytes, &c.overflow)
		qualificationAddUint64(&c.physicalShortAttemptWireBytes, uint64(wireBytes), &c.overflow)
		qualificationAddUint64(&c.physicalShortWrittenWireBytes, uint64(written), &c.overflow)
	}
}

// finishQualificationSendLoop terminally owns queued DATA after the physical
// send goroutine exits. Caller timeout never invokes this path prematurely.
func (s *Session) finishQualificationSendLoop() {
	if s == nil || s.aggregate == nil {
		return
	}
	a := s.aggregate
	a.mu.Lock()
	defer a.mu.Unlock()
	c := &a.qualification
	c.sendLoopTerminated = true
	if c.activePhysicalFrames != 0 || c.activePhysicalPayloadBytes != 0 {
		c.ambiguous = true
	}
	qualificationAddUint64(&c.dataAbandonedFrames, c.activeQueuedFrames, &c.overflow)
	qualificationAddUint64(&c.dataAbandonedPayloadBytes, c.activeQueuedPayloadBytes, &c.overflow)
	qualificationAddUint64(&c.dataCompletedFrames, c.activeQueuedFrames, &c.overflow)
	qualificationAddUint64(&c.dataCompletedPayloadBytes, c.activeQueuedPayloadBytes, &c.overflow)
	c.activeQueuedFrames = 0
	c.activeQueuedPayloadBytes = 0
}
