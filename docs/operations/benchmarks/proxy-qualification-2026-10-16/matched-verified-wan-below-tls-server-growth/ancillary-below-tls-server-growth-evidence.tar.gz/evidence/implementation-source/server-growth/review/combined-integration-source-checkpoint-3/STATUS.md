Source-only combined-integration checkpoint 3 candidate. No combined behavioral contract, build, endpoint, or WAN execution has occurred.

Checkpoint 1 and checkpoint 2 are preserved unchanged. Checkpoint 3 adds the final bounded artifact corrections: the runner rejects non-regular, empty, or greater-than-4-MiB terminal/validation artifacts before hashing, and the actual arm-function contract adds distinct oversized-terminal and oversized-validation cases. All checkpoint 2 closure, tuple, and interpretation corrections remain.

The final external receipt must bind the fresh owned copied integration tree and every imported helper path/hash before and after execution. Publication remains blocked on review of this checkpoint and on pending external receipts in INPUTS.json.
