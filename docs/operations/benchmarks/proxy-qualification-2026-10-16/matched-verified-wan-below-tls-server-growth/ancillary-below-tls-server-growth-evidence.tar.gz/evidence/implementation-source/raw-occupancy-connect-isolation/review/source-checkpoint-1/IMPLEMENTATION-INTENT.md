# Narrow ordinary/tagged `connectAndServe` isolation

Status: source only. No build, Go test, endpoint, or traffic has been run from this checkpoint.

The raw temporal-occupancy runtime is byte-identical to accepted raw checkpoint 5 except for one mechanical source selection split. The shared `internal/agent/agent.go` no longer declares `connectAndServe`; its sole newly unused `strconv` import is removed. `connect_and_serve_ordinary.go` declares the exact immutable audited-base function under `!p2pstream_qualification`. `connect_and_serve_qualification.go` declares the exact accepted checkpoint-5 function under `p2pstream_qualification`. The three qualification calls therefore do not occur in the ordinary function body. No observer implementation, counter, lifecycle, timeout, socket, window, request, or policy semantics change in the tagged build.

`verify-isolation.py` binds the complete checkpoint-5 manifest, the exact base and checkpoint-5 `agent.go` hashes, exact overlay file set, byte identity of every other overlay file, the deterministic shared-file derivation, and exact extracted function bodies. `BODY-PROVENANCE.json` records the two body hashes and sizes.

The prior strict ordinary comparison remains a real failure and is not reclassified. Its code, compiler, compiler-data, and escape gates failed because the no-op calls changed the ordinary compiler result. This split removes those calls from the ordinary source selected by the build tag; it does not weaken any comparator normalization or acceptance gate.
