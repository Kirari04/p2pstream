#!/usr/bin/env python3
"""One owned focused verification of the frozen raw-write observer."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import time
import traceback

sys.dont_write_bytecode = True

REPO = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
COMPONENT = REPO / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy"
BASE = REPO / "tmp/continuation-20261016/wan-sender-wait-build-source/runs/audited-build-attempt-1/source"
GO = Path("/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go")
GO_SHA = "29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45"
GO_VERSION = "go version go1.26.6 linux/amd64"
TASKSET = Path("/usr/bin/taskset")
TASKSET_SHA = "42acb8e233943873f3bf9eeb1e15bd3281498b5603a5b10d0f9bc37067a12d57"
OWNED_HELPER = REPO / "tmp/continuation-20261016/wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
OWNED_HELPER_SHA = "8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
MAX_JSON_STREAM_BYTES = 64 << 20
MAX_JSON_LINE_BYTES = 1 << 20


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def write_text(path: Path, value: str) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w") as stream:
        stream.write(value)


def inventory(root: Path) -> dict[str, str]:
    if not root.is_dir() or root.is_symlink():
        raise ValueError(f"unsafe inventory root: {root}")
    result = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"symlink in source corpus: {path}")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha(path)
    return result


def safe_ledger_name(name: str) -> str:
    pure = PurePosixPath(name)
    if not name or name != pure.as_posix() or name.startswith("/") or "\\" in name or any(part in ("", ".", "..") for part in pure.parts):
        raise ValueError(f"unsafe checkpoint ledger path: {name!r}")
    return pure.as_posix()


def verify_component(component: Path, expected_manifest_sha: str) -> dict[str, str]:
    manifest = component / "SHA256SUMS.txt"
    if not manifest.is_file() or manifest.is_symlink() or sha(manifest) != expected_manifest_sha:
        raise ValueError("frozen checkpoint manifest changed")
    entries = {}
    for line in manifest.read_text().splitlines():
        parts = line.split("  ", 1)
        if len(parts) != 2 or re.fullmatch(r"[0-9a-f]{64}", parts[0]) is None:
            raise ValueError("malformed checkpoint ledger line")
        name = safe_ledger_name(parts[1])
        if name in entries:
            raise ValueError(f"duplicate checkpoint ledger path: {name}")
        entries[name] = parts[0]
    actual = {name: digest for name, digest in inventory(component).items() if name != "SHA256SUMS.txt"}
    if entries != actual:
        raise ValueError("checkpoint ledger does not exactly cover frozen files")
    return inventory(component)


def load_owned_helper():
    if not OWNED_HELPER.is_file() or OWNED_HELPER.is_symlink() or sha(OWNED_HELPER) != OWNED_HELPER_SHA:
        raise ValueError("reviewed owned-process helper changed")
    spec = importlib.util.spec_from_file_location("reviewed_owned_process", OWNED_HELPER)
    if spec is None or spec.loader is None:
        raise ValueError("cannot load reviewed owned-process helper")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def expected_contract(path: Path) -> tuple[str, list[str], list[str], str]:
    value = json.loads(path.read_text())
    package = value.get("package")
    roots = value.get("roots")
    tests = value.get("all_tests")
    if not isinstance(package, str) or not package or not isinstance(roots, list) or not roots or not isinstance(tests, list) or not tests:
        raise ValueError(f"invalid expected Go test contract: {path}")
    if len(roots) != len(set(roots)) or len(tests) != len(set(tests)):
        raise ValueError(f"duplicate expected Go test names: {path}")
    if any(not isinstance(name, str) or re.fullmatch(r"Test[A-Za-z0-9_]+", name) is None for name in roots):
        raise ValueError(f"invalid expected root name: {path}")
    if any(not isinstance(name, str) or name.split("/", 1)[0] not in roots for name in tests):
        raise ValueError(f"invalid expected subtest name: {path}")
    if set(roots) != {name for name in tests if "/" not in name}:
        raise ValueError(f"root/subtest contract mismatch: {path}")
    pattern = "^(" + "|".join(re.escape(root) for root in roots) + ")$"
    return package, roots, tests, pattern


def audit_go_json(stream_path: Path, expected_path: Path, report_path: Path) -> bool:
    package, roots, expected_tests, pattern = expected_contract(expected_path)
    expected = set(expected_tests)
    actions = {name: [] for name in expected_tests}
    unexpected = []
    rejected = []
    audit_overflow = False
    package_passes = 0
    total = 0
    with stream_path.open("rb") as stream:
        for number, raw_line in enumerate(stream, 1):
            total += len(raw_line)
            if total > MAX_JSON_STREAM_BYTES or len(raw_line) > MAX_JSON_LINE_BYTES or not raw_line.endswith(b"\n"):
                raise ValueError(f"bounded Go JSON stream violation at line {number}")
            try:
                event = json.loads(raw_line)
            except Exception as error:
                raise ValueError(f"invalid Go JSON line {number}: {error}") from error
            if event.get("Package") != package:
                if len(rejected) < 128:
                    rejected.append({"line": number, "reason": "unexpected_package", "package": event.get("Package"), "action": event.get("Action"), "test": event.get("Test")})
                else:
                    audit_overflow = True
                continue
            action = event.get("Action")
            test = event.get("Test")
            if test is None:
                if action == "pass":
                    package_passes += 1
                elif action in ("fail", "skip"):
                    if len(rejected) < 128:
                        rejected.append({"line": number, "reason": "package_terminal", "action": action})
                    else:
                        audit_overflow = True
                continue
            if test not in expected:
                if len(unexpected) < 128:
                    unexpected.append({"line": number, "test": test, "action": action})
                else:
                    audit_overflow = True
                continue
            if action in ("run", "pass", "fail", "skip"):
                actions[test].append(action)
                if action in ("fail", "skip"):
                    if len(rejected) < 128:
                        rejected.append({"line": number, "reason": "test_terminal", "test": test, "action": action})
                    else:
                        audit_overflow = True
    accepted = package_passes == 1 and not unexpected and not rejected and not audit_overflow and all(actions[name] == ["run", "pass"] for name in expected_tests)
    write_json(report_path, {
        "schema_version": 1, "accepted": accepted, "package": package,
        "pattern": pattern, "roots": roots, "expected_tests": expected_tests,
        "actions": actions, "package_passes": package_passes,
        "unexpected": unexpected, "rejected": rejected, "audit_overflow": audit_overflow, "stream_bytes": total,
    })
    return accepted


def main() -> int:
    if len(sys.argv) != 3:
        raise ValueError("usage: run-focused.py FRESH_OUTPUT EXPECTED_CHECKPOINT_SHA256")
    output = Path(sys.argv[1]).resolve()
    expected_checkpoint_sha = sys.argv[2]
    component = Path(__file__).resolve().parent.parent
    runs_path = COMPONENT / "runs"
    allowed_parent = runs_path.resolve()
    if output.exists() or output.parent != allowed_parent or not allowed_parent.is_dir() or runs_path.is_symlink():
        raise ValueError("focused output must be a fresh direct child of the owned runs directory")
    output.mkdir(mode=0o700)
    output_stat = output.stat()
    if output_stat.st_uid != os.geteuid() or output_stat.st_mode & 0o022:
        raise ValueError("focused output must be euid-owned and not group/world writable")
    records = output / "records"
    records.mkdir(mode=0o700)
    write_text(records / "start-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))

    accepted = False
    issue = None
    component_pre = None
    source_pre = None
    expected_base = None
    try:
        component_pre = verify_component(component, expected_checkpoint_sha)
        write_json(records / "checkpoint-pre.json", {"manifest_sha256": expected_checkpoint_sha, "files": component_pre})
        if sha(GO) != GO_SHA or sha(TASKSET) != TASKSET_SHA:
            raise ValueError("pinned Go or taskset changed")
        owned = load_owned_helper()
        write_json(records / "external-inputs.json", {
            "schema_version": 1,
            "go": {"path": str(GO), "sha256": GO_SHA, "version": GO_VERSION},
            "taskset": {"path": str(TASKSET), "sha256": TASKSET_SHA, "cpus": "0-15"},
            "owned_process_helper": {"path": str(OWNED_HELPER), "sha256": OWNED_HELPER_SHA},
            "base_source": {"path": str(BASE), "inventory_sha256": sha(component / "validation-source/BASE-INVENTORY.json")},
        })
        expected_base = json.loads((component / "validation-source/BASE-INVENTORY.json").read_text()).get("files")
        if not isinstance(expected_base, dict) or inventory(BASE) != expected_base:
            raise ValueError("immutable audited base source changed")

        source = output / "source"
        shutil.copytree(BASE, source, symlinks=False, copy_function=shutil.copy2)
        if inventory(source) != expected_base:
            raise ValueError("copied base source differs from immutable inventory")
        for relative, digest in inventory(component / "overlay").items():
            source_path = component / "overlay" / relative
            target = source / relative
            target.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
            shutil.copy2(source_path, target)
            if sha(target) != digest:
                raise ValueError(f"overlay copy changed: {relative}")
        source_pre = inventory(source)
        write_json(records / "source-pre.json", {"schema_version": 1, "files": source_pre})

        common_env = {
            "HOME": os.environ["HOME"], "PATH": "/usr/bin:/bin", "GOENV": "off",
            "GOTOOLCHAIN": "local", "GOWORK": "off", "GOFLAGS": "", "CGO_ENABLED": "1",
            "GOMAXPROCS": "16", "GOPATH": str(output / "gopath"),
            "GOMODCACHE": "/home/user/go/pkg/mod", "GOPROXY": "off", "GOSUMDB": "off",
            "LC_ALL": "C", "TZ": "Europe/Zurich",
        }
        (output / "gopath").mkdir(mode=0o700)
        for mode in ("normal", "race"):
            (output / f"tmp-{mode}").mkdir(mode=0o700)
            (output / f"gocache-{mode}").mkdir(mode=0o700)
        write_json(records / "go-environment.json", common_env)
        normal_env = dict(common_env, TMPDIR=str(output / "tmp-normal"), GOTMPDIR=str(output / "tmp-normal"), GOCACHE=str(output / "gocache-normal"))
        for name, cwd, want_mod in (
            ("go-env-root", source, source / "go.mod"),
            ("go-env-yamux", source / "third_party/yamux", source / "third_party/yamux/go.mod"),
        ):
            status = owned.run(records, name, [str(GO), "env", "-json", "GOMOD", "GOWORK", "GOENV", "GOTOOLCHAIN", "GOMODCACHE", "GOPATH", "GOPROXY", "GOSUMDB"], cwd, normal_env, 30)
            if status != 0:
                raise ValueError(f"pinned Go environment query failed: {name}")
            effective = json.loads((records / f"{name}.stdout.log").read_text())
            expected_env = {
                "GOMOD": str(want_mod), "GOWORK": "off", "GOENV": "", "GOTOOLCHAIN": "local",
                "GOMODCACHE": "/home/user/go/pkg/mod", "GOPATH": str(output / "gopath"),
                "GOPROXY": "off", "GOSUMDB": "off",
            }
            if effective != expected_env:
                raise ValueError(f"effective pinned Go environment changed: {name}")
        status = owned.run(records, "go-version", [str(GO), "version"], source, normal_env, 30)
        if status != 0 or (records / "go-version.stdout.log").read_text().strip() != GO_VERSION:
            raise ValueError("pinned Go version changed")

        agent_contract = component / "validation-source/EXPECTED-AGENT-TESTS.json"
        yamux_contract = component / "validation-source/EXPECTED-YAMUX-TESTS.json"
        agent_package, _, _, agent_pattern = expected_contract(agent_contract)
        yamux_package, _, _, yamux_pattern = expected_contract(yamux_contract)
        jobs = (
            ("agent-normal", source, "./internal/agent", agent_pattern, agent_contract, "normal"),
            ("yamux-normal", source / "third_party/yamux", ".", yamux_pattern, yamux_contract, "normal"),
            ("agent-race", source, "./internal/agent", agent_pattern, agent_contract, "race"),
            ("yamux-race", source / "third_party/yamux", ".", yamux_pattern, yamux_contract, "race"),
        )
        for name, cwd, package_arg, pattern, contract, mode in jobs:
            env = dict(common_env, TMPDIR=str(output / f"tmp-{mode}"), GOTMPDIR=str(output / f"tmp-{mode}"), GOCACHE=str(output / f"gocache-{mode}"))
            command = [str(TASKSET), "-c", "0-15", str(GO), "test", "-json", "-count=1", "-timeout=300s", "-tags=p2pstream_qualification"]
            if mode == "race":
                command.append("-race")
            command.extend([package_arg, "-run", pattern])
            status = owned.run(records, name, command, cwd, env, 360)
            if status != 0:
                raise ValueError(f"focused Go test failed: {name}")
            if not audit_go_json(records / f"{name}.stdout.log", contract, records / f"{name}.audit.json"):
                raise ValueError(f"exact Go JSON audit failed: {name}")
        if agent_package != "p2pstream/internal/agent" or yamux_package != "github.com/hashicorp/yamux":
            raise ValueError("reviewed package identities changed")
        accepted = True
    except BaseException as error:
        issue = f"{type(error).__name__}: {error}"
        traceback.print_exc()
    finally:
        checks = {}
        post_errors = {}

        def post_check(name, operation):
            try:
                checks[name] = bool(operation())
            except BaseException as post_error:
                checks[name] = False
                post_errors[name] = f"{type(post_error).__name__}: {post_error}"

        def materialized_source_check():
            if source_pre is None:
                return False
            source_post = inventory(output / "source")
            if not (records / "source-post.json").exists():
                write_json(records / "source-post.json", {"schema_version": 1, "files": source_post})
            return source_post == source_pre

        def checkpoint_check():
            post_component = verify_component(component, expected_checkpoint_sha)
            if not (records / "checkpoint-post.json").exists():
                write_json(records / "checkpoint-post.json", {"manifest_sha256": expected_checkpoint_sha, "files": post_component})
            return component_pre is not None and post_component == component_pre

        def base_check():
            current_expected_base = json.loads((component / "validation-source/BASE-INVENTORY.json").read_text()).get("files")
            return isinstance(current_expected_base, dict) and current_expected_base == expected_base and inventory(BASE) == current_expected_base

        post_check("materialized_source_unchanged", materialized_source_check)
        post_check("checkpoint_unchanged", checkpoint_check)
        post_check("base_source_unchanged", base_check)
        post_check("go_tool_unchanged", lambda: sha(GO) == GO_SHA)
        post_check("taskset_unchanged", lambda: sha(TASKSET) == TASKSET_SHA)
        post_check("owned_process_helper_unchanged", lambda: sha(OWNED_HELPER) == OWNED_HELPER_SHA)
        accepted = accepted and all(value is True for value in checks.values())
        write_json(records / "RESULT.json", {"schema_version": 1, "accepted": accepted, "issue": issue, "post_checks": checks, "post_errors": post_errors, "endpoint_or_traffic": False, "ordinary_proof_run": False})
        write_text(records / "final.status", "0\n" if accepted else "1\n")
        write_text(records / "end-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))
        with (records / "SHA256SUMS.txt").open("x", encoding="utf-8") as stream:
            for path in sorted(records.rglob("*")):
                if path.is_file() and path.name != "SHA256SUMS.txt":
                    stream.write(f"{sha(path)}  ./{path.relative_to(records).as_posix()}\n")
        write_text(output / "FINAL", "complete\n")
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
