# Source checkpoint status

This directory is source-only. No validator, contract, Go test, build, endpoint,
or traffic command has run from this checkpoint.

The derivative preserves the exact sender validator base, binds raw occupancy
checkpoint 2, adds one strict raw activity module and final closure mode, and
provides an unexecuted focused contract driver. Integration into the combined
runner, arm validator, and final gate remains separately owned and must bind
this checkpoint by hash.
