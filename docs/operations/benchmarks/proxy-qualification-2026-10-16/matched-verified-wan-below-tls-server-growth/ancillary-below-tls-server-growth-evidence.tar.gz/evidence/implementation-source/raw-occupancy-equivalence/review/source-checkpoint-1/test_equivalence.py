#!/usr/bin/env python3
"""Focused positive and negative contracts for exact generated-reference equivalence."""
from __future__ import annotations
import argparse,copy,importlib.util,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
def load(path):
 spec=importlib.util.spec_from_file_location('equivalence',path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def replace_section(text,name,old,new):
 start=text.index(name+' ');end=text.find('\n',start);end=text.find('\n',end+1)
 # Extend across indented section lines.
 while end+1<len(text) and (text[end+1]=='\t' or text[end+1]=='\n'):
  nxt=text.find('\n',end+1)
  if nxt<0:break
  end=nxt
 block=text[start:end+1]
 if block.count(old)!=1:raise ValueError(f'mutation cardinality {name} {old!r}')
 return text[:start]+block.replace(old,new,1)+text[end+1:]
def main():
 p=argparse.ArgumentParser();p.add_argument('--analyzer',type=Path,required=True);p.add_argument('--input-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 if a.output.exists():raise ValueError('fresh output')
 m=load(a.analyzer);r=a.input_root
 basm=(r/'baseline-asm.stderr.log').read_text();casm=(r/'candidate-asm.stderr.log').read_text();bcan=json.loads((r/'proof/baseline-canonical.json').read_text());ccan=json.loads((r/'proof/candidate-canonical.json').read_text());strict=json.loads((r/'proof/report.json').read_text())
 cases={}
 def run(name,bb=basm,ca=casm,bc=bcan,cc=ccan,want=True):
  try:m.analyze(bb,ca,bc,cc,strict);accepted=True;error=None
  except Exception as exc:accepted=False;error=f'{type(exc).__name__}: {exc}'
  cases[name]={'expected_accept':want,'accepted':accepted,'error':error,'passed':accepted is want}
 run('positive')
 run('changed_target_byte',ca=replace_section(casm,'p2pstream/internal/agent..stmp_31','0x0000 00 00 20','0x0000 01 00 20'),want=False)
 run('changed_target_type',ca=casm.replace('p2pstream/internal/agent..stmp_31 SRODATA static size=20','p2pstream/internal/agent..stmp_31 SDATA static size=20',1),want=False)
 run('changed_target_size',ca=casm.replace('p2pstream/internal/agent..stmp_31 SRODATA static size=20','p2pstream/internal/agent..stmp_31 SRODATA static size=21',1),want=False)
 run('changed_target_relocation',ca=replace_section(casm,'p2pstream/internal/agent..typeAssert.14','type:io.Reader+0','type:io.Writer+0'),want=False)
 alias=copy.deepcopy(ccan)
 for row in alias['code']['p2pstream/internal/agent.connectAndServe']:
  if '..stmp_32' in row['asm']:row['asm']=row['asm'].replace('..stmp_32','..stmp_31');break
 run('aliased_generated_target',cc=alias,want=False)
 site=copy.deepcopy(ccan)
 for row in site['code']['p2pstream/internal/agent.connectAndServe']:
  if '..stmp_31' in row['asm']:row['bytes']='90'+row['bytes'][2:];break
 run('changed_instruction_site',cc=site,want=False)
 unmapped=copy.deepcopy(ccan)
 for i,row in enumerate(unmapped['code']['p2pstream/internal/agent.connectAndServe']):
  if row==bcan['code']['p2pstream/internal/agent.connectAndServe'][i]:row['asm']=row['asm']+' UNMAPPED';break
 run('new_unmapped_difference',cc=unmapped,want=False)
 foreign=casm+'\np2pstream/internal/agent.foreignOwner STEXT size=1 args=0x0 locals=0x0 funcid=0x0 align=0x0\n\t0x0000 00000 (foreign.go:1)\tLEAQ\t0(IP), AX\t[3:7]R_PCREL:p2pstream/internal/agent..stmp_31<1>\n'
 run('foreign_incoming_owner',ca=foreign,want=False)
 accepted=all(v['passed'] for v in cases.values()) and set(cases)=={'positive','changed_target_byte','changed_target_type','changed_target_size','changed_target_relocation','aliased_generated_target','changed_instruction_site','new_unmapped_difference','foreign_incoming_owner'}
 a.output.mkdir();fd=os.open(a.output/'result.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump({'schema_version':1,'accepted':accepted,'cases':cases},f,indent=2,sort_keys=True);f.write('\n')
 return 0 if accepted else 1
if __name__=='__main__':raise SystemExit(main())
