#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,os,re,stat
from pathlib import Path
MAX=128<<20
RELOC=re.compile(r'(?P<prefix>R_PCREL:)(?P<name>p2pstream/internal/agent\.\.(?:stmp_\d+|typeAssert\.\d+))(?P<suffix>(?:<[^>]+>)?)')
HEADER=re.compile(r'^(?P<name>p2pstream/internal/agent\.\.(?:stmp_\d+|typeAssert\.\d+)) (?P<meta>(?:SRODATA|SDATA).*)$')
def read(p):
 st=p.lstat()
 if not stat.S_ISREG(st.st_mode) or st.st_size>MAX:raise ValueError(f'input bounds {p}')
 b=p.read_bytes();return b.decode(),hashlib.sha256(b).hexdigest()
def sections(text):
 lines=text.splitlines(); out={}
 for i,line in enumerate(lines):
  m=HEADER.match(line)
  if not m:continue
  name=m.group('name')
  if name in out:raise ValueError(f'duplicate section {name}')
  body=[];j=i+1
  while j<len(lines) and (not lines[j] or lines[j].startswith('\t')):body.append(lines[j]);j+=1
  out[name]={'meta':m.group('meta'),'body':body}
 return out
def occurrences(text,name):
 pat=re.compile(r'(?<![A-Za-z0-9_.])'+re.escape(name)+r'(?![A-Za-z0-9_.])')
 return [{'line':i,'text':line} for i,line in enumerate(text.splitlines(),1) if pat.search(line)]
def main():
 p=argparse.ArgumentParser()
 for side in ('baseline','candidate'):
  p.add_argument(f'--{side}-asm',type=Path,required=True);p.add_argument(f'--{side}-canonical',type=Path,required=True)
 p.add_argument('--proof-report',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 if a.output.exists():raise ValueError('fresh output')
 values={};hashes={}
 for side in ('baseline','candidate'):
  asm,hashes[f'{side}_asm']=read(getattr(a,f'{side}_asm'));can,hashes[f'{side}_canonical']=read(getattr(a,f'{side}_canonical'))
  values[side]={'asm':asm,'canonical':json.loads(can),'sections':sections(asm)}
 report_text,hashes['proof_report']=read(a.proof_report);report=json.loads(report_text)
 if report.get('gates')!={'code':False,'compiler':True,'compiler_data':True,'escape':True,'layout':True,'nm':True}:raise ValueError('proof gates')
 bc=values['baseline']['canonical']['code'];cc=values['candidate']['canonical']['code'];pairs=[];mapping={};reverse={};other=[]
 if set(bc)!=set(cc):raise ValueError('code symbol set')
 for symbol in sorted(bc):
  if len(bc[symbol])!=len(cc[symbol]):raise ValueError('instruction cardinality')
  for index,(b,c) in enumerate(zip(bc[symbol],cc[symbol])):
   if b==c:continue
   if b.get('offset')!=c.get('offset') or b.get('bytes')!=c.get('bytes'):other.append({'symbol':symbol,'index':index,'baseline':b,'candidate':c});continue
   bm=RELOC.search(b.get('asm',''));cm=RELOC.search(c.get('asm',''))
   if not bm or not cm or RELOC.sub(r'\g<prefix><GENERATED>\g<suffix>',b['asm'])!=RELOC.sub(r'\g<prefix><GENERATED>\g<suffix>',c['asm']):other.append({'symbol':symbol,'index':index,'baseline':b,'candidate':c});continue
   bn,cn=bm.group('name'),cm.group('name')
   if bn in mapping and mapping[bn]!=cn or cn in reverse and reverse[cn]!=bn:raise ValueError('non-bijective mapping')
   mapping[bn]=cn;reverse[cn]=bn;pairs.append({'symbol':symbol,'index':index,'offset':b['offset'],'bytes':b['bytes'],'baseline_target':bn,'candidate_target':cn})
 expected={
 'p2pstream/internal/agent..stmp_20':'p2pstream/internal/agent..stmp_31','p2pstream/internal/agent..stmp_21':'p2pstream/internal/agent..stmp_32','p2pstream/internal/agent..stmp_22':'p2pstream/internal/agent..stmp_33','p2pstream/internal/agent..stmp_23':'p2pstream/internal/agent..stmp_34','p2pstream/internal/agent..typeAssert.0':'p2pstream/internal/agent..typeAssert.14','p2pstream/internal/agent..typeAssert.1':'p2pstream/internal/agent..typeAssert.15'}
 if mapping!=expected or other or len(pairs)!=8:raise ValueError(f'unexpected code delta mapping={mapping} other={len(other)} pairs={len(pairs)}')
 referents=[]
 for bn,cn in expected.items():
  bs=values['baseline']['sections'].get(bn);cs=values['candidate']['sections'].get(cn)
  if bs is None or cs is None or bs!=cs:raise ValueError(f'referent mismatch {bn} {cn}')
  referents.append({'baseline':bn,'candidate':cn,'section':bs,'section_identical':True,'baseline_occurrences':occurrences(values['baseline']['asm'],bn),'candidate_occurrences':occurrences(values['candidate']['asm'],cn)})
 a.output.mkdir();result={'schema_version':1,'strict_proof_accepted':False,'strict_code_gate':False,'classification':'generated-relocation-alias-only','inference':'Moving the exact ordinary function to a separately selected source file changed package-global compiler-generated symbol numbering; paired target sections are byte-for-byte and relocation-graph identical. This is an inference from the artifacts, not a runtime execution result.','instruction_differences':pairs,'instruction_difference_count':len(pairs),'target_mapping':expected,'target_mapping_bijective':True,'referents':referents,'referent_sections_identical':True,'other_instruction_differences':other,'input_sha256':hashes}
 fd=os.open(a.output/'result.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
 return 0
if __name__=='__main__':raise SystemExit(main())
