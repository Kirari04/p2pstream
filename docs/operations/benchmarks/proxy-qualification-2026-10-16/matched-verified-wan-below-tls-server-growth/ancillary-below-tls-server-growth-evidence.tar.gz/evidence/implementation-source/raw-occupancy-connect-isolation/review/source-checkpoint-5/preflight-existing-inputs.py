#!/usr/bin/env python3
"""Read-only preflight of all immutable ledgers and receipt shapes consumed by the driver."""
from __future__ import annotations
import argparse, importlib.util, json, os, sys
from pathlib import Path
sys.dont_write_bytecode=True

def load(path:Path):
 spec=importlib.util.spec_from_file_location('focused_proof_driver',path)
 if spec is None or spec.loader is None:raise ValueError('driver import')
 mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def write_json(path,value):
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')

def main():
 p=argparse.ArgumentParser();p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 if a.output.exists():raise ValueError('fresh output required')
 d=load(a.checkpoint/'run-focused-proof.py'); ledgers={}
 for name,path,digest in (('raw-focused',d.RAW_ATTEMPT,d.RAW_ATTEMPT_SHA),('ordinary-attempt-1',d.ATTEMPT1,d.ATTEMPT1_SHA),('ordinary-attempt-2',d.ATTEMPT2,d.ATTEMPT2_SHA),('offline-compare',d.OFFLINE,d.OFFLINE_SHA)):
  entries=d.verify_ledger(path,digest);raw=(path/'SHA256SUMS.txt').read_text().splitlines();names=[x.split('  ',1)[1] for x in raw]
  ledgers[name]={'sha256':digest,'entries':len(entries),'leading_dot_slash_entries':sum(x.startswith('./') for x in names),'plain_entries':sum(not x.startswith('./') for x in names)}
 raw_result=json.loads((d.RAW_ATTEMPT/'RESULT.json').read_text());attempt1=json.loads((d.ATTEMPT1/'FINAL.json').read_text());attempt2=json.loads((d.ATTEMPT2/'FINAL.json').read_text());offline=json.loads((d.OFFLINE/'FINAL.json').read_text());report=json.loads((d.OFFLINE/'proof/report.json').read_text())
 if raw_result.get('accepted') is not True or raw_result.get('endpoint_or_traffic') is not False:raise ValueError('raw result shape')
 if attempt1.get('issue')!='RuntimeError: baseline-layout status 1' or attempt1.get('accepted') is not False or not all(attempt1.get('post_checks',{}).values()):raise ValueError('attempt1 shape')
 if attempt2.get('issue')!='RuntimeError: compare status 1' or attempt2.get('accepted') is not False or not all(attempt2.get('post_checks',{}).values()):raise ValueError('attempt2 shape')
 if offline.get('comparison_completed') is not True or offline.get('accepted') is not False or not all(offline.get('post_checks',{}).values()):raise ValueError('offline shape')
 gates={'code':False,'compiler':False,'compiler_data':False,'escape':False,'layout':True,'nm':True}
 if report.get('gates')!=gates:raise ValueError('offline gates')
 for name,digest in d.BASELINE_HASHES.items():d.exact(d.ATTEMPT2/name,digest)
 a.output.mkdir()
 write_json(a.output/'result.json',{'schema_version':1,'accepted':True,'ledgers':ledgers,'receipt_shapes':{'raw_focused':True,'attempt1_expected_failure':True,'attempt2_expected_failure':True,'offline_expected_failure':True,'offline_gates':gates},'baseline_artifact_sha256':d.BASELINE_HASHES})
 return 0
if __name__=='__main__':raise SystemExit(main())
