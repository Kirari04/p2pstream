# Raw-write validator review map

## Bound inputs

- `provenance/validate-sender-wait-snapshot.base.py` is the exact mature
  schema-2 sender validator recorded in `BASE-SENDER-VALIDATOR-SHA256.txt`.
- `RAW-SCHEMA-CHECKPOINT-SHA256.txt` binds raw-occupancy runtime-source
  checkpoint 3, including the exact raw owner and Yamux schema sources. Later
  driver-only checkpoints and focused receipts are separate provenance.
- `SENDER-VALIDATOR-DERIVATIVE.diff` shows the complete sender-validator delta.

## Acceptance invariants

- The raw object uses exact schema-1 fields, exact booleans, bounded unsigned
  scalars, bounded duration buckets, conserved outcomes, and conserved
  envelope/contained/residual time. Non-object inputs return rejection evidence
  rather than escaping through field access.
- Every live lane is enabled, bound, complete, reset, quiescent, unambiguous,
  and free of overflow, errors, short writes, overlaps, generation changes,
  boundary ownership, and straddling raw writes.
- Lane, positive generation, and canonical non-placeholder connection tuple
  bind each raw record to its sender record. Pre/post identity is stable.
- Lane 0 and non-selected lanes may retain successful outside-envelope writes.
  They must contain no Yamux DATA envelope, contained DATA write, or straddling
  write. The selected lane must exactly join sender stream ID, DATA frame and
  payload totals, and Yamux framed-plaintext wire bytes, with positive
  contained raw calls and bytes. Its envelope duration count, total, and
  maximum exactly match the sender physical-write duration bucket.
- Final closure consumes the fixed four pre/post pairs plus terminal history.
  It requires nine records per lane, stable session/generation/tuple identity,
  exactly five ordered post-join records, `aggregate: true` on lanes 0 through
  4, observed close and join, no active ownership, and no DATA or straddling
  activity after terminal reset.
- The derivative keeps the mature sender validator's response, timestamp,
  cardinality, timing, conservation, allocation, and outcome gates.

## Focused contract sources

- `contracts/run-raw-write-validator-contracts.py` covers raw schema positives,
  outside-envelope control activity, malformed and nonconserving values,
  selected DATA joins, raw error/short outcomes, straddling boundaries, and
  final closure identity/lifecycle failures.
- `contracts/test-sender-raw-integration.py` imports the actual sender
  derivative and constructs preserved inputs for valid pre, pair, terminal,
  and final-closure paths. It also covers missing raw data, placeholder tuples,
  stream/wire mismatches, non-selected DATA, and final straddling activity.
- Both drivers are source-only and unexecuted. A later focused receipt must bind
  their exact sources, persistent inputs, output, direct status, outer result,
  and source pre/post hashes.

## Interpretation limit

The Yamux envelope ledger measures framed plaintext above TLS. The raw observer
below `tls.Conn` counts encrypted buffers passed by TLS to the underlying
connection during or outside an envelope interval. It does not decode TLS
records, attribute ciphertext bytes to DATA, measure kernel or socket
residence, delivery, or TCP/NIC completion, or establish a cause for the
original WAN performance failure.
