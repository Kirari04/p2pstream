#!/usr/bin/env python3
"""Materialize and run the reviewed raw-observer focused contracts once."""
from __future__ import annotations
import hashlib,json,os,re,signal,shutil,subprocess,sys,time
from pathlib import Path

REPO=Path('/home/user/.codex/worktrees/astra-proxy-performance/p2pstream')
COMPONENT=REPO/'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy'
BASE=REPO/'tmp/continuation-20261016/wan-sender-wait-build-source/runs/audited-build-attempt-1/source'
GO=Path('/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go')
GO_SHA='29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45'
GO_VERSION='go version go1.26.6 linux/amd64'
TIMEOUT=600

def sha(path:Path)->str:
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
def inv(root:Path)->dict[str,str]:
 if not root.is_dir() or root.is_symlink(): raise ValueError(f'invalid root {root}')
 out={}
 for p in sorted(root.rglob('*')):
  if p.is_symlink(): raise ValueError(f'symlink {p}')
  if p.is_file(): out[p.relative_to(root).as_posix()]=sha(p)
 return out
def write(path:Path,value):
 path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:
  if isinstance(value,str): f.write(value)
  else: json.dump(value,f,sort_keys=True,separators=(',',':')); f.write('\n')
def group_exists(pgid:int)->bool:
 try: os.killpg(pgid,0); return True
 except ProcessLookupError: return False
 except PermissionError: return True
def wait_absent(pgid:int,seconds:float)->bool:
 end=time.monotonic()+seconds
 while group_exists(pgid) and time.monotonic()<end: time.sleep(.05)
 return not group_exists(pgid)
def run(records:Path,name:str,argv:list[str],cwd:Path,env:dict[str,str],timeout:int=TIMEOUT)->int:
 write(records/f'{name}.invocation.json',{'argv':argv,'cwd':str(cwd),'timeout_seconds':timeout})
 start=time.time_ns(); forced=False; term=False; kill=False
 with (records/f'{name}.stdout').open('xb') as out,(records/f'{name}.stderr').open('xb') as err:
  p=subprocess.Popen(argv,cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True)
  pid=p.pid; pgid=os.getpgid(pid)
  if pgid!=pid:
   p.terminate(); rc=p.wait(timeout=5)
   write(records/f'{name}.lifecycle.json',{'pid':pid,'pgid':pgid,'identity_valid':False,'wait_status':rc,'group_joined':not group_exists(pgid),'forced_cleanup':True})
   return 125
  try: rc=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   forced=True; term=True; os.killpg(pid,signal.SIGTERM)
   if not wait_absent(pid,5): kill=True; os.killpg(pid,signal.SIGKILL); wait_absent(pid,5)
   rc=p.wait(timeout=5)
 joined=wait_absent(pid,5)
 lifecycle={'pid':pid,'pgid':pgid,'identity_valid':True,'direct_status':rc,'wait_status':rc,'timed_out':forced,'term_attempted':term,'kill_attempted':kill,'forced_cleanup':forced,'group_joined':joined,'start_unix_ns':start,'end_unix_ns':time.time_ns()}
 write(records/f'{name}.lifecycle.json',lifecycle); write(records/f'{name}.status',f'{rc}\n')
 if forced or not joined: return 125
 return rc
def audit(stream:Path,expected_path:Path,report:Path)->bool:
 expected=json.loads(expected_path.read_text()); package=expected['package']; roots=set(expected['roots']); all_expected=set(expected['all_tests']); exact_all=expected['exact_all']
 runs=set(); passes=set(); fails=[]; package_pass=False; package_fail=False
 for no,line in enumerate(stream.read_text().splitlines(),1):
  try: e=json.loads(line)
  except Exception as exc: raise ValueError(f'{stream}: invalid JSON {no}: {exc}')
  if e.get('Package')!=package: continue
  action=e.get('Action'); test=e.get('Test')
  if test:
   if action=='run': runs.add(test)
   elif action=='pass': passes.add(test)
   elif action=='fail': fails.append(test)
  elif action=='pass': package_pass=True
  elif action=='fail': package_fail=True
 got_roots={x for x in runs if '/' not in x}; pass_roots={x for x in passes if '/' not in x}
 unknown={test for test in runs|passes if test.split('/',1)[0] not in roots}
 accepted=got_roots==roots and pass_roots==roots and not unknown and runs==passes and not fails and package_pass and not package_fail
 if exact_all: accepted=accepted and runs==all_expected
 write(report,{'accepted':accepted,'package':package,'expected_roots':sorted(roots),'runs':sorted(runs),'passes':sorted(passes),'failures':fails,'package_pass':package_pass,'package_fail':package_fail,'unknown':sorted(unknown),'exact_all':exact_all})
 return accepted

def exact_pattern(expected_path:Path)->str:
 expected=json.loads(expected_path.read_text()); roots=expected['roots']
 if not isinstance(roots,list) or not roots or len(roots)!=len(set(roots)):
  raise ValueError(f'invalid exact root set: {expected_path}')
 if any(not isinstance(root,str) or re.fullmatch(r'Test[A-Za-z0-9_]+',root) is None for root in roots):
  raise ValueError(f'invalid exact root name: {expected_path}')
 return '^('+'|'.join(re.escape(root) for root in roots)+')$'

def verify_checkpoint(checkpoint:Path,expected_sha:str)->None:
 manifest=checkpoint/'SHA256SUMS.txt'
 if sha(manifest)!=expected_sha: raise ValueError('checkpoint hash changed')
 for line in manifest.read_text().splitlines():
  digest,relative=line.split('  ',1); p=checkpoint/relative
  if not p.is_file() or p.is_symlink() or sha(p)!=digest: raise ValueError(f'checkpoint entry mismatch: {relative}')

def main()->int:
 if len(sys.argv)!=3: raise SystemExit('usage: run-focused.py FRESH_OUTPUT EXPECTED_CHECKPOINT_SHA256')
 output=Path(sys.argv[1]).resolve(); expected_cp=sys.argv[2]
 checkpoint=Path(__file__).resolve().parent.parent
 manifest=checkpoint/'SHA256SUMS.txt'
 if sha(manifest)!=expected_cp: raise ValueError('checkpoint hash mismatch')
 verify_checkpoint(checkpoint,expected_cp)
 # Full checkpoint verification has completed before materialization.
 if output.exists() or output.parent!=(COMPONENT/'runs').resolve(): raise ValueError('output must be fresh direct child of component runs')
 output.mkdir(parents=True,mode=0o700); records=output/'records'; records.mkdir(mode=0o700)
 write(records/'start-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
 if sha(GO)!=GO_SHA: raise ValueError('Go hash mismatch')
 version_env={'HOME':os.environ['HOME'],'PATH':'/usr/bin:/bin','LC_ALL':'C','TZ':'UTC'}
 if run(records,'go-version',[str(GO),'version'],REPO,version_env,30)!=0 or (records/'go-version.stdout').read_text().strip()!=GO_VERSION: raise ValueError('Go version mismatch')
 expected_base=json.loads((checkpoint/'validation-source/BASE-INVENTORY.json').read_text())['files']
 if inv(BASE)!=expected_base: raise ValueError('immutable base inventory mismatch')
 source=output/'source'; shutil.copytree(BASE,source,copy_function=shutil.copy2)
 if inv(source)!=expected_base: raise ValueError('copied base inventory mismatch')
 overlay=checkpoint/'overlay'; overlay_inventory=inv(overlay)
 for rel,digest in overlay_inventory.items():
  src=overlay/rel; dst=source/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
  if sha(dst)!=digest: raise ValueError(f'overlay copy mismatch: {rel}')
 source_pre=inv(source); write(records/'source-pre.json',{'files':source_pre})
 common={'HOME':os.environ['HOME'],'PATH':'/usr/bin:/bin','GOENV':'off','GOTOOLCHAIN':'local','GOWORK':'off','GOFLAGS':'','CGO_ENABLED':'1','GOMAXPROCS':'16','GOPATH':str(output/'gopath'),'GOMODCACHE':'/home/user/go/pkg/mod','GOPROXY':'off','GOSUMDB':'off','LC_ALL':'C','TZ':'UTC'}
 (output/'gopath').mkdir(mode=0o700)
 for mode in ('normal','race'):
  (output/f'tmp-{mode}').mkdir(mode=0o700); (output/f'gocache-{mode}').mkdir(mode=0o700)
 env=dict(common,TMPDIR=str(output/'tmp-normal'),GOTMPDIR=str(output/'tmp-normal'),GOCACHE=str(output/'gocache-normal'))
 if run(records,'go-env',[str(GO),'env','-json','GOMOD','GOWORK','GOENV','GOTOOLCHAIN','GOMODCACHE','GOPATH','GOPROXY','GOSUMDB'],source,env,30)!=0: raise ValueError('go env failed')
 effective=json.loads((records/'go-env.stdout').read_text())
 if effective!={'GOMOD':str(source/'go.mod'),'GOWORK':'off','GOENV':'','GOTOOLCHAIN':'local','GOMODCACHE':'/home/user/go/pkg/mod','GOPATH':str(output/'gopath'),'GOPROXY':'off','GOSUMDB':'off'}: raise ValueError(f'Go env mismatch: {effective}')
 agent_pattern=exact_pattern(checkpoint/'validation-source/EXPECTED-AGENT-TESTS.json')
 yamux_pattern=exact_pattern(checkpoint/'validation-source/EXPECTED-YAMUX-TESTS.json')
 jobs=[('agent-normal',source,['./internal/agent'],agent_pattern,'EXPECTED-AGENT-TESTS.json','normal'),('yamux-normal',source/'third_party/yamux',['.'],yamux_pattern,'EXPECTED-YAMUX-TESTS.json','normal'),('agent-race',source,['./internal/agent'],agent_pattern,'EXPECTED-AGENT-TESTS.json','race'),('yamux-race',source/'third_party/yamux',['.'],yamux_pattern,'EXPECTED-YAMUX-TESTS.json','race')]
 for name,cwd,pkg,pattern,expected,mode in jobs:
  e=dict(common,TMPDIR=str(output/f'tmp-{mode}'),GOTMPDIR=str(output/f'tmp-{mode}'),GOCACHE=str(output/f'gocache-{mode}'))
  argv=[str(GO),'test','-json','-count=1','-tags','p2pstream_qualification']
  if mode=='race': argv.append('-race')
  argv += pkg+['-run',pattern]
  if run(records,name,argv,cwd,e)!=0: raise ValueError(f'{name} failed')
  if not audit(records/f'{name}.stdout',checkpoint/f'validation-source/{expected}',records/f'{name}.audit.json'): raise ValueError(f'{name} audit failed')
 source_post=inv(source); write(records/'source-post.json',{'files':source_post})
 if source_post!=source_pre: raise ValueError('source changed during validation')
 if sha(GO)!=GO_SHA: raise ValueError('Go changed after validation')
 verify_checkpoint(checkpoint,expected_cp)
 write(records/'checkpoint-post.status','0\n')
 write(records/'result.json',{'accepted':True,'checkpoint_sha256':expected_cp,'go_sha256':GO_SHA,'tests':['agent-normal','yamux-normal','agent-race','yamux-race'],'source_pre_post_equal':True,'ordinary_proof_run':False,'endpoint_or_traffic':False})
 write(records/'end-utc',time.strftime('%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
 return 0
if __name__=='__main__':
 try:
  raise SystemExit(main())
 except Exception as exc:
  try:
   if len(sys.argv)>=2:
    output=Path(sys.argv[1]).resolve(); records=output/'records'; source=output/'source'
    if records.is_dir():
     failure={'accepted':False,'error_type':type(exc).__name__,'error':str(exc),'unix_ns':time.time_ns()}
     if source.is_dir() and not (records/'source-post-failure.json').exists(): write(records/'source-post-failure.json',{'files':inv(source)})
     checkpoint_status=1
     if len(sys.argv)==3:
      try: verify_checkpoint(Path(__file__).resolve().parent.parent,sys.argv[2]); checkpoint_status=0
      except Exception: checkpoint_status=1
     if not (records/'checkpoint-post-failure.status').exists(): write(records/'checkpoint-post-failure.status',f'{checkpoint_status}\n')
     if not (records/'failure.json').exists(): write(records/'failure.json',failure)
  except Exception as final_exc:
   sys.stderr.write(f'failure finalization error: {final_exc}\n')
  sys.stderr.write(f'{type(exc).__name__}: {exc}\n')
  raise SystemExit(1)
