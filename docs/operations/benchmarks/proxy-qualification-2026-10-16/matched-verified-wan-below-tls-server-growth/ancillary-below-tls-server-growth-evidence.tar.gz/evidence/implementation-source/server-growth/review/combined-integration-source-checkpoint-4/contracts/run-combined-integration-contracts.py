#!/usr/bin/env python3
"""Run the bounded no-endpoint combined-integration source contracts."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import pathlib
import sys
import time

sys.dont_write_bytecode = True
REPO = pathlib.Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
COMPONENT = REPO / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/server-growth"
VERIFIER = REPO / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/raw-occupancy/review/raw-occupancy-source-checkpoint-5/validation-source/run-focused.py"
VERIFIER_SHA = "b68aaec8403fb02dd031df1c73fbe37706b92cd57e6c4bb26a3acc01b7d3745d"
OWNED_HELPER = REPO / "tmp/continuation-20261016/wan-sender-wait-build-source/review/source-checkpoint-3/run-audited-build.py"
OWNED_HELPER_SHA = "8d40407691bc70d6341f9932d7e6d8345ccb06e181ceaed4a5cdf3491e234440"
PYTHON = pathlib.Path("/usr/bin/python3.14")
PYTHON_SHA = "52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
BASH = pathlib.Path("/usr/bin/bash")
BASH_SHA = "3efccc187bafa75ff1e37d246270ab3e7aa559f242c7a52bf3ec2a1b5450bdbd"


def sha(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def exact(path: pathlib.Path, expected: str) -> None:
    if path.is_symlink() or not path.is_file() or sha(path) != expected:
        raise ValueError(f"immutable input differs: {path}")


def load(name: str, path: pathlib.Path, expected: str):
    exact(path, expected)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_text(path: pathlib.Path, value: str) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        stream.write(value)


def write_json(path: pathlib.Path, value) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def main() -> int:
    if len(sys.argv) != 3:
        raise ValueError("usage: run-combined-integration-contracts.py FRESH_OUTPUT EXPECTED_CHECKPOINT_SHA256")
    output = pathlib.Path(sys.argv[1]).resolve()
    expected = sys.argv[2]
    checkpoint = pathlib.Path(__file__).resolve().parent.parent
    if output.exists() or output.parent != (COMPONENT / "runs").resolve():
        raise ValueError("fresh owned component run directory is required")
    output.mkdir(mode=0o700)
    records = output / "records"
    records.mkdir(mode=0o700)
    write_text(records / "start-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))
    accepted = False
    issue = None
    verifier = owned = None
    checkpoint_pre = None
    try:
        exact(PYTHON, PYTHON_SHA)
        exact(BASH, BASH_SHA)
        verifier = load("component_verifier", VERIFIER, VERIFIER_SHA)
        owned = load("owned_process", OWNED_HELPER, OWNED_HELPER_SHA)
        checkpoint_pre = verifier.verify_component(checkpoint, expected)
        write_json(records / "checkpoint-pre.json", {"schema_version": 1, "manifest_sha256": expected, "files": checkpoint_pre})
        write_json(records / "inputs.json", {
            "schema_version": 1, "checkpoint_sha256": expected,
            "component_verifier_sha256": VERIFIER_SHA, "owned_process_helper_sha256": OWNED_HELPER_SHA,
            "python_sha256": PYTHON_SHA, "bash_sha256": BASH_SHA, "endpoint_or_traffic": False,
        })
        environment = {"HOME": os.environ["HOME"], "PATH": "/usr/bin:/bin", "LC_ALL": "C",
                       "TZ": "Europe/Zurich", "PYTHONDONTWRITEBYTECODE": "1",
                       "PYTHONOPTIMIZE": "", "PYTHONPATH": ""}
        def run(name: str, arguments: list[object], timeout: int = 60) -> None:
            status = owned.run(records, name, [str(value) for value in arguments], REPO, environment, timeout)
            if status != 0:
                raise RuntimeError(f"{name} status {status}")
        runner = checkpoint / "integration/qualify-proxy-agent-growth-wan-below-tls.sh"
        run("static-source", [PYTHON, "-I", "-B", checkpoint / "contracts/static-combined-check.py", checkpoint])
        run("runner-bash-syntax", [BASH, "-n", runner])
        finalizer_work = output / "finalizer-contract-work"
        run("runner-finalizer-contract", [BASH, checkpoint / "contracts/test-post-join-raw-finalization.sh", runner, finalizer_work])
        closure_work = output / "arm-closure-contract-work"
        closure_result = output / "arm-closure-contract-result.json"
        run("arm-closure-contract", [PYTHON, "-I", "-B", checkpoint / "contracts/test-post-join-arm-closure.py",
                                     checkpoint / "integration/validate-post-join-raw-closure.py", closure_work, closure_result])
        finalizer_summary = json.loads((finalizer_work / "summary.json").read_text())
        expected_finalizer = {"correct": True, "missing": False, "invalid_mode": False,
                              "rejected_closure": False, "join_failure": False}
        if finalizer_summary != {"schema_version": 1, "accepted": True, "case_outcomes": expected_finalizer}:
            raise ValueError("runner finalizer case summary changed")
        closure_summary = json.loads(closure_result.read_text())
        closure_names = ("valid", "changed_hash", "status_false", "missing", "invalid_closure",
                         "invalid_mode", "symlink", "oversized_terminal", "oversized_validation")
        expected_closure = {name: name == "valid" for name in closure_names}
        if closure_summary != {"schema_version": 1, "accepted": True, "case_count": 9,
                               "case_outcomes": expected_closure}:
            raise ValueError("arm closure case summary changed")
        if verifier.verify_component(checkpoint, expected) != checkpoint_pre:
            raise ValueError("combined checkpoint changed during contracts")
        accepted = True
    except BaseException as error:
        issue = f"{type(error).__name__}: {error}"
    finally:
        checks: dict[str, bool] = {}
        errors: dict[str, str] = {}
        def check(name, operation) -> None:
            try:
                checks[name] = bool(operation())
            except BaseException as error:
                checks[name] = False
                errors[name] = f"{type(error).__name__}: {error}"
        def checkpoint_unchanged() -> bool:
            if verifier is None or checkpoint_pre is None:
                return False
            current = verifier.verify_component(checkpoint, expected)
            if not (records / "checkpoint-post.json").exists():
                write_json(records / "checkpoint-post.json", {"schema_version": 1, "manifest_sha256": expected, "files": current})
            return current == checkpoint_pre
        def lifecycle_valid() -> bool:
            rows = []
            for path in sorted(records.glob("*.lifecycle.json")):
                rows.append(json.loads(path.read_text()))
            return bool(rows) and all(type(row.get("direct_status")) is int and row["direct_status"] == 0
                                      and row.get("group_joined") is True
                                      and row.get("forced_cleanup") is False for row in rows)
        check("checkpoint_unchanged", checkpoint_unchanged)
        check("component_verifier_unchanged", lambda: sha(VERIFIER) == VERIFIER_SHA)
        check("owned_process_helper_unchanged", lambda: sha(OWNED_HELPER) == OWNED_HELPER_SHA)
        check("python_unchanged", lambda: sha(PYTHON) == PYTHON_SHA)
        check("bash_unchanged", lambda: sha(BASH) == BASH_SHA)
        check("all_started_process_groups_joined_without_force", lifecycle_valid)
        accepted = accepted and all(checks.values())
        final = {"schema_version": 1, "accepted": accepted, "issue": issue,
                 "checkpoint_sha256": expected, "post_checks": checks, "post_errors": errors,
                 "endpoint_or_traffic": False}
        write_json(records / "FINAL.json", final)
        write_text(records / "FINAL.status", "0\n" if accepted else "1\n")
        write_text(records / "end-utc", time.strftime("%Y-%m-%dT%H:%M:%SZ\n", time.gmtime()))
        lines = []
        for path in sorted(records.rglob("*")):
            if path.is_file() and path.name != "SHA256SUMS.txt":
                lines.append(f"{sha(path)}  {path.relative_to(records).as_posix()}\n")
        write_text(records / "SHA256SUMS.txt", "".join(lines))
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
