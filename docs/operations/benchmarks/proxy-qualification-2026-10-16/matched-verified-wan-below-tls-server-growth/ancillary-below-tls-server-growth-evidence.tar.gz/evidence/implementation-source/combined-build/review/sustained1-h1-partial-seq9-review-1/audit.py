#!/usr/bin/python3
from __future__ import annotations
import collections, hashlib, json
from pathlib import Path

ROOT = Path('/home/user/.codex/worktrees/astra-proxy-performance/p2pstream')
RUN = ROOT / 'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/final-integration-source/integration/runs/sustained-below-tls-1/h1'
OUT = ROOT / 'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/combined-build/review/sustained1-h1-partial-seq9-review-1'
CONTROL = RUN / 'results.sender-wait-controls'
VALIDATOR = ROOT / 'tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source/final-integration-source/integration/validate-server-receive-growth.py'

def read(path: Path): return json.loads(path.read_text())
def sha(path: Path): return hashlib.sha256(path.read_bytes()).hexdigest()
def ns(bucket): return bucket['total_nanoseconds']

def label(path: Path) -> str:
    try: return str(path.relative_to(ROOT))
    except ValueError: return str(path.relative_to(OUT))

# The cohort stopped after one selected transfer. The row itself is complete.
result_rows = [json.loads(line) for line in (RUN/'results.jsonl').read_text().splitlines()]
rows9 = [r for r in result_rows if r.get('diagnostic_sequence') == 9]
assert len(result_rows) == 9 and len(rows9) == 1
row = rows9[0]
assert row['measurement_stage'] == 'retained-warmup' and row['transfer_direction'] == 'download'
assert row['protocol'] == row['public_protocol'] == 'h1'
assert row['configured_payload_bytes'] == row['response_bytes'] == 268435456
assert row['attempted'] == row['useful_completed'] == 1 and row['errors'] == 0
assert row['status_codes'] == {'200': 1}
assert row['observed_http_major'] == row['observed_origin_http_major'] == 1
assert len(row['response_copy_attribution']['matches']) == 1
assert row['response_copy_attribution']['overflow'] is False
copy = row['response_copy_attribution']['matches'][0]
assert copy == read(OUT/'sequence-9-copy-record.json')
assert copy['sequence'] == '9' and copy['scope'] == 'response-body-copy'
assert copy['copy']['complete'] is True
assert copy['copy']['upstream_read']['bytes'] == copy['copy']['downstream_write']['bytes'] == 268435456
assert copy['copy']['read_eof'] == 1
assert copy['copy']['read_errors'] == copy['copy']['write_errors'] == copy['copy']['short_writes'] == 0

# Sender and raw-write interval were drained and locally accepted before serialization failed.
sender = read(CONTROL/'sequence-9-validation.json')
assert sender['accepted'] is True and sender['issues'] == [] and sender['selected_lane'] == 1
selected = sender['selected']; lane = selected['lane']; stream = selected['stream_id']
assert (lane, stream) == (1, 6)
post_sender = read(CONTROL/'sequence-9-post-sender.json')
match = [v for v in post_sender['response']['send_counters'] if v['lane'] == lane]
assert len(match) == 1
counter = match[0]; timing = counter['timing']; raw = selected['raw_write_activity']
assert counter['enabled'] is True and timing['complete'] is True and timing['reset_performed'] is True
assert timing['ambiguous'] is False and timing['overflow'] is False and timing['multiple_streams'] is False
assert timing['active_caller_frames'] == timing['active_credit_waits'] == timing['active_enqueue_frames'] == 0
assert timing['active_physical_frames'] == timing['active_queued_frames'] == timing['active_reserved_frames'] == 0
assert timing['data_completed_frames'] == timing['data_enqueued_frames'] == timing['physical_success_frames'] == selected['frames']
assert timing['data_completed_payload_bytes'] == timing['data_enqueued_payload_bytes'] == timing['physical_success_payload_bytes'] == selected['payload_bytes']
assert timing['physical_success_wire_bytes'] == selected['wire_bytes']
assert timing['physical_error_frames'] == timing['physical_short_frames'] == timing['data_abandoned_frames'] == 0
assert ns(timing['credit_wait_total']) == ns(selected['durations']['credit_wait_total'])
assert ns(timing['physical_write_total']) == ns(selected['durations']['physical_write_total'])
causes = {k: ns(v) for k,v in timing['credit_wait_by_cause'].items()}
assert sum(causes.values()) == ns(timing['credit_wait_total'])
assert causes['session_allocation_zero'] == causes['stream_and_session_allocation_zero'] == 0
assert raw['accepted'] is True and raw['issues'] == []
assert raw['bools']['complete'] is True and raw['bools']['reset_performed'] is True
assert raw['bools']['ambiguous'] is raw['bools']['overflow'] is raw['bools']['multiple_streams'] is False
ri = raw['ints']
assert ri['active_envelopes'] == ri['active_raw_writes'] == ri['boundary_active_raw_writes'] == 0
assert ri['boundary_outside_completions'] == ri['envelope_overlaps'] == ri['owner_generation_changes'] == 0
assert ri['maximum_active_raw_writes'] == 1 and ri['envelope_zero_raw_calls'] == 0
assert ri['envelope_count'] == selected['frames']
assert ri['envelope_payload_bytes'] == selected['payload_bytes'] and ri['envelope_wire_bytes'] == selected['wire_bytes']
physical_ns = ns(selected['durations']['physical_write_total'])
contained_ns = ns(raw['durations']['contained_raw_duration'])
residual_ns = ns(raw['durations']['residual_duration'])
assert ns(raw['durations']['envelope_duration']) == physical_ns
assert contained_ns + residual_ns == physical_ns
assert raw['classes']['contained']['scalars']['calls'] > 0
assert raw['classes']['outside']['scalars']['calls'] > 0
assert raw['classes']['straddling']['scalars']['calls'] == 0
assert raw['classes']['contained']['scalars']['error_calls'] == raw['classes']['contained']['scalars']['short_calls'] == 0

# Correctly extracted copy record makes the existing strict growth validator accept.
growth = read(OUT/'server-growth-validation-corrected.json')
assert (OUT/'server-growth-validator-corrected.status').read_text().strip() == '0'
assert growth['accepted'] is True and growth['issues'] == [] and growth['sequence'] == 9
assert growth['selected_event_count'] == len(growth['selected_events']) == 212
assert growth['post_dropped_events'] == growth['pre_prior_dropped_events'] == 0
identity = growth['selected_identity']
assert identity['lane'] == lane and identity['stream_id'] == stream
assert identity['local_address'] == counter['remote_address']
assert identity['remote_address'] == counter['local_address']
timestamps = [e['sample_unix_nano'] for e in growth['selected_events']]
assert timestamps == sorted(timestamps)
outcomes = collections.Counter(e['outcome'] for e in growth['selected_events'])
assert outcomes == {'no_proposal': 200, 'grown': 12}
post_capacity = read(CONTROL/'sequence-9-post-capacity.json')
sessions = post_capacity['response']['server_receive_growth']['credit_snapshot']['sessions']
session = [v for v in sessions if v['lane'] == lane and v['session_identity'] == identity['session_identity'] and v['snapshot']['local_address'] == identity['local_address'] and v['snapshot']['remote_address'] == identity['remote_address']]
assert len(session) == 1 and session[0]['snapshot']['aggregate_enabled'] is True and session[0]['snapshot']['truncated'] is False
streams = [v for v in session[0]['snapshot']['streams'] if v['id'] == stream]
assert len(streams) == 1
post_stream = streams[0]
assert post_stream['byte_receive_limit'] == post_stream['allocation_receive_limit'] == 20905984

# The harness failure invalidated the qualification and forced all inner groups.
assert (RUN/'runner.status').read_text().strip() == '126'
assert (RUN/'validation.status').read_text().strip() == '1'
assert 'Argument list too long' in (RUN/'runner.stderr.log').read_text()
assert not (RUN/'results.summary.json').exists() and not (RUN/'attestation.json').exists()
assert not (CONTROL/'final-raw-write-terminal.json').exists()
assert (RUN/'results.sender-wait-records.jsonl').stat().st_size == 0
lifecycle = [json.loads(line) for line in (RUN/'results.lifecycle.jsonl').read_text().splitlines()]
exits = [v for v in lifecycle if v.get('event') == 'process-exit']
assert len(exits) == 5
assert {v['label'] for v in exits} == {'current-server-aggregate-v1-h1-1-agent','current-server-aggregate-v1-h1-1-server','origin','agent-namespace','router-namespace'}
for event in exits:
    assert event['cleanup'] is event['forced'] is event['group_joined'] is event['invalidates_success'] is True
    assert event['status'] == 143 and event['term'] == {'attempted': True, 'status': 0}
    assert event['kill'] == {'attempted': False, 'status': None}
    assert event['final_group_probe_status'] == 1 and event['final_group_exists'] is False
assert lifecycle[-1] == {'event':'forced-cleanup','invalidates_success':True}
supervisor = read(RUN/'supervisor-lifecycle.json')
assert supervisor['runner_status'] == 126 and supervisor['group_joined'] is True
assert supervisor['invalidates_success'] is True and supervisor['sender_evidence']['terminal_valid'] is False
assert supervisor['raw_write_evidence']['final_closure_valid'] is False
assert supervisor['server_scope']['unit_joined'] is True
assert supervisor['server_scope']['unit_load_state'] == 'not-found'
assert supervisor['server_scope']['unit_active_state'] == 'inactive' and supervisor['server_scope']['unit_sub_state'] == 'dead'
scope_join = read(RUN/'server-scope/scope-process-join.json')
assert scope_join == {'launcher_alive_same_identity':False,'launcher_group_joined':True,'sentinel_alive_same_identity':False,'sentinel_group_joined':True}
resource = read(RUN/'server-scope/server-resource-attestation.json')
assert resource == {'schema_version':1,'accepted':False,'error':'missing pre-traffic or post-workload cgroup snapshot'}

input_paths = [
    RUN/'results.jsonl', RUN/'results.lifecycle.jsonl', RUN/'runner.status', RUN/'runner.stderr.log',
    RUN/'validation.status', RUN/'supervisor-lifecycle.json', RUN/'supervisor-cleanup.json',
    RUN/'raw-post-join-supervisor-validation.json', RUN/'server-scope/scope-process-join.json',
    RUN/'server-scope/unit-final.json', RUN/'server-scope/server-resource-attestation.json',
    CONTROL/'sequence-9-pre-sender.json', CONTROL/'sequence-9-post-sender.json',
    CONTROL/'sequence-9-validation.json', CONTROL/'sequence-9-pre-capacity.json',
    CONTROL/'sequence-9-post-capacity.json', OUT/'sequence-9-copy-record.json',
    OUT/'server-growth-validation.json', OUT/'server-growth-validator.status',
    OUT/'server-growth-validation-corrected.json', OUT/'server-growth-validator-corrected.status',
    OUT/'TOOL-ENVELOPE.json', VALIDATOR,
]
report = {
    'schema_version': 1,
    'review_completed': True,
    'run_accepted': False,
    'qualification_gate_cleared': False,
    'disposition': 'invalid/inconclusive cohort; one locally conserved partial H1 sequence is retained as diagnostic evidence only',
    'invalidating_facts': [
        'runner status 126 after jq argv exceeded ARG_MAX while serializing sequence 9',
        'all five inner endpoint/helper groups required TERM cleanup, exited 143, and therefore invalidate success',
        'final sender/raw terminal artifacts, results summary, arm attestation, and complete resource attestation are absent',
        'validation status is 1; no fixed performance, stability, lifecycle, or cohort gate is cleared',
        'the strict server-growth validator first invocation used the wrong copy-record object and failed status 1; this attempt is preserved',
        'the corrected strict validator direct status is 0 but its tool envelope reported exit 1 for an unresolved external reason',
    ],
    'partial_sequence': {
        'sequence': 9, 'protocol': 'h1', 'stage': 'retained-warmup', 'direction': 'download',
        'configured_payload_bytes': row['configured_payload_bytes'], 'response_bytes': row['response_bytes'],
        'wall_seconds': row['wall_seconds'], 'useful_transfer_bytes_per_second': row['useful_transfer_bytes_per_second'],
        'observed_http_major': row['observed_http_major'], 'observed_origin_http_major': row['observed_origin_http_major'],
        'copy_upstream_read_ns': copy['copy']['upstream_read']['total_ns'],
        'copy_downstream_write_ns': copy['copy']['downstream_write']['total_ns'],
        'copy_inter_read_gap_ns': copy['copy']['inter_read_gap']['total_ns'],
        'lane': lane, 'stream_id': stream, 'sender_frames': selected['frames'],
        'sender_payload_bytes': selected['payload_bytes'], 'sender_wire_bytes': selected['wire_bytes'],
        'credit_wait_ns': ns(timing['credit_wait_total']), 'credit_wait_by_cause_ns': causes,
        'enqueue_select_ns': ns(timing['data_enqueue_select_total']),
        'completion_select_ns': ns(timing['data_completion_select_total']),
        'physical_write_ns': physical_ns, 'contained_raw_write_ns': contained_ns,
        'tls_residual_ns': residual_ns, 'contained_raw_calls': raw['classes']['contained']['scalars']['calls'],
        'outside_raw_calls': raw['classes']['outside']['scalars']['calls'], 'straddling_raw_calls': 0,
        'contained_raw_attempt_bytes': raw['classes']['contained']['scalars']['attempt_bytes'],
        'growth_selected_events': growth['selected_event_count'], 'growth_outcomes': dict(outcomes),
        'growth_dropped_events': growth['post_dropped_events'],
        'post_byte_receive_limit': post_stream['byte_receive_limit'],
        'post_allocation_receive_limit': post_stream['allocation_receive_limit'],
        'compound_tuple_join': True, 'local_sender_and_raw_conservation': True,
        'strict_growth_validation_direct_status': 0,
    },
    'cleanup': {
        'inner_forced': True, 'inner_groups': 5, 'inner_statuses': [143]*5,
        'term_attempted_statuses': [0]*5, 'kill_attempted': False,
        'all_inner_groups_joined': True, 'all_final_group_exists': False,
        'outer_runner_group_joined': True, 'scope_launcher_group_joined': True,
        'scope_sentinel_group_joined': True, 'unit_joined': True,
        'unit_final': {'load':'not-found','active':'inactive','sub':'dead'},
        'resource_attestation_accepted': False,
    },
    'interpretation_limits': [
        'The 15.543512 MB/s row is not an accepted performance result because the cohort and natural-lifecycle gates failed.',
        'Agent sender/raw intervals and server copy intervals use different processes and instrument boundaries; their durations are descriptive and must not be arithmetically combined.',
        'Contained raw-write time is temporal TLS-connection write occupancy inside DATA envelopes, not proof of kernel TCP wait, packet delivery, or DATA-only ciphertext identity.',
        'The server stream grew through twelve published receive-limit increases to 20,905,984 bytes, while sender credit wait and TLS/raw occupancy were both nonzero; this single partial row cannot assign causality between them.',
        'Forced shutdown prevents final five-session terminal closure and resource evidence, even though every observed process group was absent after cleanup.',
    ],
    'input_sha256': {label(path): sha(path) for path in input_paths},
}
(OUT/'REVIEW.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
