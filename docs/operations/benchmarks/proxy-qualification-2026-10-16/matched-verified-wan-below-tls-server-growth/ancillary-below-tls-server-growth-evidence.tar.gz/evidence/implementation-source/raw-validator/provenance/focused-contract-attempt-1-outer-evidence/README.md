# Focused contract attempt 1 outer evidence

This directory supplements the immutable accepted run at
`../../runs/focused-contract-attempt-1`. It does not modify or rehash the
run's `records/` directory.

`OUTER-EXECUTION.json` preserves the exact native execution result and the
separate pre/post invocation-source verification metadata reported by the main
reviewer. The complete outer command and raw pre/post verifier output were not
persisted in this supplement and are not reconstructed.

`INDEPENDENT-REVIEW.json` records an independent read-only verification of the
run manifest, statuses, natural child process-group joins, fixed input/source
equality, declared case outcomes, retained composition inputs, and the positive
cross-ledger duration join. No contract was rerun.
