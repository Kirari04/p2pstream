#!/usr/bin/env python3
"""Atomically materialize the ten reviewed cp8-to-cp10 source changes."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import stat
import sys


REPO = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
BASE = REPO / "tmp/continuation-20261016/wan-below-tls-raw-write-source/implementation-source"
CP8 = BASE / "server-growth/review/final-integration-source-checkpoint-8"
CP10 = BASE / "server-growth/review/final-integration-source-checkpoint-10"
ACTIVE = BASE / "final-integration-source"
CP8_MANIFEST_SHA = "162ff6e8f6333560e8c89beb3eb2ff74452a55f30ab5593b3435e1e17f89c5aa"
CP10_MANIFEST_SHA = "1961587927cf5816347bcc4930412e69668c3c5084c28b3264a4856f86da37d4"
GUARD_PATHS = (
    "integration/generated/qualify-proxy-agent-growth-wan-below-tls.sh",
    "integration/validate-wan-below-tls-arm.py",
    "integration/validate-arm-outcome.py",
    "integration/validate-copy-record.py",
    "integration/validate-sender-wait-snapshot.py",
    "integration/validate-raw-write-activity.py",
    "integration/validate-server-receive-growth.py",
    "integration/validate-post-join-raw-closure.py",
)


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def corpus(checkpoint: Path, manifest_sha: str) -> dict[str, str]:
    if sha(checkpoint / "SHA256SUMS.txt") != manifest_sha:
        raise ValueError("checkpoint manifest changed")
    value = json.loads((checkpoint / "SOURCE-CORPUS.json").read_text(encoding="utf-8"))
    result = dict(value["files"])
    result["SOURCE-CORPUS.json"] = sha(checkpoint / "SOURCE-CORPUS.json")
    return result


def inventory() -> dict[str, str]:
    result: dict[str, str] = {}
    for path in sorted(ACTIVE.rglob("*")):
        relative = path.relative_to(ACTIVE).as_posix()
        if relative == "provenance" or relative.startswith("provenance/"):
            continue
        if relative == "integration/runs" or relative.startswith("integration/runs/"):
            continue
        if path.is_symlink():
            raise ValueError(f"symlink in active source: {relative}")
        if path.is_file():
            result[relative] = sha(path)
    return result


def write_json(path: Path, value: object) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def main() -> int:
    if len(sys.argv) != 2:
        raise ValueError("usage: materialize.py FRESH_EVIDENCE_DIRECTORY")
    evidence = Path(sys.argv[1]).resolve()
    if evidence.exists() or evidence.is_symlink() or not evidence.parent.is_dir():
        raise ValueError("evidence directory must be fresh")
    evidence.mkdir(mode=0o700)

    before = corpus(CP8, CP8_MANIFEST_SHA)
    after = corpus(CP10, CP10_MANIFEST_SHA)
    if inventory() != before:
        raise ValueError("active source does not equal checkpoint 8 before materialization")
    change_file = Path(__file__).resolve().parent / "CHANGED-FILES.json"
    declared = json.loads(change_file.read_text(encoding="utf-8"))
    changes = declared.get("changes")
    expected_changes = [name for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)]
    if (not isinstance(changes, list) or [item.get("path") for item in changes] != expected_changes
            or len(changes) != 10):
        raise ValueError("declared cp8-to-cp10 file set differs")

    pre_modes: dict[str, int | None] = {}
    for item in changes:
        relative = item["path"]
        if item.get("before_sha256") != before.get(relative) or item.get("after_sha256") != after.get(relative):
            raise ValueError(f"declared hash differs: {relative}")
        source = CP10 / relative
        destination = ACTIVE / relative
        if sha(source) != after[relative] or source.is_symlink() or not source.is_file():
            raise ValueError(f"unsafe cp10 source: {relative}")
        if relative in before:
            info = destination.lstat()
            if not stat.S_ISREG(info.st_mode) or destination.is_symlink() or sha(destination) != before[relative]:
                raise ValueError(f"active predecessor differs: {relative}")
            pre_modes[relative] = stat.S_IMODE(info.st_mode)
        else:
            if destination.exists() or destination.is_symlink():
                raise ValueError(f"new destination is not fresh: {relative}")
            pre_modes[relative] = None

    guard_modes_before = {}
    for relative in GUARD_PATHS:
        path = ACTIVE / relative
        mode = stat.S_IMODE(path.lstat().st_mode)
        if not path.is_file() or path.is_symlink() or not os.access(path, os.X_OK):
            raise ValueError(f"active executable guard differs: {relative}")
        if relative == "integration/validate-sender-wait-snapshot.py" and mode != 0o755:
            raise ValueError("sender snapshot helper is not mode 0755")
        guard_modes_before[relative] = mode
    write_json(evidence / "pre.json", {"active_corpus": before, "change_modes": pre_modes,
                                       "guard_modes": guard_modes_before})

    for item in changes:
        relative = item["path"]
        source = CP10 / relative
        destination = ACTIVE / relative
        destination.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
        mode = pre_modes[relative]
        if mode is None:
            mode = stat.S_IMODE(source.lstat().st_mode)
        temporary = destination.with_name(destination.name + ".cp10-materialize-tmp")
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
        try:
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(source.read_bytes())
                stream.flush()
                os.fsync(stream.fileno())
            os.chmod(temporary, mode)
            os.replace(temporary, destination)
        finally:
            if temporary.exists():
                temporary.unlink()

    current = inventory()
    if current != after:
        raise ValueError("active source does not equal checkpoint 10 after materialization")
    guard_modes_after = {}
    for relative in GUARD_PATHS:
        path = ACTIVE / relative
        mode = stat.S_IMODE(path.lstat().st_mode)
        if (not path.is_file() or path.is_symlink() or not os.access(path, os.X_OK)
                or mode != guard_modes_before[relative]):
            raise ValueError(f"post-materialization executable guard differs: {relative}")
        guard_modes_after[relative] = mode
    write_json(evidence / "post.json", {"active_corpus": current, "change_modes": {
        item["path"]: stat.S_IMODE((ACTIVE / item["path"]).lstat().st_mode) for item in changes},
        "guard_modes": guard_modes_after})
    write_json(evidence / "RESULT.json", {"schema_version": 1, "accepted": True,
        "changed_file_count": len(changes), "cp8_manifest_sha256": CP8_MANIFEST_SHA,
        "cp10_manifest_sha256": CP10_MANIFEST_SHA, "runs_or_provenance_copied": False,
        "snapshot_validator_mode": guard_modes_after["integration/validate-sender-wait-snapshot.py"]})
    (evidence / "direct.status").write_text("0\n", encoding="utf-8")
    with (evidence / "SHA256SUMS.txt").open("x", encoding="utf-8") as stream:
        for path in sorted(evidence.iterdir()):
            if path.is_file() and path.name != "SHA256SUMS.txt":
                stream.write(f"{sha(path)}  {path.name}\n")
    (evidence / "FINAL").write_text("complete\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
