# Combined server-growth and below-TLS raw-write integration

This source-only derivative composes the reviewed server-growth checkpoint 3 runner with the reviewed raw-validator checkpoint 5 sender validator. It does not change the timed `run_transfer` function, schedules, limits, public handlers, transport policy, or runtime source.

The selected agent drain rows carry raw-write activity and are validated in the same pre/post sender boundary. The server validator independently selects the inverse physical tuple for the same lane and stream. The arm validator emits the exact new agent local/remote and server inverse tuple; it does not compare process-local session pointers.

The agent receives one fresh absolute raw terminal sidecar path. The runner calls the existing natural `stop_process` join first, then and only then checks the owned regular 0600 sidecar, runs final-closure validation, and writes a bounded provenance record. Missing, malformed, invalid, or non-naturally joined closure evidence remains preserved and invalidates the arm. There is no polling or timeout extension.

Raw occupancy measures time within the bound raw socket `Write` wrapper, including Go TCP and poller work. It does not identify TLS ciphertext. Residual DATA-envelope time is outside that wrapper but is not uniquely TLS output-lock wait, and concurrent TLS protocol writes are temporal occupancy only.

The final supervisor/coordinator publication remains pending the new audited binary manifest, accepted raw ordinary-proof receipt, and reviewed raw focused receipt. Those external artifacts must be bound before any endpoint execution; this component checkpoint deliberately does not invent their hashes.
