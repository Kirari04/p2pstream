//go:build linux && p2pstream_qualification

package agent

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestExternalQualificationWANSenderWaitControl(t *testing.T) {
	bearer := strings.Repeat("a1", 32)
	owner, err := newExternalQualificationWANSenderWaitOwner("1", bearer, externalQualificationWANSenderWaitSequences)
	if err != nil || owner == nil {
		t.Fatalf("create owner: owner=%v err=%v", owner, err)
	}
	for name, authorization := range map[string]string{
		"missing": "", "raw": bearer, "wrong": "Bearer " + strings.Repeat("b2", 32),
	} {
		t.Run(name, func(t *testing.T) {
			request := httptest.NewRequest(http.MethodGet, "/?wan_sender_wait_snapshot=drain&sequence=9", nil)
			request.Header.Set("Authorization", authorization)
			recorder := httptest.NewRecorder()
			owner.serveDrainHTTP(recorder, request, newExternalQualificationSessionRegistry(5))
			if recorder.Code != http.StatusUnauthorized {
				t.Fatalf("status=%d, want %d", recorder.Code, http.StatusUnauthorized)
			}
		})
	}
	request := httptest.NewRequest(http.MethodGet, "/?wan_sender_wait_snapshot=drain&sequence=9", nil)
	request.Header.Set("Authorization", "Bearer "+bearer)
	recorder := httptest.NewRecorder()
	owner.serveDrainHTTP(recorder, request, newExternalQualificationSessionRegistry(5))
	if recorder.Code != http.StatusOK {
		t.Fatalf("status=%d body=%q", recorder.Code, recorder.Body.String())
	}
	var snapshot externalQualificationGrowthResponse
	if err := json.NewDecoder(recorder.Body).Decode(&snapshot); err != nil {
		t.Fatal(err)
	}
	if snapshot.SchemaVersion != externalQualificationCreditSnapshotSchemaVersion || snapshot.Capacity != 4096 || len(snapshot.SendCounters) != 0 {
		t.Fatalf("unexpected snapshot: %+v", snapshot)
	}
	for _, invalid := range [][3]string{
		{"", bearer, externalQualificationWANSenderWaitSequences},
		{"1", strings.Repeat("A1", 32), externalQualificationWANSenderWaitSequences},
		{"1", bearer, "9,11,13"},
	} {
		if got, err := newExternalQualificationWANSenderWaitOwner(invalid[0], invalid[1], invalid[2]); err == nil || got != nil {
			t.Fatalf("invalid configuration accepted: %#v", invalid)
		}
	}
}
