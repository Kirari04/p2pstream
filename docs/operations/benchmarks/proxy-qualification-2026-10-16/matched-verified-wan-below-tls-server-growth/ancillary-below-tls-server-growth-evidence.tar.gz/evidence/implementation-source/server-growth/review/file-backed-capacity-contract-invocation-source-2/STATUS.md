Source-only and unexecuted. This one-shot offline driver binds checkpoint 10,
the exact old/current runners, frozen failed-sustained and accepted-tiny input
ledgers, two exact large response fixtures, pinned tools and the reviewed owned
process helper. All eight selected capacity/sender control files consumed by
the contract, plus the old runner, owned process helper, and three executable
tools, are bound by exact byte hashes before and after execution. It runs
only the five-case serializer contract in a fresh work
root, requires a natural child/group join without forced cleanup, rechecks all
source and fixture hashes afterward, and preserves every case artifact under a
single records ledger. It starts no endpoint and performs no WAN traffic.
