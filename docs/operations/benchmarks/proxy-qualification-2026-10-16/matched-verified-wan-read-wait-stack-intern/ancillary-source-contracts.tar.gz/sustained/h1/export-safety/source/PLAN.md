# Sustained execution-trace export-safety plan

This source adapts the reviewed H2 smoke 3 export-safety helper at SHA-256
`0398351767466cab06203dc51122b69cb18ccf07a1b1476506ecd2b390751058`
to the closed sustained H1 sequences 9, 11, 14, and 15. It retains the wire
string inventory, exact task/region annotation gate, allowed runtime-label
gate, and in-memory scans for the closed run's agent token, authorization
value, private key and certificate encodings, header names, public host/path,
and payload marker. Secret values, fragments, lengths, and secret-derived
hashes must never be emitted.

The compact run has no persisted expanded parsed text. The adapted helper
therefore reads logical lines through the reviewed, exact-hash
`CanonicalReader` and combines annotation inventory with a bounded streaming
secret/hex scan. It also scans the physical raw, wire, canonical, and reduction
artifacts without loading large artifacts as a single byte string. Canonical
decoding is shared with the diagnostic analyzer; this safety review does not
independently verify the compact format.

The generated trace-control bearer was process-local and was not persisted.
Exact bearer-byte comparison is impossible. Absence of user log events,
constant task/region labels, complete wire-string inventory, and rejection of
lowercase 64-hex runs are supporting controls only; the report must preserve
this limitation.

After the protocol worker releases the CPU slot, the bounded runner will:

1. create one fresh mode-0700 review directory;
2. bind the pinned Go 1.26.6 tool, audit source, format module, and closed index;
3. run `go tool trace -d=wire` once for each exact raw trace, retaining each
   invocation, direct status, stderr, and wire output without retries;
4. run the safety helper once and retain its direct status and report;
5. hash every source, input identity, status, report, and review artifact.

Wire dumps, compact canonical streams, readiness/config/environment logs, TLS
private material, and logically expanded content remain excluded from any
eventual evidence export. If a standalone H2 arm closes later, a separately
hashed path-only/protocol adaptation will be reviewed before execution; H1
results will not be reused as an H2 safety claim.
