#!/usr/bin/env python3
import base64
import hashlib
import importlib.util
import json
import re
from collections import Counter
from pathlib import Path


ROOT = Path("/home/user/.codex/worktrees/astra-proxy-performance/p2pstream")
RUN = ROOT / "tmp/continuation-20261016/wan-read-wait-stack-intern-source/integration-source/runs/sustained-matched-protocol-1/h1"
TLS = RUN.parent / "tls"
REVIEW = ROOT / "tmp/continuation-20261016/wan-read-wait-stack-intern-source/sustained-trace-export-safety-source/runs/sustained-h1-1"
INDEX = RUN / "read-wait-reductions/index.json"
FORMAT_MODULE = ROOT / "tmp/continuation-20261016/wan-read-wait-stack-intern-source/stack_intern_format.py"
FORMAT_MODULE_SHA256 = "f370243b753a94a122157e9b0b13eb535065fe88746269bd70de5475d82e4dbf"
SEQUENCES = (9, 11, 14, 15)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def pem_der(path: Path) -> bytes:
    lines = [line.strip() for line in path.read_bytes().splitlines()]
    payload = b"".join(line for line in lines if line and not line.startswith(b"-----"))
    return base64.b64decode(payload, validate=True)


def quoted_field(line: str, name: str):
    match = re.search(rf"(?:^| ){re.escape(name)}=(\"(?:[^\"\\]|\\.)*\")", line)
    if not match:
        return None
    return json.loads(match.group(1))


def update_inventory(line: str, kinds, inventory):
    main_event = re.compile(r"^M=-?\d+ P=-?\d+ G=-?\d+ ([A-Za-z]+) Time=")
    match = main_event.match(line)
    if not match:
        return
    kind = match.group(1)
    kinds[kind] += 1
    if kind in {"TaskBegin", "TaskEnd"}:
        value = quoted_field(line, "Type")
        if value is not None:
            inventory["task_types"].add(value)
    elif kind in {"RegionBegin", "RegionEnd"}:
        value = quoted_field(line, "Type")
        if value is not None:
            inventory["region_types"].add(value)
    elif kind == "Log":
        category = quoted_field(line, "Category")
        message = quoted_field(line, "Message")
        if category is not None:
            inventory["log_categories"].add(category)
        if message is not None:
            inventory["log_messages"].add(message)
    elif kind == "Label":
        value = quoted_field(line, "Label")
        if value is not None:
            inventory["labels"].add(value)
    elif kind == "StateTransition":
        value = quoted_field(line, "Reason")
        if value is not None:
            inventory["state_reasons"].add(value)
    elif kind == "Metric":
        value = quoted_field(line, "Name")
        if value is not None:
            inventory["metric_names"].add(value)
    elif kind in {"RangeBegin", "RangeActive", "RangeEnd"}:
        value = quoted_field(line, "Name")
        if value is not None:
            inventory["range_names"].add(value)
    elif kind == "Experimental":
        match_name = re.search(r"(?:^| )Name=([^ ]+)", line)
        if match_name:
            inventory["experimental_names"].add(match_name.group(1))


class StreamScanner:
    def __init__(self, needles):
        self.needles = needles
        self.hits = set()
        self.hex64_present = False
        self.tail = b""
        self.overlap = max([64, *(len(value) for _, value in needles if value)]) - 1

    def feed(self, data: bytes):
        combined = self.tail + data
        for label, needle in self.needles:
            if needle and needle in combined:
                self.hits.add(label)
        if hex64.search(combined):
            self.hex64_present = True
        self.tail = combined[-self.overlap:] if self.overlap else b""

    def result(self, label, reject_hex64=False):
        result = {"artifact": label, "unsafe_labels": sorted(self.hits), "accepted": not self.hits}
        if reject_hex64:
            result["ascii_hex64_runs"] = int(self.hex64_present)
            result["accepted"] = result["accepted"] and not self.hex64_present
        return result


def scan_path(label: str, path: Path, needles, reject_hex64=False):
    scanner = StreamScanner(needles)
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            scanner.feed(block)
    return scanner.result(label, reject_hex64)


def load_canonical_reader():
    if sha256(FORMAT_MODULE) != FORMAT_MODULE_SHA256:
        raise ValueError("reviewed canonical format module hash mismatch")
    spec = importlib.util.spec_from_file_location("export_safety_stack_intern_format", FORMAT_MODULE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.CanonicalReader


def canonical_inventory(path: Path, reader_type, needles):
    kinds = Counter()
    inventory = {
        "task_types": set(),
        "region_types": set(),
        "log_categories": set(),
        "log_messages": set(),
        "labels": set(),
        "state_reasons": set(),
        "metric_names": set(),
        "range_names": set(),
        "experimental_names": set(),
    }
    scanner = StreamScanner(needles)
    reader = reader_type(path)
    for raw in reader.iter_lines():
        scanner.feed(raw)
        update_inventory(raw.decode("utf-8", errors="strict"), kinds, inventory)
    if reader.summary is None:
        raise ValueError("canonical reader did not validate a footer")
    return (
        dict(sorted(kinds.items())),
        {key: sorted(values) for key, values in inventory.items()},
        scanner.result("canonical_expanded", reject_hex64=True),
        reader.summary,
    )


def wire_strings(path: Path):
    strings = []
    event_counts = Counter()
    pending_string = False
    with path.open("r", encoding="utf-8", errors="strict") as source:
        for line in source:
            if line and not line[0].isspace():
                event_counts[line.split(" ", 1)[0]] += 1
            if line.startswith("String id="):
                pending_string = True
                continue
            if pending_string:
                if not line.startswith("\tdata="):
                    raise ValueError(f"String record in {path} lacks data line")
                strings.append(json.loads(line[len("\tdata="):]))
                pending_string = False
    if pending_string:
        raise ValueError(f"unterminated String record in {path}")
    return strings, dict(sorted(event_counts.items()))


index = json.loads(INDEX.read_text(encoding="utf-8"))
entries = {int(entry["sequence"]): entry for entry in index["entries"]}
if set(entries) != set(SEQUENCES):
    raise SystemExit("unexpected reduction index sequence set")

# Load sensitive values only into memory. The report records availability and
# match labels, never the values, fragments, lengths, or secret-derived hashes.
runtime_dirs = sorted(RUN.glob("proxy-agent-growth.*"))
if len(runtime_dirs) != 1:
    raise SystemExit("expected exactly one proxy-agent-growth runtime directory")
ready_paths = sorted(runtime_dirs[0].glob("*-server.ready.json"))
if len(ready_paths) != 1:
    raise SystemExit("expected exactly one server readiness record")
ready_path = ready_paths[0]
agent_token = json.loads(ready_path.read_text(encoding="utf-8"))["agents"][0]["token"].encode()
private_key_path = TLS / "public.test.key.pem"
certificate_path = TLS / "public.test.crt.pem"
private_key_pem = private_key_path.read_bytes()
private_key_der = pem_der(private_key_path)
certificate_pem = certificate_path.read_bytes()
certificate_der = pem_der(certificate_path)
private_key_body = b"".join(line.strip() for line in private_key_pem.splitlines() if line and not line.startswith(b"-----"))
certificate_body = b"".join(line.strip() for line in certificate_pem.splitlines() if line and not line.startswith(b"-----"))

needles = [
    ("agent_auth_token", agent_token),
    ("agent_authorization_value", b"Bearer " + agent_token),
    ("private_key_pem", private_key_pem),
    ("private_key_der", private_key_der),
    ("private_key_base64_body", private_key_body),
    ("certificate_pem", certificate_pem),
    ("certificate_der", certificate_der),
    ("certificate_base64_body", certificate_body),
    ("authorization_header_name", b"Authorization"),
    ("diagnostic_sequence_header_name", b"X-Qualification-Diagnostic-Sequence"),
    ("public_host_header_value", b"public.test"),
    ("public_request_path", b"/agent/bulk"),
    ("payload_marker", b"p2pstream-qualification-payload-"),
    ("payload_marker_repeated", b"p2pstream-qualification-payload-" * 8),
]

# A generated trace bearer is intentionally process-local and was not persisted
# by this runner. Cover accidental ASCII serialization independently by rejecting
# any 64-character lowercase hexadecimal run in raw, wire, or parsed trace data.
hex64 = re.compile(rb"(?<![0-9a-f])[0-9a-f]{64}(?![0-9a-f])")

report = {
    "schema_version": 1,
    "review_kind": "offline-go-execution-trace-export-safety",
    "source_run": str(RUN),
    "index": {"path": str(INDEX), "sha256": sha256(INDEX)},
    "secret_handling": {
        "values_emitted": False,
        "secret_derived_hashes_emitted": False,
        "agent_auth_token_loaded": True,
        "private_key_loaded": True,
        "certificate_loaded": True,
        "trace_bearer_recovered": False,
        "trace_bearer_limitation": "generated process-local bearer was not persisted in the closed sustained H1 run; generic ASCII hex64 rejection and annotation inventory cover accidental text serialization, but exact decoded-byte comparison is unavailable",
    },
    "expected_annotations": {
        "task_types": ["wan-read-wait-request"],
        "region_types": ["public-proxy-handler"],
        "event_logs": 0,
    },
    "entries": [],
}

all_accepted = True
canonical_reader = load_canonical_reader()
for sequence in SEQUENCES:
    entry = entries[sequence]
    raw = Path(entry["raw_path"])
    canonical = Path(entry["canonical_path"])
    reduction = Path(entry["reduction_path"])
    parser_status_path = Path(entry["parser_status_path"])
    canonicalizer_status_path = Path(entry["canonicalizer_status_path"])
    adapter_status_path = Path(entry["adapter_status_path"])
    analyzer_status_path = Path(entry["analyzer_status_path"])
    wire = REVIEW / f"sequence-{sequence}.wire.txt"
    wire_status_path = REVIEW / f"sequence-{sequence}.wire.status"
    wire_stderr = REVIEW / f"sequence-{sequence}.wire.stderr.log"

    raw_hash = sha256(raw)
    canonical_hash = sha256(canonical)
    reduction_hash = sha256(reduction)
    parser_status = parser_status_path.read_text(encoding="ascii").strip()
    canonicalizer_status = canonicalizer_status_path.read_text(encoding="ascii").strip()
    adapter_status = adapter_status_path.read_text(encoding="ascii").strip()
    analyzer_status = analyzer_status_path.read_text(encoding="ascii").strip()
    if analyzer_status not in {"0", "1"}:
        raise ValueError(f"unexpected analyzer status for sequence {sequence}: {analyzer_status!r}")
    wire_status = wire_status_path.read_text(encoding="ascii").strip()
    strings, wire_event_counts = wire_strings(wire)
    logical_event_counts, annotations, expanded_scan, canonical_summary = canonical_inventory(
        canonical, canonical_reader, needles
    )

    scans = [
        scan_path("raw", raw, needles, reject_hex64=True),
        scan_path("wire", wire, needles, reject_hex64=True),
        scan_path("canonical", canonical, needles, reject_hex64=True),
        expanded_scan,
        scan_path("reduction", reduction, needles),
    ]

    exact_annotations = (
        annotations["task_types"] == ["wan-read-wait-request"]
        and annotations["region_types"] == ["public-proxy-handler"]
        and logical_event_counts.get("TaskBegin") == 1
        and logical_event_counts.get("TaskEnd") == 1
        and logical_event_counts.get("RegionBegin") == 1
        and logical_event_counts.get("RegionEnd") == 1
        and logical_event_counts.get("Log", 0) == 0
        and not annotations["log_categories"]
        and not annotations["log_messages"]
    )
    labels_allowed = set(annotations["labels"]).issubset({"Not worker", "GC (dedicated)", "GC (fractional)", "GC (idle)"})
    string_controls = {
        "count": len(strings),
        "unique_count": len(set(strings)),
        "all_utf8": True,
        "contains_nul": any("\x00" in value for value in strings),
        "max_utf8_bytes": max((len(value.encode("utf-8")) for value in strings), default=0),
        "exact_task_name_present": "wan-read-wait-request" in strings,
        "exact_region_name_present": "public-proxy-handler" in strings,
        "ascii_hex64_values": sum(1 for value in strings if re.fullmatch(r"[0-9a-f]{64}", value)),
    }
    string_controls["accepted"] = (
        not string_controls["contains_nul"]
        and string_controls["exact_task_name_present"]
        and string_controls["exact_region_name_present"]
        and string_controls["ascii_hex64_values"] == 0
    )

    accepted = (
        raw_hash == entry["raw_sha256"]
        and canonical_hash == entry["canonical_sha256"]
        and reduction_hash == entry["reduction_sha256"]
        and sha256(adapter_status_path) == entry["adapter_status_sha256"]
        and sha256(parser_status_path) == entry["parser_status_sha256"]
        and sha256(canonicalizer_status_path) == entry["canonicalizer_status_sha256"]
        and sha256(analyzer_status_path) == entry["analyzer_status_sha256"]
        and adapter_status == canonicalizer_status == parser_status == "0"
        and wire_status == "0"
        and wire_stderr.stat().st_size == 0
        and exact_annotations
        and labels_allowed
        and string_controls["accepted"]
        and all(scan["accepted"] for scan in scans)
    )
    all_accepted = all_accepted and accepted
    report["entries"].append({
        "sequence": sequence,
        "protocol": entry["public_protocol"],
        "raw": {"path": str(raw), "sha256": raw_hash, "bytes": raw.stat().st_size, "index_hash_match": raw_hash == entry["raw_sha256"]},
        "canonical": {"path": str(canonical), "sha256": canonical_hash, "bytes": canonical.stat().st_size, "index_hash_match": canonical_hash == entry["canonical_sha256"], "reader_summary": canonical_summary},
        "adapter_status": int(adapter_status),
        "adapter_status_sha256": sha256(adapter_status_path),
        "parser_status": int(parser_status),
        "parser_status_sha256": sha256(parser_status_path),
        "canonicalizer_status": int(canonicalizer_status),
        "canonicalizer_status_sha256": sha256(canonicalizer_status_path),
        "reduction": {"path": str(reduction), "sha256": reduction_hash, "bytes": reduction.stat().st_size, "index_hash_match": reduction_hash == entry["reduction_sha256"], "original_analyzer_status": int(analyzer_status), "original_analyzer_status_path": str(analyzer_status_path), "original_analyzer_status_sha256": sha256(analyzer_status_path)},
        "wire": {"path": str(wire), "sha256": sha256(wire), "bytes": wire.stat().st_size, "status": int(wire_status), "stderr_bytes": wire_stderr.stat().st_size},
        "wire_event_counts": wire_event_counts,
        "logical_event_counts": logical_event_counts,
        "annotation_and_runtime_strings": annotations,
        "wire_string_controls": string_controls,
        "sensitive_content_scans": scans,
        "exact_annotations_accepted": exact_annotations,
        "runtime_labels_accepted": labels_allowed,
        "accepted_for_export_safety": accepted,
    })

report["accepted"] = all_accepted
report["export_scope"] = {
    "safe_if_packaged_with_hashes": [
        "four raw runtime trace files",
        "four original rejected reduction JSON files with their exact analyzer statuses",
        "adapter, parser, canonicalizer, and analyzer status sidecars",
        "this export-safety report and its source/provenance manifest",
    ],
    "omit_by_default": [
        "four compact canonical traces and their logically expanded content",
        "four wire dumps (review intermediates)",
    ],
    "disclosed_metadata": [
        "whole-server scheduler and timing events",
        "goroutine/thread/proc identifiers",
        "GC/heap metrics and concurrency",
        "function names and absolute source, build, and module-cache paths",
        "Go trace wall-clock synchronization",
    ],
    "causal_limit": "all four original analyzer statuses remain rejected because positive waiting intervals lack TransitionStack; export safety neither validates causal attribution nor replaces those status records",
}

destination = REVIEW / "export-safety-report.json"
with destination.open("x", encoding="utf-8") as output:
    json.dump(report, output, indent=2, sort_keys=True)
    output.write("\n")
raise SystemExit(0 if all_accepted else 1)
