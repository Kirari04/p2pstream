#!/usr/bin/env bash
set -uo pipefail

root=/home/user/.codex/worktrees/astra-proxy-performance/p2pstream
source_root=$root/tmp/continuation-20261016/wan-read-wait-stack-intern-source/sustained-trace-export-safety-source
run=$root/tmp/continuation-20261016/wan-read-wait-stack-intern-source/integration-source/runs/sustained-matched-protocol-1/h1
review=$source_root/runs/sustained-h1-1
index=$run/read-wait-reductions/index.json
format=$root/tmp/continuation-20261016/wan-read-wait-stack-intern-source/stack_intern_format.py
go=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
audit=$source_root/audit_trace_export.py

if [[ -e $review ]]; then
  echo "review output must be fresh: $review" >&2
  exit 2
fi
mkdir -m 0700 -p "$source_root/runs"
mkdir -m 0700 "$review" || exit $?

sha256sum "$go" "$audit" "$format" "$index" > "$review/preflight.sha256"
if [[ $(sha256sum "$go" | awk '{print $1}') != 29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45 ||
      $(sha256sum "$audit" | awk '{print $1}') != 6ab0c4f9523e4348dfcd1d478df9d0b34fb7950014a8c886eaccb4e97e7a6d88 ||
      $(sha256sum "$format" | awk '{print $1}') != f370243b753a94a122157e9b0b13eb535065fe88746269bd70de5475d82e4dbf ||
      $(sha256sum "$index" | awk '{print $1}') != 43e4f9dc7be2dda55b7e388c2dbc951a2ff8f87a4b0b7ac758f4dcb152863dc4 ]]; then
  echo "pinned tool/source/index hash mismatch" >&2
  exit 2
fi

wire_all_status=0
for sequence in 9 11 14 15; do
  raw=$run/results.read-wait-traces/runtime-trace-sequence-${sequence}.out
  wire=$review/sequence-${sequence}.wire.txt
  stderr=$review/sequence-${sequence}.wire.stderr.log
  status_file=$review/sequence-${sequence}.wire.status
  printf '%q ' env -i HOME=/home/user PATH=/usr/bin:/bin GOENV=off GOTOOLCHAIN=local \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 TZ=Europe/Zurich "$go" tool trace -d=wire "$raw" \
    > "$review/sequence-${sequence}.wire.invocation.txt"
  printf '\n' >> "$review/sequence-${sequence}.wire.invocation.txt"
  set +e
  env -i HOME=/home/user PATH=/usr/bin:/bin GOENV=off GOTOOLCHAIN=local \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 TZ=Europe/Zurich \
    "$go" tool trace -d=wire "$raw" > "$wire" 2> "$stderr"
  status=$?
  set -e
  printf '%s\n' "$status" > "$status_file"
  ((status == 0)) || wire_all_status=1
done

printf '%q ' /usr/bin/python3.14 "$audit" > "$review/audit.invocation.txt"
printf '\n' >> "$review/audit.invocation.txt"
set +e
/usr/bin/python3.14 "$audit" > "$review/audit.stdout.log" 2> "$review/audit.stderr.log"
audit_status=$?
set -e
printf '%s\n' "$audit_status" > "$review/audit.status"

sha256sum "$go" "$audit" "$format" "$index" > "$review/postflight.sha256"
source_stable=0
cmp "$review/preflight.sha256" "$review/postflight.sha256" >/dev/null && source_stable=1
final_status=1
if ((wire_all_status == 0 && audit_status == 0 && source_stable == 1)); then
  final_status=0
fi
printf '%s\n' "$wire_all_status" > "$review/wire-all.status"
printf '%s\n' "$source_stable" > "$review/source-stable.status"
printf '%s\n' "$final_status" > "$review/final.status"
printf 'SUSTAINED_H1_EXPORT_SAFETY_STATUS=%s REVIEW=%s\n' "$final_status" "$review"
exit "$final_status"
