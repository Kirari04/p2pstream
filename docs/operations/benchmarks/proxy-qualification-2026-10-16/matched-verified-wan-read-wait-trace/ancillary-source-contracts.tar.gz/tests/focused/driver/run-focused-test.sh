#!/usr/bin/env bash
set -Eeuo pipefail

mode=${1:?normal or race required}
root=$(cd "$(dirname "$0")/.." && pwd)
source_dir="$root/build/source"
go_binary=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
record="$root/provenance/focused-tests/$mode-attempt1"
tmpdir="$root/build/focused-test-tmp-$mode"
gocache="$root/build/focused-test-cache-$mode"
pattern='^(TestQualificationWANReadWait|TestProxyCopyAttribution|TestProxyResponseRecorderCopyAttribution|TestQualificationWANCopyAttribution|TestQualificationWANLoadTransportHistoricalDisabled|TestQualificationWANVerifiedProtocolNegotiation|TestQualificationWANVerifiedTLSFailures|TestQualificationWANForcedH2DoesNotFallback|TestQualificationWANTraceStoreBoundedAndComposes)'
case "$mode" in
  normal) race=(); timeout=180s ;;
  race) race=(-race); timeout=300s ;;
  *) echo "mode must be normal or race" >&2; exit 2 ;;
esac
[[ ! -e $record ]] || { echo "focused-test record already exists: $record" >&2; exit 2; }
[[ $(sha256sum "$go_binary" | awk '{print $1}') == 29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45 ]]
[[ $($go_binary version) == 'go version go1.26.6 linux/amd64' ]]
mkdir -p "$record" "$tmpdir" "$gocache"

source_manifest() {
  local destination=$1
  python3 - "$source_dir" "$destination" <<'PY'
import hashlib, json, pathlib, sys
root, destination = map(pathlib.Path, sys.argv[1:])
files = {}
for path in sorted(root.rglob('*')):
    if path.is_file():
        digest = hashlib.sha256()
        with path.open('rb') as source:
            for block in iter(lambda: source.read(1024 * 1024), b''):
                digest.update(block)
        files[str(path.relative_to(root))] = digest.hexdigest()
destination.write_text(json.dumps({'schema_version': 1, 'root': str(root), 'files': files}, indent=2, sort_keys=True) + '\n')
PY
}

source_manifest "$record/source-pre.json"
printf '%s\n' "$source_dir" > "$record/working-directory.txt"
printf '%s\n' 'taskset_cpu_list=0-3' 'GOMAXPROCS=4' > "$record/resource-bounds.txt"
sha256sum "$go_binary" > "$record/toolchain-pre.sha256"
"$go_binary" version > "$record/go-version.txt"
cat > "$record/environment.txt" <<ENV
HOME=/home/user
PATH=/usr/bin:/bin
TMPDIR=$tmpdir
GOCACHE=$gocache
GOENV=off
GOTOOLCHAIN=local
GOWORK=off
GOFLAGS=
CGO_ENABLED=1
GOMAXPROCS=4
ENV
cd "$source_dir"
env -i HOME=/home/user PATH=/usr/bin:/bin TMPDIR="$tmpdir" GOCACHE="$gocache" GOENV=off GOTOOLCHAIN=local GOWORK=off GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=4 \
  "$go_binary" env -json > "$record/go-env-from-test-cwd.json"
printf '%q ' taskset -c 0-3 env -i HOME=/home/user PATH=/usr/bin:/bin TMPDIR="$tmpdir" GOCACHE="$gocache" GOENV=off GOTOOLCHAIN=local GOWORK=off GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=4 \
  "$go_binary" test "${race[@]}" ./internal/server -run "$pattern" -count=1 -timeout="$timeout" > "$record/invocation.txt"
printf '\n' >> "$record/invocation.txt"
set +e
taskset -c 0-3 env -i HOME=/home/user PATH=/usr/bin:/bin TMPDIR="$tmpdir" GOCACHE="$gocache" GOENV=off GOTOOLCHAIN=local GOWORK=off GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=4 \
  "$go_binary" test "${race[@]}" ./internal/server -run "$pattern" -count=1 -timeout="$timeout" \
  > "$record/stdout.log" 2> "$record/stderr.log"
status=$?
set -e
printf '%s\n' "$status" > "$record/inner.status"
source_manifest "$record/source-post.json"
sha256sum "$go_binary" > "$record/toolchain-post.sha256"
set +e
cmp "$record/source-pre.json" "$record/source-post.json" > "$record/source-pre-post.stdout.log" 2> "$record/source-pre-post.stderr.log"
source_status=$?
cmp "$record/toolchain-pre.sha256" "$record/toolchain-post.sha256" > "$record/toolchain-pre-post.stdout.log" 2> "$record/toolchain-pre-post.stderr.log"
toolchain_status=$?
set -e
printf '%s\n' "$source_status" > "$record/source-pre-post.status"
printf '%s\n' "$toolchain_status" > "$record/toolchain-pre-post.status"
python3 - "$record/attestation.json" "$mode" "$status" "$source_status" "$toolchain_status" "$record" <<'PY'
import hashlib, json, pathlib, sys, time
out, mode, status, source_status, toolchain_status, record = sys.argv[1:]
record = pathlib.Path(record)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
value = {
  'schema_version': 1, 'mode': mode, 'inner_status': int(status),
  'source_pre_post_status': int(source_status), 'toolchain_pre_post_status': int(toolchain_status),
  'persistent_test_binary': False, 'traffic_run': False,
  'finished_unix_ns': time.time_ns(),
  'sha256': {p.name: sha(p) for p in sorted(record.iterdir()) if p.is_file() and p.name != 'attestation.json'},
}
value['accepted'] = all(value[k] == 0 for k in ('inner_status','source_pre_post_status','toolchain_pre_post_status'))
pathlib.Path(out).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
PY
printf '%s\n' complete > "$record/FINAL"
((status == 0 && source_status == 0 && toolchain_status == 0))
