#!/bin/sh
cd /home/user/.codex/worktrees/astra-proxy-performance/p2pstream
bash tmp/continuation-20261016/wan-read-wait-source/provenance/run-focused-test.sh normal
