# Pinned parsed-trace reducer source checkpoint

Status: source only. The reducer and fixtures have not been executed. No raw
trace has been parsed and no build, test, endpoint, or workload was run.

`analyze_parsed_trace.py` accepts only the debug text emitted by pinned Go
1.26.6 `go tool trace -d=parsed`. It makes two streaming passes over a regular
file: one to bind exactly one `wan-read-wait-request` task and one nested
`public-proxy-handler` region, and one to partition only that region's handler
goroutine. The 512 MiB input, 1 MiB line, 5,000,000 event, 4,096 continuation,
4 MiB event, 4,096 distinct wait-stack, eight top-wait, and 8 MiB output bounds
are fixed in source. Each line uses a size-limited `readline`; ordinary and
transition stacks must be complete pinned-format function/file pairs. The input
must remain the same regular-file identity and SHA-256 across both parser
passes. The output is a fresh mode-0600 file.

Pinned `internal/trace/event.go:316-320` emits a newline after each printed
stack frame, and `cmd/trace/main.go:336-349` prints the resulting event string
with `fmt.Println`. The reducer therefore consumes the exact empty separator
line after a stacked event while still charging it to line, continuation, and
event-byte bounds.

The reducer also requires a separate parser-status file whose entire content is
exactly `0\n`. `debugProcessedEvents` returns non-EOF reader errors, so the
offline launcher must run the pinned tool without a status-masking pipeline,
persist its direct exit status, and keep partial stdout on failure. A nonzero,
missing, or malformed status makes the reduction invalid even when the partial
text happens to contain complete-looking markers.

The reducer keys every state transition by the transition's `GoID`. It never
uses the event-header `G` as the transitioned goroutine; the fixture includes
an unblock whose header `G=77` and resource `GoID=42`. Task and region begin/end
IDs, types, event-header handler GID, nesting, and positive duration must match
exactly; task begin/end must run on the same GID as both region markers. The
handler state comes from the last matching transition at or before the region
begin. Intervals are clipped to the region and Running, Runnable, Syscall, and
Waiting must exactly conserve its wall duration. Event timestamps must be
nondecreasing. Equal-time events retain stream order, and zero-duration state
intervals remain counted. Go `%q` fields use an explicit pinned-format
unquoter; unsupported byte escapes reject instead of being treated as JSON.

Waiting time is grouped independently by entry reason, full raw stack
fingerprint, and a small source-path classifier. A Yamux empty-receive label
requires reason `select` plus the pinned `yamux.(*Stream).Read` frame at
`third_party/yamux/stream.go:207`; a `Stream.Read` ancestor at a lock callsite
remains unknown. Nested credit/growth/owner paths use the leaf-most matching
frame, with stable same-depth precedence. Missing stacks are explicit and
invalidate the result. Unrecognized stacks remain `waiting_unknown_stack`;
they make `attribution_complete` false without falsifying an otherwise complete
state partition. No time from transport, Yamux reader, growth owner, or any
other goroutine is added to request wall time.

The categories are observational. `waiting_yamux_empty_receive` shows that the
handler parked at the pinned empty-receive select; it does not establish
peer-credit, TCP, buffering, or scheduler cause. Credit-publication,
growth/reservation, or adaptive-owner labels likewise require the handler's
own Waiting-entry stack.

The `fixtures/contract.json` file declares the expected outcome of each small
synthetic parsed-text fixture. They cover a positive exact partition, an
unblock where header G differs from resource GoID, duplicate markers, missing
Waiting stack, task/region GID mismatch, a Stream.Read lock that must remain
unknown, nested classifier precedence, equal-time order, and an old-state
conservation failure.
They are review inputs only at this checkpoint.

`accepted` in the reducer output means only that the pinned parsed stream and
handler partition satisfy this local contract. A cohort validator must still
join the trace capture and transfer row on the exact sequence, server binary,
source, runner, public protocol, certificate, and origin identities. It must
also require capture validity, payload/protocol exactness, the owned resource
and lifecycle contracts, and the pinned Go binary/tool command and hashes.
Trace-region nanoseconds must not be compared for exact equality with the copy
observer's `time.Now`/`Sub` duration: their boundaries and precision differ.
Read/write and handler-wait durations are descriptive evidence only.
