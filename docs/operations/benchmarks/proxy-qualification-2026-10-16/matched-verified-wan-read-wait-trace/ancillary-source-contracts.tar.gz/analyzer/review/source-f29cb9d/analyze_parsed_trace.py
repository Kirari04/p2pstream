#!/usr/bin/env python3
"""Reduce pinned Go 1.26.6 `go tool trace -d=parsed` output.

This parser is intentionally tied to Event.String in the pinned toolchain.  It
reads the input twice, one event at a time: first to bind the unique task and
region, then to partition only that region's handler goroutine state.
"""

from __future__ import annotations

import argparse
import hashlib
import heapq
import json
import os
from pathlib import Path
import re
import sys
from typing import Iterator


TASK_TYPE = "wan-read-wait-request"
REGION_TYPE = "public-proxy-handler"
MAX_INPUT_BYTES = 512 * 1024 * 1024
MAX_OUTPUT_BYTES = 8 * 1024 * 1024
MAX_LINE_BYTES = 1024 * 1024
MAX_EVENTS = 5_000_000
MAX_EVENT_CONTINUATIONS = 4096
MAX_WAIT_STACK_GROUPS = 4096
TOP_WAIT_COUNT = 8

HEADER_RE = re.compile(
    rb"^M=(-?\d+) P=(-?\d+) G=(-?\d+) ([A-Za-z]+) Time=(\d+)(?: (.*))?\n?$"
)
QUOTED = rb'"((?:[^"\\]|\\.)*)"'
TASK_RE = re.compile(rb"^ID=(\d+) Parent=(\d+) Type=" + QUOTED + rb"$")
REGION_RE = re.compile(rb"^Task=(\d+) Type=" + QUOTED + rb"$")
TRANSITION_RE = re.compile(
    rb"^GoID=(\d+) ([A-Za-z]+)->([A-Za-z]+) Reason=" + QUOTED + rb"$"
)


class InvalidTrace(Exception):
    pass


def decode_quoted(raw: bytes) -> str:
    try:
        return json.loads(b'"' + raw + b'"')
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise InvalidTrace(f"invalid quoted field: {error}") from error


def event_stream(path: Path) -> Iterator[dict]:
    count = 0
    current = None
    continuation_count = 0
    section = None
    with path.open("rb", buffering=1024 * 1024) as stream:
        for line_number, line in enumerate(stream, 1):
            if len(line) > MAX_LINE_BYTES:
                raise InvalidTrace(f"line {line_number} exceeds fixed line bound")
            match = HEADER_RE.match(line)
            if match:
                if current is not None:
                    yield current
                count += 1
                if count > MAX_EVENTS:
                    raise InvalidTrace("event count exceeds fixed bound")
                current = {
                    "order": count,
                    "m": int(match.group(1)),
                    "p": int(match.group(2)),
                    "g": int(match.group(3)),
                    "kind": match.group(4).decode("ascii"),
                    "time": int(match.group(5)),
                    "fields": match.group(6) or b"",
                    "transition_stack": [],
                    "event_stack": [],
                }
                continuation_count = 0
                section = None
                continue
            if current is None:
                raise InvalidTrace(f"continuation before first event at line {line_number}")
            continuation_count += 1
            if continuation_count > MAX_EVENT_CONTINUATIONS:
                raise InvalidTrace(f"event at line {line_number} exceeds continuation bound")
            stripped = line.rstrip(b"\n")
            if stripped == b"TransitionStack=":
                section = "transition"
            elif stripped == b"Stack=":
                section = "event"
            elif section == "transition":
                current["transition_stack"].append(stripped.decode("utf-8", "strict"))
            elif section == "event":
                current["event_stack"].append(stripped.decode("utf-8", "strict"))
            elif stripped:
                raise InvalidTrace(f"unrecognized event continuation at line {line_number}")
    if current is not None:
        yield current
    if count == 0:
        raise InvalidTrace("parsed trace has no events")


def position(event: dict) -> tuple[int, int]:
    return event["time"], event["order"]


def parse_task(event: dict) -> dict | None:
    if event["kind"] not in ("TaskBegin", "TaskEnd"):
        return None
    match = TASK_RE.match(event["fields"])
    if not match:
        raise InvalidTrace(f"malformed {event['kind']} fields")
    return {"id": int(match.group(1)), "parent": int(match.group(2)), "type": decode_quoted(match.group(3))}


def parse_region(event: dict) -> dict | None:
    if event["kind"] not in ("RegionBegin", "RegionEnd"):
        return None
    match = REGION_RE.match(event["fields"])
    if not match:
        raise InvalidTrace(f"malformed {event['kind']} fields")
    return {"task": int(match.group(1)), "type": decode_quoted(match.group(2))}


def parse_transition(event: dict) -> dict | None:
    if event["kind"] != "StateTransition":
        return None
    match = TRANSITION_RE.match(event["fields"])
    if not match:
        # Proc transitions have ProcID rather than GoID and are irrelevant.
        if event["fields"].startswith(b"ProcID="):
            return None
        raise InvalidTrace("malformed goroutine StateTransition fields")
    return {
        "goid": int(match.group(1)),
        "old": match.group(2).decode("ascii"),
        "new": match.group(3).decode("ascii"),
        "reason": decode_quoted(match.group(4)),
        "stack": event["transition_stack"],
        "header_g": event["g"],
        "time": event["time"],
        "order": event["order"],
    }


def bind_markers(path: Path) -> dict:
    task_begins, task_ends, region_begins, region_ends = [], [], [], []
    event_count = 0
    for event in event_stream(path):
        event_count = event["order"]
        task = parse_task(event)
        if task and task["type"] == TASK_TYPE:
            (task_begins if event["kind"] == "TaskBegin" else task_ends).append((event, task))
        region = parse_region(event)
        if region and region["type"] == REGION_TYPE:
            (region_begins if event["kind"] == "RegionBegin" else region_ends).append((event, region))
        if max(len(task_begins), len(task_ends), len(region_begins), len(region_ends)) > 1:
            raise InvalidTrace("duplicate fixed task or region marker")
    if tuple(map(len, (task_begins, task_ends, region_begins, region_ends))) != (1, 1, 1, 1):
        raise InvalidTrace("missing or incomplete fixed task/region markers")
    task_begin, begin_fields = task_begins[0]
    task_end, end_fields = task_ends[0]
    region_begin, region_begin_fields = region_begins[0]
    region_end, region_end_fields = region_ends[0]
    task_id = begin_fields["id"]
    if task_id == 0 or end_fields["id"] != task_id:
        raise InvalidTrace("task begin/end ID mismatch or background task")
    if region_begin_fields["task"] != task_id or region_end_fields["task"] != task_id:
        raise InvalidTrace("region task ID mismatch")
    if region_begin["g"] <= 0 or region_end["g"] != region_begin["g"]:
        raise InvalidTrace("region handler GID mismatch")
    if not (position(task_begin) < position(region_begin) < position(region_end) < position(task_end)):
        raise InvalidTrace("task/region markers are not strictly nested")
    if region_end["time"] <= region_begin["time"]:
        raise InvalidTrace("region has nonpositive wall duration")
    return {
        "task_id": task_id,
        "handler_gid": region_begin["g"],
        "task_begin": position(task_begin),
        "task_end": position(task_end),
        "region_begin": position(region_begin),
        "region_end": position(region_end),
        "event_count": event_count,
    }


def classify_wait(stack: list[str]) -> str:
    if not stack:
        return "waiting_missing_stack"
    text = "\n".join(stack)
    if "(*GrowingConn).grow" in text or "(*AggregateReceiveWindowGrowth).Grow" in text:
        return "waiting_growth_or_reservation"
    if "sendWindowUpdate" in text or "waitForSendErr" in text or "GrowReceiveWindow" in text:
        return "waiting_credit_publication"
    if "adaptive" in text.lower() and ("owner" in text.lower() or "reserve" in text.lower()):
        return "waiting_adaptive_owner"
    if "yamux.(*Stream).Read" in text or "third_party/yamux.(*Stream).Read" in text:
        return "waiting_yamux_receive"
    return "waiting_unknown_stack"


def reduce_states(path: Path, markers: dict) -> dict:
    gid = markers["handler_gid"]
    begin = markers["region_begin"]
    end = markers["region_end"]
    current_state = None
    current_wait = None
    cursor = begin[0]
    state_totals = {name: 0 for name in ("Running", "Runnable", "Syscall", "Waiting")}
    wait_categories: dict[str, int] = {}
    wait_reasons: dict[str, int] = {}
    wait_stacks: dict[tuple[str, str], dict] = {}
    top_waits: list[tuple[int, int, dict]] = []
    transition_count = 0
    unblock_header_gid_diff = 0
    serial = 0

    def add_interval(state: str, start: int, finish: int, wait: dict | None) -> None:
        nonlocal serial
        if finish < start:
            raise InvalidTrace("negative state interval")
        duration = finish - start
        if state not in state_totals:
            raise InvalidTrace(f"unsupported handler state inside region: {state}")
        state_totals[state] += duration
        if state != "Waiting" or duration == 0:
            return
        if wait is None:
            raise InvalidTrace("waiting interval lacks entry metadata")
        reason = wait["reason"]
        category = classify_wait(wait["stack"])
        wait_categories[category] = wait_categories.get(category, 0) + duration
        wait_reasons[reason] = wait_reasons.get(reason, 0) + duration
        fingerprint = hashlib.sha256("\n".join(wait["stack"]).encode()).hexdigest()
        key = (reason, fingerprint)
        if key not in wait_stacks:
            if len(wait_stacks) >= MAX_WAIT_STACK_GROUPS:
                raise InvalidTrace("wait stack group count exceeds fixed bound")
            wait_stacks[key] = {
                "reason": reason,
                "stack_sha256": fingerprint,
                "stack": wait["stack"],
                "category": category,
                "count": 0,
                "duration_ns": 0,
            }
        group = wait_stacks[key]
        group["count"] += 1
        group["duration_ns"] += duration
        detail = {
            "start_ns": start,
            "end_ns": finish,
            "duration_ns": duration,
            "reason": reason,
            "category": category,
            "stack_sha256": fingerprint,
        }
        serial += 1
        item = (duration, serial, detail)
        if len(top_waits) < TOP_WAIT_COUNT:
            heapq.heappush(top_waits, item)
        elif item[:2] > top_waits[0][:2]:
            heapq.heapreplace(top_waits, item)

    for event in event_stream(path):
        transition = parse_transition(event)
        if transition is None or transition["goid"] != gid:
            continue
        where = transition["time"], transition["order"]
        if where <= begin:
            current_state = transition["new"]
            current_wait = transition if current_state == "Waiting" else None
            continue
        if where >= end:
            continue
        if current_state is None:
            raise InvalidTrace("handler state not established at region start")
        transition_count += 1
        if transition["old"] != current_state:
            raise InvalidTrace("handler transition old state disagrees with partition state")
        add_interval(current_state, cursor, transition["time"], current_wait)
        cursor = transition["time"]
        current_state = transition["new"]
        current_wait = transition if current_state == "Waiting" else None
        if transition["new"] == "Runnable" and transition["header_g"] != gid:
            unblock_header_gid_diff += 1
    if current_state is None:
        raise InvalidTrace("handler state not established at region start")
    add_interval(current_state, cursor, end[0], current_wait)

    region_duration = end[0] - begin[0]
    partition_sum = sum(state_totals.values())
    waiting_sum = sum(wait_categories.values())
    if partition_sum != region_duration:
        raise InvalidTrace("state partition does not exactly conserve region duration")
    if waiting_sum != state_totals["Waiting"]:
        raise InvalidTrace("waiting classification does not exactly conserve waiting duration")
    missing_stack_ns = wait_categories.get("waiting_missing_stack", 0)
    unknown_stack_ns = wait_categories.get("waiting_unknown_stack", 0)
    groups = sorted(wait_stacks.values(), key=lambda value: (-value["duration_ns"], value["stack_sha256"]))
    return {
        "region_duration_ns": region_duration,
        "partition_sum_ns": partition_sum,
        "partition_delta_ns": partition_sum - region_duration,
        "state_ns": state_totals,
        "waiting_category_ns": dict(sorted(wait_categories.items())),
        "waiting_reason_ns": dict(sorted(wait_reasons.items())),
        "waiting_stack_groups": groups,
        "top_wait_intervals": [item[2] for item in sorted(top_waits, reverse=True)],
        "handler_transition_count": transition_count,
        "unblock_header_gid_diff_count": unblock_header_gid_diff,
        "missing_stack_ns": missing_stack_ns,
        "unknown_stack_ns": unknown_stack_ns,
        "attribution_complete": missing_stack_ns == 0 and unknown_stack_ns == 0,
    }


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb", buffering=1024 * 1024) as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--tool-status", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    arguments = parser.parse_args()
    source = arguments.input.resolve(strict=True)
    tool_status_path = arguments.tool_status.resolve(strict=False)
    output = arguments.output.resolve(strict=False)
    if output.exists():
        raise SystemExit("output already exists")
    size = source.stat().st_size
    result = {
        "schema_version": 1,
        "accepted": False,
        "task_type": TASK_TYPE,
        "region_type": REGION_TYPE,
        "input": str(source),
        "input_bytes": size,
        "parsed_tool_status_file": str(tool_status_path),
        "fixed_bounds": {
            "max_input_bytes": MAX_INPUT_BYTES,
            "max_line_bytes": MAX_LINE_BYTES,
            "max_events": MAX_EVENTS,
            "max_event_continuations": MAX_EVENT_CONTINUATIONS,
            "max_wait_stack_groups": MAX_WAIT_STACK_GROUPS,
            "max_output_bytes": MAX_OUTPUT_BYTES,
        },
        "errors": [],
    }
    try:
        if tool_status_path.stat().st_size != 2:
            raise InvalidTrace("pinned go tool trace parsed status has invalid size")
        status_bytes = tool_status_path.read_bytes()
        if status_bytes != b"0\n":
            raise InvalidTrace("pinned go tool trace parsed status is not exact zero")
        result["parsed_tool_status_sha256"] = hashlib.sha256(status_bytes).hexdigest()
        if size <= 0 or size > MAX_INPUT_BYTES:
            raise InvalidTrace("input size violates fixed bound")
        result["input_sha256"] = sha256_file(source)
        markers = bind_markers(source)
        reduction = reduce_states(source, markers)
        result["markers"] = markers
        result["reduction"] = reduction
        if reduction["missing_stack_ns"]:
            raise InvalidTrace("positive waiting interval has no TransitionStack")
        result["accepted"] = True
    except (InvalidTrace, OSError, UnicodeError) as error:
        result["errors"].append(str(error))
    encoded = (json.dumps(result, indent=2, sort_keys=True) + "\n").encode()
    if len(encoded) > MAX_OUTPUT_BYTES:
        raise SystemExit("result exceeds fixed output bound")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    descriptor = os.open(output, flags, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    return 0 if result["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
