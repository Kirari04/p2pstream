// Command real_trace_control emits one fixed task/region with a known channel wait.
package main

import (
	"context"
	"os"
	"runtime/trace"
	"time"
)

func main() {
	file, err := os.OpenFile(os.Args[1], os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if err != nil {
		panic(err)
	}
	if err := trace.Start(file); err != nil {
		panic(err)
	}
	wake := make(chan struct{})
	go func() {
		time.Sleep(20 * time.Millisecond)
		close(wake)
	}()
	ctx, task := trace.NewTask(context.Background(), "wan-read-wait-request")
	region := trace.StartRegion(ctx, "public-proxy-handler")
	<-wake
	region.End()
	task.End()
	trace.Stop()
	if err := file.Sync(); err != nil {
		panic(err)
	}
	if err := file.Close(); err != nil {
		panic(err)
	}
}
