# Execution-trace proposal amendment: control, resource, and parser contracts

Date: 2026-10-16

Scope: read-only source and completed-evidence investigation. No binary, runtime,
test, runner, workload, or tracked evidence was changed or run. This amendment
preserves the original proposal at `DESIGN-PROPOSAL.md` byte-for-byte (SHA-256
`5b79b7572936917e16f43232e99458e993acaf5d7f0f25181a99ef496ffcb670`).
Where the two differ, this amendment controls.

## Decisions

1. The existing qualification admin listener is **namespace-local and
   unauthenticated**, not authenticated. A trace control added to it must either
   use a run-scoped secret or be described accurately as unauthenticated.
2. The completed matched-copy cohort did not place the server in a finite child
   cgroup. Its exact historical hard memory limit was not recorded. The current
   inherited Codex scope is unlimited, so it cannot be the trace observer's
   hard process-memory bound.
3. Before any trace workload, use the mature server-only `systemd-run` pattern
   with `MemoryMax=4294967296` and `MemorySwapMax=0`, joined to the runner's
   network namespace. This is a diagnostic environment change and requires a
   scope-only provenance/lifecycle probe before traffic.
4. Use one independent streamed trace per predeclared post-conditioning
   download: sustained sequences 9, 11, 14, and 15 in both H1 and H2. If the
   smoke is run, use sequences 9, 11, and 13 in both arms. Do not trace warmup,
   select a request after observing its speed, or combine partial attempts.
5. Fix the raw trace cap at **64 MiB per file**. Overflow or any sink error
   invalidates that capture. This bounds the artifact file, not the tracer's
   internal memory and not the server's total memory.

## Admin listener: established facts and required correction

The qualification server binds the admin listener to a random loopback port:
`net.Listen("tcp", "127.0.0.1:0")`
(`internal/server/proxy_qualification_test.go:933-937`). Requests without the
`agent_health` query are passed directly to `qualificationRuntimeHandler`
(`proxy_qualification_test.go:944-949`). That handler accepts state-changing
queries such as `close_idle_agent_transports` and `flush` and returns runtime,
owner, and tunnel state without checking a token or credential
(`proxy_qualification_test.go:558-635`). The ready record publishes a plaintext
`http://` URL (`proxy_qualification_test.go:982-985`). There is no authentication
in this path.

The arm supervisor first creates private user, PID, mount, and network
namespaces (`run-wan-copy-monotonic-arm.sh:290-320`). The generated runner then
creates its own disposable user/network namespace. The server and load process
share the runner network namespace; the external agent joins a separate one.
Consequently the admin port is reachable by the runner/load side and by a
privileged process that can enter that namespace. It is not routed through the
public `10.211.0.1` listener and the external agent cannot reach the runner's
loopback by the normal topology. Loopback isolation is not authentication.

If implementation proceeds, keep the control qualification-only on the same
loopback listener, permit only fixed start/stop operations, enforce a single
active trace, map predeclared sequence numbers to server-owned `O_EXCL` paths,
and require a run-scoped high-entropy bearer secret. Do not accept a public
filename, path, cap, task type, or region type. The wrapper should receive the
secret through owned evidence rather than public request data. Exactly one
start and one stop control are allowed per selected request; there is no
endpoint polling.

## Memory-bound evidence

### Historical completed cohort

The completed H1/H2 invocations contain no `--pressure` option, so
`pressure_mode=0`. The server therefore followed the ordinary `setsid env`
branch (`generated/qualify-proxy-agent-growth-wan-copy-monotonic.sh:1161-1176`).
The only 4 GiB server scope is inside `if ((pressure_mode))`
(`generated/...sh:1143-1160`) and was not active.

Both `host-settings.txt` files record the inherited scope as:

```
/user.slice/user-1000.slice/user@1000.service/app.slice/app-t3code.slice/
app-t3code-agents.slice/app-t3code-agents-a29d81d75689.slice/
t3code-codex-f83127a3.scope
```

The recorder then looked only at `/sys/fs/cgroup/$name` for `memory.current`,
`memory.high`, `memory.max`, and `memory.swap.max`
(`run-wan-copy-monotonic-arm.sh:222-237`). Because the actual unified cgroup was
nested, those historical values are absent from both host-settings files.
Therefore the completed evidence proves no finite child bound and cannot
reconstruct the inherited scope's exact historical hard limit.

The completed row samples provide context, not a hard-bound measurement:

| Arm | Maximum server RSS | Maximum server heap allocation | Minimum sampled adaptive policy headroom |
| --- | ---: | ---: | ---: |
| H1 | 235,900,928 B | 543,458,992 B | 17,532,076,032 B |
| H2 | 339,427,328 B | 627,522,520 B | 17,433,247,744 B |

Every row's adaptive sample reported `memory_limit_bytes=28014153728`, source
`cgroup_v2`, and healthy pressure. That is the app controller's selected
resource sample, not a per-process hard bound. The controller computes
headroom to its configured hard percentage from the sampled constraint
(`internal/sysmetrics/memory_pressure.go:394-412`; the default hard percentage
is 90 at lines 109-121). The exported app fields are defined and copied at
`internal/server/agent_stream_capacity.go:245-267,1478-1498`.

### Current read, distinct from historical evidence

On 2026-10-16, the same inherited scope reported `MemoryHigh=infinity`,
`MemoryMax=infinity`, and `MemorySwapMax=infinity`; its cgroup files contained
`memory.high=max`, `memory.max=max`, and `memory.swap.max=max`. `MemoryCurrent`
was about 9.1 GB and `MemoryPeak=10072408064`, values for the shared live Codex
scope and therefore volatile. This current read confirms that the inherited
scope is not a finite bound now. It does not retroactively establish the
historical values or attribute the shared scope's memory to the server.

### Required finite diagnostic scope

The smallest existing mechanism is the mature server-only launch:

```
systemd-run --user --scope ... \
  -p MemoryMax=4294967296 -p MemorySwapMax=0 -- \
  nsenter -t "$$" -n env ... taskset -c 0,1,2,3 SERVER
```

This keeps the runner network topology, server CPU set, and `GOMAXPROCS=4`
while giving the traced server a 4 GiB hard memory maximum and no swap. It is
already present at `generated/...sh:1143-1160`, but using it here changes the
adaptive environment from the completed qualification. The result is a
diagnostic only, never a replacement qualification result.

Before traffic, a scope-only probe must prove the owned unit, server PID/cgroup
membership, runner network-namespace join, natural exit/join, and exact
`memory.max=4294967296`, `memory.swap.max=0`. At scope start and end, and around
each captured request, retain `memory.current`, `memory.peak`, `memory.high`,
`memory.max`, `memory.swap.max`, and all `memory.events`. Any increment in
`high`, `max`, `oom`, `oom_kill`, or `oom_group_kill`, any changed limit, or
forced cleanup invalidates the diagnostic.

Also retain the app's effective `memory_used_bytes`, `memory_limit_bytes`,
`memory_headroom_bytes`, `memory_source`, pressure/reason/sample error, and
effective admission limits around every selected request. Under a 4 GiB child
scope these values are expected to differ from the historical 28 GB sample;
that difference must be reported rather than normalized away.

## Fixed capture schedule and perturbation rule

Each arm uses the same predeclared subset:

| Workload | H1 download sequences | H2 download sequences |
| --- | --- | --- |
| sustained | 9, 11, 14, 15 | 9, 11, 14, 15 |
| smoke, if separately approved | 9, 11, 13 | 9, 11, 13 |

For each selected sequence, call `trace.Start` immediately before launching the
load request, create one fixed-type task/region around the real app handler,
finish task/region when the handler completes, then call `trace.Stop`
immediately after the load returns and before post-transfer admin queries. The
Start and Stop controls are outside the recorded request wall interval. Only
one trace is active at a time.

Start/Stop still perturb the schedule between requests. Start advances trace
state, Stop flushes and waits for all writes (`runtime/trace/trace.go:115-125`;
`runtime/trace/subscribe.go:68-104`), and ongoing tracing adds runtime work.
Record UTC and monotonic start/end/control durations. Keep the existing 30 s
idle timeout unchanged and preserve each row's `GotConn` Reused/WasIdle/IdleTime
and origin connection ID. If trace controls push a later idle age past 30 s,
that row's upstream-reuse classification is inconclusive even if its trace is
otherwise parseable. Do not change the timeout or substitute intended schedule
for observed reuse.

## File cap and headroom rationale

Use a 64 MiB hard cap for each raw trace. The current ext4 filesystem had
41,663,479,808 B free when inspected. Eight sustained captures reserve at most
512 MiB (1.29% of that free space); six optional smoke captures reserve at most
384 MiB. Together they reserve at most 896 MiB (2.26%). The slowest prior
handler lasted 18.305 s, so 64 MiB corresponds to about 3.50 MiB/s over that
interval, but there is no prior trace-rate measurement and this is not a claim
that the cap is sufficient.

Go 1.26.6 ignores the trace writer's returned count and error
(`runtime/trace/subscribe.go:157-197`). The cap writer must write only the
remaining bytes, atomically remember overflow or the first file error, and
thereafter report input as consumed while discarding it so the runtime reader
does not block. `trace.Stop` has no error return; the stop control must inspect
the writer state after Stop has completed. Overflow, short/failed file write,
control failure, or an output larger than 64 MiB makes the capture invalid and
nonzero. Never parse a truncated prefix as evidence and never retry by raising
the cap selectively.

The cap bounds raw bytes on ext4. It does not bound runtime trace buffers or Go
heap use; the 4 GiB owned cgroup is the total-process backstop. Hash the raw
file and preserve actual bytes, overflow state, trace/toolchain/binary/source
hashes, exact control times, and cgroup/app snapshots. Offline parsed text can
be larger than the raw trace; stream it to a separately capped derived file or
reduce it directly, and preserve nonzero parser/derived-cap status.

## Pinned parser contract

Use only the pinned Go 1.26.6 binary (SHA-256
`29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45`)
and `go tool trace -d=parsed`; do not start the interactive HTTP viewer.
`cmd/trace/main.go:336-349` feeds the trace to `internal/trace.NewReader` and
prints ordered `Event.String()` values. The string format is explicitly a
debug format subject to change (`internal/trace/event.go:1260-1266`), so the
tool hash and reducer must be reviewed and hashed together.

For this pinned version, task lines contain `ID`, `Parent`, and `Type`; region
lines contain `Task` and `Type`; state-transition lines contain resource
`GoID`, old/new state, reason, and an optional multiline `TransitionStack`
(`internal/trace/event.go:1292-1318`). Task and region fields are decoded at
`event.go:971-1010`. A `Running->Waiting` transition carries the blocking stack,
whereas a later unblock identifies the target in its transition `GoID`; the
event header `G=` can be the unblocking goroutine
(`event.go:1066-1096`). Always key state intervals by transition `GoID`.

The offline reducer must:

1. require exactly one begin/end pair for the fixed request task type, with the
   same nonzero task ID;
2. require exactly one begin/end pair for the fixed handler region type, with
   that task ID, the same event-header handler GID, and strictly ordered times
   inside the task;
3. establish the handler GID state from the last transition at or before region
   start, then build its ordered state intervals and clip each interval to the
   closed region interval;
4. report Running, Runnable scheduler wait, Syscall, and Waiting separately,
   splitting Waiting by entry reason and entry `TransitionStack`;
5. require nonnegative, nonoverlapping intervals whose exact sum equals region
   duration, without adding intervals from any other goroutine.

The toolchain summary follows the same completeness model: a task is complete
only with Start and End (`internal/trace/summary.go:44-70`), and region stats are
snapshotted/subtracted on begin/end (`summary.go:534-570`). Its nonoverlapping
categories separately report execution, scheduler wait, syscall, and block
time (`summary.go:103-150`). These source facts support the reducer contract;
the repository cannot import the toolchain's `internal/trace` package directly.

A handler wait may be attributed to Yamux empty-buffer wait,
`sendWindowUpdate`/send-result wait, `GrowingConn.grow`/aggregate publication,
or adaptive owner sampling only when its entry stack resolves to that source
path. Missing stack for a material wait is unresolved. A handler park in
`Stream.Read` establishes that the handler waited for receive data; it does not
identify peer credit, origin delivery, TCP buffering, or the responsible
background goroutine. Whole-trace `-pprof` outputs are corroborative and must
not be summed across goroutines as request wall time.

## Fail-closed interpretation

The diagnostic is invalid for a capture if the sink cap/error trips,
Start/control fails, Stop does not complete, pinned parsing fails, markers are
missing/duplicated/incomplete/mismatched, handler state cannot be established,
the interval partition fails conservation, a required stack is absent, payload
or protocol exactness fails, the owned cgroup records a limit/memory event, or
cleanup is forced/non-natural. An observed reuse mismatch can leave a valid
request trace while making its upstream-reuse classification inconclusive; it
must be reported separately.

Even a complete trace is observational. It can locate handler goroutine waits
but cannot prove an upstream-credit, TCP, buffering, or scheduling cause. It
does not authorize a runtime fix or reopen the rejected DATA/refund queue,
epoch, TCP low-water, allocation/growth, SQL, or earlier profiling variants.
