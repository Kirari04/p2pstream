# Go execution-trace feasibility for the WAN upstream-read stall

Date: 2026-10-16

Scope: read-only source investigation against current production source
`8ac4c8df8237e37777ba2fac0da6f949da17bdea` and the pinned Go 1.26.6
toolchain at
`/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64`.
No runtime, test, harness, workload, or frozen evidence was changed or run.
The runtime paths cited below were compared with `8ac4c8d` and are
byte-identical in this worktree.

The motivating observation is the matched H2 retained download at sequence 14:
14.550 MB/s, 18.305 s handler time, 17.334 s inside upstream `Read`, and
0.803 s inside downstream `Write`. This localizes the excess to the response
body read boundary. It does not establish a credit, scheduler, or transport
cause.

## Decision

A `runtime/trace.FlightRecorder` cannot meet the proposed strict fixed-memory
contract. Its `MaxBytes` is explicitly a hint: it may retain and write more
than the configured value, and `MaxBytes` may override the requested minimum
age (`runtime/trace/flightrecorder.go:156-175`). It also snapshots only when
`WriteTo` forces and waits for a global trace-generation advance
(`flightrecorder.go:105-153`); `Stop` clears the retained generations, so the
snapshot must precede `Stop` (`flightrecorder.go:87-98`). An 18-second request
therefore creates an unresolved choice between enough age to retain its start
and a size hint that may evict that start or exceed its supposed bound.
The recorder copies each runtime batch into retained generations and discards
only at generation granularity (`runtime/trace/recorder.go:21-29,63-96`), which
is why neither retained memory nor snapshot bytes has the requested hard cap.

One server-only execution trace with one task/region per selected request is
**partially feasible as a new discriminator**, but it cannot provide the full
four-way causal attribution in the question. It can measure parks of the
request handler and distinguish their stack sites when the runtime records a
state transition. In particular, it can separate a long Yamux empty-buffer
`select` from a park in synchronous window-update or growth publication. It
cannot reliably time CPU-running work, assign separate session/background
goroutines to the request, or observe the agent-side sender and kernel credit
state. A result can therefore falsify or support a handler-wait hypothesis; it
cannot by itself prove why upstream data did not arrive.

If this observer is approved, prefer a finite streamed `runtime/trace.Start`
capture over `FlightRecorder`. Stream to a local ext4 file through a capped
writer, start before the selected phase and stop after the completed slow
request (or at the fixed phase end if none is slow), with both controls outside
the timed transfer. The file cap is strict; the Go tracer's total internal
memory is not API-capped and remains bounded only by the existing process
cgroup. This distinction must remain explicit.

## What the trace can see

The execution tracer records goroutine creation, blocking/unblocking, syscalls,
scheduler transitions, GC, and most event stacks with precise timestamps
(`runtime/trace/trace.go:5-17`). A task spans creation to `Task.End`; a region is
bound to its calling goroutine and is associated with a task only through the
passed context (`runtime/trace/annotation.go:16-48,72-81,115-175`). One constant
task type and one constant outer region type are sufficient; request IDs belong
in bounded-value logs or the existing evidence mapping, not in dynamically
created task types.

The handler's response-body read remains on the handler goroutine. The HTTP/1
transport read loop installs `bodyEOFSignal`, then waits for the caller to
finish the body (`net/http/transport.go:2409-2468`); `bodyEOFSignal.Read`
directly invokes the wrapped body's `Read` (`transport.go:3041-3085`). The
outer handler region can therefore contain the measured `GrowingConn`/Yamux
read waits. It does not need per-chunk annotations.

The relevant current source sites have observably different park stacks:

- With no buffered Yamux data, `Stream.Read` parks in its `select` on receive,
  shutdown, or deadline notification (`third_party/yamux/stream.go:131-160,
  195-235`). A long transition to Go `Waiting` with reason `select` and this
  stack is direct evidence that the handler spent that interval waiting for
  its Yamux receive buffer to become non-empty. It does not say why the peer did
  not supply data.
- After consuming bytes, the same call synchronously invokes
  `sendWindowUpdate` (`stream.go:162-193`). A selected update may park acquiring
  `controlHdrLock`, queueing the control, or waiting for its send result
  (`stream.go:426-511`; `third_party/yamux/session.go:466-535`). Those stacks are
  distinct from the empty-buffer `select`.
- `GrowingConn.Read` performs growth only after its Yamux read returns and does
  so synchronously on the handler (`internal/tunnel/growing_conn.go:69-121`).
  Aggregate growth serializes under its own mutex, reserves adaptive ownership,
  then publishes session allocation, stream allocation, and byte-window growth
  (`growing_conn.go:148-212`). Session and stream growth may park on publication
  locks or `waitForSendErrCommit` (`third_party/yamux/aggregate_window.go:
  759-850`). Those blocked intervals can be attributed to the corresponding
  stacks.
- The adaptive reserve callback may synchronously refresh procfs/cgroup state
  when its cached sample is stale, then waits for any concurrent sample before
  spending (`internal/server/agent_stream_capacity.go:366-465,1374-1407`).
  Trace can expose syscall, synchronization, and scheduler waits in that call
  chain. It cannot assign elapsed time spent running ordinary sampling or
  ledger code without an internal region or a separate CPU sample, neither of
  which is proposed here.

Go 1.26.6 computes blocking profiles from goroutine state transitions and the
stack on entry to `network`, `chan`, `sync`, or `select` waits
(`cmd/trace/pprof.go:111-195`). This is the concrete mechanism that makes the
first three park classes distinguishable. It does not convert continuously
running code into a duration by source function.

## Attribution limits

The per-request context is not automatically propagated into Yamux session
workers. Aggregate refunds are queued by the read but published by a dedicated
session goroutine (`third_party/yamux/aggregate_window.go:538-559,576-746`). The
physical Yamux reader, control sender, HTTP transport read loop, and adaptive
sampler may also run outside the handler task. Their events are present in a
server trace, but correlation by time and lane is an inference; task focus does
not give those goroutines a stream/request identity.

A server trace cannot observe the agent's origin read, agent-side send-credit
wait, remote kernel/TCP queues, or the reason a server Yamux buffer stayed
empty. It cannot distinguish a peer credit shortage from origin delivery or
physical-network delay solely from a long handler `Stream.Read` wait. It also
cannot show the value of Yamux byte/session/allocation credit at the park. A
mutex or channel park in publication is attributable; allocation, copying,
atomic work, and uncontended locks that remain Running are not precisely
attributable with only the outer region.

The current tool supports four whole-trace CLI profiles (`net`, `sync`,
`syscall`, and `sched`) and a processed event dump (`go tool trace -d=parsed`)
(`cmd/trace/doc.go:22-34`; `cmd/trace/main.go:105-145`). The interactive tool
has task/region views and region-filtered versions of those profiles
(`cmd/trace/main.go:201-226`), but it starts a local HTTP server
(`main.go:148-179,228-229`). For immutable offline evidence, use the pinned
tool's `-d=parsed` output to identify the marked task interval and goroutine,
plus the whole-trace CLI profiles as corroboration. Treat this text format as
tool-version-specific. The underlying parser is the toolchain-internal
`internal/trace` package, so repository code cannot import it without creating
a new decoder/harness. A region summary is complete only if both its begin and
end are within the capture (`cmd/trace/regions.go:123-131`).

## Smallest bounded observer

This is a measurement-only proposal, not an authorized implementation.

1. Add a qualification-only, server-side trace owner. Start one
   `runtime/trace.Start` stream by existing authenticated private admin control
   before the fixed retained diagnostic phase. Stop it by one control action
   after the load driver has completed and classified the first fixed-gate slow
   request, or after the phase if no request is slow. There is no polling,
   per-chunk hook, deadline change, or public control surface. Start and Stop
   are outside a timed request; tracing overhead during the request remains a
   declared diagnostic perturbation.
2. Attach one constant-type `trace.Task` and one constant-type
   `trace.StartRegion` to each selected public proxy request, ending both on the
   handler goroutine after the response copy ends. Bind the observed request to
   existing fixed sequence/lane/result evidence. Do not trust public labels to
   allocate trace type names or select files.
3. Stream to a fresh, `O_EXCL` file on the owned ext4 output directory through
   a synchronous capped sink kept fast by local writes. Up to the configured
   cap is written; after the cap it must continue reporting each runtime write
   as fully consumed while discarding its bytes and atomically recording
   overflow. Any underlying file error takes the same record-and-discard path.
   This is necessary because Go 1.26.6 ignores the writer's returned count and
   error in its trace-reader goroutine
   (`runtime/trace/subscribe.go:157-197`). `trace.Stop` waits for all trace
   writes (`runtime/trace/trace.go:115-125`). After Stop, any overflow, file
   error, missing task end, parse failure, or process/cgroup limit event makes
   the capture invalid and nonzero; a truncated prefix must never be presented
   as usable evidence.
4. Preserve cap, actual bytes, start/stop UTC and monotonic markers, writer and
   Stop statuses, trace/toolchain/binary/source hashes, exact analysis commands,
   process/cgroup memory peaks, and the raw trace hash. Analyze with the exact
   pinned `go tool trace`; do not run its interactive server during the
   workload.

The cap strictly bounds the trace file, not all trace memory. Runtime event
buffers are allocated outside the Go heap and recycled through full/empty
queues (`runtime/tracebuf.go:155-172,224-272`; `runtime/trace.go:198-228`), and
there is no public byte-limit option for them. A fast ext4 writer that switches
to discard after overflow prevents a blocked sink from driving avoidable queue
growth, while the existing cgroup supplies the only hard total-process bound.
The initial cap must therefore be reviewed against available cgroup headroom;
cap overflow is an invalid attempt, never permission to retry selectively.

Start and Stop are not free: trace start/advance coordinates runtime state,
preempts processors, flushes generations, and Stop waits for the reader to
finish (`runtime/trace.go:470-570,750-816`). Keeping those calls outside the
timed request removes their direct latency from the transfer but not the
execution tracer's ongoing event and scheduling overhead. The diagnostic can
localize a reproduced stall only if the same fixed qualification gate still
fails under tracing; a healthy traced replay is non-diagnostic, as with the
earlier profiles.

## Existing-evidence boundary

A repository search found no completed `runtime/trace`/`go tool trace`
execution-trace artifact in the 2026-10-16 qualification documentation or
continuation source, apart from planning text for this investigation. The
completed WAN TCP diagnostic used whole-endpoint CPU and block profiles plus
100 ms external TCP sampling
(`docs/operations/benchmarks/proxy-qualification-2026-10-16/agent-wan-tcp-diagnostic/README.md:8-17`).
Its slow case did not reproduce (`README.md:19-23`), and its whole-lifecycle
block sums mixed startup, warmups, both directions, and cleanup
(`README.md:42-47`). The proposed completed-request trace is therefore new in
time scope and anomaly capture, while relying on related scheduler/blocking
events. It does not reopen the rejected DATA emission, refund queue/epoch,
TCP low-water, allocation/growth policy, SQL, or prior profiling variants.

## Falsifiable outcomes

- If most of the reproduced 9-10 s excess is one or more handler parks at
  `Stream.Read`'s empty-buffer `select`, the trace supports “server handler was
  waiting for Yamux receive data” and rejects synchronous server publication or
  adaptive collection as the direct carrier of that elapsed interval. It still
  cannot assign the upstream reason.
- If the excess is instead in parks whose stacks are
  `sendWindowUpdate`/`waitForSendErrCommit`, aggregate growth publication, or
  adaptive sampling/ledger synchronization, it directly identifies that
  server-side blocking boundary and its duration. A production fix would still
  require separate source/risk review.
- If the handler remains Running/Runnable, or the time is carried by unmarked
  session workers, the outer markers are insufficient. The result must be
  reported as unresolved rather than converted into a credit or H2 scheduling
  claim. Runnable scheduler latency must be reported separately from Waiting
  time, and blocked durations from different goroutines must never be summed as
  request wall time.
- If the cap overflows, a marker is incomplete, the trace cannot be parsed, the
  slow row does not reproduce, or cleanup is not natural, the capture is
  invalid/inconclusive. It must not be retried or selectively combined without
  a new reviewed attempt.
