# Exact zero-PC sentinel parser correction

Pinned Go 1.26.6 `internal/trace.printStack` prints every `StackFrame` without
special-casing zero values: `Func + " @ 0x" + PC`, then `File + ":" + Line`
(`src/internal/trace/event.go:316-320`). A zero-valued frame therefore has the
exact two-line representation `\t @ 0x0` and `\t\t:0` after the event printer's
stack indentation. The three frozen H1 traces each contain exactly one such
frame on a `Waiting->Runnable` event.

The derivative accepts only that exact pair. It represents it as an empty
function/file, line and PC zero, with `zero_pc_sentinel:true`. The existing raw
`stack` line array remains byte-for-byte available in every emitted waiting
stack group. A pair with only one sentinel line, a nonzero PC or line, or a
nonempty file remains malformed. Ordinary frame parsing is unchanged.

The source contracts include both observed shapes: an event-level `Stack=` on
a `Waiting->Runnable` transition, matching the frozen smoke traces, and a
positive handler wait whose `TransitionStack=` is the sentinel. The first must
parse without changing the known yamux wait result. The second must retain the
two raw lines and remain unknown/incomplete. Two near-sentinel variants remain
fail-closed. These contracts are source only and have not been executed.

If the sentinel occurs anywhere in a multi-frame waiting stack, the entire
stack remains unknown/incomplete. A recognizable credit, growth, adaptive, or
yamux ancestor cannot override the unresolved frame. The mixed-stack contract
retains both raw frames and verifies this conservative result.

A zero-PC sentinel cannot identify a blocking path. If it is the transition
stack for a positive handler Waiting interval, the existing classifier places
that duration in `waiting_unknown_stack`; `unknown_stack_ns` is positive and
`attribution_complete` is false. It is never mapped to a credit, adaptive,
growth, or yamux wait category. Missing transition stacks remain rejected by
the existing positive-wait guard.

This source checkpoint is unexecuted. It does not alter or overwrite the
original smoke3 parsed traces, failed reductions, statuses, or final outcome.
