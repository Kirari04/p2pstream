# Units clarification

`REPORT.md` was frozen and reported at SHA-256
`8b187e6efb441531e0c2109cc1b251a7f732eb54c9f7373c95ed7bb7a01bce4b`.
Its labels “MiB” on the observed parsed-size ranges are a prose unit error:
those displayed values are decimal MB (bytes / 1,000,000), as are the other
displayed `MB`/`GB` estimates. The fixed parser/input cap remains exactly
512 MiB (536,870,912 bytes). The machine-readable JSON files retain exact
integer byte counts and are authoritative; no estimate or fit conclusion
changes.
