# Sustained parsed-trace cap assessment

## Finding

The 512 MiB parsed-input cap is at material risk, and the sustained cohort
should not launch with direct `go tool trace -d=parsed` materialization.

The six closed 4 MiB traces produce 22.48–26.15 MiB of parsed H1 text and
34.66–40.05 MiB of parsed H2 text. Direct 64× payload scaling for the 256 MiB
phases yields 1.44–1.67 GB for H1 and 2.22–2.56 GB for H2. Even the less
conservative time-density model exceeds 512 MiB for the previously observed
18.848 s H2 retained download: 844,212,575 estimated bytes.

Control and post-query noise cannot explain the risk. Exact event-block
classification against the handler region markers places 85.7–86.8% of H1
parsed bytes and 92.1–92.8% of H2 parsed bytes inside the public handler
region. Removing events outside that region would also violate the approved
whole-process evidence contract and would not make the payload-scaled traces
fit.

The raw and event bounds still have substantial headroom under the same direct
64× model. Raw traces estimate to 8.48–10.01 MB for H1 and 12.17–15.27 MB for
H2, below the fixed 64 MiB file cap. Event counts estimate to 772,800–901,376
for H1 and 1,597,696–1,811,776 for H2, below the fixed 5,000,000-event cap.

## Why the parsed text grows

Repeated stack text dominates the parsed artifacts. A source-free size model
that replaces each exact `Stack=` or `TransitionStack=` body with a reference
and emits each exact raw stack once reduces the tiny artifacts to 10.4–10.8%
of parsed size for H1 and 12.5–12.7% for H2. A conservative 64× scaling of the
entire canonical artifact is 151.8–174.2 MB for H1 and 282.7–325.6 MB for H2,
below 512 MiB. The model keeps every event header, order, timestamp, stack
frame, and background event.

Pinned Go 1.26.6 exposes only `wire`, `parsed`, and `footprint` debug modes.
`footprint` is aggregate-only and loses the required event stream. `wire` is
compact, but it is the unprocessed runtime format and would require a new
ordering/state implementation equivalent to pinned Go's internal trace
reader. It is a larger correctness surface than canonicalizing the already
processed `parsed` stream.

## Smallest safe alternative

Add one offline, streaming canonicalizer between pinned `go tool trace
-d=parsed` and the analyzer. It should intern exact whole-stack bodies, emit a
definition before the first reference, and retain event headers and
non-stack continuations byte-for-byte. Repeated stack content must resolve to
the exact stored bytes; a digest collision or duplicate definition mismatch
must fail closed. The analyzer can resolve references per event without ever
materializing the expanded verbose stream. This runs after endpoint exit and
does not alter the handler, timed load, trace capture, or resource policy.

The existing fixed raw-file, event-count, line, per-event byte, continuation,
and analyzer-output limits must remain unchanged. Parser and canonicalizer
statuses must be captured separately with pipeline failure preserved. No
background events, frames, or time ranges may be dropped.

There is one explicit architecture decision before implementation. Today the
same 512 MiB number is both the parser stdout file-size limit and the analyzer
input-file-size limit for verbose text. A canonical file can remain physically
bounded to 512 MiB, but its logically expanded repeated-stack text can exceed
512 MiB. The new schema must distinguish `max_canonical_input_bytes` from an
`expanded_text_bytes` evidence counter and state the approved expanded-text
budget or explicitly approve that repeated dictionary references are not
materialized or charged as physical input. This cannot be changed silently.

Standard compression has the same physical-versus-expanded distinction and
adds decompression-bomb handling. Exact stack interning is easier to validate
against the existing parsed grammar and preserves stack identity for the
current reducer.

## Evidence

- `tiny-parsed-distribution.json` classifies exact event blocks using each
  corrected reduction's region markers.
- `stack-dictionary-size-model.json` records exact stack occurrence, unique
  stack, dictionary, reference-stream, and 64× size counts.
- `sustained-size-risk.json` binds the fixed caps, tiny distributions, direct
  payload scaling, and prior matched sustained phase durations.

This assessment is read-only. It did not parse a new trace, change a runtime
artifact, launch traffic, or implement the alternative.
