# Pinned zero-PC source evidence

The canonical Go 1.26.6 file
`/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/src/internal/trace/event.go`
has SHA-256 `a46791f64767c5a8ce98e9d227603ebdc482fd3b3b4b5f01358d1ee7bd56ecd0`.
`Stack.Frames` constructs each frame directly from the trace tables at lines
285-304. `printStack` prints `Func`, `PC`, `File`, and `Line` without a zero
special case at lines 316-320. A zero-valued frame therefore produces the
exact pair accepted by this derivative.

The frozen H1 parsed traces contain exactly one such event-level `Stack=` each:

- sequence 9, lines 293605-293607, parsed SHA-256 `22949b93e2f1f54c4470e952b34ed479a56cfa3b8f3e8e7a8aa0a34bd3433879`
- sequence 11, lines 277729-277731, parsed SHA-256 `3dad5811599ca86f475c56af5959de184fd5fad4b5e9cafe0b7d8a2c01c49fd1`
- sequence 13, lines 267215-267217, parsed SHA-256 `16818ef9617bb2cc454d86348a1292cbbbaefa928409ad5a70c2dc2fee7f99b8`

The original parser failed while validating every event stack, before handler
state reduction. The narrow correction changes only exact frame parsing and
the output schema for the sentinel representation. It does not classify an
unknown frame as a known wait and does not change task, region, partition,
resource-GoID, bound, or cohort-join logic.
