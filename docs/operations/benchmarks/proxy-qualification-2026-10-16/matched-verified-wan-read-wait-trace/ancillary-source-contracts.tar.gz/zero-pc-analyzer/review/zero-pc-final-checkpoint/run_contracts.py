#!/usr/bin/env python3
"""Run the fixed synthetic reducer contract once into a fresh directory."""

import argparse
import json
import pathlib
import subprocess
import sys


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", required=True, type=pathlib.Path)
    args = parser.parse_args()
    root = pathlib.Path(__file__).resolve().parent
    fixtures = root / "fixtures"
    contract = json.loads((fixtures / "contract.json").read_text())
    args.output_dir.mkdir(parents=True, exist_ok=False)
    rows = []
    failures = []
    for index, case in enumerate(contract["cases"], 1):
        stem = f"{index:02d}-{pathlib.Path(case['file']).stem}-{pathlib.Path(case['tool_status']).stem}"
        result_path = args.output_dir / f"{stem}.json"
        stdout_path = args.output_dir / f"{stem}.stdout"
        stderr_path = args.output_dir / f"{stem}.stderr"
        command = [
            sys.executable, str(root / "analyze_parsed_trace.py"),
            "--input", str(fixtures / case["file"]),
            "--tool-status", str(fixtures / case["tool_status"]),
            "--output", str(result_path),
        ]
        with stdout_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
            completed = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, check=False)
        result = json.loads(result_path.read_text())
        expected_status = 0 if case["accepted"] else 1
        errors = []
        if completed.returncode != expected_status:
            errors.append(f"status={completed.returncode} want={expected_status}")
        if result.get("accepted") is not case["accepted"]:
            errors.append("accepted mismatch")
        if "error_contains" in case and not any(case["error_contains"] in value for value in result.get("errors", [])):
            errors.append("expected error text absent")
        markers = result.get("markers", {})
        reduction = result.get("reduction", {})
        for key in ("handler_gid",):
            if key in case and markers.get(key) != case[key]:
                errors.append(f"{key} mismatch")
        for key in ("region_duration_ns", "state_ns", "waiting_category_ns", "unblock_header_gid_diff_count",
                    "zero_duration_state_interval_counts", "partition_delta_ns", "attribution_complete"):
            if key in case and reduction.get(key) != case[key]:
                errors.append(f"{key} mismatch")
        if "zero_pc_stack" in case:
            groups = reduction.get("waiting_stack_groups", [])
            matches = [group for group in groups if group.get("stack") == case["zero_pc_stack"]]
            if len(matches) != 1:
                errors.append("exact zero-PC raw stack was not retained once")
            else:
                frames = matches[0].get("frames")
                expected = case["zero_pc_frames"]
                if frames != expected:
                    errors.append("zero-PC sentinel frame representation mismatch")
        row = {"case": stem, "command": command, "status": completed.returncode, "errors": errors}
        rows.append(row)
        failures.extend(f"{stem}: {error}" for error in errors)
    summary = {"schema_version": 1, "accepted": not failures, "failures": failures, "cases": rows}
    (args.output_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
