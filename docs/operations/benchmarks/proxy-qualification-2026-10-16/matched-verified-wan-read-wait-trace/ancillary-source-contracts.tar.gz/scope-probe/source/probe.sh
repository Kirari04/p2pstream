#!/usr/bin/env bash
set -euo pipefail

root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../../../.." && pwd)
probe_root=$root/tmp/continuation-20261016/wan-read-wait-source/scope-probe
dummy=$probe_root/dummy.sh
output=${1:?output directory required}
unit=p2p-trace-scope-probe-20261016-a.scope

[[ ! -e $output ]] || { echo "output exists: $output" >&2; exit 2; }
mkdir -p "$output"

python3 - "$output/parent.json" "$unit" <<'PY'
import json, os, pathlib, sys
out, unit = sys.argv[1:]
payload = {
    "boot_id": pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    "pid": os.getpid(),
    "namespaces": {name: os.readlink(f"/proc/self/ns/{name}") for name in ("user", "pid", "mnt", "net")},
    "self_cgroup": pathlib.Path("/proc/self/cgroup").read_text().splitlines(),
    "unit": unit,
}
pathlib.Path(out).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
PY

printf '%q ' setsid timeout --signal=TERM --kill-after=5s 60s \
  unshare --user --map-root-user --pid --fork --kill-child=TERM --mount --mount-proc --net \
  bash -c '<embedded-owned-probe>' bash "$output" "$dummy" "$unit" > "$output/outer-command.txt"
printf '\n' >> "$output/outer-command.txt"

parent_user=$(readlink /proc/self/ns/user)
parent_pid=$(readlink /proc/self/ns/pid)
parent_mnt=$(readlink /proc/self/ns/mnt)
parent_net=$(readlink /proc/self/ns/net)

set +e
setsid timeout --signal=TERM --kill-after=5s 60s \
  unshare --user --map-root-user --pid --fork --kill-child=TERM --mount --mount-proc --net \
  bash -c '
    set -euo pipefail
    out=$1 dummy=$2 unit=$3 parent_user=$4 parent_pid=$5 parent_mnt=$6 parent_net=$7
    python3 - "$out/outer.json" "$parent_user" "$parent_pid" "$parent_mnt" "$parent_net" "$$" <<'"'"'PY'"'"'
import json, os, pathlib, sys
out, parent_user, parent_pid, parent_mnt, parent_net, shell_pid = sys.argv[1:]
owned = {name: os.readlink(f"/proc/self/ns/{name}") for name in ("user", "pid", "mnt", "net")}
payload = {
    "pid": int(shell_pid),
    "pid_is_one": int(shell_pid) == 1,
    "python_parent_pid": os.getppid(),
    "python_parent_is_one": os.getppid() == 1,
    "namespaces": owned,
    "parent_namespaces": {"user": parent_user, "pid": parent_pid, "mnt": parent_mnt, "net": parent_net},
    "all_private": all(owned[k] != v for k, v in (("user", parent_user), ("pid", parent_pid), ("mnt", parent_mnt), ("net", parent_net))),
}
pathlib.Path(out).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
PY
    release=$out/release
    exit_release=$out/exit-release
    state=$out/dummy.json
    setsid systemd-run --user --scope --quiet --collect --unit="$unit" \
      -p MemoryMax=4294967296 -p MemorySwapMax=0 -- \
      nsenter -t "$$" -n env GOMAXPROCS=4 taskset -c 0,1,2,3 "$dummy" "$state" "$release" "$exit_release" \
      >"$out/systemd-run.stdout.log" 2>"$out/systemd-run.stderr.log" &
    launcher=$!
    python3 - "$out/launcher.json" "$launcher" <<'"'"'PY'"'"'
import json, os, pathlib, sys, time
out, pid_s = sys.argv[1:]
pid = int(pid_s)
stat = pathlib.Path(f"/proc/{pid}/stat").read_text().split()
payload = {"pid": pid, "pgid": os.getpgid(pid), "sid": os.getsid(pid), "start_ticks": int(stat[21])}
pathlib.Path(out).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
PY
    ready=0
    for _ in $(seq 1 200); do
      if [[ -s $state ]]; then ready=1; break; fi
      kill -0 "$launcher" 2>/dev/null || break
      sleep 0.05
    done
    ((ready)) || { wait "$launcher"; exit $?; }
    systemctl --user show "$unit" \
      -p Id -p LoadState -p ActiveState -p SubState -p ControlGroup \
      -p MemoryCurrent -p MemoryPeak -p MemoryHigh -p MemoryMax -p MemorySwapMax \
      > "$out/unit-running.txt"
    cgroup=$(python3 -c '"'"'import json,sys; print(json.load(open(sys.argv[1]))["cgroup_path"])'"'"' "$state")
    [[ $cgroup == /* ]]
    cgroup_dir=/sys/fs/cgroup$cgroup
    for name in memory.current memory.peak memory.high memory.max memory.swap.max memory.events; do
      [[ -r $cgroup_dir/$name ]] || exit 42
      { printf "%s=" "$name"; cat "$cgroup_dir/$name"; } >> "$out/cgroup-start.txt"
    done
    touch "$release"
    for _ in $(seq 1 200); do [[ -e $state.released ]] && break; sleep 0.05; done
    [[ -e $state.released ]] || exit 43
    for name in memory.current memory.peak memory.high memory.max memory.swap.max memory.events; do
      [[ -r $cgroup_dir/$name ]] || exit 44
      { printf "%s=" "$name"; cat "$cgroup_dir/$name"; } >> "$out/cgroup-end.txt"
    done
    touch "$exit_release"
    set +e
    wait "$launcher"
    status=$?
    set -e
    printf "%s\n" "$status" > "$out/systemd-run.status"
    [[ $status -eq 0 ]]
    [[ -e $state.natural-exit ]]
    python3 - "$out/process-join.json" "$out/launcher.json" "$state" <<'"'"'PY'"'"'
import json, os, pathlib, sys
out, launcher_path, dummy_path = sys.argv[1:]
launcher = json.load(open(launcher_path))
dummy = json.load(open(dummy_path))
def alive_same(identity):
    path = pathlib.Path(f"/proc/{identity['"'"'pid'"'"']}/stat")
    if not path.exists(): return False
    try: return int(path.read_text().split()[21]) == identity["start_ticks"]
    except (FileNotFoundError, ProcessLookupError): return False
pgids = {int(line) for line in os.popen("ps -e -o pgid=").read().split()}
payload = {
    "launcher_alive_same_identity": alive_same(launcher),
    "dummy_alive_same_identity": alive_same(dummy),
    "launcher_group_joined": launcher["pgid"] not in pgids,
    "dummy_group_joined": dummy["pgid"] not in pgids,
}
pathlib.Path(out).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
if any((payload["launcher_alive_same_identity"], payload["dummy_alive_same_identity"])) or not all((payload["launcher_group_joined"], payload["dummy_group_joined"])):
    raise SystemExit(1)
PY
    joined=0
    : > "$out/unit-final-polls.txt"
    for _ in $(seq 1 100); do
      set +e
      show=$(systemctl --user show "$unit" -p LoadState -p ActiveState -p SubState 2>&1)
      show_status=$?
      set -e
      printf "status=%s %s\n" "$show_status" "${show//$'"'"'\n'"'"'/ }" >> "$out/unit-final-polls.txt"
      if ((show_status != 0)) || grep -Eq '"'"'LoadState=not-found|ActiveState=inactive|ActiveState=failed'"'"' <<<"$show"; then joined=1; break; fi
      sleep 0.05
    done
    printf "%s\n" "$joined" > "$out/unit.joined"
    ((joined))
  ' bash "$output" "$dummy" "$unit" "$parent_user" "$parent_pid" "$parent_mnt" "$parent_net" \
  > "$output/outer.stdout.log" 2> "$output/outer.stderr.log" &
outer_launcher=$!
outer_start_ticks=$(awk '{print $22}' "/proc/$outer_launcher/stat")
outer_pgid=$(ps -o pgid= -p "$outer_launcher" | tr -d ' ')
printf '{"pid":%s,"pgid":%s,"start_ticks":%s}\n' "$outer_launcher" "$outer_pgid" "$outer_start_ticks" > "$output/outer-launcher.json"
wait "$outer_launcher"
outer_status=$?
set -e
printf '%s\n' "$outer_status" > "$output/outer.status"
outer_alive_same=false
if [[ -r /proc/$outer_launcher/stat ]] && [[ $(awk '{print $22}' "/proc/$outer_launcher/stat") == "$outer_start_ticks" ]]; then
  outer_alive_same=true
fi
outer_group_joined=true
if ps -e -o pgid= | awk -v wanted="$outer_pgid" '$1 == wanted { found=1 } END { exit !found }'; then
  outer_group_joined=false
fi
printf '{"alive_same_identity":%s,"group_joined":%s}\n' "$outer_alive_same" "$outer_group_joined" > "$output/outer-join.json"

set +e
systemctl --user show "$unit" -p LoadState -p ActiveState -p SubState > "$output/unit-host-final.txt" 2> "$output/unit-host-final.stderr.txt"
unit_host_status=$?
set -e
printf '%s\n' "$unit_host_status" > "$output/unit-host-final.status"

python3 - "$output" "$unit" <<'PY'
import json, os, pathlib, re, sys

out = pathlib.Path(sys.argv[1])
unit = sys.argv[2]

def load(name): return json.loads((out / name).read_text())
def scalar(name): return (out / name).read_text().strip()
def cgroup_values(name):
    result = {}
    current = None
    for line in (out / name).read_text().splitlines():
        if re.match(r"^[a-z.]+=", line):
            key, value = line.split("=", 1)
            current = key
            result[key] = value
        elif current == "memory.events":
            key, value = line.split()
            result[f"memory.events.{key}"] = value
    return result

errors = []
outer_status = int(scalar("outer.status"))
if outer_status != 0: errors.append(f"outer_status={outer_status}")
outer = load("outer.json") if (out / "outer.json").exists() else {}
dummy = load("dummy.json") if (out / "dummy.json").exists() else {}
join = load("process-join.json") if (out / "process-join.json").exists() else {}
outer_join = load("outer-join.json")
if not outer.get("pid_is_one") or not outer.get("python_parent_is_one") or not outer.get("all_private"):
    errors.append("outer_namespace_contract")
if dummy.get("gomaxprocs") != "4" or dummy.get("cpu_affinity") != [0, 1, 2, 3]:
    errors.append("dummy_cpu_contract")
if dummy.get("namespaces", {}).get("net") != outer.get("namespaces", {}).get("net"):
    errors.append("dummy_net_namespace_join")
if not dummy.get("cgroup_path", "").endswith("/" + unit):
    errors.append("dummy_cgroup_membership")
if join and (join.get("launcher_alive_same_identity") or join.get("dummy_alive_same_identity") or not join.get("launcher_group_joined") or not join.get("dummy_group_joined")):
    errors.append("process_group_join")
if outer_join.get("alive_same_identity") or not outer_join.get("group_joined"): errors.append("outer_process_group_join")
if not (out / "unit.joined").exists() or scalar("unit.joined") != "1": errors.append("unit_join")
if not (out / "dummy.json.natural-exit").exists(): errors.append("natural_exit_marker")
if (out / "systemd-run.status").exists() and scalar("systemd-run.status") != "0": errors.append("systemd_run_status")
if (out / "cgroup-start.txt").exists() and (out / "cgroup-end.txt").exists():
    start, end = cgroup_values("cgroup-start.txt"), cgroup_values("cgroup-end.txt")
    if start.get("memory.max") != "4294967296" or end.get("memory.max") != "4294967296": errors.append("memory_max")
    if start.get("memory.swap.max") != "0" or end.get("memory.swap.max") != "0": errors.append("memory_swap_max")
    for event in ("high", "max", "oom", "oom_kill", "oom_group_kill"):
        key = "memory.events." + event
        if start.get(key) != end.get(key) or int(end.get(key, "-1")) != 0: errors.append(key)
else:
    errors.append("cgroup_snapshots")

payload = {
    "schema_version": 1,
    "accepted": not errors,
    "errors": errors,
    "forced_cleanup": outer_status in (124, 137, 143),
    "outer_status": outer_status,
    "systemd_run_status": int(scalar("systemd-run.status")) if (out / "systemd-run.status").exists() else None,
    "unit_joined": (out / "unit.joined").exists() and scalar("unit.joined") == "1",
    "natural_exit": (out / "dummy.json.natural-exit").exists(),
    "unit": unit,
}
(out / "attestation.json").write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
raise SystemExit(0 if payload["accepted"] else 1)
PY

