#!/usr/bin/env bash
set -euo pipefail

out=$1
release=$2
exit_release=$3

python3 - "$out" <<'PY'
import json
import os
import pathlib

def ns(name):
    return os.readlink(f"/proc/self/ns/{name}")

status = pathlib.Path("/proc/self/status").read_text().splitlines()
nspid = next(line.split()[1:] for line in status if line.startswith("NSpid:"))
cgroup = pathlib.Path("/proc/self/cgroup").read_text().splitlines()
unified = next(line.split("::", 1)[1] for line in cgroup if line.startswith("0::"))
payload = {
    "pid": os.getpid(),
    "ppid": os.getppid(),
    "pgid": os.getpgid(0),
    "sid": os.getsid(0),
    "start_ticks": int(pathlib.Path("/proc/self/stat").read_text().split()[21]),
    "namespaces": {name: ns(name) for name in ("user", "pid", "mnt", "net")},
    "nspid": [int(value) for value in nspid],
    "cgroup_path": unified,
    "gomaxprocs": os.environ.get("GOMAXPROCS"),
    "cpu_affinity": sorted(os.sched_getaffinity(0)),
}
pathlib.Path(out).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
PY

for _ in $(seq 1 200); do
  [[ -e $release ]] && break
  sleep 0.05
done
[[ -e $release ]] || exit 40
printf 'released\n' > "$out.released"

for _ in $(seq 1 200); do
  [[ -e $exit_release ]] && break
  sleep 0.05
done
[[ -e $exit_release ]] || exit 41
printf 'natural-exit\n' > "$out.natural-exit"

