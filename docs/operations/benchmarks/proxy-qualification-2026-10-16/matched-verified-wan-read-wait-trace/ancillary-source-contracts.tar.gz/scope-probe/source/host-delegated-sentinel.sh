#!/usr/bin/env bash
set -euo pipefail

state=$1
release=$2

python3 - "$state" <<'PY'
import json, os, pathlib, sys
status = pathlib.Path("/proc/self/status").read_text().splitlines()
value = {
    "pid": os.getpid(),
    "pgid": os.getpgid(0),
    "sid": os.getsid(0),
    "start_ticks": int(pathlib.Path("/proc/self/stat").read_text().split()[21]),
    "cgroup_lines": pathlib.Path("/proc/self/cgroup").read_text().splitlines(),
    "namespaces": {name: os.readlink(f"/proc/self/ns/{name}") for name in ("user", "pid", "mnt", "net", "cgroup")},
}
pathlib.Path(sys.argv[1]).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
PY

for _ in $(seq 1 400); do
  [[ -e $release ]] && break
  sleep 0.05
done
[[ -e $release ]] || exit 40
printf 'natural-exit\n' > "$state.natural-exit"

