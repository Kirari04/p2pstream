#!/usr/bin/env python3
import json
import os
import pathlib
import sys
import time

target_procs, expected_cgroup, state_path, measure_release, exit_release, nonce = sys.argv[1:]
state = pathlib.Path(state_path)

def cgroup():
    return next(line.split("::", 1)[1] for line in pathlib.Path("/proc/self/cgroup").read_text().splitlines() if line.startswith("0::"))

def vector(name):
    return [int(v) for v in next(line.split()[1:] for line in pathlib.Path("/proc/self/status").read_text().splitlines() if line.startswith(name + ":"))]

before = cgroup()
join_error = ""
try:
    with open(target_procs, "w") as stream:
        stream.write("0\n")
    join_status = 0
except OSError as error:
    join_status = 1
    join_error = f"{type(error).__name__}: {error}"
after = cgroup()

value = {
    "pid": os.getpid(),
    "pgid": os.getpgid(0),
    "sid": os.getsid(0),
    "start_ticks": int(pathlib.Path("/proc/self/stat").read_text().split()[21]),
    "nspid": vector("NSpid"),
    "nspgid": vector("NSpgid"),
    "before_cgroup": before,
    "after_cgroup": after,
    "expected_cgroup": expected_cgroup,
    "join_status": join_status,
    "join_error": join_error,
    "role": os.environ.get("P2PSTREAM_SCOPE_PROBE_ROLE"),
    "nonce": os.environ.get("P2PSTREAM_SCOPE_PROBE_NONCE"),
    "gomaxprocs": os.environ.get("GOMAXPROCS"),
    "cpu_affinity": sorted(os.sched_getaffinity(0)),
    "namespaces": {name: os.readlink(f"/proc/self/ns/{name}") for name in ("user", "pid", "mnt", "net", "cgroup")},
}
state.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
if join_status != 0 or after != expected_cgroup or value["role"] != "server-dummy" or value["nonce"] != nonce:
    raise SystemExit(41)

for _ in range(200):
    if pathlib.Path(measure_release).exists():
        break
    time.sleep(0.05)
else:
    raise SystemExit(42)
pathlib.Path(str(state) + ".interval-start").write_text("interval-start\n")

for _ in range(200):
    if pathlib.Path(exit_release).exists():
        break
    time.sleep(0.05)
else:
    raise SystemExit(43)
pathlib.Path(str(state) + ".natural-exit").write_text("natural-exit\n")

