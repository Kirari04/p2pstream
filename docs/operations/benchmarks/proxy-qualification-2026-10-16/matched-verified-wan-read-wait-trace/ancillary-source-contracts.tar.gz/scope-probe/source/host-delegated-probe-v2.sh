#!/usr/bin/env bash
set -euo pipefail

root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../../../.." && pwd)
probe_root=$root/tmp/continuation-20261016/wan-read-wait-source/scope-probe
sentinel=$probe_root/host-delegated-sentinel.sh
dummy=$probe_root/host-delegated-dummy-v2.py
output=$(realpath -m "${1:?output directory required}")
unit=p2p-trace-scope-probe-20261016-c.scope
[[ ! -e $output ]] || { echo "output exists: $output" >&2; exit 2; }
mkdir -p "$output"

parent_user=$(readlink /proc/self/ns/user)
parent_pid=$(readlink /proc/self/ns/pid)
parent_mnt=$(readlink /proc/self/ns/mnt)
parent_net=$(readlink /proc/self/ns/net)
parent_cgroup=$(readlink /proc/self/ns/cgroup)
source_cgroup=$(awk -F'::' '$1 == "0" { print $2 }' /proc/self/cgroup)
sentinel_state=$output/sentinel.json
sentinel_release=$output/sentinel-release

setsid systemd-run --user --scope --quiet --collect --unit="$unit" \
  -p MemoryMax=4294967296 -p MemorySwapMax=0 -p Delegate=yes -- \
  "$sentinel" "$sentinel_state" "$sentinel_release" \
  >"$output/systemd-run.stdout.log" 2>"$output/systemd-run.stderr.log" &
scope_launcher=$!
python3 - "$output/scope-launcher.json" "$scope_launcher" <<'PY'
import json, os, pathlib, sys
out, pid_s = sys.argv[1:]
pid = int(pid_s)
stat = pathlib.Path(f"/proc/{pid}/stat").read_text().split()
pathlib.Path(out).write_text(json.dumps({
    "pid": pid, "pgid": os.getpgid(pid), "sid": os.getsid(pid), "start_ticks": int(stat[21]),
}, indent=2, sort_keys=True) + "\n")
PY

ready=0
for _ in $(seq 1 200); do
  if [[ -s $sentinel_state ]]; then ready=1; break; fi
  kill -0 "$scope_launcher" 2>/dev/null || break
  sleep 0.05
done
((ready)) || { set +e; wait "$scope_launcher"; s=$?; set -e; printf '%s\n' "$s" > "$output/systemd-run.status"; exit "$s"; }

systemctl --user show "$unit" \
  -p Id -p LoadState -p ActiveState -p SubState -p ControlGroup -p Delegate \
  -p MemoryCurrent -p MemoryPeak -p MemoryHigh -p MemoryMax -p EffectiveMemoryMax -p MemorySwapMax \
  > "$output/unit-with-sentinel.txt"
dest_cgroup=$(systemctl --user show "$unit" -p ControlGroup --value)
[[ $dest_cgroup == /user.slice/user-1000.slice/user@1000.service/app.slice/*.scope ]]
target_dir=/sys/fs/cgroup$dest_cgroup
target_procs=$target_dir/cgroup.procs
[[ -d $target_dir && -f $target_procs ]]

python3 - "$output/cgroup-path-contract.json" "$source_cgroup" "$dest_cgroup" "$target_procs" <<'PY'
import json, os, pathlib, stat, sys
out, source, dest, target = sys.argv[1:]
sp, dp = pathlib.PurePosixPath(source), pathlib.PurePosixPath(dest)
common = pathlib.PurePosixPath(os.path.commonpath((str(sp), str(dp))))
common_procs = pathlib.Path("/sys/fs/cgroup") / str(common).lstrip("/") / "cgroup.procs"
target_path = pathlib.Path(target)
def meta(path):
    st = path.stat()
    return {"path": str(path), "uid": st.st_uid, "gid": st.st_gid, "mode": stat.S_IMODE(st.st_mode), "writable": os.access(path, os.W_OK)}
value = {
    "source_cgroup": source,
    "destination_cgroup": dest,
    "nearest_common_ancestor": str(common),
    "destination_procs": meta(target_path),
    "common_ancestor_procs": meta(common_procs),
}
pathlib.Path(out).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
if not value["destination_procs"]["writable"] or not value["common_ancestor_procs"]["writable"]:
    raise SystemExit(1)
PY

measure_release=$output/measure-release
exit_release=$output/exit-release
dummy_state=$output/dummy.json
nonce=$(cat /proc/sys/kernel/random/uuid)
printf '%s\n' "$nonce" > "$output/nonce.txt"

set +e
setsid timeout --signal=TERM --kill-after=5s 45s \
  unshare --user --map-root-user --pid --fork --kill-child=TERM --mount --mount-proc --net \
  bash -c '
    set -euo pipefail
    out=$1 dummy=$2 target_procs=$3 expected=$4 measure_release=$5 exit_release=$6 nonce=$7
    parent_user=$8 parent_pid=$9 parent_mnt=${10} parent_net=${11} parent_cgroup=${12}
    python3 - "$out/outer.json" "$parent_user" "$parent_pid" "$parent_mnt" "$parent_net" "$parent_cgroup" "$$" <<'"'"'PY'"'"'
import json, os, pathlib, sys
out, parent_user, parent_pid, parent_mnt, parent_net, parent_cgroup, shell_pid = sys.argv[1:]
owned = {name: os.readlink(f"/proc/self/ns/{name}") for name in ("user", "pid", "mnt", "net", "cgroup")}
parents = {"user": parent_user, "pid": parent_pid, "mnt": parent_mnt, "net": parent_net, "cgroup": parent_cgroup}
value = {
    "pid": int(shell_pid), "pid_is_one": int(shell_pid) == 1,
    "python_parent_pid": os.getppid(), "python_parent_is_one": os.getppid() == 1,
    "namespaces": owned, "parent_namespaces": parents,
    "owned_four_private": all(owned[k] != parents[k] for k in ("user", "pid", "mnt", "net")),
    "cgroup_namespace_unchanged": owned["cgroup"] == parents["cgroup"],
}
pathlib.Path(out).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
PY
    state=$out/dummy.json
    setsid env GOMAXPROCS=4 P2PSTREAM_SCOPE_PROBE_ROLE=server-dummy P2PSTREAM_SCOPE_PROBE_NONCE="$nonce" \
      taskset -c 0,1,2,3 python3 "$dummy" "$target_procs" "$expected" "$state" "$measure_release" "$exit_release" "$nonce" \
      >"$out/dummy.stdout.log" 2>"$out/dummy.stderr.log" &
    child=$!
    python3 - "$out/dummy-launcher.json" "$child" <<'"'"'PY'"'"'
import json, os, pathlib, sys
out, pid_s = sys.argv[1:]
pid = int(pid_s); st = pathlib.Path(f"/proc/{pid}/stat").read_text().split()
pathlib.Path(out).write_text(json.dumps({"pid":pid,"pgid":os.getpgid(pid),"sid":os.getsid(pid),"start_ticks":int(st[21])}, indent=2, sort_keys=True)+"\n")
PY
    set +e
    wait "$child"
    status=$?
    set -e
    printf "%s\n" "$status" > "$out/dummy.status"
    python3 - "$out/dummy-join.json" "$out/dummy-launcher.json" <<'"'"'PY'"'"'
import json, os, pathlib, sys
out, identity_path = sys.argv[1:]
i = json.load(open(identity_path)); p = pathlib.Path(f"/proc/{i['"'"'pid'"'"']}/stat")
alive = p.exists() and int(p.read_text().split()[21]) == i["start_ticks"]
pgids = {int(v) for v in os.popen("ps -e -o pgid=").read().split()}
value={"alive_same_identity":alive,"group_joined":i["pgid"] not in pgids}
pathlib.Path(out).write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")
raise SystemExit(0 if not alive and value["group_joined"] else 1)
PY
    [[ $status -eq 0 ]]
  ' bash "$output" "$dummy" "$target_procs" "$dest_cgroup" "$measure_release" "$exit_release" "$nonce" \
    "$parent_user" "$parent_pid" "$parent_mnt" "$parent_net" "$parent_cgroup" \
  >"$output/outer.stdout.log" 2>"$output/outer.stderr.log" &
outer_launcher=$!
outer_start_ticks=$(awk '{print $22}' "/proc/$outer_launcher/stat")
outer_pgid=$(ps -o pgid= -p "$outer_launcher" | tr -d ' ')
printf '{"pid":%s,"pgid":%s,"start_ticks":%s}\n' "$outer_launcher" "$outer_pgid" "$outer_start_ticks" > "$output/outer-launcher.json"
set -e

dummy_ready=0
for _ in $(seq 1 200); do
  if [[ -s $dummy_state ]]; then dummy_ready=1; break; fi
  kill -0 "$outer_launcher" 2>/dev/null || break
  sleep 0.05
done
((dummy_ready)) || exit 50

python3 - "$dummy_state" "$dest_cgroup" <<'PY'
import json, sys
v=json.load(open(sys.argv[1]))
assert v["join_status"] == 0 and v["after_cgroup"] == sys.argv[2]
PY

for name in memory.current memory.peak memory.high memory.max memory.swap.max memory.events cgroup.procs; do
  { printf '%s=' "$name"; cat "$target_dir/$name"; } >> "$output/cgroup-with-sentinel.txt"
done
touch "$sentinel_release"
set +e
wait "$scope_launcher"
scope_status=$?
set -e
printf '%s\n' "$scope_status" > "$output/systemd-run.status"
[[ $scope_status -eq 0 && -e $sentinel_state.natural-exit ]]
python3 - "$output/scope-process-join.json" "$output/scope-launcher.json" "$sentinel_state" <<'PY'
import json, os, pathlib, sys
out, launcher_path, sentinel_path = sys.argv[1:]
launcher=json.load(open(launcher_path)); sentinel=json.load(open(sentinel_path))
def alive(i):
    p=pathlib.Path(f"/proc/{i['pid']}/stat")
    try: return p.exists() and int(p.read_text().split()[21]) == i["start_ticks"]
    except (FileNotFoundError, ProcessLookupError): return False
pgids={int(v) for v in os.popen("ps -e -o pgid=").read().split()}
value={
    "launcher_alive_same_identity":alive(launcher),
    "sentinel_alive_same_identity":alive(sentinel),
    "launcher_group_joined":launcher["pgid"] not in pgids,
    "sentinel_group_joined":sentinel["pgid"] not in pgids,
}
pathlib.Path(out).write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")
raise SystemExit(0 if not value["launcher_alive_same_identity"] and not value["sentinel_alive_same_identity"] and value["launcher_group_joined"] and value["sentinel_group_joined"] else 1)
PY

for _ in $(seq 1 100); do
  mapfile -t members < "$target_procs"
  [[ ${#members[@]} -eq 1 ]] && break
  sleep 0.05
done
mapfile -t members < "$target_procs"
[[ ${#members[@]} -eq 1 ]]
dummy_host_pid=${members[0]}
python3 - "$output/host-pid-binding.json" "$dummy_state" "$output/outer.json" "$dummy_host_pid" "$nonce" <<'PY'
import json, os, pathlib, sys
out, dummy_path, outer_path, host_pid_s, nonce = sys.argv[1:]
dummy=json.load(open(dummy_path)); outer=json.load(open(outer_path)); host_pid=int(host_pid_s)
proc=pathlib.Path(f"/proc/{host_pid}")
status=proc.joinpath("status").read_text().splitlines()
def vector(name): return [int(v) for v in next(line.split()[1:] for line in status if line.startswith(name+":"))]
namespaces={name:os.readlink(proc/f"ns/{name}") for name in ("user","pid","mnt","net","cgroup")}
environ={entry.split("=",1)[0]:entry.split("=",1)[1] for entry in proc.joinpath("environ").read_bytes().decode().split("\0") if "=" in entry}
cmdline=[v.decode() for v in proc.joinpath("cmdline").read_bytes().split(b"\0") if v]
start_ticks=int(proc.joinpath("stat").read_text().split()[21])
value={
    "host_pid":host_pid,
    "host_start_ticks":start_ticks,
    "host_nspid":vector("NSpid"),
    "host_nspgid":vector("NSpgid"),
    "host_namespaces":namespaces,
    "host_cpu_affinity":sorted(os.sched_getaffinity(host_pid)),
    "role":environ.get("P2PSTREAM_SCOPE_PROBE_ROLE"),
    "nonce":environ.get("P2PSTREAM_SCOPE_PROBE_NONCE"),
    "cmdline":cmdline,
    "local_pid":dummy["pid"],
}
checks={
    "start_ticks_match":start_ticks==dummy["start_ticks"],
    "local_pid_match":vector("NSpid")[-1]==dummy["pid"],
    "local_pgid_match":vector("NSpgid")[-1]==dummy["pgid"],
    "namespaces_match_outer":namespaces==outer["namespaces"],
    "namespaces_match_dummy":namespaces==dummy["namespaces"],
    "cpu_match":value["host_cpu_affinity"]==dummy["cpu_affinity"]==[0,1,2,3],
    "role_match":value["role"]==dummy["role"]=="server-dummy",
    "nonce_match":value["nonce"]==dummy["nonce"]==nonce and nonce in cmdline,
}
value["checks"]=checks
pathlib.Path(out).write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")
raise SystemExit(0 if all(checks.values()) else 1)
PY
systemctl --user show "$unit" -p LoadState -p ActiveState -p SubState -p ControlGroup -p Delegate > "$output/unit-server-only.txt"
grep -qx 'ActiveState=active' "$output/unit-server-only.txt"
for name in memory.current memory.peak memory.high memory.max memory.swap.max memory.events cgroup.procs; do
  { printf '%s=' "$name"; cat "$target_dir/$name"; } >> "$output/cgroup-server-only.txt"
done
touch "$measure_release"
for _ in $(seq 1 100); do [[ -e $dummy_state.interval-start ]] && break; sleep 0.05; done
[[ -e $dummy_state.interval-start ]]
touch "$exit_release"

set +e
wait "$outer_launcher"
outer_status=$?
set -e
printf '%s\n' "$outer_status" > "$output/outer.status"
outer_alive=false
if [[ -r /proc/$outer_launcher/stat ]] && [[ $(awk '{print $22}' "/proc/$outer_launcher/stat") == "$outer_start_ticks" ]]; then outer_alive=true; fi
outer_group_joined=true
if ps -e -o pgid= | awk -v wanted="$outer_pgid" '$1 == wanted {found=1} END {exit !found}'; then outer_group_joined=false; fi
printf '{"alive_same_identity":%s,"group_joined":%s}\n' "$outer_alive" "$outer_group_joined" > "$output/outer-join.json"

unit_joined=0
: > "$output/unit-final-polls.txt"
for _ in $(seq 1 100); do
  set +e
  show=$(systemctl --user show "$unit" -p LoadState -p ActiveState -p SubState 2>&1)
  show_status=$?
  set -e
  printf 'status=%s %s\n' "$show_status" "${show//$'\n'/ }" >> "$output/unit-final-polls.txt"
  if ((show_status != 0)) || grep -Eq 'LoadState=not-found|ActiveState=inactive|ActiveState=failed' <<<"$show"; then unit_joined=1; break; fi
  sleep 0.05
done
printf '%s\n' "$unit_joined" > "$output/unit.joined"

python3 - "$output" "$unit" <<'PY'
import json, pathlib, re, sys
out=pathlib.Path(sys.argv[1]); unit=sys.argv[2]
def load(n): return json.loads((out/n).read_text())
def scalar(n): return (out/n).read_text().strip()
def values(n):
    v={}; current=None
    for line in (out/n).read_text().splitlines():
        if re.match(r"^[a-z.]+=",line): current,x=line.split("=",1); v[current]=x
        elif current=="memory.events": k,x=line.split(); v["memory.events."+k]=x
    return v
errors=[]; outer=load("outer.json"); dummy=load("dummy.json"); path=load("cgroup-path-contract.json")
if not outer["pid_is_one"] or not outer["python_parent_is_one"] or not outer["owned_four_private"] or not outer["cgroup_namespace_unchanged"]: errors.append("namespace_contract")
if dummy["join_status"] != 0 or dummy["after_cgroup"] != path["destination_cgroup"]: errors.append("self_join")
if dummy["namespaces"] != outer["namespaces"]: errors.append("namespace_changed_during_join")
if dummy["gomaxprocs"] != "4" or dummy["cpu_affinity"] != [0,1,2,3]: errors.append("cpu_contract")
if not path["destination_procs"]["writable"] or not path["common_ancestor_procs"]["writable"]: errors.append("cgroup_write_permissions")
if scalar("systemd-run.status") != "0" or scalar("dummy.status") != "0" or scalar("outer.status") != "0": errors.append("natural_status")
if not (out/"sentinel.json.natural-exit").exists() or not (out/"dummy.json.natural-exit").exists(): errors.append("natural_markers")
if load("outer-join.json")["alive_same_identity"] or not load("outer-join.json")["group_joined"]: errors.append("outer_join")
if load("dummy-join.json")["alive_same_identity"] or not load("dummy-join.json")["group_joined"]: errors.append("dummy_join")
scope_join=load("scope-process-join.json")
if scope_join["launcher_alive_same_identity"] or scope_join["sentinel_alive_same_identity"] or not scope_join["launcher_group_joined"] or not scope_join["sentinel_group_joined"]: errors.append("sentinel_join")
if scalar("unit.joined") != "1": errors.append("unit_join")
a,b=values("cgroup-with-sentinel.txt"),values("cgroup-server-only.txt")
for valueset in (a,b):
    if valueset.get("memory.max")!="4294967296" or valueset.get("memory.swap.max")!="0": errors.append("memory_limits")
for event in ("high","max","oom","oom_kill","oom_group_kill"):
    key="memory.events."+event
    if a.get(key)!=b.get(key) or int(b.get(key,"-1"))!=0: errors.append(key)
binding=load("host-pid-binding.json")
if not all(binding["checks"].values()) or b.get("cgroup.procs") != str(binding["host_pid"]): errors.append("server_only_membership")
result={"schema_version":1,"accepted":not errors,"errors":sorted(set(errors)),"forced_cleanup":int(scalar("outer.status")) in (124,137,143),"unit":unit,"statuses":{"systemd_run":int(scalar("systemd-run.status")),"dummy":int(scalar("dummy.status")),"outer":int(scalar("outer.status"))},"unit_joined":scalar("unit.joined")=="1","sentinel_exited_before_interval":(out/"sentinel.json.natural-exit").exists() and (out/"dummy.json.interval-start").exists()}
(out/"attestation.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
raise SystemExit(0 if result["accepted"] else 1)
PY

