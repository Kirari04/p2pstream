#!/usr/bin/env bash
set -euo pipefail

target_procs=$1
expected_cgroup=$2
state=$3
measure_release=$4
exit_release=$5

before=$(awk -F'::' '$1 == "0" { print $2 }' /proc/self/cgroup)
set +e
printf '0\n' > "$target_procs"
join_status=$?
set -e
after=$(awk -F'::' '$1 == "0" { print $2 }' /proc/self/cgroup)

python3 - "$state" "$before" "$after" "$expected_cgroup" "$join_status" <<'PY'
import json, os, pathlib, sys
out, before, after, expected, join_status = sys.argv[1:]
status = pathlib.Path("/proc/self/status").read_text().splitlines()
def vector(name):
    return [int(v) for v in next(line.split()[1:] for line in status if line.startswith(name + ":"))]
value = {
    "pid": os.getpid(),
    "pgid": os.getpgid(0),
    "sid": os.getsid(0),
    "start_ticks": int(pathlib.Path("/proc/self/stat").read_text().split()[21]),
    "nspid": vector("NSpid"),
    "nspgid": vector("NSpgid"),
    "before_cgroup": before,
    "after_cgroup": after,
    "expected_cgroup": expected,
    "join_status": int(join_status),
    "gomaxprocs": os.environ.get("GOMAXPROCS"),
    "cpu_affinity": sorted(os.sched_getaffinity(0)),
    "namespaces": {name: os.readlink(f"/proc/self/ns/{name}") for name in ("user", "pid", "mnt", "net", "cgroup")},
}
pathlib.Path(out).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
PY

[[ $join_status -eq 0 && $after == "$expected_cgroup" ]] || exit 41
for _ in $(seq 1 200); do
  [[ -e $measure_release ]] && break
  sleep 0.05
done
[[ -e $measure_release ]] || exit 42
printf 'interval-start\n' > "$state.interval-start"
for _ in $(seq 1 200); do
  [[ -e $exit_release ]] && break
  sleep 0.05
done
[[ -e $exit_release ]] || exit 43
printf 'natural-exit\n' > "$state.natural-exit"

