#!/usr/bin/env python3
import hashlib
import importlib.util
import json
import math
import pathlib
import sys

if len(sys.argv) != 11:
    raise SystemExit("usage: validate-wan-copy-attribution-arm.py RESULTS LIFECYCLE SUMMARY OUTER SUPERVISOR PRE_HASHES POST_HASHES ATTESTATION PROTOCOL SMOKE")

copy_validator_path = pathlib.Path(__file__).with_name("validate-copy-record.py")
spec = importlib.util.spec_from_file_location("copy_record_validator", copy_validator_path)
copy_record_validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(copy_record_validator)

(results_path, lifecycle_path, summary_path, outer_path, supervisor_path,
 pre_path, post_path, attestation_path) = map(pathlib.Path, sys.argv[1:9])
protocol, smoke_text = sys.argv[9:]
if protocol not in ("h1", "h2") or smoke_text not in ("0", "1"):
    raise SystemExit("invalid protocol or smoke argument")
smoke = smoke_text == "1"
rows = [json.loads(line) for line in results_path.read_text().splitlines() if line.strip()]
lifecycle = [json.loads(line) for line in lifecycle_path.read_text().splitlines() if line.strip()]
summary = json.loads(summary_path.read_text())
outer = json.loads(outer_path.read_text())
supervisor = json.loads(supervisor_path.read_text())
pre = json.loads(pre_path.read_text())
post = json.loads(post_path.read_text())
issues = []

def sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def safe_sha(path: pathlib.Path):
    try:
        return sha(path)
    except OSError:
        return None

expected = [("warmup", "download", n) for n in range(1, 5)]
expected += [("warmup", "upload", n) for n in range(1, 5)]
expected += [("retained-warmup", "download", 1), ("retained-warmup", "upload", 1)]
if smoke:
    expected += [("steady", "download", 1), ("steady", "upload", 1), ("reuse-probe", "download", 1)]
else:
    expected += [
        ("steady", "download", 1), ("steady", "upload", 1),
        ("steady", "upload", 2), ("steady", "download", 2),
        ("steady", "download", 3), ("steady", "upload", 3),
    ]
actual = [(row.get("measurement_stage"), row.get("transfer_direction"), row.get("repetition")) for row in rows]
if actual != expected:
    issues.append(f"result order/shape changed: {actual!r}")
if pre != post:
    issues.append("binary, source overlay, certificate, or harness hashes changed during the arm")
hashes = pre.get("sha256", {})
required_hashes = {
    "supervisor", "runner", "validator", "approved_lifecycle_runner", "frozen_protocol_runner", "frozen_copy_runner",
    "wan_protocol_runner_patch", "copy_runner_patch", "monotonic_runner_patch", "read_wait_runner_patch", "go_base_patch", "go_helper",
    "copy_record_validator", "copy_attribution_overlay_patch", "copy_attribution_design",
    "monotonic_observer_patch", "monotonic_validator_patch", "monotonic_arm_validator_patch",
    "final_source_attestation", "integration_notes", "copy_timing_decision_map",
    "runner_reconstruction_attestation", "monotonic_build_manifest", "monotonic_audited_build_manifest",
    "read_wait_observer_patch", "read_wait_observer_checkpoint", "read_wait_focused_checkpoint",
    "read_wait_audited_build_manifest", "server_scope_entrypoint", "server_scope_sentinel",
    "server_scope_validator", "server_scope_resource_validator", "delegated_scope_probe_attestation", "trace_analyzer", "trace_analyzer_hashes",
    "trace_analyzer_schema", "trace_analyzer_checkpoint", "trace_parser_wrapper", "pinned_go",
    "runner_integration_design", "static_contract", "resource_contract", "traced_transfer_contract",
    "arm_validator_contract", "all_contracts",
    "server_binary", "aggregate_agent_binary", "certificate_pem", "private_key_pem",
}
if set(hashes) != required_hashes or any(not isinstance(hashes.get(name), str) or len(hashes[name]) != 64 for name in required_hashes):
    issues.append("preflight hash manifest is incomplete")
expected_major = 1 if protocol == "h1" else 2
expected_alpn = "http/1.1" if protocol == "h1" else "h2"
payload_bytes = (4 if smoke else 256) << 20
required_pool_bytes = (2 if smoke else 8) << 20
floor = 29_700_000
phase_download_rates = {stage: [] for stage in ("warmup", "retained-warmup", "steady")}
trace_records = []
copy_records = []
copy_issues_by_sequence = {}

for index, row in enumerate(rows, 1):
    direction = row.get("transfer_direction")
    expected_response = payload_bytes if direction == "download" else 32
    wall = row.get("wall_seconds")
    rate = row.get("useful_transfer_bytes_per_second")
    finite_rate = isinstance(wall, (int, float)) and math.isfinite(wall) and wall > 0
    finite_rate = finite_rate and isinstance(rate, (int, float)) and math.isfinite(rate) and rate > 0
    rate_matches = finite_rate and math.isclose(rate, payload_bytes / wall, rel_tol=1e-9, abs_tol=1e-6)
    exact = (
        row.get("diagnostic_sequence") == index
        and row.get("transport_mode") == "aggregate-v1"
        and row.get("public_protocol") == protocol
        and row.get("protocol") == protocol
        and row.get("observed_http_major") == expected_major
        and row.get("attempted") == row.get("useful_completed") == 1
        and row.get("errors") == 0
        and row.get("status_classes") == {"2xx": 1}
        and row.get("status_codes") == {"200": 1}
        and row.get("configured_payload_bytes") == payload_bytes
        and row.get("response_bytes") == expected_response
        and rate_matches
        and row.get("event_stats_captured") is True
        and row.get("persisted_event_delta") == 1
        and (row.get("dropped_event_delta") or 0) == 0
        and (row.get("event_queue_after_drain") or 0) == 0
        and (row.get("event_drain_error") or "") == ""
        and row.get("configured_rtt_ms") == 80
        and row.get("shaped_rate_bits_per_second") == 1_000_000_000
    )
    if not exact:
        issues.append(f"row {index} failed exact schedule/payload/status/rate/event conservation")
    if direction == "download" and isinstance(rate, (int, float)) and math.isfinite(rate):
        phase_download_rates.setdefault(row.get("measurement_stage"), []).append(rate)
    tls = row.get("wan_response_tls", [])
    if not (len(tls) == 1 and tls[0].get("http_major") == expected_major
            and tls[0].get("negotiated_alpn") == expected_alpn
            and tls[0].get("peer_leaf_der_sha256") == pre.get("expected_leaf_der_sha256")
            and tls[0].get("origin_connection_id") and not tls[0].get("validation_error")):
        issues.append(f"row {index} failed verified public TLS/protocol/origin identity")
    copy_envelope = row.get("response_copy_attribution", {})
    copy_issues = copy_record_validator.validate_copy_envelope(copy_envelope, index, direction, payload_bytes)
    if copy_issues:
        copy_issues_by_sequence[str(index)] = copy_issues
        issues.append(f"row {index} copy attribution failed: {'; '.join(copy_issues)}")
    copy_matches = copy_envelope.get("matches", []) if isinstance(copy_envelope, dict) else []
    copy_record = copy_matches[0] if len(copy_matches) == 1 and isinstance(copy_matches[0], dict) else {}
    copy_metrics = copy_record.get("copy", {}) if isinstance(copy_record.get("copy"), dict) else {}
    started_ns, returned_ns = copy_record.get("started_unix_ns"), copy_record.get("handler_return_unix_ns")
    copy_records.append({
        "sequence": index, "direction": direction, "scope": copy_record.get("scope"),
        "method": copy_record.get("method"), "path": copy_record.get("path"),
        "complete": copy_metrics.get("complete"),
        "handler_elapsed_ns": copy_record.get("handler_elapsed_ns"),
        "upstream_read": copy_metrics.get("upstream_read"),
        "downstream_write": copy_metrics.get("downstream_write"),
        "inter_read_gap": copy_metrics.get("inter_read_gap"),
        "read_eof": copy_metrics.get("read_eof"),
    })
    envelope = row.get("upstream_transport_trace", {})
    matches = envelope.get("matches", [])
    method = "GET" if direction == "download" else "POST"
    path = "/agent/bulk" if direction == "download" else "/agent/bulk-upload"
    if len(matches) != 1:
        issues.append(f"row {index} missing or repeated upstream trace")
        trace_records.append({})
    else:
        trace = matches[0]
        if not (
            envelope.get("overflow") is False
            and envelope.get("store_count") == index
            and envelope.get("sequence") == str(index)
            and trace.get("sequence") == str(index)
            and trace.get("method") == method
            and trace.get("path") == path
            and trace.get("callback_overflow") is False
            and len(trace.get("got_conn", [])) == 1
            and len(trace.get("put_idle_conn", [])) <= 1
        ):
            issues.append(f"row {index} upstream trace correlation/cardinality changed")
        got = trace.get("got_conn", [{}])[0] if len(trace.get("got_conn", [])) == 1 else {}
        parts = (got.get("connection_type"), got.get("local_address"), got.get("remote_address"))
        trace_records.append({
            "connection_key": "|".join(parts) if all(isinstance(part, str) and part for part in parts) else "",
            "reused": got.get("reused"), "was_idle": got.get("was_idle"),
            "idle_time_ns": got.get("idle_time_ns"), "got_conn_unix_ns": got.get("observed_unix_ns"),
            "put_idle_conn": trace.get("put_idle_conn", []),
            "origin_connection_id": tls[0].get("origin_connection_id") if len(tls) == 1 else None,
        })
    provenance = row.get("provenance", {})
    if not (
        provenance.get("server_binary_sha256") == hashes.get("server_binary")
        and provenance.get("aggregate_agent_binary_sha256") == hashes.get("aggregate_agent_binary")
        and provenance.get("harness_sha256") == hashes.get("runner")
        and provenance.get("server_source_ref") == pre.get("server_source_ref")
        and provenance.get("aggregate_agent_source_ref") == pre.get("aggregate_agent_source_ref")
    ):
        issues.append(f"row {index} binary, source, or harness provenance changed")
    if row.get("measurement_stage") == "steady" and not row.get("receiving_pool_observed_bytes", 0) > required_pool_bytes:
        issues.append(f"row {index} did not retain required aggregate receive-pool evidence")

phase_classification = {}
for stage in ("warmup", "retained-warmup", "steady"):
    rates = phase_download_rates.get(stage, [])
    expected_samples = 4 if stage == "warmup" else (1 if stage == "retained-warmup" else (1 if smoke else 3))
    at_floor = len(rates) == expected_samples and all(rate >= floor for rate in rates)
    phase_classification[stage] = {
        "samples": len(rates),
        "minimum_bytes_per_second": min(rates) if rates else None,
        "all_at_or_above_floor": at_floor,
        "gating": not smoke,
    }
    if not smoke and not at_floor:
        issues.append(f"{stage} download phase failed independent {floor} B/s floor")

reuse_expectations = []
reuse_issues = []
first_visits = trace_records[8:12]
if len(first_visits) != 4:
    reuse_issues.append("missing four first post-close lane-key visits")
first_keys = set()
for offset, trace in enumerate(first_visits):
    sequence = offset + 9
    key = trace.get("connection_key")
    puts = trace.get("put_idle_conn", [])
    successful_put = (len(puts) == 1 and isinstance(puts[0].get("observed_unix_ns"), int)
                      and puts[0]["observed_unix_ns"] > 0 and not puts[0].get("error"))
    satisfied = bool(key and key not in first_keys and trace.get("reused") is False
                     and trace.get("was_idle") is False and trace.get("idle_time_ns") == 0 and successful_put)
    if not satisfied:
        reuse_issues.append(f"sequence {sequence} is not a distinct expected-fresh post-close key with successful PutIdleConn")
    if key:
        first_keys.add(key)
    reuse_expectations.append({"sequence": sequence, "kind": "first-post-close-visit", "lane_position": offset + 1,
                               "connection_key": key, "satisfied": satisfied})
revisits = trace_records[12:]
expected_revisit_count = 1 if smoke else 4
if len(revisits) != expected_revisit_count:
    reuse_issues.append(f"same-key revisit count {len(revisits)} changed")
for offset, trace in enumerate(revisits):
    first = first_visits[offset % 4] if len(first_visits) == 4 else {}
    prior_put = first.get("put_idle_conn", [])
    prior_put_ns = prior_put[0].get("observed_unix_ns") if len(prior_put) == 1 else None
    got_ns = trace.get("got_conn_unix_ns")
    elapsed = got_ns - prior_put_ns if isinstance(got_ns, int) and isinstance(prior_put_ns, int) else None
    satisfied = bool(first.get("connection_key") and trace.get("connection_key") == first.get("connection_key")
                     and trace.get("reused") is True and trace.get("was_idle") is True
                     and isinstance(trace.get("idle_time_ns"), int) and trace["idle_time_ns"] >= 0
                     and isinstance(elapsed, int) and 0 <= elapsed < 30_000_000_000
                     and trace.get("origin_connection_id") == first.get("origin_connection_id"))
    if not satisfied:
        reuse_issues.append(f"sequence {offset + 13} did not reuse its bound post-close lane key")
    reuse_expectations.append({
        "sequence": offset + 13, "kind": "same-key-revisit", "lane_position": offset % 4 + 1,
        "connection_key": trace.get("connection_key"),
        "expected_connection_key": first.get("connection_key"), "prior_put_idle_unix_ns": prior_put_ns,
        "got_conn_unix_ns": got_ns, "elapsed_idle_ns": elapsed, "httptrace_idle_time_ns": trace.get("idle_time_ns"),
        "prior_origin_connection_id": first.get("origin_connection_id"),
        "observed_origin_connection_id": trace.get("origin_connection_id"), "satisfied": satisfied,
    })
issues.extend(reuse_issues)

trace_records_path = pathlib.Path(str(results_path).removesuffix(".jsonl") + ".read-wait-trace-records.jsonl")
trace_directory = pathlib.Path(str(results_path).removesuffix(".jsonl") + ".read-wait-traces")
trace_control_directory = pathlib.Path(str(results_path).removesuffix(".jsonl") + ".read-wait-controls")
expected_trace_specs = ({9: ("retained-warmup", 1), 11: ("steady", 1), 13: ("reuse-probe", 1)} if smoke else
                        {9: ("retained-warmup", 1), 11: ("steady", 1), 14: ("steady", 2), 15: ("steady", 3)})
try:
    read_wait_records = [json.loads(line) for line in trace_records_path.read_text().splitlines() if line.strip()]
except (OSError, json.JSONDecodeError) as error:
    read_wait_records = []
    issues.append(f"read-wait trace records are unreadable: {error}")
if len(read_wait_records) != len(expected_trace_specs):
    issues.append(f"read-wait trace record count {len(read_wait_records)} changed")
trace_artifacts = []
seen_trace_sequences = set()
for record in read_wait_records:
    sequence = record.get("sequence") if isinstance(record, dict) else None
    if sequence in seen_trace_sequences:
        issues.append(f"read-wait sequence {sequence!r} was repeated")
    seen_trace_sequences.add(sequence)
    expected_spec = expected_trace_specs.get(sequence)
    start = record.get("start_control") if isinstance(record, dict) else None
    stop = record.get("stop_control") if isinstance(record, dict) else None
    start_capture = start.get("response", {}).get("capture", {}) if isinstance(start, dict) else {}
    stop_capture = stop.get("response", {}).get("capture", {}) if isinstance(stop, dict) else {}
    expected_path = trace_directory / f"runtime-trace-sequence-{sequence}.out"
    writer = stop_capture.get("writer", {}) if isinstance(stop_capture.get("writer"), dict) else {}
    try:
        artifact_size = expected_path.stat().st_size
        artifact_sha = sha(expected_path)
    except OSError as error:
        artifact_size, artifact_sha = None, None
        issues.append(f"read-wait sequence {sequence!r} artifact is unreadable: {error}")
    valid = bool(
        expected_spec is not None
        and record.get("stage") == expected_spec[0] and record.get("direction") == "download"
        and record.get("repetition") == expected_spec[1]
        and record.get("control_boundary") == "start-before-run_transfer-stop-after-run_transfer-including-postqueries"
        and record.get("handler_region_boundary") == "unchanged-public-proxy-handler-only"
        and record.get("trace_artifact_scope") == "whole-server-process"
        and record.get("qualification_result") is False
        and record.get("pre_resource_status") == record.get("pre_healthy_status") == 0
        and record.get("transfer_status") == record.get("stop_status") == 0
        and record.get("post_runtime_status") == record.get("post_cgroup_status") == record.get("resource_status") == 0
        and record.get("complete") is True and record.get("valid") is True
        and isinstance(start, dict) and start.get("action") == "start" and start.get("sequence") == str(sequence)
        and start.get("http_status") == 200 and start.get("error") == ""
        and start_capture.get("sequence") == str(sequence) and start_capture.get("state") == "active"
        and start_capture.get("complete") is False and start_capture.get("valid") is False
        and isinstance(stop, dict) and stop.get("action") == "stop" and stop.get("sequence") == str(sequence)
        and stop.get("http_status") == 200 and stop.get("error") == ""
        and stop_capture.get("sequence") == str(sequence) and stop_capture.get("state") == "complete"
        and stop_capture.get("task_type") == "wan-read-wait-request"
        and stop_capture.get("region_type") == "public-proxy-handler"
        and stop_capture.get("expected_method") == "GET" and stop_capture.get("expected_path") == "/agent/bulk"
        and stop_capture.get("path") == str(expected_path)
        and stop_capture.get("candidate_requests") == stop_capture.get("marked_requests") == 1
        and stop_capture.get("active_requests") == stop_capture.get("requests_outside_capture") == 0
        and stop_capture.get("controller_timed_out") is False and stop_capture.get("issues") == []
        and stop_capture.get("issue_overflow") is False and stop_capture.get("complete") is True and stop_capture.get("valid") is True
        and isinstance(stop_capture.get("started_unix_ns"), int) and isinstance(stop_capture.get("stopped_unix_ns"), int)
        and stop_capture["started_unix_ns"] <= stop_capture["stopped_unix_ns"]
        and isinstance(stop_capture.get("trace_elapsed_ns"), int) and stop_capture["trace_elapsed_ns"] >= 0
        and writer.get("cap_bytes") == 64 << 20 and isinstance(writer.get("bytes"), int)
        and writer.get("input_bytes") == writer.get("bytes") == artifact_size and artifact_size is not None and artifact_size > 0
        and writer.get("overflow") is False and (writer.get("error") or "") == ""
    )
    if not valid:
        issues.append(f"read-wait sequence {sequence!r} control/artifact contract failed")
    trace_artifacts.append({"sequence": sequence, "path": str(expected_path), "size_bytes": artifact_size,
                            "sha256": artifact_sha, "valid": valid})
if seen_trace_sequences != set(expected_trace_specs):
    issues.append(f"read-wait trace sequence set {sorted(v for v in seen_trace_sequences if isinstance(v, int))!r} changed")
expected_control_names = {f"sequence-{sequence}-{action}.json" for sequence in expected_trace_specs for action in ("start", "stop")}
try:
    actual_control_names = {path.name for path in trace_control_directory.iterdir() if path.is_file()}
except OSError as error:
    actual_control_names = set()
    issues.append(f"read-wait control directory is unreadable: {error}")
if actual_control_names != expected_control_names:
    issues.append(f"read-wait control file set changed: {sorted(actual_control_names)!r}")
try:
    actual_trace_names = {path.name for path in trace_directory.iterdir() if path.is_file()}
except OSError as error:
    actual_trace_names = set()
    issues.append(f"read-wait trace directory is unreadable: {error}")
expected_trace_names = {f"runtime-trace-sequence-{sequence}.out" for sequence in expected_trace_specs}
if actual_trace_names != expected_trace_names:
    issues.append(f"read-wait trace artifact set changed: {sorted(actual_trace_names)!r}")

reduction_directory = results_path.parent / "read-wait-reductions"
reduction_index_path = reduction_directory / "index.json"
try:
    reduction_index = json.loads(reduction_index_path.read_text())
except (OSError, json.JSONDecodeError) as error:
    reduction_index = {}
    issues.append(f"trace reduction index is unreadable: {error}")
reduction_entries = reduction_index.get("entries", []) if isinstance(reduction_index, dict) else []
if not (reduction_index.get("schema_version") == 1 and reduction_index.get("diagnostic_only") is True
        and reduction_index.get("duration_relation_to_copy_observer") == "descriptive-only"
        and [entry.get("sequence") for entry in reduction_entries if isinstance(entry, dict)] == list(expected_trace_specs)):
    issues.append("trace reduction index scope or sequence order changed")
trace_reductions = []
for entry in reduction_entries:
    sequence = entry.get("sequence") if isinstance(entry, dict) else None
    if sequence not in expected_trace_specs or not (1 <= sequence <= len(rows)):
        issues.append(f"trace reduction has invalid sequence {sequence!r}")
        continue
    row = rows[sequence - 1]
    raw_path = pathlib.Path(entry.get("raw_path", ""))
    parsed_path = pathlib.Path(entry.get("parsed_path", ""))
    status_path = pathlib.Path(entry.get("parser_status_path", ""))
    reduction_path = pathlib.Path(entry.get("reduction_path", ""))
    analyzer_status_path = reduction_directory / f"sequence-{sequence}.analyzer.status"
    expected_parsed_path = reduction_directory / f"sequence-{sequence}.parsed.txt"
    expected_parser_status_path = reduction_directory / f"sequence-{sequence}.parser.status"
    expected_reduction_path = reduction_directory / f"sequence-{sequence}.reduction.json"
    try:
        reduction = json.loads(reduction_path.read_text())
        parser_status_exact = status_path.read_bytes() == b"0\n"
        analyzer_status_exact = analyzer_status_path.read_bytes() == b"0\n"
    except (OSError, json.JSONDecodeError) as error:
        reduction = {}
        parser_status_exact = analyzer_status_exact = False
        issues.append(f"trace reduction sequence {sequence} is unreadable: {error}")
    tls = row.get("wan_response_tls", [])
    origin_identity = tls[0].get("origin_connection_id") if len(tls) == 1 and isinstance(tls[0], dict) else None
    state_ns = reduction.get("reduction", {}).get("state_ns", {})
    region_duration = reduction.get("reduction", {}).get("region_duration_ns")
    join_valid = bool(
        entry.get("server_binary_sha256") == hashes.get("server_binary")
        and entry.get("server_source_ref") == pre.get("server_source_ref")
        and entry.get("runner_sha256") == hashes.get("runner")
        and entry.get("public_protocol") == protocol
        and entry.get("certificate_der_sha256") == pre.get("expected_leaf_der_sha256")
        and isinstance(origin_identity, str) and origin_identity
        and entry.get("origin_connection_id") == origin_identity
        and raw_path == trace_directory / f"runtime-trace-sequence-{sequence}.out"
        and parsed_path == expected_parsed_path
        and status_path == expected_parser_status_path
        and reduction_path == expected_reduction_path
        and entry.get("raw_sha256") == safe_sha(raw_path)
        and entry.get("parsed_sha256") == safe_sha(parsed_path)
        and entry.get("parser_status_sha256") == safe_sha(status_path)
        and entry.get("reduction_sha256") == safe_sha(reduction_path)
    )
    reduction_valid = bool(
        parser_status_exact and analyzer_status_exact
        and reduction.get("schema_version") == 1 and reduction.get("accepted") is True and reduction.get("errors") == []
        and reduction.get("task_type") == "wan-read-wait-request" and reduction.get("region_type") == "public-proxy-handler"
        and reduction.get("input") == str(parsed_path) and reduction.get("input_sha256") == safe_sha(parsed_path)
        and reduction.get("parsed_tool_status_file") == str(status_path)
        and reduction.get("parsed_tool_status_sha256") == hashlib.sha256(b"0\n").hexdigest()
        and reduction.get("fixed_bounds", {}).get("max_input_bytes") == 512 << 20
        and reduction.get("fixed_bounds", {}).get("max_output_bytes") == 8 << 20
        and isinstance(reduction.get("markers", {}).get("task_id"), int) and reduction["markers"]["task_id"] > 0
        and isinstance(reduction.get("markers", {}).get("handler_gid"), int) and reduction["markers"]["handler_gid"] > 0
        and isinstance(region_duration, int) and region_duration > 0
        and set(state_ns) == {"Running", "Runnable", "Syscall", "Waiting"}
        and all(isinstance(state_ns[name], int) and state_ns[name] >= 0 for name in state_ns)
        and sum(state_ns.values()) == region_duration
        and reduction.get("reduction", {}).get("partition_delta_ns") == 0
        and reduction.get("reduction", {}).get("partition_sum_ns") == region_duration
        and reduction.get("reduction", {}).get("missing_stack_ns") == 0
        and isinstance(reduction.get("reduction", {}).get("unknown_stack_ns"), int)
        and reduction["reduction"]["unknown_stack_ns"] >= 0
        and isinstance(reduction.get("reduction", {}).get("waiting_category_ns"), dict)
        and isinstance(reduction.get("reduction", {}).get("waiting_reason_ns"), dict)
        and isinstance(reduction.get("reduction", {}).get("waiting_stack_groups"), list)
        and len(reduction["reduction"]["waiting_stack_groups"]) <= 4096
        and isinstance(reduction.get("reduction", {}).get("top_wait_intervals"), list)
        and len(reduction["reduction"]["top_wait_intervals"]) <= 8
        and isinstance(reduction.get("reduction", {}).get("attribution_complete"), bool)
    )
    if not join_valid:
        issues.append(f"trace reduction sequence {sequence} failed cohort identity join")
    if not reduction_valid:
        issues.append(f"trace reduction sequence {sequence} failed local parser/reducer contract")
    trace_reductions.append({
        "sequence": sequence, "join_valid": join_valid, "reduction_valid": reduction_valid,
        "region_duration_ns": region_duration, "state_ns": state_ns,
        "waiting_category_ns": reduction.get("reduction", {}).get("waiting_category_ns"),
        "waiting_reason_ns": reduction.get("reduction", {}).get("waiting_reason_ns"),
        "waiting_stack_groups": reduction.get("reduction", {}).get("waiting_stack_groups"),
        "top_wait_intervals": reduction.get("reduction", {}).get("top_wait_intervals"),
        "unknown_stack_ns": reduction.get("reduction", {}).get("unknown_stack_ns"),
        "attribution_complete": reduction.get("reduction", {}).get("attribution_complete"),
        "copy_handler_elapsed_ns": copy_records[sequence - 1].get("handler_elapsed_ns"),
        "duration_comparison": "descriptive-only",
    })

acceptance = summary.get("acceptance")
expected_acceptance = {
    "correctness", "verified_tls_and_protocol_every_response", "transport_trace_complete", "expected_upstream_reuse",
    "response_copy_attribution_complete", "download_floor_every_phase"
}
if summary.get("classification") != "observational-complete":
    issues.append(f"diagnostic classification is not conclusive: {summary.get('classification')!r}")
if not isinstance(acceptance, dict) or set(acceptance) != expected_acceptance or any(value is not True for value in acceptance.values()):
    issues.append(f"diagnostic acceptance failed or incomplete: {acceptance!r}")
if summary.get("public_protocol") != protocol or summary.get("diagnostic_only") is not True:
    issues.append("summary protocol/scope changed")
if summary.get("copy_attribution_issues_by_sequence") != copy_issues_by_sequence:
    issues.append("summary copy-attribution issue evidence differs from independently validated rows")
expected_copy_interpretation = ("Diagnostic observer only. Upstream Read and downstream Write durations are compared separately with monotonic handler elapsed time. Unix timestamps are retained only for coarse correlation. "
                                "Inter-read gaps include downstream Write time and bookkeeping and are never added as an independent component. "
                                "POST observations cover only the 32-byte response copy, not upload request-body handling.")
if summary.get("copy_attribution_interpretation") != expected_copy_interpretation:
    issues.append("summary copy-attribution interpretation changed")

expected_labels = {
    f"current-server-aggregate-v1-{protocol}-1-agent",
    f"current-server-aggregate-v1-{protocol}-1-server",
    "origin", "agent-namespace", "router-namespace",
}
process_exits = [row for row in lifecycle if row.get("event") == "process-exit"]
labels = [row.get("label") for row in process_exits]
pids = [row.get("pid") for row in process_exits]
lifecycle_identity_ok = not (len(process_exits) != len(expected_labels) or set(labels) != expected_labels or len(set(labels)) != len(labels)
        or any(not isinstance(pid, int) or pid <= 0 for pid in pids) or len(set(pids)) != len(pids))
if not lifecycle_identity_ok:
    issues.append(f"endpoint/namespace exit count, labels, or process identities changed: {process_exits!r}")
lifecycle_status_ok = not any(not (row.get("forced") is False and row.get("status") == 0 and row.get("group_joined") is True
               and row.get("invalidates_success") is False) for row in process_exits)
if not lifecycle_status_ok:
    issues.append(f"endpoint or namespace lifecycle was not wholly natural: {process_exits!r}")
lifecycle_no_invalidation = not any(row.get("invalidates_success") is True for row in lifecycle)
if not lifecycle_no_invalidation:
    issues.append("lifecycle contains an invalidating event")
namespace_rows = [row for row in lifecycle if row.get("event") == "namespace-helpers-start"]
namespace_ok = len(namespace_rows) == 1
if not namespace_ok:
    issues.append("missing unique namespace-helper identity row")
else:
    helper = namespace_rows[0]
    if helper.get("agent", {}).get("namespace") == helper.get("router", {}).get("namespace"):
        namespace_ok = False
        issues.append("agent and router namespace identities are equal")
    for role in ("agent", "router"):
        if not isinstance(helper.get(role, {}).get("start_ticks"), int) or helper[role]["start_ticks"] <= 0:
            namespace_ok = False
            issues.append(f"invalid {role} namespace helper start ticks")
outer_ok = (outer.get("all_private") is True and outer.get("shell_pid_is_one") is True
            and outer.get("python_parent_is_one") is True
            and outer.get("cgroup_namespace_unchanged") is True
            and outer.get("owned", {}).get("cgroup") == outer.get("parent", {}).get("cgroup"))
if not outer_ok:
    issues.append(f"outer user/PID/mount/network namespace ownership missing: {outer!r}")

scope_directory = results_path.parent / "server-scope"
def read_scope_json(name):
    try:
        return json.loads((scope_directory / name).read_text())
    except (OSError, json.JSONDecodeError) as error:
        issues.append(f"server scope {name} is unreadable: {error}")
        return {}
scope_preexec_binding = read_scope_json("server-preexec-binding.json")
scope_application_binding = read_scope_json("server-application-binding.json")
scope_resource = read_scope_json("server-resource-attestation.json")
scope_process_join = read_scope_json("scope-process-join.json")
scope_pre_traffic = read_scope_json("server-cgroup-pre-traffic.json")
scope_post_workload = read_scope_json("server-cgroup-post-workload.json")
scope_unit_policy = read_scope_json("unit-policy.json")
scope_unit_final = read_scope_json("unit-final.json")
scope_launcher = read_scope_json("scope-launcher.json")
scope_delegation = read_scope_json("cgroup-delegation-paths.json")
pre_host = scope_preexec_binding.get("host_process", {})
app_host = scope_application_binding.get("host_process", {})
scope_event_keys = ("high", "max", "oom", "oom_kill", "oom_group_kill")
expected_scope_path = scope_preexec_binding.get("scope", {}).get("path")
expected_scope_unified_path = scope_preexec_binding.get("state", {}).get("expected_cgroup")
delegation_destination = scope_delegation.get("destination", {})
delegation_procs = scope_delegation.get("destination_cgroup_procs", {})
delegation_common = scope_delegation.get("common_ancestor", {})
delegation_common_procs = scope_delegation.get("common_ancestor_cgroup_procs", {})
scope_ok = bool(
    scope_preexec_binding.get("accepted") is True and scope_application_binding.get("accepted") is True
    and all(value is True for value in scope_preexec_binding.get("checks", {}).values())
    and all(value is True for value in scope_application_binding.get("checks", {}).values())
    and isinstance(pre_host.get("host_pid"), int) and pre_host.get("host_pid") == app_host.get("host_pid")
    and pre_host.get("host_start_ticks") == app_host.get("host_start_ticks")
    and pre_host.get("host_namespaces") == app_host.get("host_namespaces")
    and scope_resource.get("accepted") is True and all(value is True for value in scope_resource.get("checks", {}).values())
    and scope_process_join == {"launcher_alive_same_identity": False, "launcher_group_joined": True,
                               "sentinel_alive_same_identity": False, "sentinel_group_joined": True}
    and scope_launcher.get("setsid_identity_stable") is True
    and scope_launcher.get("pid") == scope_launcher.get("pgid") == scope_launcher.get("sid")
    and isinstance(scope_launcher.get("start_ticks"), int) and scope_launcher["start_ticks"] > 0
    and scope_unit_policy.get("accepted") is True
    and all(value is True for value in scope_unit_policy.get("checks", {}).values())
    and scope_unit_final.get("query_status") == 0 and scope_unit_final.get("joined") is True
    and scope_unit_final.get("failed_state_rejected") is True
    and scope_unit_final.get("confirmation") == "show" and scope_unit_final.get("show_status") == 0
    and scope_unit_final.get("load_state") in ("not-found", "loaded")
    and scope_unit_final.get("active_state") == "inactive" and scope_unit_final.get("sub_state") == "dead"
    and isinstance(scope_delegation.get("source"), dict) and isinstance(scope_delegation.get("common_ancestor"), dict)
    and scope_delegation.get("source_cgroup") == scope_delegation.get("source", {}).get("path")
    and scope_delegation.get("destination_cgroup") == delegation_destination.get("path")
    and scope_delegation.get("nearest_common_ancestor") == delegation_common.get("path")
    and delegation_destination.get("path") == expected_scope_path
    and delegation_procs.get("path") == str(pathlib.Path(expected_scope_path or "") / "cgroup.procs")
    and delegation_procs.get("writable") is True
    and delegation_common_procs.get("path") == str(pathlib.Path(delegation_common.get("path", "")) / "cgroup.procs")
    and delegation_common_procs.get("writable") is True
    and scope_pre_traffic.get("path") == expected_scope_path
    and scope_post_workload.get("cgroup_path") == expected_scope_unified_path
    and scope_pre_traffic.get("memory_max_bytes") == scope_post_workload.get("memory_max_bytes") == 4294967296
    and scope_pre_traffic.get("memory_swap_max_bytes") == scope_post_workload.get("memory_swap_max_bytes") == 0
    and scope_pre_traffic.get("memory_high_bytes") == scope_post_workload.get("memory_high_bytes") == "max"
    and all(scope_pre_traffic.get("memory_events", {}).get(key) == scope_post_workload.get("memory_events", {}).get(key) == 0
            for key in scope_event_keys)
)
if not scope_ok:
    issues.append("delegated server-only cgroup identity, policy, or memory-event contract failed")
supervisor_joined_ok = (supervisor.get("group_joined") is True and supervisor.get("forced") is False
                        and supervisor.get("server_scope", {}).get("systemd_run_status") == 0
                        and supervisor.get("server_scope", {}).get("resource_status") == 0
                        and supervisor.get("server_scope", {}).get("unit_joined") is True
                        and supervisor.get("server_scope", {}).get("unit_query_status") == 0
                        and supervisor.get("server_scope", {}).get("unit_active_state") != "failed"
                        and supervisor.get("trace_reduction", {}).get("parser_status") == 0
                        and supervisor.get("trace_reduction", {}).get("analyzer_status") == 0)
if not supervisor_joined_ok:
    issues.append(f"outer runner process group did not join naturally: {supervisor!r}")
runner_status_ok = supervisor.get("runner_status") == 0
expected_supervisor_invalidation = not (runner_status_ok and supervisor_joined_ok)
if supervisor.get("invalidates_success") is not expected_supervisor_invalidation:
    issues.append("supervisor invalidates_success does not match recorded runner/resource/parser statuses")
if not runner_status_ok:
    issues.append(f"runner exited nonzero after preserving evidence: {supervisor.get('runner_status')!r}")

attestation = {
    "schema_version": 1,
    "accepted": not issues,
    "diagnostic_only": True,
    "protocol": protocol,
    "smoke": smoke,
    "row_count": len(rows),
    "classification": summary.get("classification"),
    "validation_issues": issues,
    "download_floor_bytes_per_second": floor,
    "download_phase_classification": phase_classification,
    "reuse_expectations": reuse_expectations,
    "copy_attribution_records": copy_records,
    "copy_attribution_issues_by_sequence": copy_issues_by_sequence,
    "copy_attribution_interpretation": expected_copy_interpretation,
    "read_wait_trace_artifacts": trace_artifacts,
    "read_wait_trace_reductions": trace_reductions,
    "read_wait_duration_relation_to_copy_observer": "descriptive-only",
    "all_observed_http_major": expected_major if rows and all(row.get("observed_http_major") == expected_major for row in rows) else None,
    "verified_alpn": expected_alpn if rows and all(len(row.get("wan_response_tls", [])) == 1 and row["wan_response_tls"][0].get("negotiated_alpn") == expected_alpn for row in rows) else None,
    "natural_endpoint_and_namespace_statuses": lifecycle_identity_ok and lifecycle_status_ok and lifecycle_no_invalidation and namespace_ok,
    "outer_private_user_pid_mount_net": outer_ok,
    "server_only_delegated_cgroup": scope_ok,
    "outer_runner_group_joined": supervisor_joined_ok,
    "runner_status": supervisor.get("runner_status"),
    "results_sha256": sha(results_path),
    "lifecycle_sha256": sha(lifecycle_path),
    "summary_sha256": sha(summary_path),
}
attestation_path.write_text(json.dumps(attestation, indent=2, sort_keys=True) + "\n")
if issues:
    raise SystemExit("WAN protocol arm validation failed: " + "; ".join(issues))
