#!/usr/bin/env python3
import json
import os
import pathlib
import sys
import time

if len(sys.argv) != 3:
    raise SystemExit("usage: server-scope-sentinel.sh STATE RELEASE")
state = pathlib.Path(sys.argv[1])
release = pathlib.Path(sys.argv[2])
if state.exists() or release.exists():
    raise SystemExit("sentinel handshake paths are not fresh")
value = {
    "schema_version": 1,
    "pid": os.getpid(),
    "pgid": os.getpgid(0),
    "sid": os.getsid(0),
    "start_ticks": int(pathlib.Path("/proc/self/stat").read_text().split()[21]),
    "cgroup": next(line.split("::", 1)[1] for line in pathlib.Path("/proc/self/cgroup").read_text().splitlines() if line.startswith("0::")),
    "namespaces": {name: os.readlink(f"/proc/self/ns/{name}") for name in ("user", "pid", "mnt", "net", "cgroup")},
}
with state.open("x", encoding="utf-8") as stream:
    json.dump(value, stream, indent=2, sort_keys=True)
    stream.write("\n")
for _ in range(400):
    if release.exists():
        break
    time.sleep(0.05)
else:
    raise SystemExit(40)
pathlib.Path(str(state) + ".natural-exit").open("x", encoding="utf-8").write("natural-exit\n")
