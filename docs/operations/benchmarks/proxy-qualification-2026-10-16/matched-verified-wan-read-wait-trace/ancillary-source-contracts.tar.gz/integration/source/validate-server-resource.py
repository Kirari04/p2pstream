#!/usr/bin/env python3
import argparse
import json
import pathlib


parser = argparse.ArgumentParser()
parser.add_argument("--pre", required=True)
parser.add_argument("--post", required=True)
parser.add_argument("--expected-absolute-cgroup", required=True)
parser.add_argument("--expected-unified-cgroup", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()

pre = json.loads(pathlib.Path(args.pre).read_text())
post = json.loads(pathlib.Path(args.post).read_text())
keys = ("high", "max", "oom", "oom_kill", "oom_group_kill")
checks = {
    "expected_cgroup_paths": (
        pre.get("path") == str(pathlib.Path(args.expected_absolute_cgroup).resolve())
        and post.get("cgroup_path") == args.expected_unified_cgroup
    ),
    "memory_max_4gib": pre.get("memory_max_bytes") == post.get("memory_max_bytes") == 4294967296,
    "memory_swap_max_zero": pre.get("memory_swap_max_bytes") == post.get("memory_swap_max_bytes") == 0,
    "memory_high_unbounded": pre.get("memory_high_bytes") == post.get("memory_high_bytes") == "max",
    "pre_events_zero": all(pre.get("memory_events", {}).get(key) == 0 for key in keys),
    "post_events_unchanged_zero": all(
        post.get("memory_events", {}).get(key) == pre.get("memory_events", {}).get(key) == 0 for key in keys
    ),
    "post_peak_within_limit": (
        isinstance(post.get("memory_peak_bytes"), int)
        and 0 <= post["memory_peak_bytes"] <= 4294967296
    ),
}
value = {"schema_version": 1, "accepted": all(checks.values()), "checks": checks, "pre": pre, "post": post}
with pathlib.Path(args.output).open("x", encoding="utf-8") as stream:
    json.dump(value, stream, indent=2, sort_keys=True)
    stream.write("\n")
raise SystemExit(0 if value["accepted"] else 1)
