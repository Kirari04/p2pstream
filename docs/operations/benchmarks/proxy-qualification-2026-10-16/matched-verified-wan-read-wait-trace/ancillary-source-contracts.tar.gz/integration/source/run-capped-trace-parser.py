#!/usr/bin/env python3
import os
import resource
import sys

if len(sys.argv) != 3:
    raise SystemExit("usage: run-capped-trace-parser.py PINNED_GO RAW_TRACE")
go_binary, raw_trace = sys.argv[1:]
cap = 512 << 20
resource.setrlimit(resource.RLIMIT_FSIZE, (cap, cap))
os.execve(go_binary, [go_binary, "tool", "trace", "-d=parsed", raw_trace], os.environ)
