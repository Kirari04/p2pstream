#!/usr/bin/env python3
import json
import pathlib
import subprocess
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: run-traced-transfer-contracts.py FRESH_OUTPUT_DIRECTORY")
root = pathlib.Path(__file__).resolve().parents[1]
runner = root / "generated/qualify-proxy-agent-growth-wan-read-wait.sh"
output = pathlib.Path(sys.argv[1])
output.mkdir(parents=True, exist_ok=False)
text = runner.read_text()
start = text.index("wan_read_wait_should_trace() {")
end = text.index("\nrun_tiny_response() {", start)
functions = text[start:end]


def run_case(name, pre_bad, transfer_status, expected_status, expected_sequence, expected_stop_count, success):
    case = output / name
    case.mkdir()
    harness = case / "harness.sh"
    harness.write_text("""#!/usr/bin/env bash
set -Eeuo pipefail
sequence=8
smoke_mode=0
read_wait_control_dir=$1/control
read_wait_trace_records=$1/records.jsonl
mkdir -p "$read_wait_control_dir"
: > "$read_wait_trace_records"
stop_count=0
start_count=0
trap_seen_by_stop=0
trap_log=$1/outer-exit-trap.log
result_path=$1/result.json
internal_after_failure=$1/internal-after-failure
outer_after_call=$1/outer-after-call
finish() {
  local status=$?
  trap - EXIT INT TERM ERR
  jq -cn --argjson status "$status" --argjson sequence "$sequence" --argjson starts "$start_count" --argjson stops "$stop_count" \
    --argjson trap_seen_by_stop "$trap_seen_by_stop" --slurpfile records "$read_wait_trace_records" \
    '{status:$status,sequence:$sequence,start_count:$starts,stop_count:$stops,trap_seen_by_stop:$trap_seen_by_stop,records:$records}' > "$result_path"
  printf x >> "$trap_log"
  exit "$status"
}
trap finish EXIT
query_server_json() {
  printf '%s\\n' '{"agent_capacity":{"pressure":"healthy","memory_sample_error":""}}'
}
cgroup_snapshot() {
  if [[ ${PRE_BAD:-0} == 1 ]]; then
    PRE_BAD=0
    printf '%s\\n' '{"cgroup_path":"/expected.scope","memory_max_bytes":1,"memory_swap_max_bytes":0,"memory_events":{"high":0,"max":0,"oom":0,"oom_kill":0,"oom_group_kill":0}}'
  else
    printf '%s\\n' '{"cgroup_path":"/expected.scope","memory_max_bytes":4294967296,"memory_swap_max_bytes":0,"memory_events":{"high":0,"max":0,"oom":0,"oom_kill":0,"oom_group_kill":0}}'
  fi
}
wan_read_wait_control() {
  local action=$1 target=$2 server=$3 destination=$4
  if [[ $action == start ]]; then
    start_count=$((start_count + 1))
    printf '{"action":"start","sequence":"%s","http_status":200,"error":"","response":{"capture":{"sequence":"%s","state":"active","complete":false,"valid":false}}}\\n' "$target" "$target" > "$destination"
  else
    stop_count=$((stop_count + 1))
    [[ ! -e $trap_log ]] || trap_seen_by_stop=1
    printf '{"action":"stop","sequence":"%s","http_status":200,"error":"","response":{"capture":{"sequence":"%s","state":"complete"}}}\\n' "$target" "$target" > "$destination"
  fi
}
run_transfer() {
  sequence=$((sequence + 1))
  ( exit "${TRANSFER_STATUS:-0}" )
  printf forbidden > "$internal_after_failure"
}
""" + functions + """
run_maybe_traced_transfer label aggregate-v1 101 https://public.test http://admin 202 http://agent retained-warmup download 268435456 1
printf reached > "$outer_after_call"
""")
    harness.chmod(0o755)
    env = {"PATH": "/usr/bin:/bin", "PRE_BAD": "1" if pre_bad else "0", "TRANSFER_STATUS": str(transfer_status)}
    result = subprocess.run([str(harness), str(case)], text=True, capture_output=True, env=env)
    assert result.returncode == expected_status, (name, result.returncode, result.stdout, result.stderr)
    assert (case / "outer-exit-trap.log").read_text() == "x", (name, "outer trap did not run exactly once")
    value = json.loads((case / "result.json").read_text())
    assert value["status"] == expected_status, (name, value)
    assert value["sequence"] == expected_sequence, (name, value)
    assert value["stop_count"] == expected_stop_count, (name, value)
    assert value["trap_seen_by_stop"] == 0, (name, value)
    assert len(value["records"]) == 1, (name, value)
    assert (case / "outer-after-call").exists() is success, name
    assert (case / "internal-after-failure").exists() is success, name
    return value


successful_transfer = run_case("transfer-success", False, 0, 0, 9, 1, True)
assert successful_transfer["records"][0]["valid"] is True
failed_transfer = run_case("transfer-failure-still-stops", False, 37, 37, 9, 1, False)
record = failed_transfer["records"][0]
assert record["transfer_status"] == 37 and record["stop_status"] == 0
assert record["complete"] is True and record["valid"] is False
pre_resource = run_case("pre-resource-failure-preserved", True, 0, 1, 8, 0, False)
record = pre_resource["records"][0]
assert record["pre_cgroup"]["memory_max_bytes"] == 1
assert record["pre_resource_status"] != 0 and record["pre_healthy_status"] == 0
assert record["complete"] is False and record["valid"] is False
print("traced transfer contracts passed")
