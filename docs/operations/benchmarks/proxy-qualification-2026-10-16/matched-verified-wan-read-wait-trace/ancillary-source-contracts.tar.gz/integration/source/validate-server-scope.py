#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
import pathlib
import sys

def sha(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def pairs(path):
    result = {}
    for line in path.read_text().splitlines():
        key, value = line.split()
        result[key] = int(value)
    return result

def scalar(path):
    value = path.read_text().strip()
    return value if value == "max" else int(value)

def cgroup_snapshot(directory):
    directory = pathlib.Path(directory)
    members = [int(value) for value in directory.joinpath("cgroup.procs").read_text().split()]
    return {
        "path": str(directory),
        "members": members,
        "memory_current_bytes": int(directory.joinpath("memory.current").read_text()),
        "memory_peak_bytes": int(directory.joinpath("memory.peak").read_text()),
        "memory_high_bytes": scalar(directory / "memory.high"),
        "memory_max_bytes": scalar(directory / "memory.max"),
        "memory_swap_max_bytes": scalar(directory / "memory.swap.max"),
        "memory_events": pairs(directory / "memory.events"),
    }

def proc_value(pid):
    root = pathlib.Path(f"/proc/{pid}")
    status = root.joinpath("status").read_text().splitlines()
    def vector(name):
        return [int(v) for v in next(line.split()[1:] for line in status if line.startswith(name + ":"))]
    environment = {}
    for item in root.joinpath("environ").read_bytes().split(b"\0"):
        if b"=" in item:
            key, value = item.split(b"=", 1)
            environment[key.decode()] = value.decode(errors="replace")
    return {
        "host_pid": pid,
        "host_start_ticks": int(root.joinpath("stat").read_text().split()[21]),
        "host_nspid": vector("NSpid"),
        "host_nspgid": vector("NSpgid"),
        "host_namespaces": {name: os.readlink(root / "ns" / name) for name in ("user", "pid", "mnt", "net", "cgroup")},
        "host_cpu_affinity": sorted(os.sched_getaffinity(pid)),
        "host_cmdline": [v.decode(errors="replace") for v in root.joinpath("cmdline").read_bytes().split(b"\0") if v],
        "host_exe": os.readlink(root / "exe"),
        "role": environment.get("P2PSTREAM_WAN_READ_WAIT_SCOPE_ROLE"),
        "nonce": environment.get("P2PSTREAM_WAN_READ_WAIT_SCOPE_NONCE"),
    }

parser = argparse.ArgumentParser()
sub = parser.add_subparsers(dest="action", required=True)
snapshot_parser = sub.add_parser("snapshot")
snapshot_parser.add_argument("--cgroup-dir", required=True)
snapshot_parser.add_argument("--output", required=True)
bind = sub.add_parser("bind")
bind.add_argument("--phase", choices=("preexec", "application"), required=True)
bind.add_argument("--cgroup-dir", required=True)
bind.add_argument("--state", required=True)
bind.add_argument("--runner-namespaces", required=True)
bind.add_argument("--outer-namespaces", required=True)
bind.add_argument("--preexec-state", required=True)
bind.add_argument("--nonce", required=True)
bind.add_argument("--expected-cgroup", required=True)
bind.add_argument("--server-binary", required=True)
bind.add_argument("--runner", required=True)
bind.add_argument("--entrypoint", required=True)
bind.add_argument("--expected-cpus", required=True)
bind.add_argument("--output", required=True)
args = parser.parse_args()

if args.action == "snapshot":
    value = cgroup_snapshot(args.cgroup_dir)
    pathlib.Path(args.output).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    raise SystemExit(0)

scope = cgroup_snapshot(args.cgroup_dir)
if len(scope["members"]) != 1:
    raise SystemExit(f"server scope member count is {len(scope['members'])}, want 1")
host = proc_value(scope["members"][0])
state = json.loads(pathlib.Path(args.state).read_text())
runner = json.loads(pathlib.Path(args.runner_namespaces).read_text())
outer = json.loads(pathlib.Path(args.outer_namespaces).read_text())
preexec = json.loads(pathlib.Path(args.preexec_state).read_text())
identity_state = preexec if args.phase == "application" else state
server_binary = str(pathlib.Path(args.server_binary).resolve())
expected_cpus = [int(value) for value in args.expected_cpus.split(",")]
checks = {
    "finite_memory_max": scope["memory_max_bytes"] == 4294967296,
    "swap_disabled": scope["memory_swap_max_bytes"] == 0,
    "memory_high_unbounded": scope["memory_high_bytes"] == "max",
    "no_memory_events": all(scope["memory_events"].get(key) == 0 for key in ("high", "max", "oom", "oom_kill", "oom_group_kill")),
    "local_pid_match": host["host_nspid"][-1] == identity_state.get("pid"),
    "start_ticks_match": host["host_start_ticks"] == identity_state.get("start_ticks"),
    "namespaces_match_state": host["host_namespaces"] == identity_state.get("namespaces"),
    "namespaces_match_owned_runner": host["host_namespaces"] == runner.get("namespaces"),
    "outer_private_user_pid_mount_net": outer.get("all_private") is True,
    "outer_shell_pid_is_one": outer.get("shell_pid_is_one") is True,
    "outer_python_parent_is_one": outer.get("python_parent_is_one") is True,
    "outer_cgroup_namespace_unchanged": outer.get("cgroup_namespace_unchanged") is True,
    "outer_cgroup_matches_parent": outer.get("owned", {}).get("cgroup") == outer.get("parent", {}).get("cgroup"),
    "runner_cgroup_matches_outer": runner.get("namespaces", {}).get("cgroup") == outer.get("owned", {}).get("cgroup"),
    "inner_user_is_nested": runner.get("namespaces", {}).get("user") != outer.get("owned", {}).get("user"),
    "inner_net_is_nested": runner.get("namespaces", {}).get("net") != outer.get("owned", {}).get("net"),
    "pid_matches_outer": runner.get("namespaces", {}).get("pid") == outer.get("owned", {}).get("pid"),
    "mount_matches_outer": runner.get("namespaces", {}).get("mnt") == outer.get("owned", {}).get("mnt"),
    "cpu_affinity_match": host["host_cpu_affinity"] == expected_cpus,
    "role_match": host["role"] == "server",
    "nonce_match": host["nonce"] == args.nonce,
}
if args.phase == "preexec":
    checks.update({
        "join_succeeded": state.get("join_status") == 0,
        "joined_expected_cgroup": state.get("after_cgroup") == state.get("expected_cgroup") == args.expected_cgroup,
        "state_role_match": state.get("role") == "server",
        "state_nonce_match": state.get("nonce") == state.get("expected_nonce") == args.nonce,
        "exec_binary_match": bool(state.get("exec_command")) and str(pathlib.Path(state["exec_command"][0]).resolve()) == server_binary,
        "exec_test_match": state.get("exec_command", [])[1:3] == ["-test.run", "^TestExternalProxyQualificationServerProcess$"],
        "helper_cmdline_match": str(pathlib.Path(args.entrypoint).resolve()) in host["host_cmdline"],
    })
else:
    ready_path = pathlib.Path(state.get("server_ready_path", ""))
    checks.update({
        "same_pid_as_preexec": state.get("server_local_pid") == preexec.get("pid") == host["host_nspid"][-1],
        "same_start_ticks_as_preexec": host["host_start_ticks"] == preexec.get("start_ticks"),
        "app_namespaces_match": state.get("runner_namespaces") == runner.get("namespaces"),
        "server_binary_hash_match": state.get("server_binary_sha256") == sha(pathlib.Path(server_binary)),
        "runner_hash_match": state.get("runner_sha256") == sha(pathlib.Path(args.runner)),
        "server_ready_hash_match": ready_path.is_file() and state.get("server_ready_sha256") == sha(ready_path),
        "server_cmdline_match": bool(host["host_cmdline"]) and str(pathlib.Path(host["host_cmdline"][0]).resolve()) == server_binary,
        "server_exe_match": pathlib.Path(host["host_exe"]).resolve() == pathlib.Path(server_binary),
    })
value = {"schema_version": 1, "phase": args.phase, "accepted": all(checks.values()), "checks": checks,
         "scope": scope, "host_process": host, "state": state}
with pathlib.Path(args.output).open("x", encoding="utf-8") as stream:
    json.dump(value, stream, indent=2, sort_keys=True)
    stream.write("\n")
if not value["accepted"]:
    raise SystemExit("server scope binding failed: " + ", ".join(key for key, accepted in checks.items() if not accepted))
