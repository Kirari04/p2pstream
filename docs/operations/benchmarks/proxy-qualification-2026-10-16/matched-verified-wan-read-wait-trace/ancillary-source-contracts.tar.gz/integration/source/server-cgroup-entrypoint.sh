#!/usr/bin/env python3
import json
import os
import pathlib
import sys
import time

if len(sys.argv) < 7:
    raise SystemExit("usage: server-cgroup-entrypoint.sh CGROUP_PROCS EXPECTED_CGROUP STATE RELEASE NONCE COMMAND...")
target_procs, expected_cgroup, state_text, release_text, nonce, *command = sys.argv[1:]
state = pathlib.Path(state_text)
release = pathlib.Path(release_text)
if state.exists() or release.exists():
    raise SystemExit("server cgroup handshake paths are not fresh")
if os.environ.get("P2PSTREAM_WAN_READ_WAIT_SCOPE_ROLE") != "server":
    raise SystemExit("server scope role changed")
if os.environ.get("P2PSTREAM_WAN_READ_WAIT_SCOPE_NONCE") != nonce:
    raise SystemExit("server scope nonce changed")

def cgroup():
    return next(line.split("::", 1)[1] for line in pathlib.Path("/proc/self/cgroup").read_text().splitlines() if line.startswith("0::"))

def vector(name):
    return [int(v) for v in next(line.split()[1:] for line in pathlib.Path("/proc/self/status").read_text().splitlines() if line.startswith(name + ":"))]

before = cgroup()
join_error = ""
try:
    fd = os.open(target_procs, os.O_WRONLY)
    try:
        os.write(fd, b"0\n")
    finally:
        os.close(fd)
    join_status = 0
except OSError as error:
    join_status = 1
    join_error = f"{type(error).__name__}: {error}"
after = cgroup()

value = {
    "schema_version": 1,
    "pid": os.getpid(),
    "pgid": os.getpgid(0),
    "sid": os.getsid(0),
    "start_ticks": int(pathlib.Path("/proc/self/stat").read_text().split()[21]),
    "nspid": vector("NSpid"),
    "nspgid": vector("NSpgid"),
    "before_cgroup": before,
    "after_cgroup": after,
    "expected_cgroup": expected_cgroup,
    "join_status": join_status,
    "join_error": join_error,
    "role": os.environ.get("P2PSTREAM_WAN_READ_WAIT_SCOPE_ROLE"),
    "nonce": os.environ.get("P2PSTREAM_WAN_READ_WAIT_SCOPE_NONCE"),
    "expected_nonce": nonce,
    "gomaxprocs": os.environ.get("GOMAXPROCS"),
    "cpu_affinity": sorted(os.sched_getaffinity(0)),
    "namespaces": {name: os.readlink(f"/proc/self/ns/{name}") for name in ("user", "pid", "mnt", "net", "cgroup")},
    "exec_command": command,
}
with state.open("x", encoding="utf-8") as stream:
    json.dump(value, stream, indent=2, sort_keys=True)
    stream.write("\n")
if join_status != 0 or after != expected_cgroup:
    raise SystemExit(41)

for _ in range(400):
    if release.exists():
        break
    time.sleep(0.05)
else:
    raise SystemExit(42)
pathlib.Path(str(state) + ".released").open("x", encoding="utf-8").write("released\n")
os.execvpe(command[0], command, os.environ)
