#!/usr/bin/env python3
import copy
import json
import pathlib
import subprocess
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: run-server-resource-contracts.py FRESH_OUTPUT_DIRECTORY")
root = pathlib.Path(__file__).resolve().parents[1]
validator = root / "validate-server-resource.py"
output = pathlib.Path(sys.argv[1])
output.mkdir(parents=True, exist_ok=False)
absolute = "/sys/fs/cgroup/user.slice/user-1000.slice/example.scope"
unified = "/user.slice/user-1000.slice/example.scope"
events = {"high": 0, "max": 0, "oom": 0, "oom_kill": 0, "oom_group_kill": 0}
pre = {
    "path": absolute, "members": [101], "memory_current_bytes": 1024, "memory_peak_bytes": 2048,
    "memory_high_bytes": "max", "memory_max_bytes": 4294967296, "memory_swap_max_bytes": 0,
    "memory_events": events,
}
post = {
    "cgroup_path": unified, "memory_current_bytes": 2048, "memory_peak_bytes": 4096,
    "memory_high_bytes": "max", "memory_max_bytes": 4294967296, "memory_swap_max_bytes": 0,
    "memory_events": events,
}


def run_case(name, before, after, want_status, failed_check=None):
    case = output / name
    case.mkdir()
    pre_path, post_path, attestation = case / "pre.json", case / "post.json", case / "attestation.json"
    pre_path.write_text(json.dumps(before) + "\n")
    post_path.write_text(json.dumps(after) + "\n")
    result = subprocess.run([
        str(validator), "--pre", str(pre_path), "--post", str(post_path),
        "--expected-absolute-cgroup", absolute, "--expected-unified-cgroup", unified,
        "--output", str(attestation),
    ], text=True, capture_output=True)
    assert result.returncode == want_status, (name, result.returncode, result.stdout, result.stderr)
    value = json.loads(attestation.read_text())
    assert value["accepted"] is (want_status == 0), (name, value)
    if failed_check:
        assert value["checks"][failed_check] is False, (name, value)


run_case("valid-distinct-schemas", pre, post, 0)
bad_post_path = copy.deepcopy(post)
bad_post_path["cgroup_path"] = "/user.slice/wrong.scope"
run_case("wrong-unified-post-path", pre, bad_post_path, 1, "expected_cgroup_paths")
bad_pre_schema = copy.deepcopy(pre)
bad_pre_schema["cgroup_path"] = bad_pre_schema.pop("path")
run_case("pre-schema-not-rewritten", bad_pre_schema, post, 1, "expected_cgroup_paths")
bad_event = copy.deepcopy(post)
bad_event["memory_events"] = dict(events, high=1)
run_case("memory-pressure-event", pre, bad_event, 1, "post_events_unchanged_zero")
bad_peak = copy.deepcopy(post)
bad_peak["memory_peak_bytes"] = 4294967297
run_case("peak-over-limit", pre, bad_peak, 1, "post_peak_within_limit")
print("server resource contracts passed")
