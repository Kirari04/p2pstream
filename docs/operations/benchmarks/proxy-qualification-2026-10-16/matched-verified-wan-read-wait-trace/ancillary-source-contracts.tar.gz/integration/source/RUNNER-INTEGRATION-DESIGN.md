# Read-wait diagnostic runner integration

This source derivative preserves the frozen matched H1/H2 protocol and monotonic
copy-attribution bundle. It adds request-scoped Go execution traces only for the
fixed post-conditioning download sequences: 9, 11, 14, and 15 in a sustained
arm; 9, 11, and the separately labelled reuse probe 13 in a smoke arm. Selection
is fixed before execution and symmetric across H1 and H2. It never selects a
request because it was slow.

The inherited `run_transfer` function is byte-identical (7,350 bytes, SHA-256
`b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798`).
The traced wrapper starts the private controller before calling that function
and always calls Stop after the complete function, including its existing admin
queries. The function runs in an errexit subshell with lifecycle traps cleared;
the parent alone owns endpoint cleanup. The parent increments the diagnostic
sequence exactly once and preserves the original transfer error after Stop.
Failed pre-resource observations and their exact statuses are retained before
the arm exits.

Each trace has an immutable 64 MiB writer cap. Writer overflow, short/error
state, a missing or duplicate configured request, controller timeout, or a
missing trace makes the diagnostic invalid. The raw trace covers the server
process interval between controller Start and Stop, while the constant task and
region markers bound the actual public proxy handler. Extra process activity is
excluded from handler attribution by the reducer.

Parsing occurs only after the inherited runner has joined its endpoints. The
pinned Go 1.26.6 parser writes to a fresh capped ext4 file and its direct status
is retained. The approved streaming reducer is then run once per fixed sequence.
The arm validator joins every reduction to the exact sequence, protocol,
certificate, origin identity, runner, source, and server binary. Trace and copy
observer durations are descriptive and use different monotonic domains; they
are never compared for equality. Unknown wait stacks remain unresolved
attribution and are reported rather than converted into a payload failure.

The server alone joins a fresh host-created delegated scope with
`MemoryMax=4294967296`, `EffectiveMemoryMax=4294967296`, `MemorySwapMax=0`, and
`Delegate=yes`. A single-process Python entrypoint writes its own PID to the
delegated `cgroup.procs`, records its identity, waits for the host barrier, and
execs the server without changing PID or start ticks. The host binds the sole
member to the runner namespaces, nonce, role, CPU affinity, binary, ready file,
and pre/post cgroup paths before releasing workload. The agent, origin, and load
processes remain outside this scope. Every memory pressure/max/OOM event,
membership or namespace mismatch, forced cleanup, failed unit query, or terminal
unit state other than `not-found|loaded` plus `inactive/dead` invalidates the
diagnostic.

This finite server-only scope changes the adaptive-budget environment from the
prior cohort, which had no finite server-only child scope; its exact inherited
historical limit was unrecorded. The observer and its throughput are diagnostic
only and cannot qualify production behavior. The nested initial lane
fields in the fixture are shallow-cloned and may later contain maxima; the
component high-water fields are not a coherent transient state. Final pool
values support conservation only and are not used to infer a transient cause.
