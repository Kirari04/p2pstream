//go:build linux

package server

import (
	"bytes"
	"context"
	"crypto/tls"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"sync"
	"testing"
	"time"
)

const qualificationWANReadWaitTestBearer = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"

type qualificationWANReadWaitShortWriter struct{}

func (qualificationWANReadWaitShortWriter) Write(p []byte) (int, error) {
	return len(p) / 2, nil
}

type qualificationWANReadWaitErrorWriter struct{}

func (qualificationWANReadWaitErrorWriter) Write([]byte) (int, error) {
	return 0, errors.New("injected write error")
}

func TestQualificationWANReadWaitCappedWriter(t *testing.T) {
	t.Run("exact", func(t *testing.T) {
		var destination bytes.Buffer
		writer := newQualificationWANReadWaitCappedWriter(&destination, 4)
		if written, err := writer.Write([]byte("abcd")); written != 4 || err != nil {
			t.Fatalf("Write = %d, %v", written, err)
		}
		snapshot := writer.snapshot()
		if destination.String() != "abcd" || snapshot.Bytes != 4 || snapshot.Overflow || snapshot.Error != "" {
			t.Fatalf("unexpected exact snapshot: destination=%q snapshot=%+v", destination.String(), snapshot)
		}
	})
	t.Run("overflow-discards-and-consumes", func(t *testing.T) {
		var destination bytes.Buffer
		writer := newQualificationWANReadWaitCappedWriter(&destination, 4)
		if written, err := writer.Write([]byte("abcdef")); written != 6 || err != nil {
			t.Fatalf("Write = %d, %v", written, err)
		}
		if written, err := writer.Write([]byte("gh")); written != 2 || err != nil {
			t.Fatalf("discard Write = %d, %v", written, err)
		}
		snapshot := writer.snapshot()
		if destination.String() != "abcd" || snapshot.Bytes != 4 || !snapshot.Overflow || snapshot.Error != "" {
			t.Fatalf("unexpected overflow snapshot: destination=%q snapshot=%+v", destination.String(), snapshot)
		}
	})
	t.Run("short-write-invalidates-but-consumes", func(t *testing.T) {
		writer := newQualificationWANReadWaitCappedWriter(qualificationWANReadWaitShortWriter{}, 16)
		if written, err := writer.Write([]byte("abcdefgh")); written != 8 || err != nil {
			t.Fatalf("Write = %d, %v", written, err)
		}
		snapshot := writer.snapshot()
		if snapshot.Bytes != 4 || snapshot.Error != io.ErrShortWrite.Error() {
			t.Fatalf("unexpected short-write snapshot: %+v", snapshot)
		}
	})
	t.Run("error-invalidates-and-future-input-is-discarded", func(t *testing.T) {
		writer := newQualificationWANReadWaitCappedWriter(qualificationWANReadWaitErrorWriter{}, 16)
		if written, err := writer.Write([]byte("abcd")); written != 4 || err != nil {
			t.Fatalf("Write = %d, %v", written, err)
		}
		if written, err := writer.Write([]byte("efgh")); written != 4 || err != nil {
			t.Fatalf("discard Write = %d, %v", written, err)
		}
		snapshot := writer.snapshot()
		if snapshot.Bytes != 0 || snapshot.Error != "injected write error" {
			t.Fatalf("unexpected error snapshot: %+v", snapshot)
		}
	})
}

func newQualificationWANReadWaitTestOwner(t *testing.T, sequences []string) *qualificationWANReadWaitTraceOwner {
	t.Helper()
	owner, err := newQualificationWANReadWaitTraceOwner(t.TempDir(), sequences, 8<<20, qualificationWANReadWaitTestBearer)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = owner.finalize() })
	return owner
}

func serveQualificationWANReadWaitRequest(handler http.Handler, sequence string) *httptest.ResponseRecorder {
	request := httptest.NewRequest(http.MethodGet, "https://public.test/agent/bulk", nil)
	request.Header.Set("X-Qualification-Diagnostic-Sequence", sequence)
	response := httptest.NewRecorder()
	handler.ServeHTTP(response, request)
	return response
}

func TestQualificationWANReadWaitTraceLifecycle(t *testing.T) {
	owner := newQualificationWANReadWaitTestOwner(t, qualificationWANReadWaitSustainedSequences)
	handler := wrapQualificationWANReadWaitTrace(owner, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Length", "2")
		_, _ = io.WriteString(w, "ok")
	}))
	for _, sequence := range qualificationWANReadWaitSustainedSequences {
		if snapshot, err := owner.start(sequence); err != nil || snapshot.State != "active" {
			t.Fatalf("start %s: snapshot=%+v err=%v", sequence, snapshot, err)
		}
		response := serveQualificationWANReadWaitRequest(handler, sequence)
		if response.Code != http.StatusOK || response.Body.String() != "ok" {
			t.Fatalf("sequence %s response = %d %q", sequence, response.Code, response.Body.String())
		}
		snapshot, err := owner.stop(context.Background(), sequence)
		if err != nil || !snapshot.Valid || snapshot.MarkedRequests != 1 || snapshot.Writer.Bytes == 0 {
			t.Fatalf("stop %s: snapshot=%+v err=%v", sequence, snapshot, err)
		}
	}
	if err := owner.finalize(); err != nil {
		t.Fatal(err)
	}
}

func TestQualificationWANReadWaitTraceStopWaitsForHandler(t *testing.T) {
	owner := newQualificationWANReadWaitTestOwner(t, qualificationWANReadWaitSustainedSequences)
	entered := make(chan struct{})
	release := make(chan struct{})
	handler := wrapQualificationWANReadWaitTrace(owner, http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
		close(entered)
		<-release
	}))
	if _, err := owner.start("9"); err != nil {
		t.Fatal(err)
	}
	requestDone := make(chan struct{})
	go func() {
		serveQualificationWANReadWaitRequest(handler, "9")
		close(requestDone)
	}()
	<-entered
	stopDone := make(chan error, 1)
	go func() {
		_, err := owner.stop(context.Background(), "9")
		stopDone <- err
	}()
	select {
	case err := <-stopDone:
		t.Fatalf("stop returned before handler: %v", err)
	case <-time.After(20 * time.Millisecond):
	}
	close(release)
	<-requestDone
	if err := <-stopDone; err != nil {
		t.Fatal(err)
	}
}

func TestQualificationWANReadWaitTraceExpiredControllerStillStops(t *testing.T) {
	owner := newQualificationWANReadWaitTestOwner(t, qualificationWANReadWaitSustainedSequences)
	entered := make(chan struct{})
	release := make(chan struct{})
	handler := wrapQualificationWANReadWaitTrace(owner, http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
		close(entered)
		<-release
	}))
	if _, err := owner.start("9"); err != nil {
		t.Fatal(err)
	}
	requestDone := make(chan struct{})
	go func() {
		serveQualificationWANReadWaitRequest(handler, "9")
		close(requestDone)
	}()
	<-entered
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	stopDone := make(chan qualificationWANReadWaitCaptureSnapshot, 1)
	go func() {
		snapshot, _ := owner.stop(ctx, "9")
		stopDone <- snapshot
	}()
	select {
	case snapshot := <-stopDone:
		t.Fatalf("expired control abandoned active trace: %+v", snapshot)
	case <-time.After(20 * time.Millisecond):
	}
	close(release)
	<-requestDone
	snapshot := <-stopDone
	if snapshot.Valid || !snapshot.Complete || !snapshot.ControllerTimedOut || snapshot.ActiveRequests != 0 {
		t.Fatalf("expired controller snapshot = %+v", snapshot)
	}
}

func TestQualificationWANReadWaitTraceDuplicateAndMissingTargetsInvalidate(t *testing.T) {
	t.Run("duplicate", func(t *testing.T) {
		owner := newQualificationWANReadWaitTestOwner(t, qualificationWANReadWaitSustainedSequences)
		handler := wrapQualificationWANReadWaitTrace(owner, http.HandlerFunc(func(http.ResponseWriter, *http.Request) {}))
		if _, err := owner.start("9"); err != nil {
			t.Fatal(err)
		}
		serveQualificationWANReadWaitRequest(handler, "9")
		serveQualificationWANReadWaitRequest(handler, "9")
		snapshot, err := owner.stop(context.Background(), "9")
		if err == nil || snapshot.Valid || snapshot.MarkedRequests != 2 {
			t.Fatalf("duplicate stop: snapshot=%+v err=%v", snapshot, err)
		}
	})
	t.Run("missing", func(t *testing.T) {
		owner := newQualificationWANReadWaitTestOwner(t, qualificationWANReadWaitSustainedSequences)
		if _, err := owner.start("9"); err != nil {
			t.Fatal(err)
		}
		snapshot, err := owner.stop(context.Background(), "9")
		if err == nil || snapshot.Valid || snapshot.MarkedRequests != 0 {
			t.Fatalf("missing stop: snapshot=%+v err=%v", snapshot, err)
		}
		if err := owner.finalize(); err == nil || !strings.Contains(err.Error(), "11,14,15") {
			t.Fatalf("finalize missing targets = %v", err)
		}
	})
}

func TestQualificationWANReadWaitTraceConcurrentAndRepeatedControl(t *testing.T) {
	owner := newQualificationWANReadWaitTestOwner(t, qualificationWANReadWaitSustainedSequences)
	if _, err := owner.start("9"); err != nil {
		t.Fatal(err)
	}
	if _, err := owner.start("11"); err == nil {
		t.Fatal("concurrent start succeeded")
	}
	serveQualificationWANReadWaitRequest(wrapQualificationWANReadWaitTrace(owner, http.HandlerFunc(func(http.ResponseWriter, *http.Request) {})), "9")
	if _, err := owner.stop(context.Background(), "9"); err != nil {
		t.Fatal(err)
	}
	if _, err := owner.stop(context.Background(), "9"); err == nil {
		t.Fatal("repeated stop succeeded")
	}
	if _, err := owner.start("9"); err == nil {
		t.Fatal("repeated start succeeded")
	}
}

func TestQualificationWANReadWaitTraceFilesAreFreshAndPrivate(t *testing.T) {
	t.Run("fresh-private", func(t *testing.T) {
		owner := newQualificationWANReadWaitTestOwner(t, qualificationWANReadWaitSustainedSequences)
		if _, err := owner.start("9"); err != nil {
			t.Fatal(err)
		}
		info, err := os.Stat(owner.captures["9"].Path)
		if err != nil {
			t.Fatal(err)
		}
		if info.Mode().Perm() != 0600 {
			t.Fatalf("trace mode = %o, want 600", info.Mode().Perm())
		}
		serveQualificationWANReadWaitRequest(wrapQualificationWANReadWaitTrace(owner, http.HandlerFunc(func(http.ResponseWriter, *http.Request) {})), "9")
		if _, err := owner.stop(context.Background(), "9"); err != nil {
			t.Fatal(err)
		}
	})
	t.Run("existing-file", func(t *testing.T) {
		owner := newQualificationWANReadWaitTestOwner(t, qualificationWANReadWaitSustainedSequences)
		path := owner.captures["9"].Path
		if err := os.WriteFile(path, []byte("preserve"), 0600); err != nil {
			t.Fatal(err)
		}
		snapshot, err := owner.start("9")
		if err == nil || snapshot.Valid || snapshot.State != "invalid" {
			t.Fatalf("start with existing file: snapshot=%+v err=%v", snapshot, err)
		}
		contents, readErr := os.ReadFile(path)
		if readErr != nil || string(contents) != "preserve" {
			t.Fatalf("existing file changed: contents=%q err=%v", contents, readErr)
		}
	})
}

func TestQualificationWANReadWaitTraceControllerBearer(t *testing.T) {
	owner := newQualificationWANReadWaitTestOwner(t, qualificationWANReadWaitSustainedSequences)
	for _, test := range []struct {
		name   string
		bearer string
		status int
	}{
		{name: "missing", status: http.StatusUnauthorized},
		{name: "wrong", bearer: strings.Repeat("f", 64), status: http.StatusUnauthorized},
		{name: "valid", bearer: qualificationWANReadWaitTestBearer, status: http.StatusOK},
	} {
		t.Run(test.name, func(t *testing.T) {
			request := httptest.NewRequest(http.MethodGet, "http://127.0.0.1/?wan_read_wait_trace=status&sequence=9", nil)
			if test.bearer != "" {
				request.Header.Set("Authorization", "Bearer "+test.bearer)
			}
			response := httptest.NewRecorder()
			owner.serveHTTP(response, request)
			if response.Code != test.status {
				t.Fatalf("status = %d, want %d; body=%s", response.Code, test.status, response.Body.String())
			}
		})
	}
}

func TestQualificationWANReadWaitTraceDisabledReturnsOriginalHandler(t *testing.T) {
	called := false
	original := http.HandlerFunc(func(http.ResponseWriter, *http.Request) { called = true })
	wrapped := wrapQualificationWANReadWaitTrace(nil, original)
	wrapped.ServeHTTP(httptest.NewRecorder(), httptest.NewRequest(http.MethodGet, "https://public.test/agent/bulk", nil))
	if !called {
		t.Fatal("disabled wrapper did not invoke original handler")
	}
}

func TestQualificationWANReadWaitTracePreservesH1H2Framing(t *testing.T) {
	for _, protocol := range []string{"h1", "h2"} {
		for _, responseMode := range []string{"content-length", "streaming"} {
			t.Run(protocol+"/"+responseMode, func(t *testing.T) {
				owner := newQualificationWANReadWaitTestOwner(t, qualificationWANReadWaitSustainedSequences)
				if _, err := owner.start("9"); err != nil {
					t.Fatal(err)
				}
				payload := "first-second"
				handler := wrapQualificationWANReadWaitTrace(owner, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
					if responseMode == "content-length" {
						w.Header().Set("Content-Length", "12")
						_, _ = io.WriteString(w, payload)
						return
					}
					_, _ = io.WriteString(w, "first-")
					w.(http.Flusher).Flush()
					_, _ = io.WriteString(w, "second")
				}))
				server := httptest.NewUnstartedServer(handler)
				server.EnableHTTP2 = true
				server.StartTLS()
				defer server.Close()
				protocols := new(http.Protocols)
				if protocol == "h1" {
					protocols.SetHTTP1(true)
				} else {
					protocols.SetHTTP2(true)
				}
				client := &http.Client{Transport: &http.Transport{
					TLSClientConfig: &tls.Config{InsecureSkipVerify: true}, // qualification-only local server
					Protocols:       protocols,
				}}
				request, err := http.NewRequest(http.MethodGet, server.URL+qualificationWANReadWaitTracePath, nil)
				if err != nil {
					t.Fatal(err)
				}
				request.Header.Set("X-Qualification-Diagnostic-Sequence", "9")
				response, err := client.Do(request)
				if err != nil {
					t.Fatal(err)
				}
				body, readErr := io.ReadAll(response.Body)
				closeErr := response.Body.Close()
				if readErr != nil || closeErr != nil {
					t.Fatalf("body read/close = %v, %v", readErr, closeErr)
				}
				expectedMajor := 1
				if protocol == "h2" {
					expectedMajor = 2
				}
				if response.ProtoMajor != expectedMajor || string(body) != payload {
					t.Fatalf("response proto/body = %d, %q", response.ProtoMajor, body)
				}
				if responseMode == "content-length" && response.ContentLength != int64(len(payload)) {
					t.Fatalf("ContentLength = %d, want %d", response.ContentLength, len(payload))
				}
				if responseMode == "streaming" && response.ContentLength != -1 {
					t.Fatalf("streaming ContentLength = %d, want -1", response.ContentLength)
				}
				if _, err := owner.stop(context.Background(), "9"); err != nil {
					t.Fatal(err)
				}
			})
		}
	}
}

func TestQualificationWANReadWaitTraceConcurrentSnapshots(t *testing.T) {
	owner := newQualificationWANReadWaitTestOwner(t, qualificationWANReadWaitSustainedSequences)
	if _, err := owner.start("9"); err != nil {
		t.Fatal(err)
	}
	var group sync.WaitGroup
	for range 8 {
		group.Add(1)
		go func() {
			defer group.Done()
			for range 100 {
				if _, err := owner.snapshot("9"); err != nil {
					t.Error(err)
					return
				}
			}
		}()
	}
	serveQualificationWANReadWaitRequest(wrapQualificationWANReadWaitTrace(owner, http.HandlerFunc(func(http.ResponseWriter, *http.Request) {})), "9")
	group.Wait()
	if _, err := owner.stop(context.Background(), "9"); err != nil {
		t.Fatal(err)
	}
}
