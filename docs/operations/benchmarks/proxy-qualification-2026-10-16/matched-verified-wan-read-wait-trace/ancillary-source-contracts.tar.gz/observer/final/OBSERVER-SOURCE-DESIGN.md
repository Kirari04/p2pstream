# WAN read-wait execution-trace observer source

Date: 2026-10-16

Status: source-only checkpoint for review. No build, focused test, race test,
parser, smoke, or sustained workload has used this source.

This overlay is copied from the frozen `wan-copy-monotonic-source/build/source`.
It changes only the qualification test fixture and adds two Linux-only `_test.go`
files. No production source, public handler, policy, timeout, limit, pool, copy
size, framing, or refund path changes.

## Boundary

The fixture keeps the existing test-only `/agent/` ServeMux route. The new
wrapper is immediately around the unchanged `app.publicProxyHandler(1)`, inside
the existing upstream-transport and response-copy observers. The constant task
type is `wan-read-wait-request`; the constant region type is
`public-proxy-handler`. The public sequence header selects neither a type nor a
path: it is accepted only when it equals the active predeclared sequence, the
method is GET, and the escaped path is exactly `/agent/bulk`.

Raw runtime traces cover the whole server process. Only the marked handler
region is request-scoped. Background and session goroutines are not assigned to
the task. The copy observer independently records its outer completion.

## Capture contract

The only accepted sequence lists are sustained `9,11,14,15` and smoke
`9,11,13`. One capture may be active. Repeated control cycles are serialized by
a control mutex; the owner and writer mutexes are never held across
`runtime/trace.Stop`. Start holds the control mutex while `runtime/trace.Start`
is in progress, so finalization cannot observe and abandon a `starting` state.
Finalization of an active capture records an explicit cleanup-stop issue before
stopping the global tracer, making the capture invalid.

Stop samples controller cancellation on entry and again after
`runtime/trace.Stop`, file sync, and file close. A cancellation observed at any
point is recorded once, invalidates the capture, and never skips the global
trace Stop or active-handler join.

The qualification-loopback trace branch requires a run-scoped 32-byte random
bearer encoded as lowercase hex and an exact `Authorization: Bearer ...`
header. This does not authenticate the pre-existing admin API. Only start and
stop actions exist; there is no status polling action. Filenames, cap, task,
region, and capture set cannot be supplied by a request.

Every file is opened with `O_EXCL`, mode 0600, below an existing absolute,
canonical owned directory. The cap is fixed at 64 MiB. The sink writes at most
the remaining prefix, records input bytes, actual bytes, overflow, and the first
short/failed write, then reports every runtime write fully consumed while
silently discarding bytes. Stop completes before sync, close, immutable capture
publication, and validity calculation. The cap bounds only file bytes; it does
not bound runtime trace buffers or process memory.

Exactly one marked request is required. Missing, overlapping, duplicate,
wrong-method, wrong-path, outside-interval, cap, writer, sync, close, controller
deadline, or cleanup-stop evidence invalidates the attempt. A bounded owner
violation ledger records configured-sequence requests received after a capture
closed without mutating the completed capture. Repeated Start or Stop controls
against a complete or invalid capture use the same ledger. Finalization rejects
any ledger entry.

## Focused test source

The added contract source covers exact cap behavior, overflow/discard, short
writes, sink errors, sequential capture lifecycle, handler/Stop synchronization,
controller cancellation without tracer abandonment, duplicate and missing
requests, late duplicate owner invalidation, cleanup-stop invalidation,
deterministic Start-versus-finalize serialization, repeated/concurrent control,
fresh private files, strict bearer parsing, disabled-wrapper behavior,
concurrent snapshots, and actual H1/H2 Content-Length and streaming responses.
These tests are written but intentionally have not been run.

## Blocked harness boundary

`review/FAILED-RESOURCE-DESIGN-systemd-user-scope.sh` preserves the first runner
source that attempted the approved 4 GiB server-only `systemd-run --user
--scope` launch. The independent prerequisite failed before launching its dummy
or cgroup because the private user namespace could not connect to the user bus.
That runner checkpoint is blocked, unexecuted, and excluded from this observer
source approval. No alternate cgroup mechanism or parser has been implemented.
