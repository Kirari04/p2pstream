#!/usr/bin/env python3
import copy
import hashlib
import json
import pathlib
import subprocess
import importlib.util
import sys

root = pathlib.Path(__file__).resolve().parents[1]
validator = root / "validate-wan-read-wait-arm.py"
copy_contract_path = root.parent / "wan-copy-monotonic-source/contracts/run-copy-record-contracts.py"
spec = importlib.util.spec_from_file_location("copy_contract", copy_contract_path)
copy_contract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(copy_contract)
COPY_INTERPRETATION = ("Diagnostic observer only. Upstream Read and downstream Write durations are compared separately with monotonic handler elapsed time. Unix timestamps are retained only for coarse correlation. "
                       "Inter-read gaps include downstream Write time and bookkeeping and are never added as an independent component. "
                       "POST observations cover only the 32-byte response copy, not upload request-body handling.")
hash_names = {
    "supervisor", "runner", "validator", "approved_lifecycle_runner", "frozen_protocol_runner", "frozen_copy_runner",
    "wan_protocol_runner_patch", "copy_runner_patch", "monotonic_runner_patch", "read_wait_runner_patch", "server_capacity_snapshot_patch", "cleanup_status_patch", "go_base_patch", "go_helper",
    "copy_record_validator", "copy_attribution_overlay_patch", "copy_attribution_design",
    "monotonic_observer_patch", "monotonic_validator_patch", "monotonic_arm_validator_patch",
    "final_source_attestation", "integration_notes", "copy_timing_decision_map", "runner_reconstruction_attestation",
    "monotonic_build_manifest", "monotonic_audited_build_manifest", "read_wait_observer_patch",
    "read_wait_observer_checkpoint", "read_wait_focused_checkpoint", "read_wait_audited_build_manifest",
    "capacity_source_checkpoint", "capacity_source_checkpoint_manifest", "capacity_focused_checkpoint", "capacity_audited_build_manifest",
    "server_scope_entrypoint", "server_scope_sentinel", "server_scope_validator", "server_scope_resource_validator",
    "delegated_scope_probe_attestation", "trace_analyzer", "trace_analyzer_hashes", "trace_analyzer_schema",
    "trace_analyzer_checkpoint", "trace_parser_wrapper", "pinned_go", "server_binary", "aggregate_agent_binary",
    "runner_integration_design", "static_contract", "resource_contract", "traced_transfer_contract",
    "arm_validator_contract", "cleanup_status_contract", "cleanup_status_body", "cleanup_status_holder", "all_contracts",
    "certificate_pem", "private_key_pem",
}


def schedule(smoke):
    value = [("warmup", "download", n) for n in range(1, 5)]
    value += [("warmup", "upload", n) for n in range(1, 5)]
    value += [("retained-warmup", "download", 1), ("retained-warmup", "upload", 1)]
    if smoke:
        return value + [("steady", "download", 1), ("steady", "upload", 1), ("reuse-probe", "download", 1)]
    return value + [
        ("steady", "download", 1), ("steady", "upload", 1),
        ("steady", "upload", 2), ("steady", "download", 2),
        ("steady", "download", 3), ("steady", "upload", 3),
    ]


def fixture(smoke):
    payload = (4 if smoke else 256) << 20
    hashes = {name: ("1" * 64) for name in hash_names}
    pre = {
        "schema_version": 1, "server_source_ref": "8ac4c8d", "aggregate_agent_source_ref": "8ac4c8d",
        "expected_leaf_der_sha256": "2" * 64, "sha256": hashes,
    }
    rows = []
    for index, (stage, direction, repetition) in enumerate(schedule(smoke), 1):
        rate = 40_000_000.0
        lane = (index - 1) % 4 + 1
        reused = index >= 13
        origin_index = index - 4 if reused else index
        got_ns = index * 1_000_000_000
        rows.append({
            "diagnostic_sequence": index, "measurement_stage": stage, "transfer_direction": direction,
            "repetition": repetition, "transport_mode": "aggregate-v1", "public_protocol": "h1",
            "protocol": "h1",
            "observed_http_major": 1, "attempted": 1, "useful_completed": 1, "errors": 0,
            "status_classes": {"2xx": 1}, "status_codes": {"200": 1}, "configured_payload_bytes": payload,
            "response_bytes": payload if direction == "download" else 32, "wall_seconds": payload / rate,
            "useful_transfer_bytes_per_second": rate, "event_stats_captured": True, "persisted_event_delta": 1,
            "dropped_event_delta": 0, "event_queue_after_drain": 0, "event_drain_error": "",
            "configured_rtt_ms": 80, "shaped_rate_bits_per_second": 1_000_000_000,
            "receiving_pool_observed_bytes": ((2 if smoke else 8) << 20) + 1,
            "wan_response_tls": [{"http_major": 1, "negotiated_alpn": "http/1.1",
                                  "peer_leaf_der_sha256": "2" * 64, "origin_connection_id": f"127.0.0.1:{1000 + origin_index}",
                                  "validation_error": ""}],
            "upstream_transport_trace": {
                "sequence": str(index), "overflow": False, "store_count": index,
                "matches": [{"sequence": str(index), "method": "GET" if direction == "download" else "POST",
                             "path": "/agent/bulk" if direction == "download" else "/agent/bulk-upload",
                             "callback_overflow": False,
                             "got_conn": [{"reused": reused, "was_idle": reused,
                                           "idle_time_ns": 3_900_000_000 if reused else 0,
                                           "connection_type": "*server.agentTunnelStreamConn",
                                           "local_address": "10.211.0.1:30000",
                                           "remote_address": f"10.212.0.2:{40000 + lane}",
                                           "observed_unix_ns": got_ns}],
                             "put_idle_conn": [{"observed_unix_ns": got_ns + 100_000_000}]}],
            },
            "response_copy_attribution": copy_contract.envelope(direction, payload),
            "provenance": {"server_binary_sha256": hashes["server_binary"],
                           "aggregate_agent_binary_sha256": hashes["aggregate_agent_binary"],
                           "harness_sha256": hashes["runner"], "server_source_ref": "8ac4c8d",
                           "aggregate_agent_source_ref": "8ac4c8d"},
        })
    for index, row in enumerate(rows, 1):
        copy_envelope = row["response_copy_attribution"]
        copy_envelope["sequence"] = str(index)
        copy_envelope["store_count"] = index
        copy_envelope["matches"][0]["sequence"] = str(index)
    labels = ["current-server-aggregate-v1-h1-1-agent", "current-server-aggregate-v1-h1-1-server",
              "origin", "agent-namespace", "router-namespace"]
    lifecycle = [{"event": "namespace-helpers-start", "agent": {"namespace": "net:[2]", "start_ticks": 2},
                  "router": {"namespace": "net:[3]", "start_ticks": 3}}]
    lifecycle += [{"event": "process-exit", "label": label, "pid": index + 10, "status": 0, "forced": False,
                   "group_joined": True, "invalidates_success": False} for index, label in enumerate(labels)]
    summary = {"diagnostic_only": True, "public_protocol": "h1", "classification": "observational-complete",
               "acceptance": {"correctness": True, "verified_tls_and_protocol_every_response": True,
                              "transport_trace_complete": True, "expected_upstream_reuse": True,
                              "response_copy_attribution_complete": True, "download_floor_every_phase": True},
               "copy_attribution_issues_by_sequence": {},
               "copy_attribution_interpretation": COPY_INTERPRETATION}
    return {"rows": rows, "lifecycle": lifecycle, "summary": summary,
            "outer": {"all_private": True, "shell_pid_is_one": True, "python_parent_is_one": True,
                      "parent": {"cgroup": "cgroup:[1]"}, "owned": {"cgroup": "cgroup:[1]"},
                      "cgroup_namespace_unchanged": True},
            "supervisor": {"runner_status": 0, "group_joined": True, "forced": False, "invalidates_success": False,
                           "server_scope": {"systemd_run_status": 0, "resource_status": 0, "unit_joined": True,
                                            "unit_query_status": 0, "unit_load_state": "not-found",
                                            "unit_active_state": "inactive", "unit_sub_state": "dead"},
                           "trace_reduction": {"parser_status": 0, "analyzer_status": 0}},
            "pre": pre, "post": copy.deepcopy(pre)}


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def server_capacity(sequence):
    return {
        "schema_version": 1, "sequence": str(sequence), "observed_unix_ns": 300, "generation": 1,
        "adaptive": True, "adaptive_admission_role": "server_stream", "adaptive_admission_limit": 40,
        "adaptive_raw_admission_limit": 50, "adaptive_public_admission_limit": 30, "reject_new": False,
        "memory_pressure": "healthy", "memory_used_bytes": 100, "memory_limit_bytes": 2 << 30,
        "memory_source": "host", "memory_headroom_to_hard_bytes": 1000,
        "file_descriptors_used": 10, "file_descriptors_limit": 100, "resource_pressure_reason": "memory",
        "resource_sample_error": "", "resource_sampled_unix_ns": 200,
        "resource_next_sample_unix_ns": 400, "resource_last_good_unix_ns": 200,
    }


def capacity_request(sequence, response):
    return {"schema_version": 1, "sequence": str(sequence), "request_started_unix_ns": 100,
            "request_elapsed_ns": 10, "http_status": 200, "response": response, "error": ""}


def materialize_read_wait_and_scope(case, value, smoke):
    results = case / "results.jsonl"
    trace_dir = case / "results.read-wait-traces"
    control_dir = case / "results.read-wait-controls"
    reduction_dir = case / "read-wait-reductions"
    scope_dir = case / "server-scope"
    for directory in (trace_dir, control_dir, reduction_dir, scope_dir):
        directory.mkdir()
    sequences = (9, 11, 13) if smoke else (9, 11, 14, 15)
    specs = {9: ("retained-warmup", 1), 11: ("steady", 1),
             13: ("reuse-probe", 1), 14: ("steady", 2), 15: ("steady", 3)}
    records, entries = [], []
    for sequence in sequences:
        raw = trace_dir / f"runtime-trace-sequence-{sequence}.out"
        raw.write_bytes(f"synthetic-trace-{sequence}\n".encode())
        start = {"action": "start", "sequence": str(sequence), "http_status": 200, "error": "",
                 "response": {"capture": {"sequence": str(sequence), "state": "active",
                                            "complete": False, "valid": False}}}
        stop = {"action": "stop", "sequence": str(sequence), "http_status": 200, "error": "",
                "response": {"capture": {"sequence": str(sequence), "state": "complete",
                                           "task_type": "wan-read-wait-request", "region_type": "public-proxy-handler",
                                           "expected_method": "GET", "expected_path": "/agent/bulk", "path": str(raw),
                                           "candidate_requests": 1, "marked_requests": 1, "active_requests": 0,
                                           "requests_outside_capture": 0, "controller_timed_out": False, "issues": None,
                                           "issue_overflow": False, "complete": True, "valid": True,
                                           "started_unix_ns": sequence * 1_000_000_000,
                                           "stopped_unix_ns": sequence * 1_000_000_000 + 100,
                                           "trace_elapsed_ns": 100,
                                           "writer": {"cap_bytes": 64 << 20, "bytes": raw.stat().st_size,
                                                      "input_bytes": raw.stat().st_size, "overflow": False,
                                                      "error": ""}}}}
        start_path = control_dir / f"sequence-{sequence}-start.json"
        stop_path = control_dir / f"sequence-{sequence}-stop.json"
        pre_capacity = server_capacity(sequence)
        post_capacity = server_capacity(sequence)
        post_capacity["generation"] = 2
        pre_capacity_request = capacity_request(sequence, pre_capacity)
        post_capacity_request = capacity_request(sequence, post_capacity)
        pre_capacity_path = control_dir / f"sequence-{sequence}-pre-capacity.json"
        post_capacity_path = control_dir / f"sequence-{sequence}-post-capacity.json"
        start_path.write_text(json.dumps(start) + "\n")
        stop_path.write_text(json.dumps(stop) + "\n")
        pre_capacity_path.write_text(json.dumps(pre_capacity_request) + "\n")
        post_capacity_path.write_text(json.dumps(post_capacity_request) + "\n")
        records.append({"schema_version": 1, "sequence": sequence, "stage": specs[sequence][0],
                        "direction": "download", "repetition": specs[sequence][1],
                        "control_boundary": "start-before-run_transfer-stop-after-run_transfer-including-postqueries",
                        "handler_region_boundary": "unchanged-public-proxy-handler-only",
                        "trace_artifact_scope": "whole-server-process", "qualification_result": False,
                        "pre_resource_status": 0, "pre_healthy_status": 0, "pre_capacity_query_status": 0,
                        "pre_server_capacity": pre_capacity, "pre_capacity_request": pre_capacity_request,
                        "transfer_status": 0,
                        "stop_status": 0, "post_runtime_status": 0, "post_cgroup_status": 0,
                        "post_capacity_query_status": 0, "post_healthy_status": 0,
                        "post_server_capacity": post_capacity, "post_capacity_request": post_capacity_request,
                        "resource_status": 0, "complete": True, "valid": True,
                        "start_control": start, "stop_control": stop})
        parsed = reduction_dir / f"sequence-{sequence}.parsed.txt"
        parsed.write_text(f"synthetic parsed trace {sequence}\n")
        parser_status = reduction_dir / f"sequence-{sequence}.parser.status"
        parser_status.write_text("0\n")
        analyzer_status = reduction_dir / f"sequence-{sequence}.analyzer.status"
        analyzer_status.write_text("0\n")
        reduction_path = reduction_dir / f"sequence-{sequence}.reduction.json"
        reduction = {"schema_version": 1, "accepted": True, "errors": [],
                     "task_type": "wan-read-wait-request", "region_type": "public-proxy-handler",
                     "input": str(parsed), "input_sha256": digest(parsed),
                     "parsed_tool_status_file": str(parser_status),
                     "parsed_tool_status_sha256": hashlib.sha256(b"0\n").hexdigest(),
                     "fixed_bounds": {"max_input_bytes": 512 << 20, "max_output_bytes": 8 << 20},
                     "markers": {"task_id": sequence, "handler_gid": sequence + 100},
                     "reduction": {"region_duration_ns": 100, "state_ns": {"Running": 25, "Runnable": 25,
                                                                            "Syscall": 25, "Waiting": 25},
                                   "partition_delta_ns": 0, "partition_sum_ns": 100,
                                   "missing_stack_ns": 0, "unknown_stack_ns": 0,
                                   "waiting_category_ns": {"synthetic": 25},
                                   "waiting_reason_ns": {"synthetic": 25}, "waiting_stack_groups": [],
                                   "top_wait_intervals": [], "attribution_complete": False}}
        reduction_path.write_text(json.dumps(reduction) + "\n")
        tls = value["rows"][sequence - 1]["wan_response_tls"][0]
        entries.append({"sequence": sequence, "raw_path": str(raw), "raw_sha256": digest(raw),
                        "parsed_path": str(parsed), "parsed_sha256": digest(parsed),
                        "parser_status_path": str(parser_status), "parser_status_sha256": digest(parser_status),
                        "reduction_path": str(reduction_path), "reduction_sha256": digest(reduction_path),
                        "server_binary_sha256": value["pre"]["sha256"]["server_binary"],
                        "server_source_ref": value["pre"]["server_source_ref"],
                        "runner_sha256": value["pre"]["sha256"]["runner"], "public_protocol": "h1",
                        "certificate_der_sha256": value["pre"]["expected_leaf_der_sha256"],
                        "origin_connection_id": tls["origin_connection_id"]})
    (case / "results.read-wait-trace-records.jsonl").write_text(
        "".join(json.dumps(record) + "\n" for record in records))
    (reduction_dir / "index.json").write_text(json.dumps({"schema_version": 1, "diagnostic_only": True,
        "duration_relation_to_copy_observer": "descriptive-only", "entries": entries}) + "\n")
    absolute = "/sys/fs/cgroup/user.slice/user-1000.slice/example.scope"
    unified = "/user.slice/user-1000.slice/example.scope"
    namespaces = {"user": "user:[2]", "pid": "pid:[2]", "mnt": "mnt:[2]", "net": "net:[2]", "cgroup": "cgroup:[1]"}
    host = {"host_pid": 501, "host_start_ticks": 9001, "host_namespaces": namespaces}
    binding = {"accepted": True, "checks": {"all": True}, "host_process": host,
               "scope": {"path": absolute}, "state": {"expected_cgroup": unified}}
    for name in ("server-preexec-binding.json", "server-application-binding.json"):
        (scope_dir / name).write_text(json.dumps(binding) + "\n")
    zero_events = {"high": 0, "max": 0, "oom": 0, "oom_kill": 0, "oom_group_kill": 0}
    pre_scope = {"path": absolute, "memory_max_bytes": 4294967296, "memory_swap_max_bytes": 0,
                 "memory_high_bytes": "max", "memory_peak_bytes": 100, "memory_events": zero_events}
    post_scope = {"cgroup_path": unified, "memory_max_bytes": 4294967296, "memory_swap_max_bytes": 0,
                  "memory_high_bytes": "max", "memory_peak_bytes": 200, "memory_events": zero_events}
    (scope_dir / "server-cgroup-pre-traffic.json").write_text(json.dumps(pre_scope) + "\n")
    (scope_dir / "server-cgroup-post-workload.json").write_text(json.dumps(post_scope) + "\n")
    resource = {"accepted": True, "checks": {"all": True}}
    (scope_dir / "server-resource-attestation.json").write_text(json.dumps(resource) + "\n")
    process_join = {"launcher_alive_same_identity": False, "launcher_group_joined": True,
                    "sentinel_alive_same_identity": False, "sentinel_group_joined": True}
    (scope_dir / "scope-process-join.json").write_text(json.dumps(process_join) + "\n")
    policy = {"accepted": True, "checks": {"all": True}}
    (scope_dir / "unit-policy.json").write_text(json.dumps(policy) + "\n")
    unit_final = {"query_status": 0, "joined": True, "failed_state_rejected": True,
                  "confirmation": "show", "show_status": 0, "load_state": "not-found",
                  "active_state": "inactive", "sub_state": "dead"}
    (scope_dir / "unit-final.json").write_text(json.dumps(unit_final) + "\n")
    (scope_dir / "scope-launcher.json").write_text(json.dumps(
        {"setsid_identity_stable": True, "pid": 401, "pgid": 401, "sid": 401, "start_ticks": 8001}) + "\n")
    common = "/sys/fs/cgroup/user.slice/user-1000.slice"
    delegation = {"source_cgroup": common + "/caller.scope", "destination_cgroup": absolute,
                  "nearest_common_ancestor": common, "source": {"path": common + "/caller.scope"},
                  "destination": {"path": absolute}, "common_ancestor": {"path": common},
                  "destination_cgroup_procs": {"path": absolute + "/cgroup.procs", "writable": True},
                  "common_ancestor_cgroup_procs": {"path": common + "/cgroup.procs", "writable": True}}
    (scope_dir / "cgroup-delegation-paths.json").write_text(json.dumps(delegation) + "\n")


def run_case(base, name, value, smoke, want_status, issue_text=None, mutate_files=None):
    case = base / name
    case.mkdir()
    paths = {key: case / f"{key}.json" for key in ("summary", "outer", "supervisor", "pre", "post")}
    (case / "results.jsonl").write_text("".join(json.dumps(row) + "\n" for row in value["rows"]))
    (case / "lifecycle.jsonl").write_text("".join(json.dumps(row) + "\n" for row in value["lifecycle"]))
    for key, path in paths.items():
        path.write_text(json.dumps(value[key]) + "\n")
    materialize_read_wait_and_scope(case, value, smoke)
    if mutate_files:
        mutate_files(case)
    attestation = case / "attestation.json"
    command = [str(validator), str(case / "results.jsonl"), str(case / "lifecycle.jsonl"),
               str(paths["summary"]), str(paths["outer"]), str(paths["supervisor"]), str(paths["pre"]),
               str(paths["post"]), str(attestation), "h1", "1" if smoke else "0"]
    result = subprocess.run(command, text=True, capture_output=True)
    assert result.returncode == want_status, (name, result.returncode, result.stdout, result.stderr)
    evidence = json.loads(attestation.read_text())
    assert evidence["accepted"] is (want_status == 0), (name, evidence)
    if issue_text:
        assert any(issue_text in issue for issue in evidence["validation_issues"]), (name, evidence)
    return evidence


if len(sys.argv) != 2:
    raise SystemExit("usage: run-arm-validator-contracts.py NEW_OUTPUT_DIRECTORY")
base = pathlib.Path(sys.argv[1])
base.mkdir(parents=True, exist_ok=False)
valid = fixture(True)
valid_evidence = run_case(base, "valid-smoke-host-selected", valid, True, 0)
assert all(record["handler_elapsed_ns"] == 10_000_000 for record in valid_evidence["copy_attribution_records"])
assert all(record["upstream_read"]["span_ns"] ==
           record["upstream_read"]["total_ns"] + record["inter_read_gap"]["total_ns"]
           for record in valid_evidence["copy_attribution_records"])


def mutate_all_capacity_sources(case, source):
    records_path = case / "results.read-wait-trace-records.jsonl"
    records = [json.loads(line) for line in records_path.read_text().splitlines()]
    for record in records:
        sequence = record["sequence"]
        for position in ("pre", "post"):
            snapshot = record[f"{position}_server_capacity"]
            request = record[f"{position}_capacity_request"]
            snapshot["memory_source"] = source
            request["response"]["memory_source"] = source
            request_path = case / f"results.read-wait-controls/sequence-{sequence}-{position}-capacity.json"
            saved_request = json.loads(request_path.read_text())
            saved_request["response"]["memory_source"] = source
            request_path.write_text(json.dumps(saved_request) + "\n")
    records_path.write_text("".join(json.dumps(record) + "\n" for record in records))

run_case(base, "valid-smoke-go-selected", copy.deepcopy(valid), True, 0,
         mutate_files=lambda case: mutate_all_capacity_sources(case, "go"))
missing_copy = copy.deepcopy(valid)
missing_copy["rows"][0]["response_copy_attribution"]["matches"] = []
missing_copy["summary"]["classification"] = "invalid"
missing_copy["summary"]["acceptance"]["response_copy_attribution_complete"] = False
missing_copy["summary"]["copy_attribution_issues_by_sequence"] = {"1": ["copy envelope correlation/cardinality changed"]}
run_case(base, "missing-copy", missing_copy, True, 1, "copy attribution failed")
wrong_copy_sequence = copy.deepcopy(valid)
wrong_copy_sequence["rows"][1]["response_copy_attribution"]["matches"][0]["sequence"] = "99"
run_case(base, "wrong-copy-sequence", wrong_copy_sequence, True, 1, "copy attribution failed")
copy_histogram = copy.deepcopy(valid)
copy_histogram["rows"][2]["response_copy_attribution"]["matches"][0]["copy"]["upstream_read"]["duration_bucket_counts"] = [1,0,0,0,0,0,0,0]
run_case(base, "copy-histogram", copy_histogram, True, 1, "histogram")
copy_read_from = copy.deepcopy(valid)
copy_read_from["rows"][3]["response_copy_attribution"]["matches"][0]["copy"]["downstream_read_from_calls"] = 1
run_case(base, "copy-read-from", copy_read_from, True, 1, "ReadFrom")
bad_sequence = copy.deepcopy(valid)
bad_sequence["rows"][3]["upstream_transport_trace"]["matches"][0]["sequence"] = "99"
run_case(base, "wrong-sequence", bad_sequence, True, 1, "trace correlation")
repeated_trace = copy.deepcopy(valid)
repeated_trace["rows"][2]["upstream_transport_trace"]["matches"].append(
    copy.deepcopy(repeated_trace["rows"][2]["upstream_transport_trace"]["matches"][0]))
run_case(base, "repeated-trace", repeated_trace, True, 1, "repeated upstream trace")
inconclusive = copy.deepcopy(valid)
inconclusive["summary"]["classification"] = "inconclusive-upstream-reuse"
run_case(base, "inconclusive", inconclusive, True, 1, "not conclusive")
missed_reuse = copy.deepcopy(valid)
missed_reuse["rows"][12]["upstream_transport_trace"]["matches"][0]["got_conn"][0].update(
    {"reused": False, "was_idle": False, "idle_time_ns": 0})
run_case(base, "missed-reuse", missed_reuse, True, 1, "did not reuse")
wrong_origin = copy.deepcopy(valid)
wrong_origin["rows"][12]["wan_response_tls"][0]["origin_connection_id"] = "127.0.0.1:9999"
run_case(base, "wrong-reuse-origin", wrong_origin, True, 1, "did not reuse")
missing_prior_put = copy.deepcopy(valid)
missing_prior_put["rows"][8]["upstream_transport_trace"]["matches"][0]["put_idle_conn"] = []
run_case(base, "missing-prior-put", missing_prior_put, True, 1, "successful PutIdleConn")
duplicate_first_key = copy.deepcopy(valid)
duplicate_first_key["rows"][9]["upstream_transport_trace"]["matches"][0]["got_conn"][0]["remote_address"] = "10.212.0.2:40001"
run_case(base, "duplicate-first-key", duplicate_first_key, True, 1, "distinct expected-fresh")
empty_acceptance = copy.deepcopy(valid)
empty_acceptance["summary"]["acceptance"] = {}
run_case(base, "empty-acceptance", empty_acceptance, True, 1, "incomplete")
duplicate_pid = copy.deepcopy(valid)
duplicate_pid["lifecycle"][-1]["pid"] = duplicate_pid["lifecycle"][-2]["pid"]
run_case(base, "duplicate-process", duplicate_pid, True, 1, "process identities")
forced_cleanup = copy.deepcopy(valid)
forced_cleanup["supervisor"].update({"forced": True, "invalidates_success": True})
run_case(base, "forced-cleanup", forced_cleanup, True, 1, "did not join naturally")
floor_failure = fixture(False)
floor_failure["rows"][0]["wall_seconds"] = ((256 << 20) / 20_000_000.0)
floor_failure["rows"][0]["useful_transfer_bytes_per_second"] = 20_000_000.0
floor_failure["supervisor"]["runner_status"] = 1
floor_failure["supervisor"]["invalidates_success"] = True
floor_evidence = run_case(base, "floor-failure", floor_failure, False, 1, "download phase failed")
assert floor_evidence["natural_endpoint_and_namespace_statuses"] is True
assert floor_evidence["outer_private_user_pid_mount_net"] is True
assert floor_evidence["outer_runner_group_joined"] is True
assert floor_evidence["runner_status"] == 1
assert any("runner exited nonzero" in issue for issue in floor_evidence["validation_issues"])

def mutate_repeated_read_wait_record(case):
    path = case / "results.read-wait-trace-records.jsonl"
    lines = path.read_text().splitlines()
    path.write_text("\n".join(lines + [lines[0]]) + "\n")
run_case(base, "repeated-read-wait-record", copy.deepcopy(valid), True, 1,
         "trace record count", mutate_repeated_read_wait_record)

def mutate_writer_overflow(case):
    path = case / "results.read-wait-trace-records.jsonl"
    records = [json.loads(line) for line in path.read_text().splitlines()]
    records[0]["stop_control"]["response"]["capture"]["writer"]["overflow"] = True
    path.write_text("".join(json.dumps(record) + "\n" for record in records))
run_case(base, "writer-overflow", copy.deepcopy(valid), True, 1,
         "control/artifact contract", mutate_writer_overflow)

def mutate_capture_issues(case, value, missing=False):
    path = case / "results.read-wait-trace-records.jsonl"
    records = [json.loads(line) for line in path.read_text().splitlines()]
    capture = records[0]["stop_control"]["response"]["capture"]
    if missing:
        del capture["issues"]
    else:
        capture["issues"] = value
    path.write_text("".join(json.dumps(record) + "\n" for record in records))

run_case(base, "missing-capture-issues", copy.deepcopy(valid), True, 1,
         "control/artifact contract", lambda case: mutate_capture_issues(case, None, missing=True))
run_case(base, "nonempty-capture-issues", copy.deepcopy(valid), True, 1,
         "control/artifact contract", lambda case: mutate_capture_issues(case, ["capture failed"]))
run_case(base, "malformed-capture-issues", copy.deepcopy(valid), True, 1,
         "control/artifact contract", lambda case: mutate_capture_issues(case, "none"))

def mutate_pre_capacity(case, field, value):
    records_path = case / "results.read-wait-trace-records.jsonl"
    records = [json.loads(line) for line in records_path.read_text().splitlines()]
    record = records[0]
    record["pre_server_capacity"][field] = value
    record["pre_capacity_request"]["response"][field] = value
    records_path.write_text("".join(json.dumps(item) + "\n" for item in records))
    request_path = case / "results.read-wait-controls/sequence-9-pre-capacity.json"
    request = json.loads(request_path.read_text())
    request["response"][field] = value
    request_path.write_text(json.dumps(request) + "\n")

run_case(base, "capacity-reject-new", copy.deepcopy(valid), True, 1,
         "control/artifact contract", lambda case: mutate_pre_capacity(case, "reject_new", True))
run_case(base, "capacity-sample-error", copy.deepcopy(valid), True, 1,
         "control/artifact contract", lambda case: mutate_pre_capacity(case, "resource_sample_error", "unavailable"))
run_case(base, "capacity-unsupported-source", copy.deepcopy(valid), True, 1,
         "control/artifact contract", lambda case: mutate_pre_capacity(case, "memory_source", "synthetic"))

def mutate_capacity_file_join(case):
    path = case / "results.read-wait-controls/sequence-9-pre-capacity.json"
    value = json.loads(path.read_text())
    value["request_elapsed_ns"] = 11
    path.write_text(json.dumps(value) + "\n")
run_case(base, "capacity-file-record-mismatch", copy.deepcopy(valid), True, 1,
         "control/artifact contract", mutate_capacity_file_join)

def mutate_reduction_path(case):
    path = case / "read-wait-reductions/index.json"
    value = json.loads(path.read_text())
    value["entries"][0]["parsed_path"] = str(case / "read-wait-reductions/not-the-sequence-path.txt")
    path.write_text(json.dumps(value) + "\n")
run_case(base, "wrong-reduction-path", copy.deepcopy(valid), True, 1,
         "cohort identity join", mutate_reduction_path)

def mutate_parser_status(case):
    status = case / "read-wait-reductions/sequence-9.parser.status"
    status.write_text("1\n")
    index = case / "read-wait-reductions/index.json"
    value = json.loads(index.read_text())
    value["entries"][0]["parser_status_sha256"] = digest(status)
    index.write_text(json.dumps(value) + "\n")
run_case(base, "parser-nonzero", copy.deepcopy(valid), True, 1,
         "local parser/reducer contract", mutate_parser_status)

wrong_outer_cgroup = copy.deepcopy(valid)
wrong_outer_cgroup["outer"]["cgroup_namespace_unchanged"] = False
run_case(base, "changed-outer-cgroup-namespace", wrong_outer_cgroup, True, 1,
         "outer user/PID/mount/network namespace ownership missing")

def mutate_effective_policy(case):
    path = case / "server-scope/unit-policy.json"
    value = json.loads(path.read_text())
    value["accepted"] = False
    value["checks"]["effective_memory_max_4gib"] = False
    path.write_text(json.dumps(value) + "\n")
run_case(base, "wrong-effective-memory-max", copy.deepcopy(valid), True, 1,
         "delegated server-only cgroup", mutate_effective_policy)

def mutate_post_cgroup_path(case):
    path = case / "server-scope/server-cgroup-post-workload.json"
    value = json.loads(path.read_text())
    value["cgroup_path"] = "/user.slice/wrong.scope"
    path.write_text(json.dumps(value) + "\n")
run_case(base, "wrong-post-cgroup-path", copy.deepcopy(valid), True, 1,
         "delegated server-only cgroup", mutate_post_cgroup_path)

def mutate_unit_query(case):
    path = case / "server-scope/unit-final.json"
    value = json.loads(path.read_text())
    value.update({"query_status": 1, "show_status": 1, "joined": False})
    path.write_text(json.dumps(value) + "\n")
run_case(base, "unit-query-failure", copy.deepcopy(valid), True, 1,
         "delegated server-only cgroup", mutate_unit_query)
print("validator contracts passed")
