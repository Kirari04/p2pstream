#!/usr/bin/env bash
set -Eeuo pipefail
exec ./provenance/run-capacity-focused-test.sh race
