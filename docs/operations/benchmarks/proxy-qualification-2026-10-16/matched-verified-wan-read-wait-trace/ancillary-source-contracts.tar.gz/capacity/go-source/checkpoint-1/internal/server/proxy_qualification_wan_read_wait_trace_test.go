//go:build linux

package server

import (
	"context"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"runtime/trace"
	"slices"
	"strings"
	"sync"
	"time"
)

const (
	qualificationWANReadWaitTraceEnv          = "P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE"
	qualificationWANReadWaitTraceDirEnv       = "P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_DIR"
	qualificationWANReadWaitTraceSequencesEnv = "P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_SEQUENCES"
	qualificationWANReadWaitTraceBearerEnv    = "P2PSTREAM_QUALIFICATION_WAN_READ_WAIT_TRACE_BEARER"
	qualificationWANReadWaitTraceCapBytes     = int64(64 << 20)
	qualificationWANReadWaitTraceTaskType     = "wan-read-wait-request"
	qualificationWANReadWaitTraceRegionType   = "public-proxy-handler"
	qualificationWANReadWaitTracePath         = "/agent/bulk"
)

var (
	qualificationWANReadWaitSustainedSequences = []string{"9", "11", "14", "15"}
	qualificationWANReadWaitSmokeSequences     = []string{"9", "11", "13"}
)

type qualificationWANReadWaitCappedWriter struct {
	mu       sync.Mutex
	file     io.Writer
	capBytes int64
	input    int64
	written  int64
	overflow bool
	writeErr string
}

type qualificationWANReadWaitWriterSnapshot struct {
	CapBytes int64  `json:"cap_bytes"`
	Input    int64  `json:"input_bytes"`
	Bytes    int64  `json:"bytes"`
	Overflow bool   `json:"overflow"`
	Error    string `json:"error,omitempty"`
}

func newQualificationWANReadWaitCappedWriter(file io.Writer, capBytes int64) *qualificationWANReadWaitCappedWriter {
	return &qualificationWANReadWaitCappedWriter{file: file, capBytes: capBytes}
}

// Write never lets a runtime trace producer block on a previously observed
// sink failure. It records the first failure or overflow, writes at most the
// configured prefix, and reports the complete input consumed while discarding
// the remainder. runtime/trace ignores the returned count and error.
func (writer *qualificationWANReadWaitCappedWriter) Write(p []byte) (int, error) {
	writer.mu.Lock()
	defer writer.mu.Unlock()
	inputBytes := len(p)
	if inputBytes == 0 {
		return 0, nil
	}
	remaining := writer.capBytes - writer.input
	if remaining < 0 {
		remaining = 0
	}
	writeBytes := int64(inputBytes)
	if writeBytes > remaining {
		writeBytes = remaining
		writer.overflow = true
	}
	writer.input += int64(inputBytes)
	if writeBytes > 0 && writer.writeErr == "" {
		written, err := writer.file.Write(p[:writeBytes])
		writer.written += int64(written)
		if err != nil {
			writer.writeErr = qualificationWANReadWaitErrorText(err)
		} else if int64(written) != writeBytes {
			writer.writeErr = qualificationWANReadWaitErrorText(io.ErrShortWrite)
		}
	}
	return inputBytes, nil
}

func (writer *qualificationWANReadWaitCappedWriter) snapshot() qualificationWANReadWaitWriterSnapshot {
	writer.mu.Lock()
	defer writer.mu.Unlock()
	return qualificationWANReadWaitWriterSnapshot{
		CapBytes: writer.capBytes,
		Input:    writer.input,
		Bytes:    writer.written,
		Overflow: writer.overflow,
		Error:    writer.writeErr,
	}
}

type qualificationWANReadWaitCapture struct {
	Sequence string
	Path     string
	State    string

	file   *os.File
	writer *qualificationWANReadWaitCappedWriter

	started                time.Time
	stopped                time.Time
	activeRequests         int
	activeRequestsDone     chan struct{}
	candidateRequests      int
	markedRequests         int
	requestsOutsideCapture int
	controllerTimedOut     bool
	issues                 []string
	issueOverflow          bool
	fileSyncError          string
	fileCloseError         string
}

type qualificationWANReadWaitCaptureSnapshot struct {
	Sequence               string                                 `json:"sequence"`
	Path                   string                                 `json:"path"`
	State                  string                                 `json:"state"`
	TaskType               string                                 `json:"task_type"`
	RegionType             string                                 `json:"region_type"`
	ExpectedMethod         string                                 `json:"expected_method"`
	ExpectedPath           string                                 `json:"expected_path"`
	StartedUnixNano        int64                                  `json:"started_unix_ns,omitempty"`
	StoppedUnixNano        int64                                  `json:"stopped_unix_ns,omitempty"`
	TraceElapsedNS         uint64                                 `json:"trace_elapsed_ns,omitempty"`
	CandidateRequests      int                                    `json:"candidate_requests"`
	MarkedRequests         int                                    `json:"marked_requests"`
	ActiveRequests         int                                    `json:"active_requests"`
	RequestsOutsideCapture int                                    `json:"requests_outside_capture"`
	ControllerTimedOut     bool                                   `json:"controller_timed_out"`
	Writer                 qualificationWANReadWaitWriterSnapshot `json:"writer"`
	FileSyncError          string                                 `json:"file_sync_error,omitempty"`
	FileCloseError         string                                 `json:"file_close_error,omitempty"`
	Issues                 []string                               `json:"issues"`
	IssueOverflow          bool                                   `json:"issue_overflow"`
	Complete               bool                                   `json:"complete"`
	Valid                  bool                                   `json:"valid"`
}

// qualificationWANReadWaitServerCapacitySnapshot is a read-only copy of the
// last resource snapshot already applied by the server admission manager. It
// deliberately does not force a resource sample or refresh admission state.
type qualificationWANReadWaitServerCapacitySnapshot struct {
	SchemaVersion                int    `json:"schema_version"`
	Sequence                     string `json:"sequence"`
	ObservedUnixNano             int64  `json:"observed_unix_ns"`
	Generation                   uint64 `json:"generation"`
	Adaptive                     bool   `json:"adaptive"`
	AdaptiveAdmissionRole        string `json:"adaptive_admission_role"`
	AdaptiveAdmissionLimit       int    `json:"adaptive_admission_limit"`
	AdaptiveRawAdmissionLimit    int    `json:"adaptive_raw_admission_limit"`
	AdaptivePublicAdmissionLimit int    `json:"adaptive_public_admission_limit"`
	RejectNew                    bool   `json:"reject_new"`
	MemoryPressure               string `json:"memory_pressure"`
	MemoryUsedBytes              int64  `json:"memory_used_bytes"`
	MemoryLimitBytes             int64  `json:"memory_limit_bytes"`
	MemorySource                 string `json:"memory_source"`
	MemoryHeadroomToHardBytes    int64  `json:"memory_headroom_to_hard_bytes"`
	FileDescriptorsUsed          int64  `json:"file_descriptors_used"`
	FileDescriptorsLimit         int64  `json:"file_descriptors_limit"`
	ResourcePressureReason       string `json:"resource_pressure_reason"`
	ResourceSampleError          string `json:"resource_sample_error"`
	ResourceSampledUnixNano      int64  `json:"resource_sampled_unix_ns"`
	ResourceNextSampleUnixNano   int64  `json:"resource_next_sample_unix_ns"`
	ResourceLastGoodUnixNano     int64  `json:"resource_last_good_unix_ns"`
}

type qualificationWANReadWaitTraceOwner struct {
	controlMu      sync.Mutex
	mu             sync.Mutex
	directory      string
	capBytes       int64
	sequences      []string
	captures       map[string]*qualificationWANReadWaitCapture
	activeSequence string
	finalized      bool
	bearer         string
	violations     []string
	violationLimit bool
	beforeStart    func()
}

func qualificationWANReadWaitSequenceSet(spec string) ([]string, error) {
	sequences := strings.Split(spec, ",")
	if slices.Equal(sequences, qualificationWANReadWaitSustainedSequences) ||
		slices.Equal(sequences, qualificationWANReadWaitSmokeSequences) {
		return append([]string(nil), sequences...), nil
	}
	return nil, fmt.Errorf("unsupported WAN read-wait trace sequence set %q", spec)
}

func newQualificationWANReadWaitTraceOwner(directory string, sequences []string, capBytes int64, bearer string) (*qualificationWANReadWaitTraceOwner, error) {
	if !filepath.IsAbs(directory) || filepath.Clean(directory) != directory {
		return nil, errors.New("WAN read-wait trace directory must be an absolute clean path")
	}
	resolvedDirectory, err := filepath.EvalSymlinks(directory)
	if err != nil || resolvedDirectory != directory {
		return nil, errors.New("WAN read-wait trace directory must be an existing canonical path")
	}
	info, err := os.Stat(directory)
	if err != nil {
		return nil, fmt.Errorf("stat WAN read-wait trace directory: %w", err)
	}
	if !info.IsDir() {
		return nil, errors.New("WAN read-wait trace path is not a directory")
	}
	if capBytes <= 0 {
		return nil, errors.New("WAN read-wait trace cap must be positive")
	}
	decodedBearer, err := hex.DecodeString(bearer)
	if err != nil || len(decodedBearer) != 32 || bearer != strings.ToLower(bearer) {
		return nil, errors.New("WAN read-wait trace bearer must be 32 random bytes encoded as lowercase hexadecimal")
	}
	if !slices.Equal(sequences, qualificationWANReadWaitSustainedSequences) &&
		!slices.Equal(sequences, qualificationWANReadWaitSmokeSequences) {
		return nil, fmt.Errorf("unsupported WAN read-wait trace sequences %v", sequences)
	}
	owner := &qualificationWANReadWaitTraceOwner{
		directory: directory,
		capBytes:  capBytes,
		sequences: append([]string(nil), sequences...),
		captures:  make(map[string]*qualificationWANReadWaitCapture, len(sequences)),
		bearer:    bearer,
	}
	for _, sequence := range sequences {
		owner.captures[sequence] = &qualificationWANReadWaitCapture{
			Sequence: sequence,
			Path:     filepath.Join(directory, "runtime-trace-sequence-"+sequence+".out"),
			State:    "pending",
		}
	}
	return owner, nil
}

func qualificationWANReadWaitTraceOwnerFromEnv() (*qualificationWANReadWaitTraceOwner, error) {
	if os.Getenv(qualificationWANReadWaitTraceEnv) != "1" {
		return nil, nil
	}
	sequences, err := qualificationWANReadWaitSequenceSet(os.Getenv(qualificationWANReadWaitTraceSequencesEnv))
	if err != nil {
		return nil, err
	}
	return newQualificationWANReadWaitTraceOwner(
		os.Getenv(qualificationWANReadWaitTraceDirEnv), sequences, qualificationWANReadWaitTraceCapBytes,
		os.Getenv(qualificationWANReadWaitTraceBearerEnv),
	)
}

func (owner *qualificationWANReadWaitTraceOwner) addIssueLocked(capture *qualificationWANReadWaitCapture, issue string) {
	if len(capture.issues) < 8 {
		capture.issues = append(capture.issues, qualificationWANReadWaitErrorText(errors.New(issue)))
		return
	}
	capture.issueOverflow = true
}

func (owner *qualificationWANReadWaitTraceOwner) addViolationLocked(issue string) {
	if len(owner.violations) < 8 {
		owner.violations = append(owner.violations, qualificationWANReadWaitErrorText(errors.New(issue)))
		return
	}
	owner.violationLimit = true
}

func (owner *qualificationWANReadWaitTraceOwner) recordControllerContextLocked(capture *qualificationWANReadWaitCapture, ctx context.Context, phase string) {
	if capture.controllerTimedOut || ctx == nil || ctx.Err() == nil {
		return
	}
	capture.controllerTimedOut = true
	owner.addIssueLocked(capture, "trace stop controller context expired "+phase+": "+qualificationWANReadWaitErrorText(ctx.Err()))
}

func qualificationWANReadWaitErrorText(err error) string {
	if err == nil {
		return ""
	}
	text := err.Error()
	if len(text) > 512 {
		text = text[:512]
	}
	return text
}

func (owner *qualificationWANReadWaitTraceOwner) snapshotLocked(capture *qualificationWANReadWaitCapture) qualificationWANReadWaitCaptureSnapshot {
	writer := qualificationWANReadWaitWriterSnapshot{CapBytes: owner.capBytes}
	if capture.writer != nil {
		writer = capture.writer.snapshot()
	}
	complete := capture.State == "complete" || capture.State == "invalid"
	valid := complete && capture.State == "complete" && len(capture.issues) == 0 && !capture.issueOverflow &&
		capture.markedRequests == 1 && capture.activeRequests == 0 && capture.requestsOutsideCapture == 0 &&
		!capture.controllerTimedOut && !writer.Overflow && writer.Error == "" && writer.Bytes > 0 &&
		capture.fileSyncError == "" && capture.fileCloseError == "" && !capture.started.IsZero() && !capture.stopped.IsZero()
	snapshot := qualificationWANReadWaitCaptureSnapshot{
		Sequence: capture.Sequence, Path: capture.Path, State: capture.State,
		TaskType: qualificationWANReadWaitTraceTaskType, RegionType: qualificationWANReadWaitTraceRegionType,
		ExpectedMethod: http.MethodGet, ExpectedPath: qualificationWANReadWaitTracePath,
		CandidateRequests: capture.candidateRequests, MarkedRequests: capture.markedRequests,
		ActiveRequests: capture.activeRequests, RequestsOutsideCapture: capture.requestsOutsideCapture,
		ControllerTimedOut: capture.controllerTimedOut, Writer: writer,
		FileSyncError: capture.fileSyncError, FileCloseError: capture.fileCloseError,
		Issues: append([]string(nil), capture.issues...), IssueOverflow: capture.issueOverflow,
		Complete: complete, Valid: valid,
	}
	if !capture.started.IsZero() {
		snapshot.StartedUnixNano = capture.started.UnixNano()
	}
	if !capture.stopped.IsZero() {
		snapshot.StoppedUnixNano = capture.stopped.UnixNano()
		elapsed := capture.stopped.Sub(capture.started)
		if elapsed > 0 {
			snapshot.TraceElapsedNS = uint64(elapsed.Nanoseconds())
		}
	}
	return snapshot
}

func (owner *qualificationWANReadWaitTraceOwner) snapshot(sequence string) (qualificationWANReadWaitCaptureSnapshot, error) {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	capture := owner.captures[sequence]
	if capture == nil {
		return qualificationWANReadWaitCaptureSnapshot{}, errors.New("sequence is not configured for WAN read-wait tracing")
	}
	return owner.snapshotLocked(capture), nil
}

func (owner *qualificationWANReadWaitTraceOwner) start(sequence string) (qualificationWANReadWaitCaptureSnapshot, error) {
	owner.controlMu.Lock()
	defer owner.controlMu.Unlock()
	owner.mu.Lock()
	capture := owner.captures[sequence]
	if capture == nil {
		owner.mu.Unlock()
		return qualificationWANReadWaitCaptureSnapshot{}, errors.New("sequence is not configured for WAN read-wait tracing")
	}
	if owner.finalized {
		owner.mu.Unlock()
		return qualificationWANReadWaitCaptureSnapshot{}, errors.New("WAN read-wait trace owner is finalized")
	}
	if capture.State == "complete" || capture.State == "invalid" {
		owner.addViolationLocked("trace start repeated after sequence " + sequence + " capture closed")
		snapshot := owner.snapshotLocked(capture)
		owner.mu.Unlock()
		return snapshot, errors.New("WAN read-wait trace sequence is already closed")
	}
	if owner.activeSequence != "" {
		owner.addIssueLocked(capture, "trace start attempted while another capture is active")
		snapshot := owner.snapshotLocked(capture)
		owner.mu.Unlock()
		return snapshot, errors.New("another WAN read-wait trace capture is active")
	}
	if capture.State != "pending" || len(capture.issues) != 0 {
		owner.addIssueLocked(capture, "trace start repeated or capture was already invalid")
		snapshot := owner.snapshotLocked(capture)
		owner.mu.Unlock()
		return snapshot, errors.New("WAN read-wait trace sequence is not unused")
	}
	file, err := os.OpenFile(capture.Path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		capture.State = "invalid"
		owner.addIssueLocked(capture, "open trace file: "+qualificationWANReadWaitErrorText(err))
		snapshot := owner.snapshotLocked(capture)
		owner.mu.Unlock()
		return snapshot, err
	}
	capture.file = file
	capture.writer = newQualificationWANReadWaitCappedWriter(file, owner.capBytes)
	capture.State = "starting"
	owner.activeSequence = sequence
	writer := capture.writer
	beforeStart := owner.beforeStart
	owner.mu.Unlock()

	if beforeStart != nil {
		beforeStart()
	}
	startErr := trace.Start(writer)
	started := time.Now()
	owner.mu.Lock()
	if startErr != nil {
		capture.State = "invalid"
		owner.addIssueLocked(capture, "runtime trace start: "+qualificationWANReadWaitErrorText(startErr))
		owner.activeSequence = ""
		if syncErr := file.Sync(); syncErr != nil {
			capture.fileSyncError = qualificationWANReadWaitErrorText(syncErr)
		}
		if closeErr := file.Close(); closeErr != nil {
			capture.fileCloseError = qualificationWANReadWaitErrorText(closeErr)
		}
		snapshot := owner.snapshotLocked(capture)
		owner.mu.Unlock()
		return snapshot, startErr
	}
	capture.started = started
	capture.State = "active"
	snapshot := owner.snapshotLocked(capture)
	owner.mu.Unlock()
	return snapshot, nil
}

func (owner *qualificationWANReadWaitTraceOwner) stop(ctx context.Context, sequence string) (qualificationWANReadWaitCaptureSnapshot, error) {
	owner.controlMu.Lock()
	defer owner.controlMu.Unlock()
	return owner.stopControlLocked(ctx, sequence)
}

func (owner *qualificationWANReadWaitTraceOwner) stopControlLocked(ctx context.Context, sequence string) (qualificationWANReadWaitCaptureSnapshot, error) {
	owner.mu.Lock()
	capture := owner.captures[sequence]
	if capture == nil {
		owner.mu.Unlock()
		return qualificationWANReadWaitCaptureSnapshot{}, errors.New("sequence is not configured for WAN read-wait tracing")
	}
	if capture.State == "complete" || capture.State == "invalid" {
		owner.addViolationLocked("trace stop repeated after sequence " + sequence + " capture closed")
		snapshot := owner.snapshotLocked(capture)
		owner.mu.Unlock()
		return snapshot, errors.New("WAN read-wait trace sequence is already closed")
	}
	if capture.State != "active" || owner.activeSequence != sequence {
		owner.addIssueLocked(capture, "trace stop attempted for a sequence that is not active")
		snapshot := owner.snapshotLocked(capture)
		owner.mu.Unlock()
		return snapshot, errors.New("WAN read-wait trace sequence is not active")
	}
	owner.recordControllerContextLocked(capture, ctx, "at entry")
	capture.State = "stopping"
	var activeDone <-chan struct{}
	if capture.activeRequests > 0 {
		activeDone = capture.activeRequestsDone
	}
	owner.mu.Unlock()

	if activeDone != nil {
		select {
		case <-activeDone:
		case <-ctx.Done():
			owner.mu.Lock()
			owner.recordControllerContextLocked(capture, ctx, "while waiting for the marked handler")
			owner.mu.Unlock()
			// The client deadline never abandons the process-global tracer. The
			// owned controller continues waiting until the marked handler ends.
			<-activeDone
		}
	}

	// Never hold the owner or writer mutex while trace.Stop waits for the
	// runtime trace reader to finish its writes.
	trace.Stop()
	stopped := time.Now()
	syncErr := capture.file.Sync()
	closeErr := capture.file.Close()

	owner.mu.Lock()
	capture.stopped = stopped
	owner.recordControllerContextLocked(capture, ctx, "after trace and file finalization")
	if syncErr != nil {
		capture.fileSyncError = qualificationWANReadWaitErrorText(syncErr)
		owner.addIssueLocked(capture, "sync trace file: "+capture.fileSyncError)
	}
	if closeErr != nil {
		capture.fileCloseError = qualificationWANReadWaitErrorText(closeErr)
		owner.addIssueLocked(capture, "close trace file: "+capture.fileCloseError)
	}
	writerSnapshot := capture.writer.snapshot()
	if writerSnapshot.Overflow {
		owner.addIssueLocked(capture, "trace file cap exceeded")
	}
	if writerSnapshot.Error != "" {
		owner.addIssueLocked(capture, "trace writer: "+writerSnapshot.Error)
	}
	if capture.markedRequests != 1 {
		owner.addIssueLocked(capture, fmt.Sprintf("marked request count is %d, want 1", capture.markedRequests))
	}
	if capture.requestsOutsideCapture != 0 {
		owner.addIssueLocked(capture, fmt.Sprintf("requests outside capture is %d, want 0", capture.requestsOutsideCapture))
	}
	if len(capture.issues) == 0 && !capture.issueOverflow {
		capture.State = "complete"
	} else {
		capture.State = "invalid"
	}
	owner.activeSequence = ""
	snapshot := owner.snapshotLocked(capture)
	owner.mu.Unlock()
	if !snapshot.Valid {
		return snapshot, errors.New("WAN read-wait trace capture is invalid")
	}
	return snapshot, nil
}

func (owner *qualificationWANReadWaitTraceOwner) beginRequest(sequence, method, path string) bool {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	capture := owner.captures[sequence]
	if capture == nil {
		return false
	}
	if capture.State != "active" || owner.activeSequence != sequence {
		if capture.State == "complete" || capture.State == "invalid" {
			owner.addViolationLocked("configured sequence " + sequence + " was repeated after its capture closed")
			return false
		}
		if capture.State == "pending" || capture.State == "starting" || capture.State == "stopping" {
			capture.requestsOutsideCapture++
			owner.addIssueLocked(capture, "configured request arrived outside its active trace interval")
		}
		return false
	}
	capture.candidateRequests++
	if method != http.MethodGet || path != qualificationWANReadWaitTracePath {
		owner.addIssueLocked(capture, "configured sequence used unexpected method or path")
		return false
	}
	capture.markedRequests++
	if capture.markedRequests > 1 {
		owner.addIssueLocked(capture, "duplicate marked request")
	}
	if capture.activeRequests == 0 {
		capture.activeRequestsDone = make(chan struct{})
	}
	capture.activeRequests++
	return true
}

func (owner *qualificationWANReadWaitTraceOwner) endRequest(sequence string) {
	owner.mu.Lock()
	defer owner.mu.Unlock()
	capture := owner.captures[sequence]
	if capture == nil || capture.activeRequests <= 0 {
		return
	}
	capture.activeRequests--
	if capture.activeRequests == 0 {
		close(capture.activeRequestsDone)
	}
}

func wrapQualificationWANReadWaitTrace(owner *qualificationWANReadWaitTraceOwner, next http.Handler) http.Handler {
	if owner == nil {
		return next
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		sequence := r.Header.Get("X-Qualification-Diagnostic-Sequence")
		if !qualificationWANSequenceValid(sequence) || !owner.beginRequest(sequence, r.Method, r.URL.EscapedPath()) {
			next.ServeHTTP(w, r)
			return
		}
		defer owner.endRequest(sequence)
		requestContext, task := trace.NewTask(r.Context(), qualificationWANReadWaitTraceTaskType)
		defer task.End()
		region := trace.StartRegion(requestContext, qualificationWANReadWaitTraceRegionType)
		defer region.End()
		next.ServeHTTP(w, r.WithContext(requestContext))
	})
}

func qualificationWANReadWaitAuthorized(owner *qualificationWANReadWaitTraceOwner, r *http.Request) bool {
	if owner == nil || r == nil {
		return false
	}
	authorization := r.Header.Get("Authorization")
	if !strings.HasPrefix(authorization, "Bearer ") {
		return false
	}
	providedBearer := strings.TrimPrefix(authorization, "Bearer ")
	return len(providedBearer) == len(owner.bearer) && subtle.ConstantTimeCompare([]byte(providedBearer), []byte(owner.bearer)) == 1
}

func qualificationWANReadWaitUnixNano(value time.Time) int64 {
	if value.IsZero() {
		return 0
	}
	return value.UnixNano()
}

func qualificationWANReadWaitServerCapacity(app *App, sequence string) (qualificationWANReadWaitServerCapacitySnapshot, error) {
	if app == nil || app.agentStreamCapacity == nil {
		return qualificationWANReadWaitServerCapacitySnapshot{}, errors.New("WAN read-wait server capacity is unavailable")
	}
	manager := app.agentStreamCapacity
	manager.mu.Lock()
	resource := manager.resourceSnapshot
	result := qualificationWANReadWaitServerCapacitySnapshot{
		SchemaVersion:                1,
		Sequence:                     sequence,
		Generation:                   resource.Generation,
		Adaptive:                     manager.adaptiveMemory != nil,
		AdaptiveAdmissionRole:        string(resource.AdmissionRole),
		AdaptiveAdmissionLimit:       manager.adaptiveStreamAdmissionLimitLocked(),
		AdaptiveRawAdmissionLimit:    resource.AdmissionLimit,
		AdaptivePublicAdmissionLimit: manager.adaptivePublicLimitLocked(),
		RejectNew:                    resource.RejectNew,
		MemoryPressure:               resource.Level.String(),
		MemoryUsedBytes:              resource.Usage.UsedBytes,
		MemoryLimitBytes:             resource.Usage.LimitBytes,
		MemorySource:                 resource.Usage.Source,
		MemoryHeadroomToHardBytes:    resource.HeadroomToHardByte,
		FileDescriptorsUsed:          resource.FDUsed,
		FileDescriptorsLimit:         resource.FDLimit,
		ResourcePressureReason:       resource.PressureReason,
		ResourceSampleError:          resource.SampleError,
		ResourceSampledUnixNano:      qualificationWANReadWaitUnixNano(resource.SampledAt),
		ResourceNextSampleUnixNano:   qualificationWANReadWaitUnixNano(resource.NextSampleAt),
		ResourceLastGoodUnixNano:     qualificationWANReadWaitUnixNano(resource.LastGoodSampleAt),
	}
	manager.mu.Unlock()
	result.ObservedUnixNano = time.Now().UnixNano()
	return result, nil
}

func (owner *qualificationWANReadWaitTraceOwner) serveServerCapacityHTTP(w http.ResponseWriter, r *http.Request, app *App) {
	if !qualificationWANReadWaitAuthorized(owner, r) {
		http.Error(w, "WAN read-wait trace authorization failed", http.StatusUnauthorized)
		return
	}
	if r.URL.Query().Get("wan_read_wait_server_capacity") != "1" {
		http.Error(w, "invalid WAN read-wait server capacity action", http.StatusBadRequest)
		return
	}
	sequence := r.URL.Query().Get("sequence")
	owner.mu.Lock()
	_, configured := owner.captures[sequence]
	finalized := owner.finalized
	owner.mu.Unlock()
	if !configured || finalized {
		http.Error(w, "WAN read-wait server capacity sequence is unavailable", http.StatusConflict)
		return
	}
	snapshot, err := qualificationWANReadWaitServerCapacity(app, sequence)
	if err != nil {
		http.Error(w, err.Error(), http.StatusServiceUnavailable)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(snapshot)
}

func (owner *qualificationWANReadWaitTraceOwner) serveHTTP(w http.ResponseWriter, r *http.Request) {
	if !qualificationWANReadWaitAuthorized(owner, r) {
		http.Error(w, "WAN read-wait trace authorization failed", http.StatusUnauthorized)
		return
	}
	sequence := r.URL.Query().Get("sequence")
	if !qualificationWANSequenceValid(sequence) {
		http.Error(w, "invalid WAN read-wait trace sequence", http.StatusBadRequest)
		return
	}
	action := r.URL.Query().Get("wan_read_wait_trace")
	var snapshot qualificationWANReadWaitCaptureSnapshot
	var err error
	switch action {
	case "start":
		snapshot, err = owner.start(sequence)
	case "stop":
		snapshot, err = owner.stop(r.Context(), sequence)
	default:
		err = errors.New("invalid WAN read-wait trace action")
	}
	status := http.StatusOK
	if err != nil {
		status = http.StatusConflict
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	owner.mu.Lock()
	violations := append([]string(nil), owner.violations...)
	violationLimit := owner.violationLimit
	owner.mu.Unlock()
	_ = json.NewEncoder(w).Encode(map[string]any{
		"action": action, "capture": snapshot, "error": qualificationWANReadWaitErrorText(err),
		"owner_violations": violations, "owner_violation_overflow": violationLimit,
	})
}

func (owner *qualificationWANReadWaitTraceOwner) finalize() error {
	owner.controlMu.Lock()
	defer owner.controlMu.Unlock()
	owner.mu.Lock()
	if owner.finalized {
		owner.mu.Unlock()
		return errors.New("WAN read-wait trace owner was finalized more than once")
	}
	owner.finalized = true
	activeSequence := owner.activeSequence
	if activeSequence != "" {
		owner.addIssueLocked(owner.captures[activeSequence], "cleanup triggered trace stop")
	}
	owner.mu.Unlock()
	if activeSequence != "" {
		_, _ = owner.stopControlLocked(context.Background(), activeSequence)
	}

	owner.mu.Lock()
	defer owner.mu.Unlock()
	var invalid []string
	for _, sequence := range owner.sequences {
		capture := owner.captures[sequence]
		if capture.State == "pending" || capture.State == "starting" || capture.State == "active" || capture.State == "stopping" {
			owner.addIssueLocked(capture, "configured trace target was not completed")
			capture.State = "invalid"
		}
		if !owner.snapshotLocked(capture).Valid {
			invalid = append(invalid, sequence)
		}
	}
	if len(owner.violations) != 0 || owner.violationLimit {
		return fmt.Errorf("WAN read-wait trace owner violations: %s", strings.Join(owner.violations, ","))
	}
	if len(invalid) != 0 {
		return fmt.Errorf("invalid or missing WAN read-wait trace sequences: %s", strings.Join(invalid, ","))
	}
	return nil
}
