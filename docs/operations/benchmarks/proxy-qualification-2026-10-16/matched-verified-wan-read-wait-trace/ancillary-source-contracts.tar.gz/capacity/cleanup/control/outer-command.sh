#!/usr/bin/env bash
set -uo pipefail
proposal=/home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-read-wait-source/review/cleanup-status-proposal
run_dir=$proposal/runs/revision-2-contract-1
contract=$proposal/cleanup-status-contract.sh
output=$run_dir/contract-output
[[ ! -e $output ]] || { echo "contract output already exists" >&2; exit 2; }
date -u +%Y-%m-%dT%H:%M:%S.%NZ > "$run_dir/start.utc"
python3 - <<'PY' > "$run_dir/start.unix-nano"
import time
print(time.time_ns())
PY
sha256sum \
  "$proposal/SHA256SUMS.txt" \
  "$proposal/CHECKPOINT.json" \
  "$proposal/cleanup-status-contract.sh" \
  "$proposal/owned-group-holder.py" \
  "$proposal/PROPOSED-CLEANUP.sh" \
  "$proposal/cleanup-status.patch" \
  /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-read-wait-source/generated/qualify-proxy-agent-growth-wan-read-wait.sh \
  > "$run_dir/source-hashes.before.txt"
printf '%q ' "$contract" "$output" > "$run_dir/direct.invocation.txt"
printf '\n' >> "$run_dir/direct.invocation.txt"
set +e
"$contract" "$output" > "$run_dir/direct.stdout.log" 2> "$run_dir/direct.stderr.log"
direct_status=$?
set -e
printf '%s\n' "$direct_status" > "$run_dir/direct.status"
date -u +%Y-%m-%dT%H:%M:%S.%NZ > "$run_dir/end.utc"
python3 - <<'PY' > "$run_dir/end.unix-nano"
import time
print(time.time_ns())
PY
if [[ -d $output ]]; then
  find "$output" -type f -print0 | LC_ALL=C sort -z | xargs -0 -r sha256sum > "$run_dir/output-hashes.txt"
else
  : > "$run_dir/output-hashes.txt"
fi
sha256sum \
  "$proposal/SHA256SUMS.txt" \
  "$proposal/CHECKPOINT.json" \
  "$proposal/cleanup-status-contract.sh" \
  "$proposal/owned-group-holder.py" \
  "$proposal/PROPOSED-CLEANUP.sh" \
  "$proposal/cleanup-status.patch" \
  /home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-read-wait-source/generated/qualify-proxy-agent-growth-wan-read-wait.sh \
  > "$run_dir/source-hashes.after.txt"
cmp -s "$run_dir/source-hashes.before.txt" "$run_dir/source-hashes.after.txt"
hash_compare_status=$?
printf '%s\n' "$hash_compare_status" > "$run_dir/source-hashes-compare.status"
python3 - "$run_dir/run-result.json" "$direct_status" "$hash_compare_status" <<'PY'
import json, pathlib, sys
out, direct, source_compare = sys.argv[1:]
value = {
    "schema_version": 1,
    "source_only_contract": True,
    "endpoint_processes_started": False,
    "direct_status": int(direct),
    "source_hash_compare_status": int(source_compare),
    "accepted": int(direct) == 0 and int(source_compare) == 0,
}
pathlib.Path(out).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
PY
exit "$direct_status"
