# Contract revision 2

The first contract source is preserved as `cleanup-status-contract-v1.sh`
with SHA-256
`b85af2bde25b85924bf4df0dc72a664b2a5c58c27845f3ab1b8399c1af06e0f0`.
Its checkpoint and manifest are preserved as `CHECKPOINT-v1.json` and
`SHA256SUMS-v1.txt`.

Revision 1 was rejected before execution for three source defects:

- the holder created an empty readiness file while the harness required a
  nonempty file;
- readiness was checked before installing the cleanup trap, permitting a
  failed setup to bypass owned-group cleanup;
- nested `bash` and `sleep` processes made TERM status and zombie process-group
  interpretation ambiguous.

Revision 2 uses one finite Python process per owned group. It writes nonempty
readiness, exits with status 23 on TERM in the responsive case, ignores TERM in
the KILL case, and exits by itself after at most ten seconds. The harness
registers the PID and installs the cleanup trap before waiting for readiness.
No revision of the contract has been executed.
