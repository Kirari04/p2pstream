#!/usr/bin/env bash
set +e
run_dir=/home/user/.codex/worktrees/astra-proxy-performance/p2pstream/tmp/continuation-20261016/wan-read-wait-source/review/cleanup-status-proposal/runs/revision-2-contract-1
bash "$run_dir/outer-command.sh" > "$run_dir/outer.stdout.log" 2> "$run_dir/outer.stderr.log"
outer_status=$?
printf '%s\n' "$outer_status" > "$run_dir/outer.status"
printf 'CLEANUP_CONTRACT_OUTER_STATUS=%s RESULT=%s\n' "$outer_status" "$run_dir/run-result.json" | tee "$run_dir/final-marker.txt"
exit "$outer_status"
