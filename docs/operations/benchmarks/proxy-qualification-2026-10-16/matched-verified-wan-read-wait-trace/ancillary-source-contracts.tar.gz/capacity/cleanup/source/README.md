# Owned-group cleanup status proposal

This source-only proposal is based on the generated runner used by
`tiny-read-wait-smoke-2`, SHA-256
`127da1ef1f1a8923fa00b218bf8458cb83f67f8c2b97f5fb2a353162c4624ed6`.
It is not applied to the live generated runner.

The patch preserves the existing cleanup sequence and bounds:

1. touch all endpoint stop files;
2. send `TERM` to every still-live owned process group;
3. poll all owned groups together 50 times at 100 ms;
4. send `KILL` to every remaining group;
5. wait for every owned leader.

For every group still registered at cleanup, the proposal writes a
`process-exit` lifecycle record containing its label and PID, exact `wait`
status, whether `TERM` and `KILL` were attempted and each command status, and
the final process-group probe status/existence. Forced signaling, a nonzero
wait status, or a residual group invalidates success. Exact wait statuses are
kept in the record; the runner's original nonzero exit remains unchanged.

`cleanup-status-contract.sh` is a bounded no-endpoint contract source. It has
not been executed. It uses disposable process groups only and checks a
TERM-responsive group and a TERM-resistant group that reaches the unchanged
KILL boundary.
