#!/usr/bin/env bash
set -Eeuo pipefail

proposal_dir=$(cd "$(dirname "$0")" && pwd)
source "$proposal_dir/PROPOSED-CLEANUP.sh"

[[ $# == 1 ]] || { echo "usage: cleanup-status-contract.sh OUTPUT" >&2; exit 2; }
output=$(realpath -m "$1")
[[ ! -e $output ]] || { echo "output already exists: $output" >&2; exit 2; }
mkdir -m 0700 "$output"

run_case() {
  local name=$1 mode=$2 expected_wait=$3 expected_kill=$4 case_dir=$output/$name
  mkdir -m 0700 "$case_dir"
  set +e
  timeout --signal=TERM --kill-after=2s 12s bash -c '
    set -Eeuo pipefail
    source "$1"
    case_dir=$2 mode=$3
    declare -A owned_groups=()
    stops=()
    lifecycle_output=$case_dir/lifecycle.jsonl
    : > "$lifecycle_output"
    if [[ $mode == term ]]; then
      setsid bash -c '\''trap "exit 23" TERM; touch "$1"; while :; do sleep .05; done'\'' bash "$case_dir/ready" &
    else
      setsid bash -c '\''trap "" TERM; touch "$1"; while :; do sleep .05; done'\'' bash "$case_dir/ready" &
    fi
    pid=$!
    printf "%s\n" "$pid" > "$case_dir/owned.pid"
    owned_groups[$pid]=$mode
    for _ in $(seq 1 200); do [[ -s $case_dir/ready ]] && break; kill -0 "$pid" 2>/dev/null || break; sleep .01; done
    [[ -s $case_dir/ready ]]
    trap cleanup EXIT
    exit 0
  ' bash "$proposal_dir/PROPOSED-CLEANUP.sh" "$case_dir" "$mode"
  case_status=$?
  set -e
  printf '%s\n' "$case_status" > "$case_dir/caller.status"
  pid=$(<"$case_dir/owned.pid")
  residual=false
  if kill -0 -- "-$pid" 2>/dev/null; then
    residual=true
    kill -KILL -- "-$pid" 2>/dev/null || true
    for _ in $(seq 1 100); do
      kill -0 -- "-$pid" 2>/dev/null || break
      sleep .01
    done
  fi
  printf '%s\n' "$residual" > "$case_dir/contract-residual-cleanup-required"
  [[ $residual == false ]]
  ((case_status == 1))
  jq -e --arg label "$mode" --argjson expected_wait "$expected_wait" --argjson expected_kill "$expected_kill" '
    select(.event == "process-exit") |
    .cleanup == true and .label == $label and .status == $expected_wait and
    .forced == true and .term == {attempted:true,status:0} and
    .kill.attempted == $expected_kill and
    (if $expected_kill then .kill.status == 0 else .kill.status == null end) and
    .final_group_probe_status != 0 and .final_group_exists == false and
    .group_joined == true and .invalidates_success == true
  ' "$case_dir/lifecycle.jsonl" >/dev/null
  [[ $(jq -s '[.[] | select(.event == "process-exit")] | length' "$case_dir/lifecycle.jsonl") == 1 ]]
  [[ $(jq -s '[.[] | select(.event == "forced-cleanup" and .invalidates_success == true)] | length' "$case_dir/lifecycle.jsonl") == 1 ]]
}

run_case term term 23 false
run_case kill kill 137 true
printf '{"schema_version":1,"accepted":true,"endpoint_processes_started":false,"cases":["term","kill"]}\n' > "$output/summary.json"
