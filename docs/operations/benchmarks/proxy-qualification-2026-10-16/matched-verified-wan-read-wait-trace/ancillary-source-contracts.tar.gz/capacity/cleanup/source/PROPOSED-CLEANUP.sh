cleanup() {
  local original_status=$? forced=0 invalid=0 pid attempt live label
  local wait_status final_probe_status term_status kill_status record_status
  local term_attempted kill_attempted final_group_exists group_forced invalidates
  local -A cleanup_term_attempted=() cleanup_term_status=()
  local -A cleanup_kill_attempted=() cleanup_kill_status=()
  trap - EXIT INT TERM
  for stop in "${stops[@]:-}"; do [[ -n $stop ]] && touch "$stop"; done
  for pid in "${!owned_groups[@]}"; do
    cleanup_term_attempted[$pid]=false
    cleanup_term_status[$pid]=null
    cleanup_kill_attempted[$pid]=false
    cleanup_kill_status[$pid]=null
    if kill -0 -- "-$pid" 2>/dev/null; then
      forced=1
      cleanup_term_attempted[$pid]=true
      set +e
      kill -TERM -- "-$pid" 2>/dev/null
      cleanup_term_status[$pid]=$?
      set -e
    fi
  done
  for ((attempt=0; attempt<50; attempt++)); do
    live=0
    for pid in "${!owned_groups[@]}"; do kill -0 -- "-$pid" 2>/dev/null && live=1; done
    ((live)) || break
    sleep .1
  done
  for pid in "${!owned_groups[@]}"; do
    if kill -0 -- "-$pid" 2>/dev/null; then
      forced=1
      cleanup_kill_attempted[$pid]=true
      set +e
      kill -KILL -- "-$pid" 2>/dev/null
      cleanup_kill_status[$pid]=$?
      set -e
    fi
    set +e
    wait "$pid" 2>/dev/null
    wait_status=$?
    kill -0 -- "-$pid" 2>/dev/null
    final_probe_status=$?
    set -e
    term_attempted=${cleanup_term_attempted[$pid]}
    term_status=${cleanup_term_status[$pid]}
    kill_attempted=${cleanup_kill_attempted[$pid]}
    kill_status=${cleanup_kill_status[$pid]}
    final_group_exists=false
    ((final_probe_status == 0)) && final_group_exists=true
    group_forced=false
    [[ $term_attempted == true || $kill_attempted == true ]] && group_forced=true
    invalidates=false
    if [[ $group_forced == true || $final_group_exists == true ]] || ((wait_status != 0)); then
      invalidates=true
      invalid=1
    fi
    label=${owned_groups[$pid]}
    set +e
    jq -cn --arg label "$label" --argjson pid "$pid" --argjson status "$wait_status" \
      --argjson forced "$group_forced" --argjson term_attempted "$term_attempted" \
      --argjson term_status "$term_status" --argjson kill_attempted "$kill_attempted" \
      --argjson kill_status "$kill_status" --argjson final_probe_status "$final_probe_status" \
      --argjson final_group_exists "$final_group_exists" --argjson invalidates "$invalidates" \
      '{event:"process-exit",cleanup:true,label:$label,pid:$pid,status:$status,forced:$forced,
        term:{attempted:$term_attempted,status:$term_status},
        kill:{attempted:$kill_attempted,status:$kill_status},
        final_group_probe_status:$final_probe_status,group_joined:($final_group_exists|not),
        final_group_exists:$final_group_exists,invalidates_success:$invalidates}' \
      >> "${lifecycle_output:-/dev/null}"
    record_status=$?
    set -e
    if ((record_status != 0)); then
      invalid=1
      printf 'failed to retain cleanup lifecycle for %s pid %s (status %s)\n' "$label" "$pid" "$record_status" >&2
    fi
  done
  if ((forced)); then
    printf '{"event":"forced-cleanup","invalidates_success":true}\n' >> "${lifecycle_output:-/dev/null}"
  fi
  if ((forced || invalid)); then
    ((original_status != 0)) || original_status=1
  fi
  exit "$original_status"
}
