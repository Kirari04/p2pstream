cleanup() {
  local original_status=$? forced=0 pid attempt live
  trap - EXIT INT TERM
  for stop in "${stops[@]:-}"; do [[ -n $stop ]] && touch "$stop"; done
  for pid in "${!owned_groups[@]}"; do
    if kill -0 -- "-$pid" 2>/dev/null; then
      forced=1
      kill -TERM -- "-$pid" 2>/dev/null || true
    fi
  done
  for ((attempt=0; attempt<50; attempt++)); do
    live=0
    for pid in "${!owned_groups[@]}"; do kill -0 -- "-$pid" 2>/dev/null && live=1; done
    ((live)) || break
    sleep .1
  done
  for pid in "${!owned_groups[@]}"; do
    if kill -0 -- "-$pid" 2>/dev/null; then
      forced=1
      kill -KILL -- "-$pid" 2>/dev/null || true
    fi
    wait "$pid" 2>/dev/null || true
  done
  if ((forced)); then
    printf '{"event":"forced-cleanup","invalidates_success":true}\n' >> "${lifecycle_output:-/dev/null}"
    ((original_status != 0)) || original_status=1
  fi
  exit "$original_status"
}
