#!/usr/bin/env python3
import argparse
import pathlib
import signal
import time


parser = argparse.ArgumentParser()
parser.add_argument("--mode", choices=("term", "kill"), required=True)
parser.add_argument("--ready", required=True)
parser.add_argument("--maximum-seconds", type=float, required=True)
args = parser.parse_args()

if args.maximum_seconds <= 0 or args.maximum_seconds > 10:
    raise SystemExit("maximum-seconds must be in (0, 10]")

if args.mode == "term":
    def terminate(_signal, _frame):
        raise SystemExit(23)
    signal.signal(signal.SIGTERM, terminate)
else:
    signal.signal(signal.SIGTERM, signal.SIG_IGN)

ready = pathlib.Path(args.ready)
with ready.open("x", encoding="utf-8") as stream:
    stream.write("ready\n")

deadline = time.monotonic() + args.maximum_seconds
while time.monotonic() < deadline:
    time.sleep(min(0.05, max(0.0, deadline - time.monotonic())))
raise SystemExit(24)
