#!/usr/bin/env python3
import json
import pathlib
import subprocess
import sys


if len(sys.argv) != 2:
    raise SystemExit("usage: run-traced-transfer-contracts.py FRESH_OUTPUT_DIRECTORY")
root = pathlib.Path(__file__).resolve().parents[1]
runner = root / "generated/qualify-proxy-agent-growth-wan-read-wait.sh"
output = pathlib.Path(sys.argv[1])
output.mkdir(parents=True, exist_ok=False)
text = runner.read_text()
start = text.index("wan_read_wait_should_trace() {")
end = text.index("\nrun_tiny_response() {", start)
functions = text[start:end]


def run_case(name, pre_bad, capacity_bad, transfer_status, expected_status, expected_sequence, expected_stop_count, expected_capacity_count, success):
    case = output / name
    case.mkdir()
    harness = case / "harness.sh"
    harness.write_text("""#!/usr/bin/env bash
set -Eeuo pipefail
sequence=8
smoke_mode=0
read_wait_control_dir=$1/control
read_wait_trace_records=$1/records.jsonl
mkdir -p "$read_wait_control_dir"
: > "$read_wait_trace_records"
stop_count=0
start_count=0
capacity_count=0
trap_seen_by_stop=0
trap_log=$1/outer-exit-trap.log
result_path=$1/result.json
internal_after_failure=$1/internal-after-failure
outer_after_call=$1/outer-after-call
finish() {
  local status=$?
  trap - EXIT INT TERM ERR
  jq -cn --argjson status "$status" --argjson sequence "$sequence" --argjson starts "$start_count" --argjson stops "$stop_count" \
    --argjson capacity_count "$capacity_count" --argjson trap_seen_by_stop "$trap_seen_by_stop" --slurpfile records "$read_wait_trace_records" \
    '{status:$status,sequence:$sequence,start_count:$starts,stop_count:$stops,capacity_count:$capacity_count,trap_seen_by_stop:$trap_seen_by_stop,records:$records}' > "$result_path"
  printf x >> "$trap_log"
  exit "$status"
}
trap finish EXIT
query_server_json() {
  printf '%s\\n' '{"heap_alloc_bytes":1,"agent_tunnels":[]}'
}
cgroup_snapshot() {
  if [[ ${PRE_BAD:-0} == 1 ]]; then
    PRE_BAD=0
    printf '%s\\n' '{"cgroup_path":"/expected.scope","memory_max_bytes":1,"memory_swap_max_bytes":0,"memory_events":{"high":0,"max":0,"oom":0,"oom_kill":0,"oom_group_kill":0}}'
  else
    printf '%s\\n' '{"cgroup_path":"/expected.scope","memory_max_bytes":4294967296,"memory_swap_max_bytes":0,"memory_events":{"high":0,"max":0,"oom":0,"oom_kill":0,"oom_group_kill":0}}'
  fi
}
wan_read_wait_server_capacity() {
  local target=$1 server=$2 destination=$3 reject=false
  capacity_count=$((capacity_count + 1))
  if [[ ${CAPACITY_BAD:-0} == 1 && $capacity_count == 1 ]]; then reject=true; fi
  jq -n --arg sequence "$target" --argjson reject "$reject" '{
    schema_version:1,sequence:$sequence,request_started_unix_ns:100,request_elapsed_ns:10,http_status:200,error:"",
    response:{schema_version:1,sequence:$sequence,observed_unix_ns:300,generation:1,adaptive:true,
      adaptive_admission_role:"server_stream",adaptive_admission_limit:40,adaptive_raw_admission_limit:50,
      adaptive_public_admission_limit:30,reject_new:$reject,memory_pressure:"healthy",memory_used_bytes:100,
      memory_limit_bytes:2147483648,memory_source:"cgroup_v2",memory_headroom_to_hard_bytes:1000,
      file_descriptors_used:10,file_descriptors_limit:100,resource_pressure_reason:"memory",
      resource_sample_error:"",resource_sampled_unix_ns:200,resource_next_sample_unix_ns:400,
      resource_last_good_unix_ns:200}}
  ' > "$destination"
}
wan_read_wait_control() {
  local action=$1 target=$2 server=$3 destination=$4
  if [[ $action == start ]]; then
    start_count=$((start_count + 1))
    printf '{"action":"start","sequence":"%s","http_status":200,"error":"","response":{"capture":{"sequence":"%s","state":"active","complete":false,"valid":false}}}\\n' "$target" "$target" > "$destination"
  else
    stop_count=$((stop_count + 1))
    [[ ! -e $trap_log ]] || trap_seen_by_stop=1
    printf '{"action":"stop","sequence":"%s","http_status":200,"error":"","response":{"capture":{"sequence":"%s","state":"complete"}}}\\n' "$target" "$target" > "$destination"
  fi
}
run_transfer() {
  sequence=$((sequence + 1))
  ( exit "${TRANSFER_STATUS:-0}" )
  printf forbidden > "$internal_after_failure"
}
""" + functions + """
run_maybe_traced_transfer label aggregate-v1 101 https://public.test http://admin 202 http://agent retained-warmup download 268435456 1
printf reached > "$outer_after_call"
""")
    harness.chmod(0o755)
    env = {"PATH": "/usr/bin:/bin", "PRE_BAD": "1" if pre_bad else "0",
           "CAPACITY_BAD": "1" if capacity_bad else "0", "TRANSFER_STATUS": str(transfer_status)}
    result = subprocess.run([str(harness), str(case)], text=True, capture_output=True, env=env)
    assert result.returncode == expected_status, (name, result.returncode, result.stdout, result.stderr)
    assert (case / "outer-exit-trap.log").read_text() == "x", (name, "outer trap did not run exactly once")
    value = json.loads((case / "result.json").read_text())
    assert value["status"] == expected_status, (name, value)
    assert value["sequence"] == expected_sequence, (name, value)
    assert value["stop_count"] == expected_stop_count, (name, value)
    assert value["capacity_count"] == expected_capacity_count, (name, value)
    assert value["trap_seen_by_stop"] == 0, (name, value)
    assert len(value["records"]) == 1, (name, value)
    assert (case / "outer-after-call").exists() is success, name
    assert (case / "internal-after-failure").exists() is success, name
    return value


successful_transfer = run_case("transfer-success", False, False, 0, 0, 9, 1, 2, True)
assert successful_transfer["records"][0]["valid"] is True
assert successful_transfer["records"][0]["pre_server_capacity"]["memory_limit_bytes"] == 2 << 30
failed_transfer = run_case("transfer-failure-still-stops", False, False, 37, 37, 9, 1, 2, False)
record = failed_transfer["records"][0]
assert record["transfer_status"] == 37 and record["stop_status"] == 0
assert record["complete"] is True and record["valid"] is False
pre_resource = run_case("pre-resource-failure-preserved", True, False, 0, 1, 8, 0, 1, False)
record = pre_resource["records"][0]
assert record["pre_cgroup"]["memory_max_bytes"] == 1
assert record["pre_resource_status"] != 0 and record["pre_healthy_status"] == 0
assert record["complete"] is False and record["valid"] is False
pre_capacity = run_case("pre-capacity-reject-new", False, True, 0, 1, 8, 0, 1, False)
record = pre_capacity["records"][0]
assert record["pre_resource_status"] == 0 and record["pre_healthy_status"] != 0
assert record["pre_server_capacity"]["reject_new"] is True
assert record["complete"] is False and record["valid"] is False
print("traced transfer contracts passed")
