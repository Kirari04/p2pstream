#!/usr/bin/env bash
set -Eeuo pipefail
exec ./contracts/run-all-no-traffic-contracts.sh ./review/capacity-no-traffic-contracts-attempt-1
