#!/usr/bin/env bash
set -Eeuo pipefail
sequence=8
smoke_mode=0
read_wait_control_dir=$1/control
read_wait_trace_records=$1/records.jsonl
mkdir -p "$read_wait_control_dir"
: > "$read_wait_trace_records"
stop_count=0
start_count=0
capacity_count=0
trap_seen_by_stop=0
trap_log=$1/outer-exit-trap.log
result_path=$1/result.json
internal_after_failure=$1/internal-after-failure
outer_after_call=$1/outer-after-call
finish() {
  local status=$?
  trap - EXIT INT TERM ERR
  jq -cn --argjson status "$status" --argjson sequence "$sequence" --argjson starts "$start_count" --argjson stops "$stop_count"     --argjson capacity_count "$capacity_count" --argjson trap_seen_by_stop "$trap_seen_by_stop" --slurpfile records "$read_wait_trace_records"     '{status:$status,sequence:$sequence,start_count:$starts,stop_count:$stops,capacity_count:$capacity_count,trap_seen_by_stop:$trap_seen_by_stop,records:$records}' > "$result_path"
  printf x >> "$trap_log"
  exit "$status"
}
trap finish EXIT
query_server_json() {
  printf '%s\n' '{"heap_alloc_bytes":1,"agent_tunnels":[]}'
}
cgroup_snapshot() {
  if [[ ${PRE_BAD:-0} == 1 ]]; then
    PRE_BAD=0
    printf '%s\n' '{"cgroup_path":"/expected.scope","memory_max_bytes":1,"memory_swap_max_bytes":0,"memory_events":{"high":0,"max":0,"oom":0,"oom_kill":0,"oom_group_kill":0}}'
  else
    printf '%s\n' '{"cgroup_path":"/expected.scope","memory_max_bytes":4294967296,"memory_swap_max_bytes":0,"memory_events":{"high":0,"max":0,"oom":0,"oom_kill":0,"oom_group_kill":0}}'
  fi
}
wan_read_wait_server_capacity() {
  local target=$1 server=$2 destination=$3 reject=false
  capacity_count=$((capacity_count + 1))
  if [[ ${CAPACITY_BAD:-0} == 1 && $capacity_count == 1 ]]; then reject=true; fi
  jq -n --arg sequence "$target" --argjson reject "$reject" '{
    schema_version:1,sequence:$sequence,request_started_unix_ns:100,request_elapsed_ns:10,http_status:200,error:"",
    response:{schema_version:1,sequence:$sequence,observed_unix_ns:300,generation:1,adaptive:true,
      adaptive_admission_role:"server_stream",adaptive_admission_limit:40,adaptive_raw_admission_limit:50,
      adaptive_public_admission_limit:30,reject_new:$reject,memory_pressure:"healthy",memory_used_bytes:100,
      memory_limit_bytes:2147483648,memory_source:"cgroup_v2",memory_headroom_to_hard_bytes:1000,
      file_descriptors_used:10,file_descriptors_limit:100,resource_pressure_reason:"memory",
      resource_sample_error:"",resource_sampled_unix_ns:200,resource_next_sample_unix_ns:400,
      resource_last_good_unix_ns:200}}
  ' > "$destination"
}
wan_read_wait_control() {
  local action=$1 target=$2 server=$3 destination=$4
  if [[ $action == start ]]; then
    start_count=$((start_count + 1))
    printf '{"action":"start","sequence":"%s","http_status":200,"error":"","response":{"capture":{"sequence":"%s","state":"active","complete":false,"valid":false}}}\n' "$target" "$target" > "$destination"
  else
    stop_count=$((stop_count + 1))
    [[ ! -e $trap_log ]] || trap_seen_by_stop=1
    printf '{"action":"stop","sequence":"%s","http_status":200,"error":"","response":{"capture":{"sequence":"%s","state":"complete"}}}\n' "$target" "$target" > "$destination"
  fi
}
run_transfer() {
  sequence=$((sequence + 1))
  ( exit "${TRANSFER_STATUS:-0}" )
  printf forbidden > "$internal_after_failure"
}
wan_read_wait_should_trace() {
	local target_sequence=$1 stage=$2 direction=$3 repetition=$4
	[[ $direction == download ]] || return 1
	if ((smoke_mode)); then
		case "$target_sequence:$stage:$repetition" in
			9:retained-warmup:1|11:steady:1|13:reuse-probe:1) return 0 ;;
		esac
	else
		case "$target_sequence:$stage:$repetition" in
			9:retained-warmup:1|11:steady:1|14:steady:2|15:steady:3) return 0 ;;
		esac
	fi
	return 1
}

run_maybe_traced_transfer() {
	local stage=$8 direction=$9 repetition=${11}
	local target_sequence=$((sequence + 1))
	if ! wan_read_wait_should_trace "$target_sequence" "$stage" "$direction" "$repetition"; then
		run_transfer "$@"
		return
	fi

	local prefix=$read_wait_control_dir/sequence-$target_sequence
	local pre_runtime pre_cgroup pre_runtime_raw pre_cgroup_raw pre_capacity post_runtime post_cgroup post_capacity
	local pre_runtime_status=0 pre_cgroup_status=0 pre_capacity_query_status=0 pre_resource_status=0 pre_healthy_status=1
	local post_runtime_status=0 post_cgroup_status=0 post_capacity_query_status=0 post_healthy_status=1
	local start_status=0 transfer_status=0 stop_status=0 resource_status=0
	set +e
	pre_runtime_raw=$(query_server_json "$5")
	pre_runtime_status=$?
	pre_cgroup_raw=$(cgroup_snapshot "$3")
	pre_cgroup_status=$?
	wan_read_wait_server_capacity "$target_sequence" "$5" "$prefix-pre-capacity.json"
	pre_capacity_query_status=$?
	set -e
	pre_runtime=$pre_runtime_raw
	pre_cgroup=$pre_cgroup_raw
	pre_capacity=$(jq -c '.response // {}' "$prefix-pre-capacity.json" 2>/dev/null || printf '{}')
	[[ $pre_runtime_status == 0 ]] || pre_runtime='{}'
	[[ $pre_cgroup_status == 0 ]] || pre_cgroup='{}'
	if ((pre_runtime_status != 0 || pre_cgroup_status != 0 || pre_capacity_query_status != 0)); then
		jq -cn --argjson sequence "$target_sequence" --arg stage "$stage" --arg direction "$direction" \
			--argjson repetition "$repetition" --argjson pre_runtime_status "$pre_runtime_status" \
			--argjson pre_cgroup_status "$pre_cgroup_status" --argjson pre_capacity_query_status "$pre_capacity_query_status" \
			--arg pre_runtime_raw "$pre_runtime_raw" --arg pre_cgroup_raw "$pre_cgroup_raw" --argjson pre_capacity "$pre_capacity" \
			--slurpfile pre_capacity_request "$prefix-pre-capacity.json" \
			'{schema_version:1,sequence:$sequence,stage:$stage,direction:$direction,repetition:$repetition,
			  control_boundary:"start-before-run_transfer-stop-after-run_transfer-including-postqueries",
			  handler_region_boundary:"unchanged-public-proxy-handler-only",pre_runtime_status:$pre_runtime_status,
			  pre_cgroup_status:$pre_cgroup_status,pre_capacity_query_status:$pre_capacity_query_status,
			  pre_runtime_raw:$pre_runtime_raw,pre_cgroup_raw:$pre_cgroup_raw,pre_server_capacity:$pre_capacity,
			  pre_capacity_request:($pre_capacity_request[0] // null),
			  complete:false,valid:false}' >> "$read_wait_trace_records"
		return 1
	fi
	set +e
	jq -e '
		.memory_max_bytes == 4294967296 and .memory_swap_max_bytes == 0 and
		([.memory_events.high,.memory_events.max,.memory_events.oom,.memory_events.oom_kill,.memory_events.oom_group_kill] | all(. == 0))
	' <<<"$pre_cgroup" >/dev/null
	pre_resource_status=$?
	jq -e --arg sequence "$target_sequence" '
		.schema_version == 1 and .sequence == $sequence and .adaptive == true and
		.adaptive_admission_role == "server_stream" and .reject_new == false and
		.memory_pressure == "healthy" and .resource_sample_error == "" and
		.memory_source == "cgroup_v2" and .memory_limit_bytes > 0 and
		.memory_used_bytes >= 0 and .memory_used_bytes <= .memory_limit_bytes and
		.memory_headroom_to_hard_bytes >= 0 and .file_descriptors_limit > 0 and
		.file_descriptors_used >= 0 and .file_descriptors_used <= .file_descriptors_limit and
		(.resource_pressure_reason | type == "string" and length > 0) and
		.generation > 0 and .resource_sampled_unix_ns > 0 and .resource_last_good_unix_ns > 0 and
		.observed_unix_ns >= .resource_sampled_unix_ns and .observed_unix_ns >= .resource_last_good_unix_ns and
		.resource_next_sample_unix_ns >= .resource_sampled_unix_ns and
		.adaptive_raw_admission_limit >= 0 and .adaptive_admission_limit >= 0 and
		.adaptive_public_admission_limit >= 0 and
		.adaptive_admission_limit <= .adaptive_raw_admission_limit and
		.adaptive_public_admission_limit <= .adaptive_admission_limit
	' <<<"$pre_capacity" >/dev/null
	pre_healthy_status=$?
	set -e
	if ((pre_resource_status != 0 || pre_healthy_status != 0)); then
		jq -cn --argjson sequence "$target_sequence" --arg stage "$stage" --arg direction "$direction" \
			--argjson repetition "$repetition" --argjson pre_runtime "$pre_runtime" --argjson pre_cgroup "$pre_cgroup" \
			--argjson pre_runtime_status "$pre_runtime_status" --argjson pre_cgroup_status "$pre_cgroup_status" \
			--argjson pre_capacity "$pre_capacity" --argjson pre_capacity_query_status "$pre_capacity_query_status" \
			--argjson pre_resource_status "$pre_resource_status" --argjson pre_healthy_status "$pre_healthy_status" \
			--slurpfile pre_capacity_request "$prefix-pre-capacity.json" \
			'{schema_version:1,sequence:$sequence,stage:$stage,direction:$direction,repetition:$repetition,
			  control_boundary:"start-before-run_transfer-stop-after-run_transfer-including-postqueries",
			  handler_region_boundary:"unchanged-public-proxy-handler-only",pre_runtime:$pre_runtime,pre_cgroup:$pre_cgroup,
			  pre_runtime_status:$pre_runtime_status,pre_cgroup_status:$pre_cgroup_status,
			  pre_server_capacity:$pre_capacity,pre_capacity_query_status:$pre_capacity_query_status,
			  pre_capacity_request:($pre_capacity_request[0] // null),
			  pre_resource_status:$pre_resource_status,pre_healthy_status:$pre_healthy_status,
			  complete:false,valid:false}' >> "$read_wait_trace_records"
		return 1
	fi

	set +e
	wan_read_wait_control start "$target_sequence" "$5" "$prefix-start.json"
	start_status=$?
	set -e
	if ((start_status != 0)); then
		jq -cn --argjson sequence "$target_sequence" --arg stage "$stage" --arg direction "$direction" \
			--argjson repetition "$repetition" --argjson pre_runtime "$pre_runtime" --argjson pre_cgroup "$pre_cgroup" \
			--argjson pre_capacity "$pre_capacity" --argjson pre_capacity_query_status "$pre_capacity_query_status" \
			--argjson start_status "$start_status" --argjson pre_resource_status "$pre_resource_status" \
			--argjson pre_healthy_status "$pre_healthy_status" --slurpfile pre_capacity_request "$prefix-pre-capacity.json" \
			--slurpfile start "$prefix-start.json" \
			'{schema_version:1,sequence:$sequence,stage:$stage,direction:$direction,repetition:$repetition,
			  control_boundary:"start-before-run_transfer-stop-after-run_transfer-including-postqueries",
			  handler_region_boundary:"unchanged-public-proxy-handler-only",pre_runtime:$pre_runtime,pre_cgroup:$pre_cgroup,
			  pre_server_capacity:$pre_capacity,pre_capacity_query_status:$pre_capacity_query_status,
			  pre_capacity_request:($pre_capacity_request[0] // null),
			  pre_resource_status:$pre_resource_status,pre_healthy_status:$pre_healthy_status,
			  start_control:($start[0] // null),start_status:$start_status,complete:false,valid:false}' >> "$read_wait_trace_records"
		return "$start_status"
	fi

	# Execute the inherited function unchanged with errexit active. The subshell
	# isolates only its sequence increment; the parent advances the same fixed
	# counter after preserving the function's exact status and file effects. It
	# must not inherit the outer lifecycle traps; only the parent owns endpoints.
	set +e
	( trap - EXIT INT TERM ERR; set -Eeuo pipefail; run_transfer "$@" )
	transfer_status=$?
	set -e
	sequence=$target_sequence

	set +e
	wan_read_wait_control stop "$target_sequence" "$5" "$prefix-stop.json"
	stop_status=$?
	post_runtime=$(query_server_json "$5")
	post_runtime_status=$?
	post_cgroup=$(cgroup_snapshot "$3")
	post_cgroup_status=$?
	wan_read_wait_server_capacity "$target_sequence" "$5" "$prefix-post-capacity.json"
	post_capacity_query_status=$?
	set -e
	[[ $post_runtime_status == 0 ]] || post_runtime='{}'
	[[ $post_cgroup_status == 0 ]] || post_cgroup='{}'
	post_capacity=$(jq -c '.response // {}' "$prefix-post-capacity.json" 2>/dev/null || printf '{}')

	if ((post_runtime_status == 0 && post_cgroup_status == 0 && post_capacity_query_status == 0)); then
		set +e
		jq -e --argjson before "$pre_cgroup" '
			.memory_max_bytes == 4294967296 and .memory_swap_max_bytes == 0 and
			.cgroup_path == $before.cgroup_path and
			.memory_events.high == $before.memory_events.high and
			.memory_events.max == $before.memory_events.max and
			.memory_events.oom == $before.memory_events.oom and
			.memory_events.oom_kill == $before.memory_events.oom_kill and
			.memory_events.oom_group_kill == $before.memory_events.oom_group_kill
		' <<<"$post_cgroup" >/dev/null
		resource_status=$?
		jq -e --arg sequence "$target_sequence" '
			.schema_version == 1 and .sequence == $sequence and .adaptive == true and
			.adaptive_admission_role == "server_stream" and .reject_new == false and
			.memory_pressure == "healthy" and .resource_sample_error == "" and
			.memory_source == "cgroup_v2" and .memory_limit_bytes > 0 and
			.memory_used_bytes >= 0 and .memory_used_bytes <= .memory_limit_bytes and
			.memory_headroom_to_hard_bytes >= 0 and .file_descriptors_limit > 0 and
			.file_descriptors_used >= 0 and .file_descriptors_used <= .file_descriptors_limit and
			(.resource_pressure_reason | type == "string" and length > 0) and
			.generation > 0 and .resource_sampled_unix_ns > 0 and .resource_last_good_unix_ns > 0 and
			.observed_unix_ns >= .resource_sampled_unix_ns and .observed_unix_ns >= .resource_last_good_unix_ns and
			.resource_next_sample_unix_ns >= .resource_sampled_unix_ns and
			.adaptive_raw_admission_limit >= 0 and .adaptive_admission_limit >= 0 and
			.adaptive_public_admission_limit >= 0 and
			.adaptive_admission_limit <= .adaptive_raw_admission_limit and
			.adaptive_public_admission_limit <= .adaptive_admission_limit
		' <<<"$post_capacity" >/dev/null
		post_healthy_status=$?
		((resource_status == 0 && post_healthy_status == 0)) || resource_status=1
		set -e
	else
		resource_status=1
	fi

	jq -cn --argjson sequence "$target_sequence" --arg stage "$stage" --arg direction "$direction" \
		--argjson repetition "$repetition" --argjson pre_runtime "$pre_runtime" --argjson pre_cgroup "$pre_cgroup" \
		--argjson pre_capacity "$pre_capacity" --argjson post_runtime "$post_runtime" --argjson post_cgroup "$post_cgroup" \
		--argjson post_capacity "$post_capacity" --argjson pre_capacity_query_status "$pre_capacity_query_status" \
		--argjson post_capacity_query_status "$post_capacity_query_status" --argjson post_healthy_status "$post_healthy_status" \
		--argjson pre_resource_status "$pre_resource_status" --argjson pre_healthy_status "$pre_healthy_status" \
		--argjson transfer_status "$transfer_status" --argjson stop_status "$stop_status" \
		--argjson post_runtime_status "$post_runtime_status" --argjson post_cgroup_status "$post_cgroup_status" \
		--argjson resource_status "$resource_status" --slurpfile pre_capacity_request "$prefix-pre-capacity.json" \
		--slurpfile post_capacity_request "$prefix-post-capacity.json" --slurpfile start "$prefix-start.json" --slurpfile stop "$prefix-stop.json" \
		'{schema_version:1,sequence:$sequence,stage:$stage,direction:$direction,repetition:$repetition,
		  control_boundary:"start-before-run_transfer-stop-after-run_transfer-including-postqueries",
		  handler_region_boundary:"unchanged-public-proxy-handler-only",trace_artifact_scope:"whole-server-process",
		  qualification_result:false,pre_runtime:$pre_runtime,pre_cgroup:$pre_cgroup,
		  pre_server_capacity:$pre_capacity,pre_capacity_query_status:$pre_capacity_query_status,
		  pre_capacity_request:($pre_capacity_request[0] // null),post_runtime:$post_runtime,post_cgroup:$post_cgroup,
		  post_server_capacity:$post_capacity,post_capacity_query_status:$post_capacity_query_status,
		  post_capacity_request:($post_capacity_request[0] // null),post_healthy_status:$post_healthy_status,
		  pre_resource_status:$pre_resource_status,pre_healthy_status:$pre_healthy_status,
		  start_control:($start[0] // null),stop_control:($stop[0] // null),transfer_status:$transfer_status,
		  stop_status:$stop_status,post_runtime_status:$post_runtime_status,post_cgroup_status:$post_cgroup_status,
		  resource_status:$resource_status,complete:true,
		  valid:($transfer_status == 0 and $stop_status == 0 and $post_runtime_status == 0 and $post_cgroup_status == 0 and $resource_status == 0)}' \
		>> "$read_wait_trace_records"

	((transfer_status == 0)) || return "$transfer_status"
	((stop_status == 0)) || return "$stop_status"
	((post_runtime_status == 0 && post_cgroup_status == 0 && resource_status == 0)) || return 1
}

run_maybe_traced_transfer label aggregate-v1 101 https://public.test http://admin 202 http://agent retained-warmup download 268435456 1
printf reached > "$outer_after_call"
