#!/usr/bin/env bash
set -Eeuo pipefail

root=$(cd "$(dirname "$0")/.." && pwd)
protocol="$root/../wan-protocol-source"
copy_source="$root/../wan-copy-attribution-source"
monotonic=$(realpath "$root/../wan-copy-monotonic-source")
owned="$root/../current-wan-prep/runner/qualify-proxy-agent-growth-owned.sh"
output=$1
[[ ! -e $output ]] || { echo "output already exists" >&2; exit 2; }
mkdir -p "$output"

bash -n "$root/run-wan-read-wait-diagnostic.sh" "$root/run-wan-read-wait-arm.sh" \
  "$root/generated/qualify-proxy-agent-growth-wan-read-wait.sh" "$root/contracts/run-cleanup-status-contract.sh" \
  "$root/contracts/PROPOSED-CLEANUP.sh"
python3 - "$root" <<'PY'
import ast, pathlib, sys
root = pathlib.Path(sys.argv[1])
for name in ("validate-wan-read-wait-arm.py", "validate-server-scope.py", "validate-server-resource.py",
             "run-capped-trace-parser.py", "contracts/run-arm-validator-contracts.py",
             "contracts/run-server-resource-contracts.py", "contracts/run-traced-transfer-contracts.py",
             "contracts/owned-group-holder.py"):
    path = root / name
    ast.parse(path.read_text(), filename=str(path))
PY

cp "$owned" "$output/rebuilt.sh"
patch --quiet "$output/rebuilt.sh" "$protocol/wan-protocol-runner.patch"
cmp "$output/rebuilt.sh" "$protocol/generated/qualify-proxy-agent-growth-wan-protocol.sh"
patch --quiet "$output/rebuilt.sh" "$copy_source/copy-attribution-runner.patch"
cmp "$output/rebuilt.sh" "$copy_source/generated/qualify-proxy-agent-growth-wan-copy-attribution.sh"
patch --quiet "$output/rebuilt.sh" "$monotonic/monotonic-runner.patch"
cmp "$output/rebuilt.sh" "$monotonic/generated/qualify-proxy-agent-growth-wan-copy-monotonic.sh"
patch --quiet "$output/rebuilt.sh" "$root/read-wait-runner.patch"
cmp "$output/rebuilt.sh" "$root/generated/qualify-proxy-agent-growth-wan-read-wait.sh"

mkdir -p "$output/capacity-source/internal/server"
for name in proxy_qualification_test.go proxy_qualification_wan_read_wait_trace_test.go proxy_qualification_wan_read_wait_trace_contract_test.go; do
  cp "$root/../wan-read-wait-source/build/source/internal/server/$name" "$output/capacity-source/internal/server/$name"
done
patch --quiet -d "$output/capacity-source" -p1 < "$root/server-capacity-snapshot.patch"
for name in proxy_qualification_test.go proxy_qualification_wan_read_wait_trace_test.go proxy_qualification_wan_read_wait_trace_contract_test.go; do
  cmp "$output/capacity-source/internal/server/$name" "$root/build/source/internal/server/$name"
done

[[ $(sha256sum "$root/read-wait-runner.patch" | awk '{print $1}') == 90b777e579b56487296042d5db0fb7148d64ab0eb913c9355ef8baa46e7442b5 ]]
[[ $(sha256sum "$root/server-capacity-snapshot.patch" | awk '{print $1}') == 0392a5055b5c1282627d959216bed7bd898e6f48da46a0c79c46d457e94284de ]]
[[ $(sha256sum "$root/cleanup-status.patch" | awk '{print $1}') == a08468825eb33a3e0a2069cc4842f807ed725befbb5dce896404dead8a218e94 ]]
[[ $(sha256sum "$root/contracts/run-cleanup-status-contract.sh" | awk '{print $1}') == 7a6c0e35c050edd9278b2973be0b1e59fc5de9d0b509acb65d913a026e8dea44 ]]
[[ $(sha256sum "$root/contracts/PROPOSED-CLEANUP.sh" | awk '{print $1}') == c5fb403202a40db713387d98758832874d8c7f632b2a7cec3eec434abf646677 ]]
[[ $(sha256sum "$root/contracts/owned-group-holder.py" | awk '{print $1}') == e3de06775529cc8b895ef7abd556aacbf85e8e66d634fc0935dfa1400272f945 ]]
[[ $(sha256sum "$root/build/bin/current-server-wan-read-wait-capacity-audited.test" | awk '{print $1}') == 57d77ddc5ee8ec6ab49cab0b7d0dd29641a70fa8598f0c7ba3eac73f46632ff5 ]]
[[ $(sha256sum "$root/provenance/CAPACITY-FOCUSED-TEST-CHECKPOINT.json" | awk '{print $1}') == 95da60a769b1efd32abb8e799b8e94fedea1c197965fbe239ded10939f8771ff ]]
[[ $(sha256sum "$root/provenance/capacity-audited-server-build-manifest.json" | awk '{print $1}') == 2bf50c5e7c7aaa4a1d16c0ab09ae516b92abf714404af7a0869234e80a64e075 ]]
[[ $(sha256sum "$root/../current-wan-prep/bin/current-agent.test" | awk '{print $1}') == 9e635d6e1e8fbd8651260eb081fb5fc7847438bc51c653a5f7785cbecde4a137 ]]
[[ $(sha256sum "$root/analyzer/analyze_parsed_trace.py" | awk '{print $1}') == 2a88d25f99f0c99ab9f9e98543c73edda52411374062b5764f28a617395a2e61 ]]
[[ $(sha256sum "$root/analyzer/OUTPUT-SCHEMA.json" | awk '{print $1}') == a95222e70554b8219909e52e6acc98df3632f700439c9138f22417bf505bee37 ]]
[[ $(sha256sum "$root/analyzer/FINAL-CHECKPOINT.json" | awk '{print $1}') == 117d177a15ae4b47ac48d4e41a5886659ced823a2f0ed6bd85bb60614abcae9b ]]
[[ $(sha256sum "$root/OBSERVER-SOURCE-CHECKPOINT.json" | awk '{print $1}') == 327a70507ddb94af99e1b2bc2ab7b9037a18b93daebfaef9acb51a7c0bd80faf ]]
[[ $(sha256sum "$root/provenance/focused-tests/FOCUSED-TEST-CHECKPOINT.json" | awk '{print $1}') == accb27f10a34d7d3319e1d11bd03600d000de62e33ae5f1cb6ae2328a5a50958 ]]
[[ $(sha256sum "$root/provenance/audited-server-build-manifest.json" | awk '{print $1}') == 42f3d7660883425391dbf01f83975957873701a65ea8daa19041a4afada15b3c ]]

for preflight in "$root/run-wan-read-wait-diagnostic.sh" "$root/run-wan-read-wait-arm.sh"; do
  [[ $(grep -Fxc 'monotonic_root=$(realpath "$script_dir/../wan-copy-monotonic-source")' "$preflight") == 1 ]]
done
lexical_gomod="$root/../wan-copy-monotonic-source/build/source/go.mod"
canonical_gomod="$monotonic/build/source/go.mod"
[[ $lexical_gomod != "$canonical_gomod" ]]
jq -e --arg server "0530cdc308bf06964f61d55ca730309e125cabd3c296ed3c22f0cfe218552013" \
  --arg path "build/bin/current-server-wan-copy-monotonic-audited.test" --arg gomod "$canonical_gomod" '
    .base_source_ref == "8ac4c8df8237e37777ba2fac0da6f949da17bdea" and
    .frozen_copy_attribution_overlay_sha256 == "4da0889228f80407806ac111187366ab06abd0ffd5d130d08d41407a8a02ff5f" and
    .monotonic_observer_patch_sha256 == "a8cc867dc9e12681e74b6a51396941d0a03c5145450eabff2e0bae0d8e79965a" and
    .source_pre_post_equal == true and .build_status == 0 and .source_compare_status == 0 and
    .toolchain.path == "/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go" and
    .toolchain.sha256 == "29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45" and
    .toolchain.version == "go version go1.26.6 linux/amd64" and .toolchain.pre_post_equal == true and
    .output.path == $path and .output.sha256 == $server and
    .metadata_inspection.go_env_captured_from_compile_working_directory == true and
    .metadata_inspection.gomod == $gomod and
    .test_rerun == false and .traffic_run == false
  ' "$monotonic/provenance/audited-server-build-manifest.json" >/dev/null
if jq -e --arg gomod "$lexical_gomod" '.metadata_inspection.gomod == $gomod' \
  "$monotonic/provenance/audited-server-build-manifest.json" >/dev/null; then
  echo "lexical predecessor path unexpectedly matched canonical audited metadata" >&2
  exit 1
fi

python3 - "$root" "$output/result.json" <<'PY'
import hashlib, json, pathlib, sys
root, destination = map(pathlib.Path, sys.argv[1:])
runner = (root / "generated/qualify-proxy-agent-growth-wan-read-wait.sh").read_bytes()
begin = runner.index(b"run_transfer() {")
end = runner.index(b"\n}\n\nwan_read_wait_should_trace()", begin) + 3
run_transfer = runner[begin:end]
assert len(run_transfer) == 7350
assert hashlib.sha256(run_transfer).hexdigest() == "b86593361c76c3d2903d722b1b0292fa1bc833210d5efb2438dea1aac08ad798"
generated = runner.decode()
assert '( trap - EXIT INT TERM ERR; set -Eeuo pipefail; run_transfer "$@" )' in generated
entrypoint = (root / "server-cgroup-entrypoint.sh").read_text()
sentinel = (root / "server-scope-sentinel.sh").read_text()
assert entrypoint.startswith("#!/usr/bin/env python3\n") and "os.execvpe(" in entrypoint
assert sentinel.startswith("#!/usr/bin/env python3\n")
assert "subprocess" not in entrypoint and "subprocess" not in sentinel
value = {"schema_version": 1, "accepted": True, "traffic_run": False,
         "generated_runner_sha256": hashlib.sha256(runner).hexdigest(),
         "run_transfer_bytes": len(run_transfer), "run_transfer_sha256": hashlib.sha256(run_transfer).hexdigest()}
destination.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
PY
printf '%s\n' complete > "$output/FINAL"
