#!/usr/bin/env bash
set -Eeuo pipefail

root=$(cd "$(dirname "$0")/.." && pwd)
source_dir="$root/build/source"
go_binary=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
output="$root/build/bin/current-server-wan-read-wait-capacity-audited.test"
record="$root/provenance/capacity-audited-server-build-attempt1"
tmpdir="$root/build/capacity-audited-build-tmp"
gocache="$root/build/capacity-audited-build-cache"
expected_go_sha=29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45

[[ ! -e $output && ! -e $record ]] || { echo "audited output or record already exists" >&2; exit 2; }
[[ $(sha256sum "$go_binary" | awk '{print $1}') == "$expected_go_sha" ]] || {
  echo "canonical pinned Go binary hash changed" >&2
  exit 2
}
[[ $($go_binary version) == "go version go1.26.6 linux/amd64" ]] || {
  echo "canonical pinned Go version changed" >&2
  exit 2
}
mkdir -p "$record" "$tmpdir" "$gocache" "$(dirname "$output")"

source_manifest() {
  local destination=$1
  python3 - "$source_dir" "$destination" <<'PY'
import hashlib, json, pathlib, sys
root, destination = map(pathlib.Path, sys.argv[1:])
files = {}
for path in sorted(root.rglob("*")):
    if path.is_file():
        digest = hashlib.sha256()
        with path.open("rb") as source:
            for block in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(block)
        files[str(path.relative_to(root))] = digest.hexdigest()
destination.write_text(json.dumps({"schema_version": 1, "root": str(root), "files": files}, indent=2, sort_keys=True) + "\n")
PY
}

source_manifest "$record/source-pre.json"
sha256sum "$source_dir/go.mod" "$source_dir/go.sum" > "$record/module-pre.sha256"
sha256sum "$go_binary" > "$record/toolchain-pre.sha256"
"$go_binary" version > "$record/go-version.txt"
cat > "$record/environment.txt" <<EOF
HOME=/home/user
PATH=/usr/bin:/bin
TMPDIR=$tmpdir
GOCACHE=$gocache
GOENV=off
GOTOOLCHAIN=local
GOWORK=off
GOFLAGS=
CGO_ENABLED=1
GOMAXPROCS=4
CPUSET=0-3
EOF

cd "$source_dir"
pwd -P > "$record/working-directory.txt"
env -i HOME=/home/user PATH=/usr/bin:/bin TMPDIR="$tmpdir" GOCACHE="$gocache" GOENV=off GOTOOLCHAIN=local GOWORK=off GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=4 \
  "$go_binary" env -json > "$record/go-env-from-build-cwd.json"
printf '%q ' taskset -c 0-3 env -i HOME=/home/user PATH=/usr/bin:/bin TMPDIR="$tmpdir" GOCACHE="$gocache" GOENV=off GOTOOLCHAIN=local GOWORK=off GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=4 \
  "$go_binary" test -c -o "$output" ./internal/server > "$record/invocation.txt"
printf '\n' >> "$record/invocation.txt"

set +e
taskset -c 0-3 env -i HOME=/home/user PATH=/usr/bin:/bin TMPDIR="$tmpdir" GOCACHE="$gocache" GOENV=off GOTOOLCHAIN=local GOWORK=off GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=4 \
  "$go_binary" test -c -o "$output" ./internal/server > "$record/stdout.log" 2> "$record/stderr.log"
build_status=$?
set -e
printf '%s\n' "$build_status" > "$record/build.status"

source_manifest "$record/source-post.json"
sha256sum "$source_dir/go.mod" "$source_dir/go.sum" > "$record/module-post.sha256"
sha256sum "$go_binary" > "$record/toolchain-post.sha256"

set +e
cmp "$record/source-pre.json" "$record/source-post.json" > "$record/source-pre-post.stdout.log" 2> "$record/source-pre-post.stderr.log"
source_status=$?
cmp "$record/module-pre.sha256" "$record/module-post.sha256" > "$record/module-pre-post.stdout.log" 2> "$record/module-pre-post.stderr.log"
module_status=$?
cmp "$record/toolchain-pre.sha256" "$record/toolchain-post.sha256" > "$record/toolchain-pre-post.stdout.log" 2> "$record/toolchain-pre-post.stderr.log"
toolchain_status=$?
set -e
printf '%s\n' "$source_status" > "$record/source-pre-post.status"
printf '%s\n' "$module_status" > "$record/module-pre-post.status"
printf '%s\n' "$toolchain_status" > "$record/toolchain-pre-post.status"

if ((build_status != 0)); then exit "$build_status"; fi
if ((source_status != 0 || module_status != 0 || toolchain_status != 0)); then
  echo "source, module, or toolchain changed during audited build" >&2
  exit 2
fi
sha256sum "$output" > "$record/output.sha256"
"$go_binary" version -m "$output" > "$record/output.go-version-m.txt"
sha256sum "$record/output.go-version-m.txt" > "$record/output.go-version-m.sha256"
printf '%s\n' complete > "$record/FINAL"
