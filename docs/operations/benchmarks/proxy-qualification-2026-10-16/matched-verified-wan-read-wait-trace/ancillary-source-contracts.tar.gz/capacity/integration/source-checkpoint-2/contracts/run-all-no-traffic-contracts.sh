#!/usr/bin/env bash
set -Eeuo pipefail

root=$(cd "$(dirname "$0")/.." && pwd)
output=$1
[[ ! -e $output ]] || { echo "output already exists" >&2; exit 2; }
mkdir -p "$output"

run() {
  local name=$1
  shift
  set +e
  "$@" "$output/$name" > "$output/$name.stdout.log" 2> "$output/$name.stderr.log"
  local status=$?
  set -e
  printf '%s\n' "$status" > "$output/$name.status"
  ((status == 0))
}

run static "$root/contracts/run-static-integration-contracts.sh"
run resource "$root/contracts/run-server-resource-contracts.py"
run traced-transfer "$root/contracts/run-traced-transfer-contracts.py"
run arm-validator "$root/contracts/run-arm-validator-contracts.py"
printf '%s\n' complete > "$output/FINAL"
