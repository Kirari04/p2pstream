# Failed resource design checkpoint

Status: blocked and unexecuted as a workload runner.

This immutable source checkpoint used `systemd-run --user --scope` from the
private user namespace to create the proposed 4 GiB server-only scope. The
separate prerequisite probe failed before its dummy process or cgroup launched
because the private user namespace could not connect to the user-scope bus.
No retry, build, focused test, smoke, or workload used this runner source.

The checkpoint is preserved byte-for-byte. It is not an approved fallback and
must not be executed. The Go observer source remains independently reviewable.
