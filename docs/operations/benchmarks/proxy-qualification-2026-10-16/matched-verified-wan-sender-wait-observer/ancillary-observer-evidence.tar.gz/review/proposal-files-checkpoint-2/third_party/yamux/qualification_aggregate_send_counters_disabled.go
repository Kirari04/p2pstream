//go:build !p2pstream_qualification

package yamux

const qualificationAggregateSendCountersEnabled = false

type qualificationAggregateSendCounters struct{}
type qualificationAggregateSendWait struct{}
type qualificationDataSendWait struct{}
type qualificationCreditWaitOutcome uint8
type qualificationDataEnqueueOutcome uint8
type qualificationDataCompletionOutcome uint8
type qualificationPhysicalWriteOutcome uint8

const (
	qualificationCreditWakeByteNotify qualificationCreditWaitOutcome = iota
	qualificationCreditWakeAggregateNotify
	qualificationCreditWakeShutdown
	qualificationCreditWakeTimeout
)

const (
	qualificationDataEnqueueAccepted qualificationDataEnqueueOutcome = iota
	qualificationDataEnqueueShutdown
	qualificationDataEnqueueTimeout
)

const (
	qualificationDataCompletionSuccess qualificationDataCompletionOutcome = iota
	qualificationDataCompletionError
	qualificationDataCompletionShutdown
	qualificationDataCompletionTimeout
)

const (
	qualificationPhysicalWriteSuccess qualificationPhysicalWriteOutcome = iota
	qualificationPhysicalWriteError
	qualificationPhysicalWriteShort
)

func (*qualificationAggregateSendCounters) recordReservedData(uint32, uint32, uint32) {}
func (*qualificationAggregateSendCounters) recordAllocationZero(bool, bool)           {}
func (*Session) recordQualificationByteCreditZero()                                   {}
func (*Stream) beginQualificationByteCreditWait() qualificationAggregateSendWait {
	return qualificationAggregateSendWait{}
}
func (*qualificationAggregateSendCounters) recordQualificationAggregateCreditWaitDecision(uint32, bool, bool) {
}
func (*Stream) takeQualificationAggregateCreditWaitDecision() qualificationAggregateSendWait {
	return qualificationAggregateSendWait{}
}
func (*Stream) finishQualificationCreditWait(qualificationAggregateSendWait, qualificationCreditWaitOutcome) {
}
func (*Session) beginQualificationDataEnqueue(uint32, int) qualificationDataSendWait {
	return qualificationDataSendWait{}
}
func (*Session) finishQualificationDataEnqueue(qualificationDataSendWait, qualificationDataEnqueueOutcome) qualificationDataSendWait {
	return qualificationDataSendWait{}
}
func (*Session) finishQualificationDataCompletion(qualificationDataSendWait, qualificationDataCompletionOutcome) {
}
func (*Session) finishQualificationGatherError(uint32, int) {}
func (*Session) beginQualificationPhysicalDataWrite(uint32, int, int) qualificationDataSendWait {
	return qualificationDataSendWait{}
}
func (*Session) finishQualificationPhysicalDataWrite(qualificationDataSendWait, qualificationPhysicalWriteOutcome, int, int) {
}
func (*Session) finishQualificationSendLoop() {}
