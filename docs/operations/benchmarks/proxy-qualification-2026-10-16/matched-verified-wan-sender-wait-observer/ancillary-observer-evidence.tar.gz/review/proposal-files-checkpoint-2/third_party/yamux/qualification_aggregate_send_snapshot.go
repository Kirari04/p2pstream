//go:build p2pstream_qualification

package yamux

type QualificationDurationBucket struct {
	Count            uint64 `json:"count"`
	TotalNanoseconds uint64 `json:"total_nanoseconds"`
	MaxNanoseconds   uint64 `json:"max_nanoseconds"`
}

type QualificationCreditWaitCauseDurations struct {
	ByteZero                       QualificationDurationBucket `json:"byte_zero"`
	StreamAllocationZero           QualificationDurationBucket `json:"stream_allocation_zero"`
	SessionAllocationZero          QualificationDurationBucket `json:"session_allocation_zero"`
	StreamAndSessionAllocationZero QualificationDurationBucket `json:"stream_and_session_allocation_zero"`
}

type QualificationCreditWaitOutcomeDurations struct {
	ByteNotify      QualificationDurationBucket `json:"byte_notify"`
	AggregateNotify QualificationDurationBucket `json:"aggregate_notify"`
	Shutdown        QualificationDurationBucket `json:"shutdown"`
	Timeout         QualificationDurationBucket `json:"timeout"`
}

type QualificationDataEnqueueOutcomeDurations struct {
	Accepted QualificationDurationBucket `json:"accepted"`
	Shutdown QualificationDurationBucket `json:"shutdown"`
	Timeout  QualificationDurationBucket `json:"timeout"`
}

type QualificationDataCompletionOutcomeDurations struct {
	Success  QualificationDurationBucket `json:"success"`
	Error    QualificationDurationBucket `json:"error"`
	Shutdown QualificationDurationBucket `json:"shutdown"`
	Timeout  QualificationDurationBucket `json:"timeout"`
}

type QualificationPhysicalWriteOutcomeDurations struct {
	Success    QualificationDurationBucket `json:"success"`
	Error      QualificationDurationBucket `json:"error"`
	ShortWrite QualificationDurationBucket `json:"short_write"`
}

type QualificationAggregateSendTiming struct {
	Complete                       bool   `json:"complete"`
	ResetPerformed                 bool   `json:"reset_performed"`
	Ambiguous                      bool   `json:"ambiguous"`
	Overflow                       bool   `json:"overflow"`
	StreamObserved                 bool   `json:"stream_observed"`
	ObservedStreamID               uint32 `json:"observed_stream_id"`
	MultipleStreams                bool   `json:"multiple_streams"`
	FirstWaitToken                 uint64 `json:"first_wait_token"`
	LastWaitToken                  uint64 `json:"last_wait_token"`
	PendingCreditDecision          bool   `json:"pending_credit_decision"`
	ActiveCreditWaits              uint64 `json:"active_credit_waits"`
	ActiveCallerFrames             uint64 `json:"active_caller_frames"`
	ActiveCallerPayloadBytes       uint64 `json:"active_caller_payload_bytes"`
	ActiveEnqueueFrames            uint64 `json:"active_enqueue_frames"`
	ActiveEnqueuePayloadBytes      uint64 `json:"active_enqueue_payload_bytes"`
	ActiveQueuedFrames             uint64 `json:"active_queued_frames"`
	ActiveQueuedPayloadBytes       uint64 `json:"active_queued_payload_bytes"`
	ClaimedBeforePublicationFrames uint64 `json:"claimed_before_publication_frames"`
	ClaimedBeforePublicationBytes  uint64 `json:"claimed_before_publication_bytes"`
	EnqueuePublicationRaces        uint64 `json:"enqueue_publication_races"`
	ActivePhysicalFrames           uint64 `json:"active_physical_frames"`
	ActivePhysicalPayloadBytes     uint64 `json:"active_physical_payload_bytes"`

	CreditWaitTotal               QualificationDurationBucket                 `json:"credit_wait_total"`
	CreditWaitByCause             QualificationCreditWaitCauseDurations       `json:"credit_wait_by_cause"`
	CreditWaitByOutcome           QualificationCreditWaitOutcomeDurations     `json:"credit_wait_by_outcome"`
	DataEnqueueSelectTotal        QualificationDurationBucket                 `json:"data_enqueue_select_total"`
	DataEnqueueSelectByOutcome    QualificationDataEnqueueOutcomeDurations    `json:"data_enqueue_select_by_outcome"`
	DataCompletionSelectTotal     QualificationDurationBucket                 `json:"data_completion_select_total"`
	DataCompletionSelectByOutcome QualificationDataCompletionOutcomeDurations `json:"data_completion_select_by_outcome"`
	DataCallTotal                 QualificationDurationBucket                 `json:"data_call_total"`
	DataCallByOutcome             QualificationDataCompletionOutcomeDurations `json:"data_call_by_outcome"`

	DataEnqueuedFrames            uint64                                     `json:"data_enqueued_frames"`
	DataEnqueuedPayloadBytes      uint64                                     `json:"data_enqueued_payload_bytes"`
	DataCompletedFrames           uint64                                     `json:"data_completed_frames"`
	DataCompletedPayloadBytes     uint64                                     `json:"data_completed_payload_bytes"`
	DataGatherErrorFrames         uint64                                     `json:"data_gather_error_frames"`
	DataGatherErrorPayloadBytes   uint64                                     `json:"data_gather_error_payload_bytes"`
	DataAbandonedFrames           uint64                                     `json:"data_abandoned_frames"`
	DataAbandonedPayloadBytes     uint64                                     `json:"data_abandoned_payload_bytes"`
	PhysicalWriteTotal            QualificationDurationBucket                `json:"physical_write_total"`
	PhysicalWriteByOutcome        QualificationPhysicalWriteOutcomeDurations `json:"physical_write_by_outcome"`
	PhysicalAttemptFrames         uint64                                     `json:"physical_attempt_frames"`
	PhysicalAttemptPayloadBytes   uint64                                     `json:"physical_attempt_payload_bytes"`
	PhysicalAttemptWireBytes      uint64                                     `json:"physical_attempt_wire_bytes"`
	PhysicalWrittenWireBytes      uint64                                     `json:"physical_written_wire_bytes"`
	PhysicalSuccessFrames         uint64                                     `json:"physical_success_frames"`
	PhysicalSuccessPayloadBytes   uint64                                     `json:"physical_success_payload_bytes"`
	PhysicalSuccessWireBytes      uint64                                     `json:"physical_success_wire_bytes"`
	PhysicalErrorFrames           uint64                                     `json:"physical_error_frames"`
	PhysicalErrorPayloadBytes     uint64                                     `json:"physical_error_payload_bytes"`
	PhysicalErrorAttemptWireBytes uint64                                     `json:"physical_error_attempt_wire_bytes"`
	PhysicalErrorWrittenWireBytes uint64                                     `json:"physical_error_written_wire_bytes"`
	PhysicalShortFrames           uint64                                     `json:"physical_short_frames"`
	PhysicalShortPayloadBytes     uint64                                     `json:"physical_short_payload_bytes"`
	PhysicalShortAttemptWireBytes uint64                                     `json:"physical_short_attempt_wire_bytes"`
	PhysicalShortWrittenWireBytes uint64                                     `json:"physical_short_written_wire_bytes"`
}

type QualificationAggregateSendCounters struct {
	Enabled                           bool
	ReservedDataFrames                uint64
	ReservedPayloadBytes              uint64
	ReservedAllocationChargedBytes    uint64
	ByteCreditZeroObservations        uint64
	StreamAllocationZeroObservations  uint64
	SessionAllocationZeroObservations uint64
	Timing                            QualificationAggregateSendTiming
}

func qualificationDurationSnapshot(bucket qualificationDurationBucket) QualificationDurationBucket {
	return QualificationDurationBucket{Count: bucket.count, TotalNanoseconds: bucket.total, MaxNanoseconds: bucket.max}
}

func qualificationTimingSnapshot(c qualificationAggregateSendCounters) QualificationAggregateSendTiming {
	complete := !c.pendingCreditDecision && c.activeCreditWaits == 0 &&
		c.activeCallerFrames == 0 && c.activeCallerPayloadBytes == 0 &&
		c.activeEnqueueFrames == 0 && c.activeEnqueuePayloadBytes == 0 &&
		c.activeQueuedFrames == 0 && c.activeQueuedPayloadBytes == 0 &&
		c.claimedBeforePublicationFrames == 0 && c.claimedBeforePublicationBytes == 0 &&
		c.activePhysicalFrames == 0 && c.activePhysicalPayloadBytes == 0
	return QualificationAggregateSendTiming{
		Complete: complete, ResetPerformed: complete, Ambiguous: c.ambiguous, Overflow: c.overflow,
		StreamObserved: c.streamObserved, ObservedStreamID: c.streamID, MultipleStreams: c.multipleStreams,
		FirstWaitToken: c.firstWaitToken, LastWaitToken: c.lastWaitToken,
		PendingCreditDecision: c.pendingCreditDecision, ActiveCreditWaits: c.activeCreditWaits,
		ActiveCallerFrames: c.activeCallerFrames, ActiveCallerPayloadBytes: c.activeCallerPayloadBytes,
		ActiveEnqueueFrames: c.activeEnqueueFrames, ActiveEnqueuePayloadBytes: c.activeEnqueuePayloadBytes,
		ActiveQueuedFrames: c.activeQueuedFrames, ActiveQueuedPayloadBytes: c.activeQueuedPayloadBytes,
		ClaimedBeforePublicationFrames: c.claimedBeforePublicationFrames,
		ClaimedBeforePublicationBytes:  c.claimedBeforePublicationBytes,
		EnqueuePublicationRaces:        c.enqueuePublicationRaces,
		ActivePhysicalFrames:           c.activePhysicalFrames, ActivePhysicalPayloadBytes: c.activePhysicalPayloadBytes,
		CreditWaitTotal: qualificationDurationSnapshot(c.creditWaitTotal),
		CreditWaitByCause: QualificationCreditWaitCauseDurations{
			ByteZero:                       qualificationDurationSnapshot(c.creditWaitByCause[qualificationCreditWaitByteZero]),
			StreamAllocationZero:           qualificationDurationSnapshot(c.creditWaitByCause[qualificationCreditWaitStreamAllocationZero]),
			SessionAllocationZero:          qualificationDurationSnapshot(c.creditWaitByCause[qualificationCreditWaitSessionAllocationZero]),
			StreamAndSessionAllocationZero: qualificationDurationSnapshot(c.creditWaitByCause[qualificationCreditWaitStreamAndSessionAllocationZero]),
		},
		CreditWaitByOutcome: QualificationCreditWaitOutcomeDurations{
			ByteNotify:      qualificationDurationSnapshot(c.creditWaitByOutcome[qualificationCreditWakeByteNotify]),
			AggregateNotify: qualificationDurationSnapshot(c.creditWaitByOutcome[qualificationCreditWakeAggregateNotify]),
			Shutdown:        qualificationDurationSnapshot(c.creditWaitByOutcome[qualificationCreditWakeShutdown]),
			Timeout:         qualificationDurationSnapshot(c.creditWaitByOutcome[qualificationCreditWakeTimeout]),
		},
		DataEnqueueSelectTotal: qualificationDurationSnapshot(c.dataEnqueueTotal),
		DataEnqueueSelectByOutcome: QualificationDataEnqueueOutcomeDurations{
			Accepted: qualificationDurationSnapshot(c.dataEnqueueByOutcome[qualificationDataEnqueueAccepted]),
			Shutdown: qualificationDurationSnapshot(c.dataEnqueueByOutcome[qualificationDataEnqueueShutdown]),
			Timeout:  qualificationDurationSnapshot(c.dataEnqueueByOutcome[qualificationDataEnqueueTimeout]),
		},
		DataCompletionSelectTotal: qualificationDurationSnapshot(c.dataCompletionTotal),
		DataCompletionSelectByOutcome: QualificationDataCompletionOutcomeDurations{
			Success:  qualificationDurationSnapshot(c.dataCompletionByOutcome[qualificationDataCompletionSuccess]),
			Error:    qualificationDurationSnapshot(c.dataCompletionByOutcome[qualificationDataCompletionError]),
			Shutdown: qualificationDurationSnapshot(c.dataCompletionByOutcome[qualificationDataCompletionShutdown]),
			Timeout:  qualificationDurationSnapshot(c.dataCompletionByOutcome[qualificationDataCompletionTimeout]),
		},
		DataCallTotal: qualificationDurationSnapshot(c.dataCallTotal),
		DataCallByOutcome: QualificationDataCompletionOutcomeDurations{
			Success:  qualificationDurationSnapshot(c.dataCallByOutcome[qualificationDataCompletionSuccess]),
			Error:    qualificationDurationSnapshot(c.dataCallByOutcome[qualificationDataCompletionError]),
			Shutdown: qualificationDurationSnapshot(c.dataCallByOutcome[qualificationDataCompletionShutdown]),
			Timeout:  qualificationDurationSnapshot(c.dataCallByOutcome[qualificationDataCompletionTimeout]),
		},
		DataEnqueuedFrames: c.dataEnqueuedFrames, DataEnqueuedPayloadBytes: c.dataEnqueuedPayloadBytes,
		DataCompletedFrames: c.dataCompletedFrames, DataCompletedPayloadBytes: c.dataCompletedPayloadBytes,
		DataGatherErrorFrames: c.dataGatherErrorFrames, DataGatherErrorPayloadBytes: c.dataGatherErrorPayloadBytes,
		DataAbandonedFrames: c.dataAbandonedFrames, DataAbandonedPayloadBytes: c.dataAbandonedPayloadBytes,
		PhysicalWriteTotal: qualificationDurationSnapshot(c.physicalWriteTotal),
		PhysicalWriteByOutcome: QualificationPhysicalWriteOutcomeDurations{
			Success:    qualificationDurationSnapshot(c.physicalWriteByOutcome[qualificationPhysicalWriteSuccess]),
			Error:      qualificationDurationSnapshot(c.physicalWriteByOutcome[qualificationPhysicalWriteError]),
			ShortWrite: qualificationDurationSnapshot(c.physicalWriteByOutcome[qualificationPhysicalWriteShort]),
		},
		PhysicalAttemptFrames: c.physicalAttemptFrames, PhysicalAttemptPayloadBytes: c.physicalAttemptPayloadBytes,
		PhysicalAttemptWireBytes: c.physicalAttemptWireBytes, PhysicalWrittenWireBytes: c.physicalWrittenWireBytes,
		PhysicalSuccessFrames: c.physicalSuccessFrames, PhysicalSuccessPayloadBytes: c.physicalSuccessPayloadBytes,
		PhysicalSuccessWireBytes: c.physicalSuccessWireBytes,
		PhysicalErrorFrames:      c.physicalErrorFrames, PhysicalErrorPayloadBytes: c.physicalErrorPayloadBytes,
		PhysicalErrorAttemptWireBytes: c.physicalErrorAttemptWireBytes,
		PhysicalErrorWrittenWireBytes: c.physicalErrorWrittenWireBytes,
		PhysicalShortFrames:           c.physicalShortFrames, PhysicalShortPayloadBytes: c.physicalShortPayloadBytes,
		PhysicalShortAttemptWireBytes: c.physicalShortAttemptWireBytes,
		PhysicalShortWrittenWireBytes: c.physicalShortWrittenWireBytes,
	}
}

// DrainQualificationAggregateSendCounters resets a complete prior interval even
// when it contains counters. Incomplete live state is returned but never reset.
func (s *Session) DrainQualificationAggregateSendCounters() QualificationAggregateSendCounters {
	if s == nil || s.aggregate == nil {
		return QualificationAggregateSendCounters{}
	}
	a := s.aggregate
	a.mu.Lock()
	counters := a.qualification
	timing := qualificationTimingSnapshot(counters)
	if timing.Complete {
		a.qualification = qualificationAggregateSendCounters{}
	}
	a.mu.Unlock()
	return QualificationAggregateSendCounters{
		Enabled:                           true,
		ReservedDataFrames:                counters.reservedDataFrames,
		ReservedPayloadBytes:              counters.reservedPayloadBytes,
		ReservedAllocationChargedBytes:    counters.reservedAllocationChargedBytes,
		ByteCreditZeroObservations:        counters.byteCreditZeroObservations,
		StreamAllocationZeroObservations:  counters.streamAllocationZeroObservations,
		SessionAllocationZeroObservations: counters.sessionAllocationZeroObservations,
		Timing:                            timing,
	}
}
