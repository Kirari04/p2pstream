# Tagged sender wait-duration observer: implementation amendment

Status: source-only derivative of commit
`8ac4c8df8237e37777ba2fac0da6f949da17bdea`. No build, test, endpoint,
or traffic execution has occurred. This amendment narrows and corrects
`DESIGN-ORIGINAL.md`; it does not authorize runtime use.

## Interval boundary

The pre-transfer drain is required to return `complete=true` and
`reset_performed=true`. Prior nonzero counters are recorded and accepted as
conditioning history; a complete drain clears them. The selected measurement
starts only after that reset. A drain with a pending credit decision or any
active enqueue, queued, pre-publication, physical, or credit-wait ownership
returns `complete=false`, `reset_performed=false`, and leaves all live state
untouched.

The snapshot schema is version 2 because the existing growth response gains a
nested timing object. The selected interval must bind one observed stream ID
to the existing endpoint's session identity, lane, local address, and remote
address. `multiple_streams`, `ambiguous`, or `overflow` invalidates the
measurement.

## DATA byte domains and conservation

`reserved_payload_bytes`, `data_enqueued_payload_bytes`,
`data_completed_payload_bytes`, and `physical_*_payload_bytes` all count Yamux
DATA payload. For a proxied HTTP response that payload includes the tunneled
HTTP response headers as well as its body. It is therefore intentionally not
asserted equal to the independently checked 256 MiB load payload.

`physical_attempt_wire_bytes` and `physical_written_wire_bytes` include the
Yamux DATA header in addition to that payload. A successful selected interval
must separately conserve:

* reserved DATA frames/payload against accepted enqueue, actual completion,
  physical attempt, and physical success frames/payload;
* attempted physical wire bytes against successful and actually written wire
  bytes;
* the load generator's response-body byte count against its configured body
  size.

Gather errors, abandoned queue entries, physical errors, short writes,
shutdowns, and caller timeouts remain exact visible outcomes. The accepted
selected transfer requires all of them to be zero.

## Queue handoff and actual operation ownership

A channel receiver may dequeue DATA and enter `conn.Write` before the sending
caller resumes to record enqueue acceptance. Changing that scheduling with a
new lock handoff would violate the observer's queue and lock invariants. The
tagged ledger therefore owns the operation from enqueue entry and uses fixed
pre-publication ownership counters when the send goroutine wins this race. The
caller later joins that ownership when it publishes acceptance; until then the
drain remains incomplete. The cumulative `enqueue_publication_races` count
remains visible after the join and invalidates post-enqueue timing, because the
caller timestamp cannot honestly include physical work that began first. The
observer stores no payload reference, map, slice, or per-frame diagnostic
object.

When `enqueue_publication_races==0`, caller post-enqueue completion is measured
from accepted enqueue until the caller's natural result. It includes queue
residence, body gathering, scheduling, physical write, and error publication,
and is labeled
`data_completion`, not physical send time. The physical DATA `conn.Write`
subtotal is independently mandatory, with exact success, error, or short-write
outcome. Caller timeout or shutdown records the caller outcome but does not
release queued or physical ownership; actual completion or natural send-loop
termination does that.

## Credit wait semantics

Each wait is attributed at the existing entry decision to exactly one of
`byte_zero`, `stream_allocation_zero`, `session_allocation_zero`, or
`stream_and_session_allocation_zero`. The selected wake is recorded separately
as byte notification, aggregate notification, shutdown, or timeout. First and
last wait tokens, total and per-cause/per-outcome duration buckets, and active
wait ownership make count/time conservation reviewable. These labels report
observed entry state and selected wake only; they do not claim that the wake
resolved the cause.

## Ordinary build proof still required

The disabled build retains zero-sized diagnostic counter and handle types and
compile-time-false calls. This source shape is not itself proof of zero ordinary
overhead. Before runtime use, pinned ordinary predecessor and derivative
objects must show unchanged relevant struct sizes, stack sizes, and real
instructions for the affected paths. Comparison may normalize symbol
addresses and relocation encodings only; it must not delete or normalize real
instructions, calls, stack changes, or layout differences.

Deterministic tagged fixture source covers exact wait causes/outcomes, an active
enqueue through its natural terminal outcome, caller timeout with later
physical completion, DATA byte conservation, multi-stream invalidation,
visible pre-publication race rejection, and natural queued-operation terminal
accounting. Those fixtures are unexecuted pending review.
