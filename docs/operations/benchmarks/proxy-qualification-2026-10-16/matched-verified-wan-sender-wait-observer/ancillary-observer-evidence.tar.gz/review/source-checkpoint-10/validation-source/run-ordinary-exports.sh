#!/usr/bin/env bash
set -uo pipefail
attempt_root="$(cd "$(dirname "$0")" && pwd)"
go_bin=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
export GOTOOLCHAIN=local GOPROXY=off GOMODCACHE=/home/user/go/pkg/mod GOPATH="$attempt_root/gopath" GOTMPDIR="$attempt_root/tmp" TMPDIR="$attempt_root/tmp" GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=16
: >"$attempt_root/outputs/ordinary-export-status.tsv"; : >"$attempt_root/outputs/ordinary-export-commands.txt"
run_export() {
 local name=$1 source=$2 cache=$3 dest=$4
 mkdir -p "$cache"
 printf '%s\tcd %q && GOCACHE=%q taskset -c 0-15 %q list -a -export -f %q .\n' "$name" "$source" "$cache" "$go_bin" '{{.Export}}' >>"$attempt_root/outputs/ordinary-export-commands.txt"
 date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/$name.start-utc"
 local export_path
 export_path=$(cd "$source" && GOCACHE="$cache" taskset -c 0-15 "$go_bin" list -a -export -f '{{.Export}}' . 2>"$attempt_root/outputs/$name.stderr")
 local status=$?
 printf '%s\n' "$export_path" >"$attempt_root/outputs/$name.stdout"
 if [[ "$status" -eq 0 && -f "$export_path" ]]; then cp "$export_path" "$dest"; else status=1; fi
 date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/$name.end-utc"
 printf '%s\t%d\n' "$name" "$status" >>"$attempt_root/outputs/ordinary-export-status.tsv"
 return "$status"
}
run_export baseline-ordinary-export "$attempt_root/baseline/source/third_party/yamux" "$attempt_root/cache/baseline-ordinary-export" "$attempt_root/outputs/baseline-yamux.a" || exit $?
run_export candidate-ordinary-export "$attempt_root/candidate/source/third_party/yamux" "$attempt_root/cache/candidate-ordinary-export" "$attempt_root/outputs/candidate-yamux.a" || exit $?
