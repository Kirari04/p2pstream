#!/usr/bin/env bash
set -uo pipefail
attempt_root="$(cd "$(dirname "$0")" && pwd)"
go_bin=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
candidate="$attempt_root/candidate/source"
export GOTOOLCHAIN=local GOPROXY=off GOMODCACHE=/home/user/go/pkg/mod
export GOPATH="$attempt_root/gopath" GOTMPDIR="$attempt_root/tmp" TMPDIR="$attempt_root/tmp"
export GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=16
mkdir -p "$GOPATH" "$GOTMPDIR"
: >"$attempt_root/outputs/focused-status.tsv"
: >"$attempt_root/outputs/focused-commands.txt"
run_one() {
  local name=$1 cwd=$2 cache=$3 expected=$4
  shift 4
  mkdir -p "$cache"
  printf '%s\t' "$name" >>"$attempt_root/outputs/focused-commands.txt"
  printf 'cd %q && GOCACHE=%q taskset -c 0-15' "$cwd" "$cache" >>"$attempt_root/outputs/focused-commands.txt"
  printf ' %q' "$@" >>"$attempt_root/outputs/focused-commands.txt"
  printf '\n' >>"$attempt_root/outputs/focused-commands.txt"
  date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/$name.start-utc"
  (cd "$cwd" && GOCACHE="$cache" taskset -c 0-15 "$@") >"$attempt_root/outputs/$name.stdout.jsonl" 2>"$attempt_root/outputs/$name.stderr"
  local direct=$?
  printf '%d\n' "$direct" >"$attempt_root/outputs/$name.direct.status"
  if [[ "$direct" -ne 0 ]]; then
    date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/$name.end-utc"
    printf '%s\tdirect\t%d\n' "$name" "$direct" >>"$attempt_root/outputs/focused-status.tsv"
    return "$direct"
  fi
  python3 -I "$attempt_root/verify-test-json.py" "$attempt_root/outputs/$name.stdout.jsonl" "$expected" "$attempt_root/outputs/$name.test-audit.json"
  local audit=$?
  printf '%d\n' "$audit" >"$attempt_root/outputs/$name.audit.status"
  date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/$name.end-utc"
  printf '%s\taudit\t%d\n' "$name" "$audit" >>"$attempt_root/outputs/focused-status.tsv"
  return "$audit"
}
yamux_pattern='^(TestQualificationAggregateSendCounters.*|TestQualificationAggregateSendCounterRecordHasNoAllocation|TestQualificationSenderDuration.*)$'
run_one yamux-normal "$candidate/third_party/yamux" "$attempt_root/cache/yamux-normal" "$attempt_root/inputs/expected-yamux-tests.txt" "$go_bin" test -json -count=1 -tags p2pstream_qualification . -run "$yamux_pattern" || exit $?
run_one yamux-race "$candidate/third_party/yamux" "$attempt_root/cache/yamux-race" "$attempt_root/inputs/expected-yamux-tests.txt" "$go_bin" test -json -count=1 -race -tags p2pstream_qualification . -run "$yamux_pattern" || exit $?
run_one agent-schema "$candidate" "$attempt_root/cache/agent-schema" "$attempt_root/inputs/expected-agent-tests.txt" "$go_bin" test -json -count=1 -tags p2pstream_qualification ./internal/agent -run '^(TestExternalQualificationCreditSnapshotHasBoundedVersionedSchema|TestExternalQualificationGrowthSnapshotHasBoundedVersionedSchema)$' || exit $?
run_one server-schema "$candidate" "$attempt_root/cache/server-schema" "$attempt_root/inputs/expected-server-tests.txt" "$go_bin" test -json -count=1 -tags p2pstream_qualification ./internal/server -run '^(TestQualificationCreditSnapshotHasBoundedVersionedSchema|TestQualificationGrowthSnapshotHasBoundedVersionedSchema)$' || exit $?
run_one ordinary-layout "$candidate/third_party/yamux" "$attempt_root/cache/ordinary-layout" "$attempt_root/inputs/expected-layout-tests.txt" "$go_bin" test -json -count=1 . -run '^TestQualificationAggregateSendCountersDoNotChangeOrdinaryLayout$' || exit $?
