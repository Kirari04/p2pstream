#!/usr/bin/env python3
import json,sys
from pathlib import Path
stream=Path(sys.argv[1]); expected_path=Path(sys.argv[2]); report=Path(sys.argv[3])
expected=set(expected_path.read_text().splitlines())
runs=set(); passes=set(); failures=[]; package_pass=False
for number,line in enumerate(stream.read_text().splitlines(),1):
    try: event=json.loads(line)
    except Exception as exc: raise SystemExit(f'invalid JSON line {number}: {exc}')
    action=event.get('Action'); test=event.get('Test')
    if test and '/' not in test:
        if action=='run': runs.add(test)
        elif action=='pass': passes.add(test)
        elif action=='fail': failures.append(test)
    if not test and action=='pass': package_pass=True
accepted=(runs==expected and passes==expected and not failures and package_pass)
report.write_text(json.dumps({'accepted':accepted,'expected':sorted(expected),'runs':sorted(runs),'passes':sorted(passes),'failures':sorted(failures),'package_pass':package_pass},sort_keys=True,separators=(',',':'))+'\n')
raise SystemExit(0 if accepted else 1)
