#!/usr/bin/env python3
import json
import sys
from pathlib import Path

baseline, candidate, body_root, output = map(Path, sys.argv[1:])
send_start = "func (s *Session) sendLoop() error {"
send_end = "// recv is a long running goroutine that accepts new data"
write_start = "// write is used to write to the stream, may return on\n// a short write.\n"
write_end = "// sendFlags determines any flags that are appropriate"

def between(path, start, end=None):
    text = path.read_text()
    first = text.index(start)
    last = text.index(end, first) if end else len(text)
    return text[first:last].rstrip() + "\n"

checks = {
    "baseline_send": between(baseline / "session.go", send_start, send_end) == (body_root / "baseline-session-send-loop.txt").read_text(),
    "baseline_write": between(baseline / "stream.go", write_start, write_end) == (body_root / "baseline-stream-write.txt").read_text(),
    "candidate_ordinary_send": between(candidate / "session_send_loop_ordinary.go", send_start) == (body_root / "baseline-session-send-loop.txt").read_text(),
    "candidate_tagged_send": between(candidate / "session_send_loop_qualification.go", send_start) == (body_root / "cp4-tagged-session-send-loop.txt").read_text(),
    "candidate_ordinary_write": between(candidate / "stream_write_ordinary.go", write_start) == (body_root / "baseline-stream-write.txt").read_text(),
    "candidate_tagged_write": between(candidate / "stream_write_qualification.go", write_start) == (body_root / "cp4-tagged-stream-write.txt").read_text(),
    "candidate_shared_send_absent": send_start not in (candidate / "session.go").read_text(),
    "candidate_shared_write_absent": write_start not in (candidate / "stream.go").read_text(),
}
report = {"accepted": all(checks.values()), "checks": checks}
output.write_text(json.dumps(report, sort_keys=True, separators=(",", ":")) + "\n")
raise SystemExit(0 if report["accepted"] else 1)
