#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then echo 'usage: run-layout-resume-attempt4.sh ATTEMPT4_ROOT' >&2; exit 64; fi
attempt_root=$(cd "$(dirname "$0")" && pwd)
reuse_root=$(cd "$1" && pwd)
go_bin=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
export GOTOOLCHAIN=local GOPROXY=off GOMODCACHE=/home/user/go/pkg/mod GOPATH="$attempt_root/gopath" GOTMPDIR="$attempt_root/tmp" TMPDIR="$attempt_root/tmp" GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=16
expected_jsonl=b5a60bffd13f44c0f8da839ce63302442140f852af182428b5f8359d25a59b56
expected_direct=9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa
expected_preflight=d47282b12db7b38cb23f1e6cbd43347f221cf1203710b6cb2dfbc2b26c38713d
expected_stderr=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
expected_start=e6c088663b83a83dec54caad4abca2b62fa639686d685761c3e0e3251601a121
expected_end=bbbc9f39ffbce4e96132b5866de54ef25630dbad0f522fe292956ed7110fb9ba
expected_archive=b625da9ccbe17c8b43ff1e5c1078bd8fb24aff4c995fcfd23302ac83c0c3d9f9
expected_baseline_inventory=d63e467367d95ccd858e288520f564b54244bed40dc6552e703ca1f3d7e4f0d3
expected_candidate_inventory=709f8f9fc486d81d43b85c91f5f193b29206b2441afaf1cca23eebba5f4d8450
expected_body_audit=8c4f3cd77bc09b47b06b90b80fa4d4d070ab59e3b2272c26439b38318eba9b1e
expected_probe=c8a461f71c048bf15266e981a9e4e6bc6948bdd2581f7222a10c06861a488071

hash_is() {
  local path=$1 expected=$2
  [[ -f "$path" && ! -L "$path" && $(sha256sum "$path" | awk '{print $1}') == "$expected" ]]
}

old_jsonl="$reuse_root/outputs/baseline-layout.stdout.jsonl"
old_direct="$reuse_root/outputs/baseline-layout.direct.status"
hash_is "$old_jsonl" "$expected_jsonl" || { echo 'attempt4 baseline JSONL binding failed' >&2; exit 70; }
hash_is "$old_direct" "$expected_direct" || { echo 'attempt4 direct-status binding failed' >&2; exit 71; }
[[ $(cat "$old_direct") == 0 ]] || { echo 'attempt4 direct status is not zero' >&2; exit 72; }
hash_is "$reuse_root/outputs/preflight-status.tsv" "$expected_preflight" || { echo 'attempt4 preflight binding failed' >&2; exit 73; }
hash_is "$reuse_root/outputs/baseline-layout.stderr" "$expected_stderr" || { echo 'attempt4 baseline stderr binding failed' >&2; exit 73; }
hash_is "$reuse_root/outputs/baseline-layout.start-utc" "$expected_start" || { echo 'attempt4 baseline start binding failed' >&2; exit 73; }
hash_is "$reuse_root/outputs/baseline-layout.end-utc" "$expected_end" || { echo 'attempt4 baseline end binding failed' >&2; exit 73; }
hash_is "$reuse_root/inputs/source.tar" "$expected_archive" || { echo 'attempt4 source archive binding failed' >&2; exit 74; }
hash_is "$attempt_root/inputs/source.tar" "$expected_archive" || { echo 'fresh source archive binding failed' >&2; exit 75; }
hash_is "$reuse_root/inputs/baseline-validation-overlay.json" "$expected_baseline_inventory" || exit 76
hash_is "$attempt_root/inputs/baseline-validation-overlay.json" "$expected_baseline_inventory" || exit 77
hash_is "$reuse_root/inputs/candidate-validation-overlay.json" "$expected_candidate_inventory" || exit 78
hash_is "$attempt_root/inputs/candidate-validation-overlay.json" "$expected_candidate_inventory" || exit 79
hash_is "$reuse_root/inputs/body-audit.json" "$expected_body_audit" || exit 80
hash_is "$attempt_root/inputs/body-audit.json" "$expected_body_audit" || exit 81
[[ $(cat "$reuse_root/inputs/resolved-commit.txt") == 8ac4c8df8237e37777ba2fac0da6f949da17bdea ]] || exit 82
[[ $(cat "$attempt_root/inputs/resolved-commit.txt") == 8ac4c8df8237e37777ba2fac0da6f949da17bdea ]] || exit 83
[[ $(cat "$reuse_root/inputs/resolved-tree.txt") == 6c460a3b1362b2711bbd3d48c722fb86f5210e14 ]] || exit 84
[[ $(cat "$attempt_root/inputs/resolved-tree.txt") == 6c460a3b1362b2711bbd3d48c722fb86f5210e14 ]] || exit 85
for probe in \
  "$reuse_root/baseline/source/third_party/yamux/qualification_ordinary_layout_probe_test.go" \
  "$reuse_root/candidate/source/third_party/yamux/qualification_ordinary_layout_probe_test.go" \
  "$attempt_root/baseline/source/third_party/yamux/qualification_ordinary_layout_probe_test.go" \
  "$attempt_root/candidate/source/third_party/yamux/qualification_ordinary_layout_probe_test.go"; do
  hash_is "$probe" "$expected_probe" || { echo "layout probe binding failed: $probe" >&2; exit 86; }
done

: >"$attempt_root/outputs/layout-status.tsv"
: >"$attempt_root/outputs/layout-commands.txt"
for target in \
  baseline-layout.stdout.jsonl baseline-layout.direct.status baseline-layout.stderr \
  baseline-layout.json baseline-layout.audit.json candidate-layout.stdout.jsonl \
  candidate-layout.direct.status candidate-layout.stderr candidate-layout.json \
  candidate-layout.audit.json; do
  [[ ! -e "$attempt_root/outputs/$target" ]] || { echo "non-fresh layout output: $target" >&2; exit 89; }
done
{
  printf 'source_attempt_root\t%s\n' "$reuse_root"
  printf 'jsonl_sha256\t%s\n' "$expected_jsonl"
  printf 'direct_status_sha256\t%s\n' "$expected_direct"
  printf 'source_archive_sha256\t%s\n' "$expected_archive"
  printf 'commit\t%s\n' 8ac4c8df8237e37777ba2fac0da6f949da17bdea
  printf 'tree\t%s\n' 6c460a3b1362b2711bbd3d48c722fb86f5210e14
} >"$attempt_root/inputs/baseline-layout-reuse-provenance.tsv"
sha256sum \
  "$reuse_root/outputs/baseline-layout.stdout.jsonl" \
  "$reuse_root/outputs/baseline-layout.direct.status" \
  "$reuse_root/outputs/baseline-layout.stderr" \
  "$reuse_root/outputs/baseline-layout.start-utc" \
  "$reuse_root/outputs/baseline-layout.end-utc" \
  "$reuse_root/inputs/source.tar" \
  "$reuse_root/inputs/baseline-validation-overlay.json" \
  "$reuse_root/inputs/candidate-validation-overlay.json" \
  "$reuse_root/inputs/body-audit.json" \
  >"$attempt_root/inputs/baseline-layout-reuse-inputs.sha256"
cp --reflink=auto "$old_jsonl" "$attempt_root/outputs/baseline-layout.stdout.jsonl"
cp "$old_direct" "$attempt_root/outputs/baseline-layout.direct.status"
cp "$reuse_root/outputs/baseline-layout.stderr" "$attempt_root/outputs/baseline-layout.stderr"
cp "$reuse_root/outputs/baseline-layout.start-utc" "$attempt_root/outputs/baseline-layout.original-start-utc"
cp "$reuse_root/outputs/baseline-layout.end-utc" "$attempt_root/outputs/baseline-layout.original-end-utc"
hash_is "$attempt_root/outputs/baseline-layout.stdout.jsonl" "$expected_jsonl" || exit 87
hash_is "$attempt_root/outputs/baseline-layout.direct.status" "$expected_direct" || exit 88
printf 'baseline-reused\tsha256=%s\tsource=%q\n' "$expected_jsonl" "$old_jsonl" >>"$attempt_root/outputs/layout-commands.txt"
date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/baseline-layout.reduction-start-utc"
set +e
python3 -I "$attempt_root/extract-layout.py" \
  "$attempt_root/outputs/baseline-layout.stdout.jsonl" \
  "$attempt_root/outputs/baseline-layout.direct.status" \
  "$attempt_root/outputs/baseline-layout.json" \
  "$attempt_root/outputs/baseline-layout.audit.json" \
  >"$attempt_root/outputs/baseline-layout.audit.stdout" \
  2>"$attempt_root/outputs/baseline-layout.audit.stderr"
baseline_audit=$?
set -e
date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/baseline-layout.reduction-end-utc"
printf '%d\n' "$baseline_audit" >"$attempt_root/outputs/baseline-layout.audit.status"
printf 'baseline-reused\t0\t%d\n' "$baseline_audit" >>"$attempt_root/outputs/layout-status.tsv"
hash_is "$attempt_root/outputs/baseline-layout.stdout.jsonl" "$expected_jsonl" || exit 90
[[ "$baseline_audit" -eq 0 ]] || exit "$baseline_audit"

source="$attempt_root/candidate/source/third_party/yamux"
cache="$attempt_root/cache/candidate-layout"
mkdir -p "$cache"
printf 'candidate\tcd %q && GOCACHE=%q taskset -c 0-15 %q test -json -v -count=1 . -run %q\n' \
  "$source" "$cache" "$go_bin" '^TestQualificationBaselineCandidateTypeLayoutProbe$' \
  >>"$attempt_root/outputs/layout-commands.txt"
date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/candidate-layout.start-utc"
set +e
(cd "$source" && GOCACHE="$cache" taskset -c 0-15 "$go_bin" test -json -v -count=1 . -run '^TestQualificationBaselineCandidateTypeLayoutProbe$') \
  >"$attempt_root/outputs/candidate-layout.stdout.jsonl" \
  2>"$attempt_root/outputs/candidate-layout.stderr"
candidate_direct=$?
set -e
printf '%d\n' "$candidate_direct" >"$attempt_root/outputs/candidate-layout.direct.status"
if [[ "$candidate_direct" -ne 0 ]]; then exit "$candidate_direct"; fi
set +e
python3 -I "$attempt_root/extract-layout.py" \
  "$attempt_root/outputs/candidate-layout.stdout.jsonl" \
  "$attempt_root/outputs/candidate-layout.direct.status" \
  "$attempt_root/outputs/candidate-layout.json" \
  "$attempt_root/outputs/candidate-layout.audit.json" \
  >"$attempt_root/outputs/candidate-layout.audit.stdout" \
  2>"$attempt_root/outputs/candidate-layout.audit.stderr"
candidate_audit=$?
set -e
printf '%d\n' "$candidate_audit" >"$attempt_root/outputs/candidate-layout.audit.status"
date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/candidate-layout.end-utc"
printf 'candidate\t%d\t%d\n' "$candidate_direct" "$candidate_audit" >>"$attempt_root/outputs/layout-status.tsv"
exit "$candidate_audit"
