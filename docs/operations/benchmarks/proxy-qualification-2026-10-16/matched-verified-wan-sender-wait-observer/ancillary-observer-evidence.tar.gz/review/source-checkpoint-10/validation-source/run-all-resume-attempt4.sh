#!/usr/bin/env bash
set -uo pipefail
if [[ $# -ne 2 ]]; then echo 'usage: run-all-resume-attempt4.sh FRESH_OUTPUT ATTEMPT4_ROOT' >&2; exit 64; fi
validation_source=$(cd "$(dirname "$0")" && pwd)
output=$1
reuse_root=$2
"$validation_source/prepare-validation.sh" "$output"
status=$?
if [[ "$status" -ne 0 ]]; then exit "$status"; fi
output=$(cd "$output" && pwd)
printf 'phase\tstatus\nprepare\t0\n' >"$output/outputs/outer-status.tsv"
finalize() {
  local final=$?
  if [[ -d "$output/baseline/source" && -f "$output/inventory.py" ]]; then
    python3 -I "$output/inventory.py" "$output/baseline/source" "$output/inputs/baseline-post-run.json"
    local baseline_inventory=$?
    python3 -I "$output/inventory.py" "$output/candidate/source" "$output/inputs/candidate-post-run.json"
    local candidate_inventory=$?
    cmp -s "$output/inputs/baseline-validation-overlay.json" "$output/inputs/baseline-post-run.json"
    local baseline_unchanged=$?
    cmp -s "$output/inputs/candidate-validation-overlay.json" "$output/inputs/candidate-post-run.json"
    local candidate_unchanged=$?
    printf 'baseline_inventory\t%d\ncandidate_inventory\t%d\nbaseline_unchanged\t%d\ncandidate_unchanged\t%d\n' "$baseline_inventory" "$candidate_inventory" "$baseline_unchanged" "$candidate_unchanged" >"$output/outputs/source-post-status.tsv"
    if [[ "$baseline_inventory" -ne 0 || "$candidate_inventory" -ne 0 || "$baseline_unchanged" -ne 0 || "$candidate_unchanged" -ne 0 ]]; then
      final=1
    fi
  fi
  date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$output/END-UTC.txt"
  printf '%d\n' "$final" >"$output/outputs/final.status"
  printf 'CP8_RESUME_VALIDATION_FINAL status=%d output=%s\n' "$final" "$output"
  trap - EXIT
  exit "$final"
}
trap finalize EXIT
run_phase() {
  local name=$1; shift
  "$@"
  local direct=$?
  printf '%s\t%d\n' "$name" "$direct" >>"$output/outputs/outer-status.tsv"
  return "$direct"
}
run_phase extractor-contract "$output/run-extract-layout-contract.sh" "$reuse_root" || exit $?
run_phase layout-reuse "$output/run-layout-resume-attempt4.sh" "$reuse_root" || exit $?
run_phase focused "$output/run-focused.sh" || exit $?
run_phase ordinary-builds "$output/run-ordinary-builds.sh" || exit $?
run_phase ordinary-exports "$output/run-ordinary-exports.sh" || exit $?
run_phase ordinary-compiler "$output/run-ordinary-compiler.sh" || exit $?
run_phase proof "$output/run-proof.sh" || exit $?
