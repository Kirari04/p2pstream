#!/usr/bin/env python3
import hashlib
import json
import stat
import sys
from pathlib import Path

baseline_path, candidate_path, overlay_root, overlay_paths_path, output_path = map(Path, sys.argv[1:])
baseline = {row["path"]: row for row in json.loads(baseline_path.read_text())}
candidate = {row["path"]: row for row in json.loads(candidate_path.read_text())}
expected = {
    line.strip().removeprefix("./")
    for line in overlay_paths_path.read_text().splitlines()
    if line.strip()
}
changed = {path for path in baseline.keys() | candidate.keys() if baseline.get(path) != candidate.get(path)}
failures = []
if changed != expected:
    failures.append({"changed_paths": sorted(changed), "expected_paths": sorted(expected)})
for relative in sorted(expected):
    source = overlay_root / relative
    row = candidate.get(relative)
    if not source.is_file() or source.is_symlink() or row is None or row.get("type") != "file":
        failures.append({"invalid_overlay_path": relative})
        continue
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    mode = stat.S_IMODE(source.stat().st_mode)
    if row.get("sha256") != digest or row.get("mode") != mode:
        failures.append({"overlay_mismatch": relative, "expected_sha256": digest, "candidate": row})
report = {"accepted": not failures, "expected_path_count": len(expected), "failures": failures}
output_path.write_text(json.dumps(report, sort_keys=True, separators=(",", ":")) + "\n")
raise SystemExit(0 if report["accepted"] else 1)
