#!/usr/bin/env python3
"""Freeze and verify exact ordinary/tagged method-body extractions."""

from __future__ import annotations

from pathlib import Path


CHECKPOINT = Path(__file__).resolve().parent
ROOT = CHECKPOINT.parents[1]
BASELINE = ROOT / "review" / "baseline-files-8ac4c8d" / "third_party" / "yamux"
CP4 = ROOT / "review" / "source-checkpoint-4" / "source" / "third_party" / "yamux"
CP5 = CHECKPOINT / "source" / "third_party" / "yamux"
OUTPUT = CHECKPOINT / "body-extractions"


def between(path: Path, start: str, end: str | None) -> str:
    text = path.read_text(encoding="utf-8")
    first = text.index(start)
    last = text.index(end, first) if end is not None else len(text)
    return text[first:last].rstrip() + "\n"


def save(name: str, value: str) -> None:
    (OUTPUT / name).write_text(value, encoding="utf-8")


def main() -> None:
    send_start = "func (s *Session) sendLoop() error {"
    send_end = "// recv is a long running goroutine that accepts new data"
    write_start = "// write is used to write to the stream, may return on\n// a short write.\n"
    write_end = "// sendFlags determines any flags that are appropriate"

    ordinary_send = between(BASELINE / "session.go", send_start, send_end)
    tagged_send = between(CP4 / "session.go", send_start, send_end)
    ordinary_write = between(BASELINE / "stream.go", write_start, write_end)
    tagged_write = between(CP4 / "stream.go", write_start, write_end)

    values = {
        "baseline-session-send-loop.txt": ordinary_send,
        "cp4-tagged-session-send-loop.txt": tagged_send,
        "baseline-stream-write.txt": ordinary_write,
        "cp4-tagged-stream-write.txt": tagged_write,
        "cp5-ordinary-session-send-loop.txt": between(
            CP5 / "session_send_loop_ordinary.go", send_start, None
        ),
        "cp5-tagged-session-send-loop.txt": between(
            CP5 / "session_send_loop_qualification.go", send_start, None
        ),
        "cp5-ordinary-stream-write.txt": between(
            CP5 / "stream_write_ordinary.go", write_start, None
        ),
        "cp5-tagged-stream-write.txt": between(
            CP5 / "stream_write_qualification.go", write_start, None
        ),
    }
    for name, value in values.items():
        save(name, value)

    comparisons = {
        "ordinary_session_send_loop": values["baseline-session-send-loop.txt"]
        == values["cp5-ordinary-session-send-loop.txt"],
        "tagged_session_send_loop": values["cp4-tagged-session-send-loop.txt"]
        == values["cp5-tagged-session-send-loop.txt"],
        "ordinary_stream_write": values["baseline-stream-write.txt"]
        == values["cp5-ordinary-stream-write.txt"],
        "tagged_stream_write": values["cp4-tagged-stream-write.txt"]
        == values["cp5-tagged-stream-write.txt"],
    }
    (OUTPUT / "comparisons.txt").write_text(
        "".join(f"{name}={str(ok).lower()}\n" for name, ok in comparisons.items()),
        encoding="utf-8",
    )
    if not all(comparisons.values()):
        raise SystemExit("body extraction mismatch")


if __name__ == "__main__":
    main()
