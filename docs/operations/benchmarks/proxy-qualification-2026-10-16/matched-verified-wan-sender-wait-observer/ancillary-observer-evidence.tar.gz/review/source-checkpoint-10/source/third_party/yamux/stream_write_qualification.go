//go:build p2pstream_qualification

package yamux

import (
	"errors"
	"sync/atomic"
	"time"
)

// write is used to write to the stream, may return on
// a short write.
func (s *Stream) write(b []byte) (n int, err error) {
	var flags uint16
	var max uint32
	var body []byte
	var aggregateNotify <-chan struct{}
	var qualificationWait qualificationAggregateSendWait
START:
	aggregateNotify = nil
	s.stateLock.Lock()
	switch s.state {
	case streamLocalClose:
		fallthrough
	case streamClosed:
		s.stateLock.Unlock()
		return 0, ErrStreamClosed
	case streamReset:
		s.stateLock.Unlock()
		return 0, ErrConnectionReset
	}
	s.stateLock.Unlock()

	// If there is no data available, block
	window := atomic.LoadUint32(&s.sendWindow)
	if window == 0 {
		if qualificationAggregateSendCountersEnabled && s.session.aggregateEnabled() {
			qualificationWait = s.beginQualificationByteCreditWait()
		}
		goto WAIT
	}

	// Send up to our send window
	max = min(window, uint32(len(b)))
	if s.session.aggregateEnabled() {
		max, aggregateNotify = s.reserveAggregateSend(max)
		if max == 0 {
			if qualificationAggregateSendCountersEnabled {
				qualificationWait = s.takeQualificationAggregateCreditWaitDecision()
			}
			goto WAIT
		}
	}
	// Determine flags only after all DATA credit is reserved. Otherwise a
	// blocked first write could consume SYN without putting it on the wire.
	flags = s.sendFlags()
	body = b[:max]

	// Send the header
	s.sendHdr.encode(typeData, flags, s.id, max)
	if err = s.session.waitForSendErr(s.sendHdr, body, s.sendErr); err != nil {
		if errors.Is(err, ErrSessionShutdown) || errors.Is(err, ErrConnectionWriteTimeout) {
			// Message left in ready queue, header re-use is unsafe.
			s.sendHdr = header(make([]byte, headerSize))
		}
		if s.session.aggregateEnabled() {
			// A timeout can race a queued write. Session credit cannot safely be
			// restored without knowing whether the peer observed the frame.
			s.session.abortAggregate(err)
		}
		return 0, err
	}

	// Reduce our send window
	atomic.AddUint32(&s.sendWindow, ^uint32(max-1))

	// Unlock
	return int(max), err

WAIT:
	var timeout <-chan time.Time
	var timer *time.Timer
	writeDeadline := s.writeDeadline.Load().(time.Time)
	if !writeDeadline.IsZero() {
		delay := time.Until(writeDeadline)
		if delay <= 0 {
			if qualificationAggregateSendCountersEnabled {
				s.finishQualificationCreditWait(qualificationWait, qualificationCreditWakeTimeout)
			}
			return 0, ErrTimeout
		}
		timer = time.NewTimer(delay)
		timeout = timer.C
	}
	select {
	case <-s.session.shutdownCh:
		if qualificationAggregateSendCountersEnabled {
			s.finishQualificationCreditWait(qualificationWait, qualificationCreditWakeShutdown)
		}
		stopDeadlineTimer(timer)
		// No DATA credit has been reserved at WAIT. Once shutdown begins no
		// future credit can make this write safe, so return instead of spinning
		// until Session.Close eventually marks every stream terminal.
		return 0, ErrSessionShutdown
	case <-s.sendNotifyCh:
		if qualificationAggregateSendCountersEnabled {
			s.finishQualificationCreditWait(qualificationWait, qualificationCreditWakeByteNotify)
		}
	case <-aggregateNotify:
		if qualificationAggregateSendCountersEnabled {
			s.finishQualificationCreditWait(qualificationWait, qualificationCreditWakeAggregateNotify)
		}
	case <-timeout:
		if qualificationAggregateSendCountersEnabled {
			s.finishQualificationCreditWait(qualificationWait, qualificationCreditWakeTimeout)
		}
		return 0, ErrTimeout
	}
	stopDeadlineTimer(timer)
	goto START
}
