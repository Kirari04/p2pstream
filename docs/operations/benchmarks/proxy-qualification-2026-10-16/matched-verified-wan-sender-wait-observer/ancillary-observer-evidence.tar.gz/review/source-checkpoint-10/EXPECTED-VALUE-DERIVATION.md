# Attempt 4 expected-value derivation record

The two expected hashes in `test-extract-layout-contract.py` were calculated
offline during checkpoint-8 source preparation from the already closed attempt
4 baseline JSONL. This was a read-only source-preparation calculation. It was
not an execution of the checkpoint-8 extractor, did not change attempt 4, and
did not turn attempt 4's failed audit into a pass.

The original calculation did not write a command or status sidecar. The
available source-preparation tool record binds the input JSONL SHA-256 to
`b5a60bffd13f44c0f8da839ce63302442140f852af182428b5f8359d25a59b56`
and records this algorithm:

1. Decode every existing JSONL event.
2. In original order, concatenate `Output` strings only when `Test` is
   `TestQualificationBaselineCandidateTypeLayoutProbe`, `Package` is
   `github.com/hashicorp/yamux`, and `Action` is `output`.
3. Take the complete line after the single `QUALIFICATION_LAYOUT_JSON=` marker
   and decode that JSON value.
4. Serialize it with Python `json.dumps(sort_keys=True,
   separators=(",", ":"))` and one trailing newline.
5. Serialize the audit object containing accepted=true, runs=1, passes=1,
   package_passes=1, and the ordered four type names with the same settings and
   one trailing newline.

The source-preparation tool record printed:

- canonical layout: 10,725 bytes, SHA-256
  `d2776d79609c7a3636942a9b997260e59eaaf0eb0c9fc048b244961ec13edf62`
- audit: 116 bytes, SHA-256
  `03b1c00c3ea5025783b9839971a5b3a8422f3d5cbfd8bd16ef8a9ef2d14316f7`

Checkpoint 9's future focused contract will independently reproduce these
values into a fresh persistent evidence directory. Until that separately
authorized execution, they remain source-preparation expected values.
