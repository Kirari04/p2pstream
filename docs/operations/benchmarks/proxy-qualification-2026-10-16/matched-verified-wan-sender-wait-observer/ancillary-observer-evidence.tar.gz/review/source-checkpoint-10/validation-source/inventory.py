#!/usr/bin/env python3
import hashlib, json, os, stat, sys
from pathlib import Path
root=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2])
rows=[]
for p in sorted(root.rglob('*')):
    rel=p.relative_to(root).as_posix()
    st=p.lstat()
    mode=stat.S_IMODE(st.st_mode)
    if p.is_symlink():
        rows.append({'path':rel,'type':'symlink','mode':mode,'target':os.readlink(p)})
    elif p.is_file():
        h=hashlib.sha256()
        with p.open('rb') as f:
            for chunk in iter(lambda:f.read(1024*1024),b''):
                h.update(chunk)
        rows.append({'path':rel,'type':'file','mode':mode,'size':st.st_size,'sha256':h.hexdigest()})
out.write_text(json.dumps(rows,sort_keys=True,separators=(',',':'))+'\n')
