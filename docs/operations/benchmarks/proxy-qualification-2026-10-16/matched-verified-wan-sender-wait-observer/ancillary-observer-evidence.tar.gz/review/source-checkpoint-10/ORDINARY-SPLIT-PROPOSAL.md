# cp4 ordinary-body split proposal

This is a source-only boundary analysis. It does not modify cp4, build code, or authorize runtime use. Attempt 3 remains frozen and rejected for exact ordinary instruction identity.

## Concrete boundary

Only two methods need separate build-tagged declarations:

1. `(*Session).sendLoop`, currently `source-checkpoint-4/source/third_party/yamux/session.go:637-736`.
2. `(*Stream).write`, including its two-line method comment, currently `source-checkpoint-4/source/third_party/yamux/stream.go:309-419`.

Leave `(*Session).send`, `(*Stream).Write`, `waitForSendErrCommitOn`, all types, all other methods, and all qualification ledger helpers in their current files. This avoids duplicating `Session`, `Stream`, or unrelated runtime implementations.

Create four files in `third_party/yamux`:

- `session_send_loop_ordinary.go`, `//go:build !p2pstream_qualification`: `bytes` and `io` imports; the **verbatim pinned 8ac4c8d baseline** `sendLoop` body.
- `session_send_loop_qualification.go`, `//go:build p2pstream_qualification`: `bytes` and `io` imports; the **verbatim cp4 tagged** `sendLoop` body.
- `stream_write_ordinary.go`, `//go:build !p2pstream_qualification`: `errors`, `sync/atomic`, and `time` imports; the method comment and **verbatim pinned 8ac4c8d baseline** `write` body. That baseline body deliberately retains the pre-existing zero-credit counter call guarded by the ordinary false constant.
- `stream_write_qualification.go`, `//go:build p2pstream_qualification`: the same three imports; the method comment and **verbatim cp4 tagged** `write` body.

Delete only those two declarations from `session.go` and `stream.go`. Remove `bytes` from `session.go:5`, because its only package-qualified use is `bytes.Buffer` inside `sendLoop`. Keep `io` in `session.go`: it remains required by the connection field, constructors, receive path, and discard path. No `stream.go` import should be removed: `errors`, `sync/atomic`, and `time` all have uses outside `write` as well as inside the split method.

The ordinary and tagged files are mutually exclusive. `qualification_aggregate_send_counters_disabled.go` continues to supply the false constant and no-op types/helpers to the ordinary build. No queue, lock, timeout, shutdown, wire, credit, or request semantics change is proposed.

## Why this is the smallest structural correction

Attempt 3 proved equal function sizes and frames, but cp4's shared `sendLoop` produced five different machine instructions around the indirect `conn.Write` interface call, and shared `Stream.write` raised the compiler inliner cost from 1227 to 1231. Constant folding removed observer work yet did not preserve the compiler's SSA/local choices. Putting the exact baseline bodies in ordinary-only files removes all new diagnostic syntax from those two ordinary methods without register-tuning no-ops or widening the split.

Other affected functions already had exact ordinary instruction bytes after function-address normalization. They remain shared.

## Fail-closed proof plan

A future reviewed checkpoint should be validated from fresh explicit `git -C <active-worktree> archive` baseline and candidate trees, pinned Go 1.26.6, offline modules, owned ext4 caches, and exact root/nested-Yamux `GOMOD` gates.

Before execution:

- Verify full baseline and candidate inventories and the exact overlay file set.
- Verify `go list` selects both ordinary files and excludes both tagged files without the tag, then selects both tagged files and excludes both ordinary files with `p2pstream_qualification`.
- Extract and compare each ordinary method body to the pinned baseline as syntax/text, allowing only its enclosing new filename/build-tag/import context.
- Verify the tagged method bodies match cp4 exactly.

Focused validation should retain the already reviewed exact test enumeration: 19 Yamux qualification tests in normal and race modes, two agent schema tests, two server schema tests, and the ordinary layout test. Direct tool status, JSON enumeration audit, and outer status must all be zero.

The ordinary proof must compare fresh baseline and candidate builds with identical settings:

- relevant `go tool nm -size` symbols;
- compiler STEXT size, args, locals, frame, stack maps, and escape decisions;
- package-archive machine instructions and relocation annotations for the same nine affected functions;
- strict function-relative address normalization only. Preserve instruction bytes/order/opcodes/operands and symbolic relocations. Preserve source file/line metadata separately and report its expected movement rather than treating whole archives or binaries as byte-identical.

Acceptance requires zero real instruction differences, exact frame/layout equality, and the baseline `Stream.write` inliner result/cost (1227, still non-inlineable). A source-path/line-table difference is metadata, but any changed opcode, operand, instruction byte, stack/frame, escape classification, or compiler cost remains a proof failure. Tagged test success cannot override an ordinary proof failure.

The current cp4/attempt-3 artifacts remain immutable regardless of a later checkpoint result.
