#!/usr/bin/env bash
set -uo pipefail
attempt_root=$(cd "$(dirname "$0")" && pwd)
go_bin=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
export GOTOOLCHAIN=local GOPROXY=off GOMODCACHE=/home/user/go/pkg/mod GOPATH="$attempt_root/gopath" GOTMPDIR="$attempt_root/tmp" TMPDIR="$attempt_root/tmp" GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=16
: >"$attempt_root/outputs/layout-status.tsv"
: >"$attempt_root/outputs/layout-commands.txt"
run_one() {
  local side=$1 source="$attempt_root/$1/source/third_party/yamux" cache="$attempt_root/cache/$1-layout"
  mkdir -p "$cache"
  printf '%s\tcd %q && GOCACHE=%q taskset -c 0-15 %q test -json -v -count=1 . -run %q\n' "$side" "$source" "$cache" "$go_bin" '^TestQualificationBaselineCandidateTypeLayoutProbe$' >>"$attempt_root/outputs/layout-commands.txt"
  date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/$side-layout.start-utc"
  (cd "$source" && GOCACHE="$cache" taskset -c 0-15 "$go_bin" test -json -v -count=1 . -run '^TestQualificationBaselineCandidateTypeLayoutProbe$') >"$attempt_root/outputs/$side-layout.stdout.jsonl" 2>"$attempt_root/outputs/$side-layout.stderr"
  local direct=$?
  printf '%d\n' "$direct" >"$attempt_root/outputs/$side-layout.direct.status"
  if [[ "$direct" -ne 0 ]]; then return "$direct"; fi
  python3 -I "$attempt_root/extract-layout.py" "$attempt_root/outputs/$side-layout.stdout.jsonl" "$attempt_root/outputs/$side-layout.direct.status" "$attempt_root/outputs/$side-layout.json" "$attempt_root/outputs/$side-layout.audit.json"
  local audit=$?
  printf '%d\n' "$audit" >"$attempt_root/outputs/$side-layout.audit.status"
  date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/$side-layout.end-utc"
  printf '%s\t%d\t%d\n' "$side" "$direct" "$audit" >>"$attempt_root/outputs/layout-status.tsv"
  return "$audit"
}
run_one baseline || exit $?
run_one candidate || exit $?
