//go:build !p2pstream_qualification

package yamux

import (
	"encoding/json"
	"reflect"
	"testing"
	"unsafe"
)

type qualificationLayoutProbeField struct {
	Index     int     `json:"index"`
	Name      string  `json:"name"`
	Type      string  `json:"type"`
	Offset    uintptr `json:"offset"`
	Size      uintptr `json:"size"`
	Align     int     `json:"align"`
	Anonymous bool    `json:"anonymous"`
}

type qualificationLayoutProbeType struct {
	Name       string                          `json:"name"`
	Size       uintptr                         `json:"size"`
	Align      uintptr                         `json:"align"`
	FieldCount int                             `json:"field_count"`
	Fields     []qualificationLayoutProbeField `json:"fields"`
}

func qualificationProbeLayout(name string, value any, size, align uintptr) qualificationLayoutProbeType {
	typ := reflect.TypeOf(value)
	fields := make([]qualificationLayoutProbeField, 0, typ.NumField())
	for index := 0; index < typ.NumField(); index++ {
		field := typ.Field(index)
		fields = append(fields, qualificationLayoutProbeField{
			Index:     index,
			Name:      field.Name,
			Type:      field.Type.String(),
			Offset:    field.Offset,
			Size:      field.Type.Size(),
			Align:     field.Type.Align(),
			Anonymous: field.Anonymous,
		})
	}
	return qualificationLayoutProbeType{
		Name: name, Size: size, Align: align, FieldCount: typ.NumField(), Fields: fields,
	}
}

func TestQualificationBaselineCandidateTypeLayoutProbe(t *testing.T) {
	records := []qualificationLayoutProbeType{
		qualificationProbeLayout("Stream", Stream{}, unsafe.Sizeof(Stream{}), unsafe.Alignof(Stream{})),
		qualificationProbeLayout("Session", Session{}, unsafe.Sizeof(Session{}), unsafe.Alignof(Session{})),
		qualificationProbeLayout("aggregateWindow", aggregateWindow{}, unsafe.Sizeof(aggregateWindow{}), unsafe.Alignof(aggregateWindow{})),
		qualificationProbeLayout("sendReady", sendReady{}, unsafe.Sizeof(sendReady{}), unsafe.Alignof(sendReady{})),
	}
	encoded, err := json.Marshal(records)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("QUALIFICATION_LAYOUT_JSON=%s", encoded)
}
