#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then echo 'usage: run-extract-layout-contract.sh ATTEMPT4_ROOT' >&2; exit 64; fi
attempt_root=$(cd "$(dirname "$0")" && pwd)
reuse_root=$(cd "$1" && pwd)
jsonl="$reuse_root/outputs/baseline-layout.stdout.jsonl"
direct="$reuse_root/outputs/baseline-layout.direct.status"
evidence="$attempt_root/outputs/extract-layout-contract-cases"
[[ ! -e "$evidence" ]] || { echo 'extractor contract evidence path is not fresh' >&2; exit 65; }
printf '%q -I %q %q %q %q %q\n' \
  python3 "$attempt_root/test-extract-layout-contract.py" "$attempt_root/extract-layout.py" "$jsonl" "$direct" "$evidence" \
  >"$attempt_root/outputs/extract-layout-contract.command"
sha256sum "$attempt_root/extract-layout.py" "$attempt_root/test-extract-layout-contract.py" "$jsonl" "$direct" \
  >"$attempt_root/inputs/extract-layout-contract-inputs.sha256"
date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/extract-layout-contract.start-utc"
export TMPDIR="$attempt_root/tmp"
set +e
python3 -I "$attempt_root/test-extract-layout-contract.py" "$attempt_root/extract-layout.py" "$jsonl" "$direct" "$evidence" \
  >"$attempt_root/outputs/extract-layout-contract.stdout" \
  2>"$attempt_root/outputs/extract-layout-contract.stderr"
status=$?
set -e
date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/extract-layout-contract.end-utc"
printf '%d\n' "$status" >"$attempt_root/outputs/extract-layout-contract.status"
exit "$status"
