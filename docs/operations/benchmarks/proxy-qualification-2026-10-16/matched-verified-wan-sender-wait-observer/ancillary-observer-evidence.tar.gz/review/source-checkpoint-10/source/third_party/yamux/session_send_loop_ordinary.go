//go:build !p2pstream_qualification

package yamux

import (
	"bytes"
	"io"
)

func (s *Session) sendLoop() error {
	defer close(s.sendDoneCh)
	var bodyBuf bytes.Buffer
	for {
		bodyBuf.Reset()
		var ready *sendReady
		// Once a control is queued, select it before the bulk FIFO. A control
		// arriving concurrently may follow at most the one DATA frame selected
		// in the fallback below.
		select {
		case <-s.shutdownCh:
			return nil
		default:
		}
		select {
		case ready = <-s.controlCh:
		default:
			select {
			case ready = <-s.controlCh:
			case ready = <-s.sendCh:
			case <-s.shutdownCh:
				return nil
			}
		}

		// A DATA caller retains ownership of its body until this worker detaches
		// it under ready.mu. Copy both header and body before the first physical
		// byte: a concurrent timeout can then return and reuse the body safely.
		// A caller whose queued header times out replaces that header before
		// reuse, so the queued backing remains stable. Header-only controls stay
		// separate.
		var frame []byte
		ready.mu.Lock()
		if ready.Body != nil {
			bodyBuf.Grow(len(ready.Hdr) + len(ready.Body))
			_, err := bodyBuf.Write(ready.Hdr)
			if err == nil {
				_, err = bodyBuf.Write(ready.Body)
			}
			if err != nil {
				ready.Body = nil
				ready.mu.Unlock()
				s.logger.Printf("[ERR] yamux: Failed to gather frame: %v", err)
				asyncSendErr(ready.Err, err)
				return err
			}
			ready.Body = nil
			frame = bodyBuf.Bytes()
		}
		ready.mu.Unlock()

		if frame == nil {
			frame = ready.Hdr
		}
		if len(frame) > 0 {
			if ready.Commit != nil {
				ready.Commit()
			}
			written, err := s.conn.Write(frame)
			if err == nil && written != len(frame) {
				err = io.ErrShortWrite
			}
			if err != nil {
				s.logger.Printf("[ERR] yamux: Failed to write frame: %v", err)
				asyncSendErr(ready.Err, err)
				return err
			}
		}

		asyncSendErr(ready.Err, nil)
	}
}
