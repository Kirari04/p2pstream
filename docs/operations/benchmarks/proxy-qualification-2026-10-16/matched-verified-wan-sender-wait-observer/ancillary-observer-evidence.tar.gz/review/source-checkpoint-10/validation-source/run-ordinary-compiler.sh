#!/usr/bin/env bash
set -uo pipefail
attempt_root="$(cd "$(dirname "$0")" && pwd)"
go_bin=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
export GOTOOLCHAIN=local GOPROXY=off GOMODCACHE=/home/user/go/pkg/mod GOPATH="$attempt_root/gopath" GOTMPDIR="$attempt_root/tmp" TMPDIR="$attempt_root/tmp" GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=16
: >"$attempt_root/outputs/ordinary-compiler-status.tsv"; : >"$attempt_root/outputs/ordinary-compiler-commands.txt"
run_compile() {
 local name=$1 source=$2 cache=$3 flag=$4
 mkdir -p "$cache"
 printf '%s\tcd %q && GOCACHE=%q taskset -c 0-15 %q build -a -trimpath -gcflags=%q .\n' "$name" "$source" "$cache" "$go_bin" "github.com/hashicorp/yamux=$flag" >>"$attempt_root/outputs/ordinary-compiler-commands.txt"
 date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/$name.start-utc"
 (cd "$source" && GOCACHE="$cache" taskset -c 0-15 "$go_bin" build -a -trimpath -gcflags="github.com/hashicorp/yamux=$flag" .) >"$attempt_root/outputs/$name.stdout" 2>"$attempt_root/outputs/$name.stderr"
 local status=$?
 date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/$name.end-utc"
 printf '%s\t%d\n' "$name" "$status" >>"$attempt_root/outputs/ordinary-compiler-status.tsv"
 return "$status"
}
run_compile baseline-ordinary-asm "$attempt_root/baseline/source/third_party/yamux" "$attempt_root/cache/baseline-ordinary-asm" -S || exit $?
run_compile candidate-ordinary-asm "$attempt_root/candidate/source/third_party/yamux" "$attempt_root/cache/candidate-ordinary-asm" -S || exit $?
run_compile baseline-ordinary-escape "$attempt_root/baseline/source/third_party/yamux" "$attempt_root/cache/baseline-ordinary-escape" -m=2 || exit $?
run_compile candidate-ordinary-escape "$attempt_root/candidate/source/third_party/yamux" "$attempt_root/cache/candidate-ordinary-escape" -m=2 || exit $?
