//go:build p2pstream_qualification

package yamux

import (
	"bytes"
	"io"
)

func (s *Session) sendLoop() error {
	defer close(s.sendDoneCh)
	if qualificationAggregateSendCountersEnabled {
		// This defer is registered after close(sendDoneCh), so the tagged
		// terminal ledger transition runs first. A sendDoneCh/Close join thus
		// publishes final diagnostic ownership rather than racing it.
		defer s.finishQualificationSendLoop()
	}
	var bodyBuf bytes.Buffer
	for {
		bodyBuf.Reset()
		var ready *sendReady
		// Once a control is queued, select it before the bulk FIFO. A control
		// arriving concurrently may follow at most the one DATA frame selected
		// in the fallback below.
		select {
		case <-s.shutdownCh:
			return nil
		default:
		}
		select {
		case ready = <-s.controlCh:
		default:
			select {
			case ready = <-s.controlCh:
			case ready = <-s.sendCh:
			case <-s.shutdownCh:
				return nil
			}
		}

		// A DATA caller retains ownership of its body until this worker detaches
		// it under ready.mu. Copy both header and body before the first physical
		// byte: a concurrent timeout can then return and reuse the body safely.
		// A caller whose queued header times out replaces that header before
		// reuse, so the queued backing remains stable. Header-only controls stay
		// separate.
		var frame []byte
		dataStreamID := uint32(0)
		dataPayloadBytes := 0
		ready.mu.Lock()
		if ready.Body != nil {
			if qualificationAggregateSendCountersEnabled {
				dataStreamID = header(ready.Hdr).StreamID()
				dataPayloadBytes = len(ready.Body)
			}
			bodyBuf.Grow(len(ready.Hdr) + len(ready.Body))
			_, err := bodyBuf.Write(ready.Hdr)
			if err == nil {
				_, err = bodyBuf.Write(ready.Body)
			}
			if err != nil {
				ready.Body = nil
				ready.mu.Unlock()
				if qualificationAggregateSendCountersEnabled {
					s.finishQualificationGatherError(dataStreamID, dataPayloadBytes)
				}
				s.logger.Printf("[ERR] yamux: Failed to gather frame: %v", err)
				asyncSendErr(ready.Err, err)
				return err
			}
			ready.Body = nil
			frame = bodyBuf.Bytes()
		}
		ready.mu.Unlock()

		if frame == nil {
			frame = ready.Hdr
		}
		if len(frame) > 0 {
			if ready.Commit != nil {
				ready.Commit()
			}
			var qualificationPhysicalWait qualificationDataSendWait
			if qualificationAggregateSendCountersEnabled && dataPayloadBytes > 0 {
				qualificationPhysicalWait = s.beginQualificationPhysicalDataWrite(dataStreamID, dataPayloadBytes, len(frame))
			}
			written, err := s.conn.Write(frame)
			if qualificationAggregateSendCountersEnabled && dataPayloadBytes > 0 {
				outcome := qualificationPhysicalWriteSuccess
				if err != nil {
					outcome = qualificationPhysicalWriteError
				} else if written != len(frame) {
					outcome = qualificationPhysicalWriteShort
				}
				s.finishQualificationPhysicalDataWrite(qualificationPhysicalWait, outcome, len(frame), written)
			}
			if err == nil && written != len(frame) {
				err = io.ErrShortWrite
			}
			if err != nil {
				s.logger.Printf("[ERR] yamux: Failed to write frame: %v", err)
				asyncSendErr(ready.Err, err)
				return err
			}
		}

		asyncSendErr(ready.Err, nil)
	}
}
