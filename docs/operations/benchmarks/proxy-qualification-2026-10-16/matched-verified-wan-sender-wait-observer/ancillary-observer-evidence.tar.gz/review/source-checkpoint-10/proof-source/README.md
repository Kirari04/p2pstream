# Ordinary proof source

This source is frozen for review only. It has not been built or executed.

Apply `ordinary_layout_probe_test.go` identically as a validation-only overlay
to fresh pinned baseline and candidate Yamux trees. `extract-layout.py` in the
validation source requires the exact named test, package pass, one marker, and
direct tool status 0. The overlay is not observer production source.

`compare_ordinary_v2.py` consumes bounded regular files for each side's
package-archive objdump and nm output, compiler `-S` and `-m=2` output,
extracted layout JSON, and source root. It requires a fresh output directory.

The comparator gates:

- exact relevant text-symbol cardinality and sizes from `nm -size`;
- instruction bytes/order/opcodes/operands and relocation annotations, after
  normalizing only whole-function addresses and in-function targets;
- compiler frames plus PCDATA/FUNCDATA records and the exact bytes/relocations
  of every referenced stack/argument data block, including `gclocals`;
- every `-m=2` diagnostic whose primary source location is inside one of the
  five affected parent method spans, including nested closures. Records are
  grouped per parent function, source positions alone are normalized, and full
  text/counts/costs/continuations are preserved;
- complete size/alignment/ordered-field layout for `Stream`, `Session`,
  `aggregateWindow`, and `sendReady`.

The driver separately binds pinned Go, source inventories, exact commands,
direct tool statuses, parser/comparator status, source pre/post hashes, and
outer shell status. A nonzero producer or partial input cannot yield an
accepted report.
