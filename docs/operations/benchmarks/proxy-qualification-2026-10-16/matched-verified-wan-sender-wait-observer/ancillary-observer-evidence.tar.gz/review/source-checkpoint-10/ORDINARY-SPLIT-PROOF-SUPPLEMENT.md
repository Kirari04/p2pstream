# Ordinary split proposal: proof additions

This supplements and preserves `source-checkpoint-4-ordinary-split-proposal.md` (SHA-256 `b11f6ebe6b2eec779c1b12b9ce0960b86f4671dc8439df5c67e00db8b7e5eb7e`).

The future proof's overall acceptance must require all of the following independently:

- exact relevant machine instructions after only function-address/relocation normalization;
- exact symbol size, compiler frame, stack metadata, and escape/classification records;
- exact per-function inliner decisions and costs, including baseline `Stream.write` cost 1227;
- exact full layouts for `Stream`, `Session`, `aggregateWindow`, and `sendReady`.

Escape output must be parsed into per-function records instead of compared in arbitrary global output order. Normalization may remove only source file/line/column positions. It must retain the full decision/classification text, costs, parameter names, escape destination and dereference counts, capture widths, and supporting flow details. The acceptance predicate must explicitly include equality of those per-function records.

Add one identical ordinary-only **test overlay**, applied separately to the pinned baseline and candidate validation trees and excluded from observer production source. Its frozen source hash must be bound before execution. The probe must report for each of `Stream`, `Session`, `aggregateWindow`, and `sendReady`:

- `unsafe.Sizeof` and `unsafe.Alignof` the complete type;
- declared field count and declaration order;
- every field name, type string, `StructField.Offset`, `StructField.Type.Size()`, and `StructField.Type.Align()` via reflection.

Baseline and candidate probe JSON must compare exactly. The probe's direct status, exact test enumeration, and outer status must be retained. The existing ordinary-layout test remains useful but cannot substitute for this complete comparison.

These additions do not authorize an implementation, build, or test and do not alter cp4 or attempt 3.
