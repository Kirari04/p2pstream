#!/usr/bin/env bash
set -uo pipefail
attempt_root="$(cd "$(dirname "$0")" && pwd)"
go_bin=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
export GOTOOLCHAIN=local GOPROXY=off GOMODCACHE=/home/user/go/pkg/mod
export GOPATH="$attempt_root/gopath" GOTMPDIR="$attempt_root/tmp" TMPDIR="$attempt_root/tmp"
export GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=16
: >"$attempt_root/outputs/ordinary-build-status.tsv"
: >"$attempt_root/outputs/ordinary-build-commands.txt"
run_build() {
  local name=$1 source=$2 cache=$3 binary=$4
  mkdir -p "$cache"
  printf '%s\tcd %q && GOCACHE=%q taskset -c 0-15 %q test -c -trimpath -o %q .\n' "$name" "$source" "$cache" "$go_bin" "$binary" >>"$attempt_root/outputs/ordinary-build-commands.txt"
  date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/$name.start-utc"
  (cd "$source" && GOCACHE="$cache" taskset -c 0-15 "$go_bin" test -c -trimpath -o "$binary" .) >"$attempt_root/outputs/$name.stdout" 2>"$attempt_root/outputs/$name.stderr"
  local status=$?
  date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$attempt_root/outputs/$name.end-utc"
  printf '%s\t%d\n' "$name" "$status" >>"$attempt_root/outputs/ordinary-build-status.tsv"
  return "$status"
}
run_build baseline-ordinary-build "$attempt_root/baseline/source/third_party/yamux" "$attempt_root/cache/baseline-ordinary-build" "$attempt_root/outputs/baseline-yamux.test" || exit $?
run_build candidate-ordinary-build "$attempt_root/candidate/source/third_party/yamux" "$attempt_root/cache/candidate-ordinary-build" "$attempt_root/outputs/candidate-yamux.test" || exit $?
