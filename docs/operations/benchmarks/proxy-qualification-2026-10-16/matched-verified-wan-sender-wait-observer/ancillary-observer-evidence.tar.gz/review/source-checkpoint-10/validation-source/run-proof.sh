#!/usr/bin/env bash
set -uo pipefail
attempt_root=$(cd "$(dirname "$0")" && pwd)
go_bin=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
export GOTOOLCHAIN=local GOPROXY=off GOMODCACHE=/home/user/go/pkg/mod GOPATH="$attempt_root/gopath" GOTMPDIR="$attempt_root/tmp" TMPDIR="$attempt_root/tmp" GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=16
pattern=$(cat "$attempt_root/inputs/ordinary-symbol-pattern.txt")
: >"$attempt_root/outputs/ordinary-inspection-status.tsv"
: >"$attempt_root/outputs/ordinary-inspection-commands.txt"
run_tool() {
  local name=$1; shift
  printf '%s' "$name" >>"$attempt_root/outputs/ordinary-inspection-commands.txt"; printf ' %q' "$@" >>"$attempt_root/outputs/ordinary-inspection-commands.txt"; printf '\n' >>"$attempt_root/outputs/ordinary-inspection-commands.txt"
  "$@" >"$attempt_root/outputs/$name.stdout" 2>"$attempt_root/outputs/$name.stderr"
  local status=$?
  printf '%s\t%d\n' "$name" "$status" >>"$attempt_root/outputs/ordinary-inspection-status.tsv"
  printf '%d\n' "$status" >"$attempt_root/outputs/$name.direct.status"
  return "$status"
}
run_tool baseline-archive-nm "$go_bin" tool nm -size "$attempt_root/outputs/baseline-yamux.a" || exit $?
run_tool candidate-archive-nm "$go_bin" tool nm -size "$attempt_root/outputs/candidate-yamux.a" || exit $?
mv "$attempt_root/outputs/baseline-archive-nm.stdout" "$attempt_root/outputs/baseline-archive.nm" || exit $?
mv "$attempt_root/outputs/candidate-archive-nm.stdout" "$attempt_root/outputs/candidate-archive.nm" || exit $?
run_tool baseline-archive-objdump "$go_bin" tool objdump -s "$pattern" "$attempt_root/outputs/baseline-yamux.a" || exit $?
run_tool candidate-archive-objdump "$go_bin" tool objdump -s "$pattern" "$attempt_root/outputs/candidate-yamux.a" || exit $?
mv "$attempt_root/outputs/baseline-archive-objdump.stdout" "$attempt_root/outputs/baseline-archive.objdump" || exit $?
mv "$attempt_root/outputs/candidate-archive-objdump.stdout" "$attempt_root/outputs/candidate-archive.objdump" || exit $?
python3 -I "$attempt_root/inputs/compare_ordinary_v2.py" \
  --baseline-objdump "$attempt_root/outputs/baseline-archive.objdump" \
  --baseline-nm "$attempt_root/outputs/baseline-archive.nm" \
  --baseline-asm "$attempt_root/outputs/baseline-ordinary-asm.stderr" \
  --baseline-escape "$attempt_root/outputs/baseline-ordinary-escape.stderr" \
  --baseline-layout "$attempt_root/outputs/baseline-layout.json" \
  --baseline-source-root "$attempt_root/baseline/source/third_party/yamux" \
  --candidate-objdump "$attempt_root/outputs/candidate-archive.objdump" \
  --candidate-nm "$attempt_root/outputs/candidate-archive.nm" \
  --candidate-asm "$attempt_root/outputs/candidate-ordinary-asm.stderr" \
  --candidate-escape "$attempt_root/outputs/candidate-ordinary-escape.stderr" \
  --candidate-layout "$attempt_root/outputs/candidate-layout.json" \
  --candidate-source-root "$attempt_root/candidate/source/third_party/yamux" \
  --output "$attempt_root/outputs/ordinary-proof-v2" \
  >"$attempt_root/outputs/ordinary-proof-v2.stdout" 2>"$attempt_root/outputs/ordinary-proof-v2.stderr"
status=$?
printf '%d\n' "$status" >"$attempt_root/outputs/ordinary-proof-v2.direct.status"
printf 'ordinary-proof-v2\t%d\n' "$status" >>"$attempt_root/outputs/ordinary-inspection-status.tsv"
exit "$status"
