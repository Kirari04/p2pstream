#!/usr/bin/env python3
import json
import sys
from pathlib import Path

ordinary_path, tagged_path, output_path = map(Path, sys.argv[1:])
ordinary = json.loads(ordinary_path.read_text())
tagged = json.loads(tagged_path.read_text())
ordinary_only = {"session_send_loop_ordinary.go", "stream_write_ordinary.go"}
tagged_only = {"session_send_loop_qualification.go", "stream_write_qualification.go"}
failures = []
if ordinary.get("ImportPath") != "github.com/hashicorp/yamux" or tagged.get("ImportPath") != "github.com/hashicorp/yamux":
    failures.append("unexpected import path")
ordinary_files = set(ordinary.get("GoFiles", []))
tagged_files = set(tagged.get("GoFiles", []))
if not ordinary_only <= ordinary_files or tagged_only & ordinary_files:
    failures.append({"ordinary_go_files": sorted(ordinary_files)})
if not tagged_only <= tagged_files or ordinary_only & tagged_files:
    failures.append({"tagged_go_files": sorted(tagged_files)})
if not tagged_only <= set(ordinary.get("IgnoredGoFiles", [])):
    failures.append({"ordinary_ignored_go_files": ordinary.get("IgnoredGoFiles", [])})
if not ordinary_only <= set(tagged.get("IgnoredGoFiles", [])):
    failures.append({"tagged_ignored_go_files": tagged.get("IgnoredGoFiles", [])})
report = {
    "accepted": not failures,
    "ordinary_selected": sorted(ordinary_only & ordinary_files),
    "tagged_selected": sorted(tagged_only & tagged_files),
    "failures": failures,
}
output_path.write_text(json.dumps(report, sort_keys=True, separators=(",", ":")) + "\n")
raise SystemExit(0 if report["accepted"] else 1)
