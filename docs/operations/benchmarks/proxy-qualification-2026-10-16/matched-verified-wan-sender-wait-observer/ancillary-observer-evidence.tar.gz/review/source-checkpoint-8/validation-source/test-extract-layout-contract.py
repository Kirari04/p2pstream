#!/usr/bin/env python3
"""Focused contracts for the bounded logical-line layout extractor.

This driver is source-only until separately authorized. It covers synthetic
chunk boundaries and reduces the exact preserved attempt-4 baseline JSONL.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path


TEST = "TestQualificationBaselineCandidateTypeLayoutProbe"
PACKAGE = "github.com/hashicorp/yamux"
MARKER = "QUALIFICATION_LAYOUT_JSON="
ATTEMPT4_JSONL_SHA256 = "b5a60bffd13f44c0f8da839ce63302442140f852af182428b5f8359d25a59b56"
ATTEMPT4_STATUS_SHA256 = "9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa"
ATTEMPT4_LAYOUT_SHA256 = "d2776d79609c7a3636942a9b997260e59eaaf0eb0c9fc048b244961ec13edf62"
ATTEMPT4_AUDIT_SHA256 = "03b1c00c3ea5025783b9839971a5b3a8422f3d5cbfd8bd16ef8a9ef2d14316f7"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def events_for(outputs: list[tuple[str, str]], *, package_pass: bool = True) -> list[dict]:
    events = [
        {"Action": "start", "Package": PACKAGE},
        {"Action": "run", "Package": PACKAGE, "Test": TEST},
    ]
    for package, output in outputs:
        events.append({"Action": "output", "Package": package, "Test": TEST, "Output": output})
    events.append({"Action": "pass", "Package": PACKAGE, "Test": TEST})
    if package_pass:
        events.append({"Action": "pass", "Package": PACKAGE})
    return events


def write_events(path: Path, events: list[dict]) -> None:
    path.write_text(
        "".join(json.dumps(event, sort_keys=True, separators=(",", ":")) + "\n" for event in events),
        encoding="utf-8",
    )


def invoke(extractor: Path, case: Path, *, status: bytes = b"0\n") -> subprocess.CompletedProcess[bytes]:
    jsonl = case / "input.jsonl"
    direct = case / "direct.status"
    direct.write_bytes(status)
    return subprocess.run(
        [
            sys.executable,
            "-I",
            str(extractor),
            str(jsonl),
            str(direct),
            str(case / "layout.json"),
            str(case / "audit.json"),
        ],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=10,
        check=False,
        env={"PATH": "/usr/bin:/bin", "PYTHONHASHSEED": "0"},
    )


def require_failure(result: subprocess.CompletedProcess[bytes], case: Path, label: str) -> None:
    if result.returncode == 0:
        raise SystemExit(f"{label}: unexpected status zero")
    if (case / "layout.json").exists() or (case / "audit.json").exists():
        raise SystemExit(f"{label}: rejected input published output")


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit("usage: test-extract-layout-contract.py EXTRACTOR ATTEMPT4_JSONL ATTEMPT4_STATUS")
    extractor, attempt4_jsonl, attempt4_status = map(Path, sys.argv[1:])
    if digest(attempt4_jsonl) != ATTEMPT4_JSONL_SHA256:
        raise SystemExit("attempt-4 JSONL hash mismatch")
    if digest(attempt4_status) != ATTEMPT4_STATUS_SHA256 or attempt4_status.read_bytes() != b"0\n":
        raise SystemExit("attempt-4 direct-status binding mismatch")

    layout = [
        {"name": "Stream", "size": 1},
        {"name": "Session", "size": 2},
        {"name": "aggregateWindow", "size": 3},
        {"name": "sendReady", "size": 4},
    ]
    payload = json.dumps(layout, separators=(",", ":"))
    logical = "    probe.go:1: " + MARKER + payload + "\n"
    cuts = (7, 31, 73, len(logical))
    chunks = []
    start = 0
    for end in cuts:
        chunks.append((PACKAGE, logical[start:end]))
        start = end

    with tempfile.TemporaryDirectory(prefix="extract-layout-contract-") as temp:
        root = Path(temp)

        positive = root / "positive-split"
        positive.mkdir()
        write_events(positive / "input.jsonl", events_for(chunks))
        result = invoke(extractor, positive)
        if result.returncode != 0:
            raise SystemExit(f"positive split contract failed: {result.stderr[:4096]!r}")
        expected = (json.dumps(layout, sort_keys=True, separators=(",", ":")) + "\n").encode()
        if (positive / "layout.json").read_bytes() != expected:
            raise SystemExit("positive split contract layout mismatch")

        duplicate = root / "duplicate-marker"
        duplicate.mkdir()
        write_events(
            duplicate / "input.jsonl",
            events_for([(PACKAGE, logical + "    probe.go:2: " + MARKER + payload + "\n")]),
        )
        require_failure(invoke(extractor, duplicate), duplicate, "duplicate marker")

        trailing = root / "trailing-fragment"
        trailing.mkdir()
        write_events(trailing / "input.jsonl", events_for([(PACKAGE, logical.removesuffix("\n"))]))
        require_failure(invoke(extractor, trailing), trailing, "trailing logical fragment")

        wrong_package = root / "wrong-package"
        wrong_package.mkdir()
        write_events(wrong_package / "input.jsonl", events_for([("example.invalid/wrong", logical)]))
        require_failure(invoke(extractor, wrong_package), wrong_package, "wrong package")

        missing_package_pass = root / "missing-package-pass"
        missing_package_pass.mkdir()
        write_events(missing_package_pass / "input.jsonl", events_for([(PACKAGE, logical)], package_pass=False))
        require_failure(invoke(extractor, missing_package_pass), missing_package_pass, "missing package pass")

        wrong_status = root / "wrong-status"
        wrong_status.mkdir()
        write_events(wrong_status / "input.jsonl", events_for([(PACKAGE, logical)]))
        require_failure(invoke(extractor, wrong_status, status=b"1\n"), wrong_status, "wrong direct status")

        oversized = root / "oversized-input"
        oversized.mkdir()
        (oversized / "input.jsonl").write_bytes(b"x" * ((1 << 20) + 1))
        require_failure(invoke(extractor, oversized), oversized, "oversized input")

        preserved = root / "attempt4-preserved"
        preserved.mkdir()
        (preserved / "input.jsonl").write_bytes(attempt4_jsonl.read_bytes())
        result = invoke(extractor, preserved, status=attempt4_status.read_bytes())
        if result.returncode != 0:
            raise SystemExit(f"attempt-4 reduction failed: {result.stderr[:4096]!r}")
        if digest(preserved / "layout.json") != ATTEMPT4_LAYOUT_SHA256:
            raise SystemExit("attempt-4 canonical layout hash mismatch")
        if digest(preserved / "audit.json") != ATTEMPT4_AUDIT_SHA256:
            raise SystemExit("attempt-4 audit hash mismatch")

    print("EXTRACT_LAYOUT_CONTRACT_FINAL status=0 cases=8")


if __name__ == "__main__":
    main()
