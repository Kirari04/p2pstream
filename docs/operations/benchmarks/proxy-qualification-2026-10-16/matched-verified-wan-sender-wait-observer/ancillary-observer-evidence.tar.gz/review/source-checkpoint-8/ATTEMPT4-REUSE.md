# Attempt 4 baseline layout reuse

Checkpoint 8 changes validation source only. The production overlay, tagged
observer, extracted ordinary/tagged bodies, layout probe, proof comparator, and
pinned source commit remain byte-identical to checkpoint 7.

Validation attempt 4 stopped after its baseline layout Go test returned status
0. Its original extractor rejected the valid split log line, so the attempt
remains failed. The preserved reusable inputs are:

- raw ordered Go JSON events: SHA-256
  `b5a60bffd13f44c0f8da839ce63302442140f852af182428b5f8359d25a59b56`
- direct status file (`0`): SHA-256
  `9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa`
- pinned source archive: SHA-256
  `b625da9ccbe17c8b43ff1e5c1078bd8fb24aff4c995fcfd23302ac83c0c3d9f9`
- baseline validation-overlay inventory: SHA-256
  `d63e467367d95ccd858e288520f564b54244bed40dc6552e703ca1f3d7e4f0d3`
- candidate validation-overlay inventory: SHA-256
  `709f8f9fc486d81d43b85c91f5f193b29206b2441afaf1cca23eebba5f4d8450`
- materialized-body audit: SHA-256
  `8c4f3cd77bc09b47b06b90b80fa4d4d070ab59e3b2272c26439b38318eba9b1e`

`extract-layout.py` now reconstructs complete logical lines only from ordered
`Output` events for the exact test and `github.com/hashicorp/yamux` package.
It retains the direct-status, single run, single test pass, and single package
pass gates. Input is capped at 1 MiB, physical and logical lines at 64 KiB,
named-test output at 1 MiB, and output-event count at 4096. A trailing logical
fragment, extra marker, incomplete JSON, wrong package, or non-fresh output is
rejected.

The source-only resume driver prepares a new full baseline and candidate from
the immutable source archive, repeats commit/tree/module/overlay/body/probe
bindings, copies the hash-bound raw baseline JSON events without changing them,
reduces that completed baseline result with the checkpoint-8 extractor, and
runs only the previously unexecuted candidate layout and later validation
phases. The focused contract includes split-line positive and fail-closed
negative fixtures plus the exact preserved attempt-4 reduction.

No checkpoint-8 contract, build, test, or proof command has been executed.
