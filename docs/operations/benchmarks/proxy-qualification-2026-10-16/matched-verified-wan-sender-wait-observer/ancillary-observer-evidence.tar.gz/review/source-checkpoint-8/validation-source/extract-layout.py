#!/usr/bin/env python3
import json
import stat
import sys
from pathlib import Path

MAX_JSONL_BYTES = 1 << 20
MAX_PHYSICAL_LINE_BYTES = 64 << 10
MAX_TEST_OUTPUT_BYTES = 1 << 20
MAX_LOGICAL_LINE_BYTES = 64 << 10
MAX_OUTPUT_EVENTS = 4096
TEST = "TestQualificationBaselineCandidateTypeLayoutProbe"
PACKAGE = "github.com/hashicorp/yamux"
MARKER = "QUALIFICATION_LAYOUT_JSON="


def require_regular(path: Path, label: str) -> None:
    try:
        mode = path.stat().st_mode
    except OSError as error:
        raise SystemExit(f"cannot stat {label}: {error}") from error
    if not stat.S_ISREG(mode):
        raise SystemExit(f"{label} is not a regular file")


def read_jsonl(path: Path) -> list[dict]:
    require_regular(path, "layout JSONL")
    size = path.stat().st_size
    if size == 0 or size > MAX_JSONL_BYTES:
        raise SystemExit(f"layout JSONL size out of bounds: {size}")
    raw = path.read_bytes()
    if len(raw) != size:
        raise SystemExit("layout JSONL changed while reading")
    if not raw.endswith(b"\n"):
        raise SystemExit("layout JSONL has a trailing physical fragment")
    events = []
    for number, physical in enumerate(raw.splitlines(), 1):
        if not physical or len(physical) > MAX_PHYSICAL_LINE_BYTES:
            raise SystemExit(f"physical JSON line {number} size out of bounds: {len(physical)}")
        try:
            line = physical.decode("utf-8", errors="strict")
            event = json.loads(line)
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise SystemExit(f"invalid JSON line {number}: {error}") from error
        if not isinstance(event, dict):
            raise SystemExit(f"JSON line {number} is not an object")
        events.append(event)
    return events


def complete_test_lines(events: list[dict]) -> list[str]:
    output_events = 0
    output_bytes = 0
    pending = ""
    complete = []
    for event in events:
        if not (
            event.get("Test") == TEST
            and event.get("Package") == PACKAGE
            and event.get("Action") == "output"
        ):
            continue
        output = event.get("Output")
        if not isinstance(output, str):
            raise SystemExit("named test Output is not a string")
        output_events += 1
        if output_events > MAX_OUTPUT_EVENTS:
            raise SystemExit("too many named test Output events")
        output_bytes += len(output.encode("utf-8"))
        if output_bytes > MAX_TEST_OUTPUT_BYTES:
            raise SystemExit("named test Output exceeds byte bound")
        parts = (pending + output).split("\n")
        for logical in parts[:-1]:
            if len(logical.encode("utf-8")) > MAX_LOGICAL_LINE_BYTES:
                raise SystemExit("named test logical line exceeds byte bound")
            complete.append(logical)
        pending = parts[-1]
        if len(pending.encode("utf-8")) > MAX_LOGICAL_LINE_BYTES:
            raise SystemExit("named test logical line exceeds byte bound")
    if pending:
        raise SystemExit("named test Output has a trailing logical fragment")
    return complete


def main() -> None:
    if len(sys.argv) != 5:
        raise SystemExit("usage: extract-layout.py JSONL STATUS LAYOUT AUDIT")
    jsonl_path, status_path, layout_path, audit_path = map(Path, sys.argv[1:])
    require_regular(status_path, "layout direct status")
    if status_path.stat().st_size != 2:
        raise SystemExit("layout direct status size is not exactly two bytes")
    if status_path.read_bytes() != b"0\n":
        raise SystemExit("layout go test status is not exactly zero")
    if layout_path.exists() or audit_path.exists():
        raise SystemExit("layout output path is not fresh")

    events = read_jsonl(jsonl_path)
    runs = sum(event.get("Test") == TEST and event.get("Action") == "run" for event in events)
    passes = sum(event.get("Test") == TEST and event.get("Action") == "pass" for event in events)
    package_passes = sum(
        "Test" not in event and event.get("Action") == "pass" and event.get("Package") == PACKAGE
        for event in events
    )
    logical_lines = complete_test_lines(events)
    marker_count = sum(line.count(MARKER) for line in logical_lines)
    if (runs, passes, package_passes, marker_count) != (1, 1, 1, 1):
        raise SystemExit(
            "unexpected layout evidence: "
            f"runs={runs} passes={passes} package_passes={package_passes} markers={marker_count}"
        )
    marker_line = next(line for line in logical_lines if MARKER in line)
    payload = marker_line.split(MARKER, 1)[1]
    if not payload or payload != payload.strip():
        raise SystemExit("layout payload is empty or has surrounding whitespace")
    try:
        layout = json.loads(payload)
    except json.JSONDecodeError as error:
        raise SystemExit(f"invalid complete layout payload: {error}") from error
    names = [row.get("name") for row in layout] if isinstance(layout, list) else []
    if names != ["Stream", "Session", "aggregateWindow", "sendReady"]:
        raise SystemExit(f"unexpected layout types: {names}")
    layout_bytes = (json.dumps(layout, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    if len(layout_bytes) > MAX_TEST_OUTPUT_BYTES:
        raise SystemExit("canonical layout output exceeds byte bound")
    audit_bytes = (
        json.dumps(
            {
                "accepted": True,
                "runs": runs,
                "passes": passes,
                "package_passes": package_passes,
                "types": names,
            },
            sort_keys=True,
            separators=(",", ":"),
        )
        + "\n"
    ).encode("utf-8")
    layout_path.write_bytes(layout_bytes)
    audit_path.write_bytes(audit_bytes)


if __name__ == "__main__":
    main()
