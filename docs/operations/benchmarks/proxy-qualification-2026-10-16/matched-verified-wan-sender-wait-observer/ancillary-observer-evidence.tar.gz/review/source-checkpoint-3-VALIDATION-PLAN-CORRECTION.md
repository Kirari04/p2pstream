# Validation plan path correction

Preserves `source-checkpoint-3-VALIDATION-PLAN.md` unchanged. The pinned Yamux
copy is a nested module (`third_party/yamux/go.mod` declares
`github.com/hashicorp/yamux`), so its focused commands must run with working
directory `SOURCE/third_party/yamux` and package argument `.`. The root-module
agent/server commands remain rooted at `SOURCE`. Ordinary Yamux test-binary,
compiler assembly, and escape commands likewise run in the nested module. No
validation command was run before this correction.
