# Sender-duration observer focused validation plan

Status: command and proof plan only. It has not been executed. The immutable
source input is `source-checkpoint-3/SHA256SUMS.txt` SHA-256
`97720394ab3b9414657fbd7f39cd4e2b93ea466ad21dd1b3790535c5a07898f9`.
Every attempt must use pinned Go 1.26.6 at
`/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go`,
use a fresh ext4 output root, bind all checkpoint hashes before starting, and
retain direct command, stdout, stderr, status, start/end UTC, environment, and
all generated hashes. There is no automatic retry.

## Focused contracts

Run these sequentially after authorization from the checkpoint's full archived
`source/`, with `GOTOOLCHAIN=local`, `GOPROXY=off`, and fresh output-local
`GOCACHE`, `GOMODCACHE`, `GOPATH`, `GOTMPDIR`, and `TMPDIR`:

```sh
PINNED_GO=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
YAMUX_PATTERN='^(TestQualificationAggregateSendCounter|TestQualificationAggregateSendCounters|TestQualificationSenderDuration)'
"${PINNED_GO}" test -count=1 -tags p2pstream_qualification ./third_party/yamux -run "${YAMUX_PATTERN}"
"${PINNED_GO}" test -count=1 -race -tags p2pstream_qualification ./third_party/yamux -run "${YAMUX_PATTERN}"
"${PINNED_GO}" test -count=1 -tags p2pstream_qualification ./internal/agent -run '^(TestExternalQualificationCreditSnapshotHasBoundedVersionedSchema|TestExternalQualificationGrowthSnapshotHasBoundedVersionedSchema)$'
"${PINNED_GO}" test -count=1 -tags p2pstream_qualification ./internal/server -run '^(TestQualificationCreditSnapshotHasBoundedVersionedSchema|TestQualificationGrowthSnapshotHasBoundedVersionedSchema)$'
"${PINNED_GO}" test -count=1 ./third_party/yamux -run '^TestQualificationAggregateSendCountersDoNotChangeOrdinaryLayout$'
```

The Yamux pattern deliberately includes the pre-existing aggregate counter
contracts, the ledger boundary contracts, and the actual Stream.write,
waitForSendErr, send-loop, sendDone, and Session.Close controls. Direct status
zero is required for every command. Race mode is a separate attempt and must
not replace the normal result.

## Ordinary object proof

Create two fresh source roots from the same pinned commit: an untouched archive
of `8ac4c8df8237e37777ba2fac0da6f949da17bdea` and a second archive with the
checkpoint proposal files copied in only after their hashes match the manifest.
Use identical environment, flags, module cache input, absolute path length,
and fresh build caches. Build ordinary, untagged Yamux test binaries and retain
compiler diagnostics:

```sh
"${PINNED_GO}" test -c -trimpath -o BASE/yamux.test BASE/third_party/yamux
"${PINNED_GO}" test -c -trimpath -o CAND/yamux.test CAND/third_party/yamux
"${PINNED_GO}" test -count=1 -gcflags='github.com/hashicorp/yamux=-m=2' ./third_party/yamux -run '^$'
"${PINNED_GO}" test -count=1 -gcflags='github.com/hashicorp/yamux=-S' ./third_party/yamux -run '^$'
```

Capture `go tool nm -size` and `go tool objdump` for these ordinary symbols:

- `(*Stream).write`
- `(*Stream).reserveAggregateSend`
- `(*Session).waitForSendErrCommitOn`
- `(*Session).send`
- `(*Session).sendLoop`

The comparison records symbol size, compiler `TEXT` frame/argument size,
instruction count and order, opcode/operands, machine bytes, calls, and escape
or heap-move decisions. It may normalize only absolute symbol/PC addresses and
bytes covered by identified relocation records. It must preserve real
instruction bytes, branch structure, calls, stack adjustments, frame sizes,
and escape/allocation decisions. Source-position metadata is retained and any
line-only movement is reported separately; it is never used to hide an
instruction difference. If a candidate instruction, stack, or escape decision
differs, the proof fails and reports the exact raw excerpts rather than adding
a new normalization rule.

The ordinary layout contract additionally requires the zero-sized disabled
counter and unchanged `aggregateWindow` offsets. Binary or archive SHA-256
identity is useful evidence but is not required because build metadata may
differ; the function-level proof above is authoritative.

## Acceptance

Acceptance requires all focused normal and race commands to exit zero, exact
natural process joins, no timeout or cleanup intervention, all checkpoint
hashes unchanged before and after, the ordinary layout contract to pass, and
no real instruction, stack, or escape/allocation difference in the affected
ordinary paths. Tagged binaries are diagnostic-only and are not compared for
performance identity.
