#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then echo 'usage: prepare-validation.sh FRESH_OUTPUT' >&2; exit 64; fi
validation_source=$(cd "$(dirname "$0")" && pwd)
checkpoint=$(cd "$validation_source/.." && pwd)
active=/home/user/.codex/worktrees/astra-proxy-performance/p2pstream
go_bin=/home/user/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.6.linux-amd64/bin/go
commit=8ac4c8df8237e37777ba2fac0da6f949da17bdea
expected_source_manifest=7327b0ef46a4bf25fa52c290fa06af3ab0684c485f239932780712a871f1ea17
expected_go=29e6e0b8be61beb1489ceae62b304343566de8a1dc700af74bde7aeb9c80ad45
expected_comparator=b77facb3ff47169a47bfa725bd8735999eb6b0c50e4d915eaf638b1a37832928
expected_probe=c8a461f71c048bf15266e981a9e4e6bc6948bdd2581f7222a10c06861a488071
output=$1
if [[ -e "$output" ]]; then echo "fresh output required: $output" >&2; exit 65; fi
if [[ $(sha256sum "$checkpoint/SOURCE-SHA256SUMS.txt" | awk '{print $1}') != "$expected_source_manifest" ]]; then echo 'source manifest binding failed' >&2; exit 66; fi
if [[ $(sha256sum "$go_bin" | awk '{print $1}') != "$expected_go" ]]; then echo 'Go binding failed' >&2; exit 67; fi
if [[ $(sha256sum "$checkpoint/proof-source/compare_ordinary_v2.py" | awk '{print $1}') != "$expected_comparator" ]]; then echo 'comparator binding failed' >&2; exit 68; fi
if [[ $(sha256sum "$checkpoint/proof-source/ordinary_layout_probe_test.go" | awk '{print $1}') != "$expected_probe" ]]; then echo 'probe binding failed' >&2; exit 69; fi
(cd "$checkpoint" && sha256sum -c SOURCE-SHA256SUMS.txt >/dev/null)
mkdir -p "$output/inputs" "$output/outputs" "$output/baseline/source" "$output/candidate/source" "$output/cache" "$output/gopath" "$output/tmp"
output=$(cd "$output" && pwd)
date -u +%Y-%m-%dT%H:%M:%S.%NZ >"$output/START-UTC.txt"
printf 'phase\tstatus\n' >"$output/outputs/preflight-status.tsv"
record() { printf '%s\t%s\n' "$1" "$2" >>"$output/outputs/preflight-status.tsv"; }
trap 'status=$?; printf "PREPARE_VALIDATION_FINAL status=%d output=%s\n" "$status" "$output"; exit "$status"' EXIT

set +e
git -C "$active" cat-file -e "$commit^{commit}"
status=$?
set -e
record commit "$status"; [[ "$status" -eq 0 ]]
git -C "$active" rev-parse "$commit^{tree}" >"$output/inputs/resolved-tree.txt"
printf '%s\n' "$commit" >"$output/inputs/resolved-commit.txt"
printf 'git -C %q archive --format=tar %q\n' "$active" "$commit" >"$output/inputs/materialization-command.txt"
set +e
git -C "$active" archive --format=tar "$commit" >"$output/inputs/source.tar"
status=$?
set -e
record archive "$status"; [[ "$status" -eq 0 ]]
sha256sum "$output/inputs/source.tar" >"$output/inputs/source-archive.sha256"
tar -tf "$output/inputs/source.tar" >"$output/inputs/source-archive-files.txt"
tar -xf "$output/inputs/source.tar" -C "$output/baseline/source"
tar -xf "$output/inputs/source.tar" -C "$output/candidate/source"

(cd "$validation_source" && find . -type f -print0 | sort -z | xargs -0 sha256sum) >"$output/inputs/validation-source.sha256"
sha256sum "$checkpoint/proof-source/compare_ordinary_v2.py" "$checkpoint/proof-source/ordinary_layout_probe_test.go" >"$output/inputs/proof-source.sha256"
cp "$validation_source"/*.py "$output/"
cp "$validation_source"/run-*.sh "$output/"
cp "$validation_source"/expected-*.txt "$output/inputs/"
cp "$validation_source/ordinary-symbol-pattern.txt" "$output/inputs/"
cp "$checkpoint/proof-source/compare_ordinary_v2.py" "$output/inputs/"
cp "$checkpoint/proof-source/ordinary_layout_probe_test.go" "$output/inputs/"
chmod 0755 "$output"/*.py "$output"/run-*.sh "$output/inputs/compare_ordinary_v2.py"
python3 -I "$output/inventory.py" "$output/baseline/source" "$output/inputs/baseline-pre.json"
python3 -I "$output/inventory.py" "$output/candidate/source" "$output/inputs/candidate-pre.json"
set +e
cmp -s "$output/inputs/baseline-pre.json" "$output/inputs/candidate-pre.json"
status=$?
set -e
record pre_inventory "$status"; [[ "$status" -eq 0 ]]

(cd "$checkpoint/source" && find . -type f -print | sort) >"$output/inputs/overlay-paths.txt"
while IFS= read -r relative; do
  relative=${relative#./}
  mkdir -p "$output/candidate/source/$(dirname "$relative")"
  cp "$checkpoint/source/$relative" "$output/candidate/source/$relative"
done <"$output/inputs/overlay-paths.txt"
python3 -I "$output/inventory.py" "$output/candidate/source" "$output/inputs/candidate-post-overlay.json"
set +e
python3 -I "$output/verify-overlay.py" "$output/inputs/baseline-pre.json" "$output/inputs/candidate-post-overlay.json" "$checkpoint/source" "$output/inputs/overlay-paths.txt" "$output/inputs/overlay-audit.json"
status=$?
set -e
record overlay "$status"; [[ "$status" -eq 0 ]]

export GOTOOLCHAIN=local GOPROXY=off GOMODCACHE=/home/user/go/pkg/mod GOPATH="$output/gopath" GOTMPDIR="$output/tmp" TMPDIR="$output/tmp" GOFLAGS= CGO_ENABLED=1 GOMAXPROCS=16
for side in baseline candidate; do
  root="$output/$side/source"
  (cd "$root" && "$go_bin" env GOMOD) >"$output/inputs/$side-root-gomod.out"
  (cd "$root/third_party/yamux" && "$go_bin" env GOMOD) >"$output/inputs/$side-yamux-gomod.out"
  [[ $(cat "$output/inputs/$side-root-gomod.out") == "$root/go.mod" ]]
  [[ $(cat "$output/inputs/$side-yamux-gomod.out") == "$root/third_party/yamux/go.mod" ]]
done
record gomod 0

candidate_yamux="$output/candidate/source/third_party/yamux"
(cd "$candidate_yamux" && GOCACHE="$output/cache/list-ordinary" "$go_bin" list -json .) >"$output/inputs/candidate-list-ordinary.json"
(cd "$candidate_yamux" && GOCACHE="$output/cache/list-tagged" "$go_bin" list -tags p2pstream_qualification -json .) >"$output/inputs/candidate-list-tagged.json"
set +e
python3 -I "$output/verify-selection.py" "$output/inputs/candidate-list-ordinary.json" "$output/inputs/candidate-list-tagged.json" "$output/inputs/file-selection-audit.json"
status=$?
set -e
record file_selection "$status"; [[ "$status" -eq 0 ]]
set +e
python3 -I "$output/verify-materialized-bodies.py" "$output/baseline/source/third_party/yamux" "$candidate_yamux" "$checkpoint/body-extractions" "$output/inputs/body-audit.json"
status=$?
set -e
record bodies "$status"; [[ "$status" -eq 0 ]]

# The identical probe is a validation overlay, applied only after production inventories.
probe=qualification_ordinary_layout_probe_test.go
cp "$output/inputs/ordinary_layout_probe_test.go" "$output/baseline/source/third_party/yamux/$probe"
cp "$output/inputs/ordinary_layout_probe_test.go" "$output/candidate/source/third_party/yamux/$probe"
python3 -I "$output/inventory.py" "$output/baseline/source" "$output/inputs/baseline-validation-overlay.json"
python3 -I "$output/inventory.py" "$output/candidate/source" "$output/inputs/candidate-validation-overlay.json"
sha256sum "$output/baseline/source/third_party/yamux/$probe" "$output/candidate/source/third_party/yamux/$probe" >"$output/inputs/layout-probe-copies.sha256"
record layout_overlay 0
