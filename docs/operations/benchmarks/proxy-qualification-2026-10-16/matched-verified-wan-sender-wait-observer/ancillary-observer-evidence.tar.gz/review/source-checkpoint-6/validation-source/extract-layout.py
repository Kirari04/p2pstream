#!/usr/bin/env python3
import json
import sys
from pathlib import Path

jsonl_path, status_path, layout_path, audit_path = map(Path, sys.argv[1:])
if status_path.read_text().strip() != "0":
    raise SystemExit("layout go test status is not zero")
test = "TestQualificationBaselineCandidateTypeLayoutProbe"
runs = passes = package_passes = 0
payloads = []
for number, line in enumerate(jsonl_path.read_text().splitlines(), 1):
    try:
        event = json.loads(line)
    except json.JSONDecodeError as error:
        raise SystemExit(f"invalid JSON line {number}: {error}")
    if event.get("Test") == test and event.get("Action") == "run":
        runs += 1
    if event.get("Test") == test and event.get("Action") == "pass":
        passes += 1
    if "Test" not in event and event.get("Action") == "pass" and event.get("Package") == "github.com/hashicorp/yamux":
        package_passes += 1
    output = event.get("Output", "")
    marker = "QUALIFICATION_LAYOUT_JSON="
    if marker in output:
        payloads.append(output.split(marker, 1)[1].strip())
if (runs, passes, package_passes, len(payloads)) != (1, 1, 1, 1):
    raise SystemExit(f"unexpected layout evidence: runs={runs} passes={passes} package_passes={package_passes} payloads={len(payloads)}")
layout = json.loads(payloads[0])
names = [row.get("name") for row in layout] if isinstance(layout, list) else []
if names != ["Stream", "Session", "aggregateWindow", "sendReady"]:
    raise SystemExit(f"unexpected layout types: {names}")
layout_path.write_text(json.dumps(layout, sort_keys=True, separators=(",", ":")) + "\n")
audit_path.write_text(json.dumps({"accepted": True, "runs": runs, "passes": passes, "package_passes": package_passes, "types": names}, sort_keys=True, separators=(",", ":")) + "\n")
