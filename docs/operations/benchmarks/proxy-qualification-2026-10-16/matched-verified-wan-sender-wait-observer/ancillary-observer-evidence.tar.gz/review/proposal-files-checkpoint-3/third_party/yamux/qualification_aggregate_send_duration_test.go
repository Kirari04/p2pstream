//go:build p2pstream_qualification

package yamux

import (
	"testing"
	"time"
)

func requirePositiveBucket(t *testing.T, got QualificationDurationBucket) {
	t.Helper()
	if got.Count != 1 || got.TotalNanoseconds == 0 || got.MaxNanoseconds == 0 ||
		got.MaxNanoseconds > got.TotalNanoseconds {
		t.Fatalf("duration bucket = %+v, want one positive conserved interval", got)
	}
}

func reserveQualificationData(t *testing.T, stream *Stream, payload int) {
	t.Helper()
	reserved, wake := stream.reserveAggregateSend(uint32(payload))
	if reserved != uint32(payload) || wake != nil {
		t.Fatalf("reservation = (%d, %v), want (%d, nil)", reserved, wake != nil, payload)
	}
}

func TestQualificationSenderDurationLedgerExactCreditCausesAndOutcomes(t *testing.T) {
	session, stream := newQualificationAggregateSendCounterFixture()
	stream.id = 17

	byteWait := stream.beginQualificationByteCreditWait()
	time.Sleep(time.Millisecond)
	stream.finishQualificationCreditWait(byteWait, qualificationCreditWakeByteNotify)

	session.aggregate.mu.Lock()
	session.aggregate.qualification.recordQualificationAggregateCreditWaitDecision(stream.id, false, true)
	session.aggregate.mu.Unlock()
	streamWait := stream.takeQualificationAggregateCreditWaitDecision()
	time.Sleep(time.Millisecond)
	stream.finishQualificationCreditWait(streamWait, qualificationCreditWakeAggregateNotify)

	session.aggregate.mu.Lock()
	session.aggregate.qualification.recordQualificationAggregateCreditWaitDecision(stream.id, true, false)
	session.aggregate.mu.Unlock()
	sessionWait := stream.takeQualificationAggregateCreditWaitDecision()
	time.Sleep(time.Millisecond)
	stream.finishQualificationCreditWait(sessionWait, qualificationCreditWakeShutdown)

	session.aggregate.mu.Lock()
	session.aggregate.qualification.recordQualificationAggregateCreditWaitDecision(stream.id, true, true)
	session.aggregate.mu.Unlock()
	bothWait := stream.takeQualificationAggregateCreditWaitDecision()
	time.Sleep(time.Millisecond)
	stream.finishQualificationCreditWait(bothWait, qualificationCreditWakeTimeout)

	got := session.DrainQualificationAggregateSendCounters()
	if !got.Enabled || !got.Timing.Complete || !got.Timing.ResetPerformed || got.Timing.Ambiguous ||
		!got.Timing.StreamObserved || got.Timing.ObservedStreamID != stream.id || got.Timing.MultipleStreams {
		t.Fatalf("credit timing identity/lifecycle = %+v", got.Timing)
	}
	if got.Timing.CreditWaitTotal.Count != 4 {
		t.Fatalf("credit total = %+v, want four intervals", got.Timing.CreditWaitTotal)
	}
	requirePositiveBucket(t, got.Timing.CreditWaitByCause.ByteZero)
	requirePositiveBucket(t, got.Timing.CreditWaitByCause.StreamAllocationZero)
	requirePositiveBucket(t, got.Timing.CreditWaitByCause.SessionAllocationZero)
	requirePositiveBucket(t, got.Timing.CreditWaitByCause.StreamAndSessionAllocationZero)
	requirePositiveBucket(t, got.Timing.CreditWaitByOutcome.ByteNotify)
	requirePositiveBucket(t, got.Timing.CreditWaitByOutcome.AggregateNotify)
	requirePositiveBucket(t, got.Timing.CreditWaitByOutcome.Shutdown)
	requirePositiveBucket(t, got.Timing.CreditWaitByOutcome.Timeout)
	if got.Timing.CreditWaitTotal.TotalNanoseconds !=
		got.Timing.CreditWaitByCause.ByteZero.TotalNanoseconds+
			got.Timing.CreditWaitByCause.StreamAllocationZero.TotalNanoseconds+
			got.Timing.CreditWaitByCause.SessionAllocationZero.TotalNanoseconds+
			got.Timing.CreditWaitByCause.StreamAndSessionAllocationZero.TotalNanoseconds {
		t.Fatal("credit duration cause conservation failed")
	}
}

func TestQualificationSenderDurationLedgerRetainsActualOperationAfterCallerTimeout(t *testing.T) {
	session, stream := newQualificationAggregateSendCounterFixture()
	stream.id = 23
	payload := 1234
	wire := payload + headerSize
	if reserved, wake := stream.reserveAggregateSend(uint32(payload)); reserved != uint32(payload) || wake != nil {
		t.Fatalf("reservation = (%d, %v), want (%d, nil)", reserved, wake != nil, payload)
	}

	enqueue := session.beginQualificationDataEnqueue(stream.id, payload)
	time.Sleep(time.Millisecond)
	completion := session.finishQualificationDataEnqueue(enqueue, qualificationDataEnqueueAccepted)
	time.Sleep(time.Millisecond)
	session.finishQualificationDataCompletion(completion, qualificationDataCompletionTimeout)

	incomplete := session.DrainQualificationAggregateSendCounters()
	if incomplete.Timing.Complete || incomplete.Timing.ResetPerformed ||
		incomplete.Timing.ActiveQueuedFrames != 1 || incomplete.Timing.ActiveQueuedPayloadBytes != uint64(payload) {
		t.Fatalf("caller timeout prematurely released operation = %+v", incomplete.Timing)
	}

	physical := session.beginQualificationPhysicalDataWrite(stream.id, payload, wire)
	time.Sleep(time.Millisecond)
	session.finishQualificationPhysicalDataWrite(physical, qualificationPhysicalWriteSuccess, wire, wire)
	complete := session.DrainQualificationAggregateSendCounters()
	if !complete.Timing.Complete || !complete.Timing.ResetPerformed || complete.Timing.Ambiguous {
		t.Fatalf("completed physical operation = %+v", complete.Timing)
	}
	if complete.ReservedDataFrames != 1 || complete.ReservedPayloadBytes != uint64(payload) ||
		complete.Timing.DataEnqueuedFrames != 1 || complete.Timing.DataEnqueuedPayloadBytes != uint64(payload) ||
		complete.Timing.DataCompletedFrames != 1 || complete.Timing.DataCompletedPayloadBytes != uint64(payload) ||
		complete.Timing.PhysicalAttemptFrames != 1 || complete.Timing.PhysicalAttemptPayloadBytes != uint64(payload) ||
		complete.Timing.PhysicalAttemptWireBytes != uint64(wire) ||
		complete.Timing.PhysicalWrittenWireBytes != uint64(wire) ||
		complete.Timing.PhysicalSuccessFrames != 1 || complete.Timing.PhysicalSuccessPayloadBytes != uint64(payload) ||
		complete.Timing.PhysicalSuccessWireBytes != uint64(wire) {
		t.Fatalf("DATA conservation = %+v", complete.Timing)
	}
	requirePositiveBucket(t, complete.Timing.DataEnqueueSelectByOutcome.Accepted)
	requirePositiveBucket(t, complete.Timing.DataCompletionSelectByOutcome.Timeout)
	requirePositiveBucket(t, complete.Timing.DataCallByOutcome.Timeout)
	requirePositiveBucket(t, complete.Timing.PhysicalWriteByOutcome.Success)

	cleared := session.DrainQualificationAggregateSendCounters()
	if !cleared.Timing.Complete || !cleared.Timing.ResetPerformed ||
		cleared.Timing.DataEnqueuedFrames != 0 || cleared.Timing.PhysicalAttemptFrames != 0 {
		t.Fatalf("complete drain did not clear prior interval = %+v", cleared.Timing)
	}
}

func TestQualificationSenderDurationLedgerRetainsEnqueueAttemptUntilNaturalOutcome(t *testing.T) {
	session, stream := newQualificationAggregateSendCounterFixture()
	stream.id = 29
	payload := 2048
	reserveQualificationData(t, stream, payload)

	enqueue := session.beginQualificationDataEnqueue(stream.id, payload)
	inFlight := session.DrainQualificationAggregateSendCounters()
	if inFlight.Timing.Complete || inFlight.Timing.ResetPerformed ||
		inFlight.Timing.ActiveEnqueueFrames != 1 ||
		inFlight.Timing.ActiveEnqueuePayloadBytes != uint64(payload) {
		t.Fatalf("enqueue attempt was not retained = %+v", inFlight.Timing)
	}

	time.Sleep(time.Millisecond)
	session.finishQualificationDataEnqueue(enqueue, qualificationDataEnqueueShutdown)
	complete := session.DrainQualificationAggregateSendCounters()
	if !complete.Timing.Complete || !complete.Timing.ResetPerformed || complete.Timing.Ambiguous ||
		complete.Timing.DataEnqueuedFrames != 0 || complete.Timing.DataCompletedFrames != 0 {
		t.Fatalf("enqueue terminal accounting was not conserved = %+v", complete.Timing)
	}
	requirePositiveBucket(t, complete.Timing.DataEnqueueSelectByOutcome.Shutdown)
	requirePositiveBucket(t, complete.Timing.DataCallByOutcome.Shutdown)
}

func TestQualificationSenderDurationLedgerRetainsReservationUntilSubmission(t *testing.T) {
	session, stream := newQualificationAggregateSendCounterFixture()
	stream.id = 28
	payload := 1024
	reserveQualificationData(t, stream, payload)

	inFlight := session.DrainQualificationAggregateSendCounters()
	if inFlight.Timing.Complete || inFlight.Timing.ResetPerformed ||
		inFlight.Timing.ActiveReservedFrames != 1 ||
		inFlight.Timing.ActiveReservedPayloadBytes != uint64(payload) ||
		inFlight.Timing.ActiveReservedAllocationChargedBytes != uint64(aggregateDataCharge(uint32(payload))) {
		t.Fatalf("reservation-to-submission ownership = %+v", inFlight.Timing)
	}

	enqueue := session.beginQualificationDataEnqueue(stream.id, payload)
	session.finishQualificationDataEnqueue(enqueue, qualificationDataEnqueueShutdown)
	complete := session.DrainQualificationAggregateSendCounters()
	if !complete.Timing.Complete || !complete.Timing.ResetPerformed || complete.Timing.Ambiguous ||
		complete.ReservedDataFrames != 1 || complete.ReservedPayloadBytes != uint64(payload) ||
		complete.Timing.ActiveReservedFrames != 0 {
		t.Fatalf("reservation submission did not join = %+v", complete)
	}
}

func TestQualificationSenderDurationLedgerMarksPrePublicationRace(t *testing.T) {
	session, stream := newQualificationAggregateSendCounterFixture()
	stream.id = 30
	payload := 2048
	wire := payload + headerSize
	reserveQualificationData(t, stream, payload)

	enqueue := session.beginQualificationDataEnqueue(stream.id, payload)
	physical := session.beginQualificationPhysicalDataWrite(stream.id, payload, wire)
	session.finishQualificationPhysicalDataWrite(physical, qualificationPhysicalWriteSuccess, wire, wire)

	inFlight := session.DrainQualificationAggregateSendCounters()
	if inFlight.Timing.Complete || inFlight.Timing.ResetPerformed ||
		inFlight.Timing.ClaimedBeforePublicationFrames != 1 ||
		inFlight.Timing.ClaimedBeforePublicationBytes != uint64(payload) ||
		inFlight.Timing.EnqueuePublicationRaces != 1 {
		t.Fatalf("pre-publication race was not retained = %+v", inFlight.Timing)
	}

	completion := session.finishQualificationDataEnqueue(enqueue, qualificationDataEnqueueAccepted)
	session.finishQualificationDataCompletion(completion, qualificationDataCompletionSuccess)
	complete := session.DrainQualificationAggregateSendCounters()
	if !complete.Timing.Complete || !complete.Timing.ResetPerformed || complete.Timing.Ambiguous ||
		complete.Timing.EnqueuePublicationRaces != 1 ||
		complete.Timing.ClaimedBeforePublicationFrames != 0 ||
		complete.Timing.ClaimedBeforePublicationBytes != 0 {
		t.Fatalf("pre-publication race did not join visibly = %+v", complete.Timing)
	}
}

func TestQualificationSenderDurationLedgerJoinsAcceptedPublicationAfterSendLoopExit(t *testing.T) {
	session, stream := newQualificationAggregateSendCounterFixture()
	stream.id = 31
	payload := 3072
	reserveQualificationData(t, stream, payload)

	enqueue := session.beginQualificationDataEnqueue(stream.id, payload)
	session.finishQualificationSendLoop()
	completion := session.finishQualificationDataEnqueue(enqueue, qualificationDataEnqueueAccepted)
	session.finishQualificationDataCompletion(completion, qualificationDataCompletionShutdown)

	got := session.DrainQualificationAggregateSendCounters()
	if !got.Timing.Complete || !got.Timing.ResetPerformed || got.Timing.Ambiguous ||
		!got.Timing.SendLoopTerminated || got.Timing.DataEnqueuedFrames != 1 ||
		got.Timing.DataAbandonedFrames != 1 || got.Timing.DataAbandonedPayloadBytes != uint64(payload) ||
		got.Timing.DataCompletedFrames != 1 || got.Timing.DataCompletedPayloadBytes != uint64(payload) ||
		got.Timing.ActiveQueuedFrames != 0 {
		t.Fatalf("late accepted publication after send-loop exit = %+v", got.Timing)
	}
}

func TestQualificationSenderDurationLedgerRetainsCallerAfterPhysicalCompletion(t *testing.T) {
	session, stream := newQualificationAggregateSendCounterFixture()
	stream.id = 32
	payload := 4096
	wire := payload + headerSize
	reserveQualificationData(t, stream, payload)

	enqueue := session.beginQualificationDataEnqueue(stream.id, payload)
	completion := session.finishQualificationDataEnqueue(enqueue, qualificationDataEnqueueAccepted)
	physical := session.beginQualificationPhysicalDataWrite(stream.id, payload, wire)
	session.finishQualificationPhysicalDataWrite(physical, qualificationPhysicalWriteSuccess, wire, wire)

	inFlight := session.DrainQualificationAggregateSendCounters()
	if inFlight.Timing.Complete || inFlight.Timing.ResetPerformed ||
		inFlight.Timing.ActiveCallerFrames != 1 ||
		inFlight.Timing.ActiveCallerPayloadBytes != uint64(payload) ||
		inFlight.Timing.ActiveQueuedFrames != 0 || inFlight.Timing.ActivePhysicalFrames != 0 {
		t.Fatalf("physical completion prematurely released caller = %+v", inFlight.Timing)
	}

	time.Sleep(time.Millisecond)
	session.finishQualificationDataCompletion(completion, qualificationDataCompletionSuccess)
	complete := session.DrainQualificationAggregateSendCounters()
	if !complete.Timing.Complete || !complete.Timing.ResetPerformed || complete.Timing.Ambiguous ||
		complete.Timing.ActiveCallerFrames != 0 || complete.Timing.DataCallTotal.Count != 1 {
		t.Fatalf("caller terminal outcome did not close whole call = %+v", complete.Timing)
	}
	requirePositiveBucket(t, complete.Timing.DataCompletionSelectByOutcome.Success)
	requirePositiveBucket(t, complete.Timing.DataCallByOutcome.Success)
}

func TestQualificationSenderDurationLedgerKeepsPhysicalErrorAndShortWriteExact(t *testing.T) {
	session, stream := newQualificationAggregateSendCounterFixture()
	stream.id = 34
	payload := 8192
	wire := payload + headerSize

	for _, item := range []struct {
		outcome qualificationPhysicalWriteOutcome
		written int
	}{
		{outcome: qualificationPhysicalWriteError, written: headerSize},
		{outcome: qualificationPhysicalWriteShort, written: wire - 1},
	} {
		reserveQualificationData(t, stream, payload)
		enqueue := session.beginQualificationDataEnqueue(stream.id, payload)
		completion := session.finishQualificationDataEnqueue(enqueue, qualificationDataEnqueueAccepted)
		physical := session.beginQualificationPhysicalDataWrite(stream.id, payload, wire)
		time.Sleep(time.Millisecond)
		session.finishQualificationPhysicalDataWrite(physical, item.outcome, wire, item.written)
		session.finishQualificationDataCompletion(completion, qualificationDataCompletionError)
	}

	got := session.DrainQualificationAggregateSendCounters()
	if !got.Timing.Complete || !got.Timing.ResetPerformed || got.Timing.Ambiguous ||
		got.Timing.PhysicalAttemptFrames != 2 || got.Timing.PhysicalAttemptPayloadBytes != 2*uint64(payload) ||
		got.Timing.PhysicalAttemptWireBytes != 2*uint64(wire) ||
		got.Timing.PhysicalWrittenWireBytes != uint64(headerSize+wire-1) ||
		got.Timing.PhysicalErrorFrames != 1 || got.Timing.PhysicalErrorPayloadBytes != uint64(payload) ||
		got.Timing.PhysicalErrorAttemptWireBytes != uint64(wire) ||
		got.Timing.PhysicalErrorWrittenWireBytes != uint64(headerSize) ||
		got.Timing.PhysicalShortFrames != 1 || got.Timing.PhysicalShortPayloadBytes != uint64(payload) ||
		got.Timing.PhysicalShortAttemptWireBytes != uint64(wire) ||
		got.Timing.PhysicalShortWrittenWireBytes != uint64(wire-1) {
		t.Fatalf("physical error/short accounting = %+v", got.Timing)
	}
	requirePositiveBucket(t, got.Timing.PhysicalWriteByOutcome.Error)
	requirePositiveBucket(t, got.Timing.PhysicalWriteByOutcome.ShortWrite)
	if got.Timing.DataCallByOutcome.Error.Count != 2 {
		t.Fatalf("whole-call error outcomes = %+v, want two", got.Timing.DataCallByOutcome.Error)
	}
}

func TestQualificationSenderDurationLedgerRejectsMultipleStreamsAndJoinsAbandonedQueue(t *testing.T) {
	session, first := newQualificationAggregateSendCounterFixture()
	first.id = 31
	second := &Stream{
		id: 33, session: session,
		allocationSendWindow: 1 << 30,
		allocationSendLimit:  1 << 30,
	}

	reserveQualificationData(t, first, 100)
	firstWait := session.beginQualificationDataEnqueue(first.id, 100)
	firstWait = session.finishQualificationDataEnqueue(firstWait, qualificationDataEnqueueAccepted)
	session.finishQualificationDataCompletion(firstWait, qualificationDataCompletionShutdown)
	reserveQualificationData(t, second, 200)
	secondWait := session.beginQualificationDataEnqueue(second.id, 200)
	secondWait = session.finishQualificationDataEnqueue(secondWait, qualificationDataEnqueueAccepted)
	session.finishQualificationDataCompletion(secondWait, qualificationDataCompletionShutdown)

	beforeJoin := session.DrainQualificationAggregateSendCounters()
	if beforeJoin.Timing.Complete || !beforeJoin.Timing.MultipleStreams ||
		beforeJoin.Timing.ActiveQueuedFrames != 2 {
		t.Fatalf("multiple-stream active snapshot = %+v", beforeJoin.Timing)
	}
	session.finishQualificationSendLoop()
	afterJoin := session.DrainQualificationAggregateSendCounters()
	if !afterJoin.Timing.Complete || !afterJoin.Timing.ResetPerformed ||
		afterJoin.Timing.DataAbandonedFrames != 2 ||
		afterJoin.Timing.DataAbandonedPayloadBytes != 300 ||
		afterJoin.Timing.DataCompletedFrames != 2 ||
		afterJoin.Timing.DataCompletedPayloadBytes != 300 {
		t.Fatalf("send-loop terminal accounting = %+v", afterJoin.Timing)
	}
}
