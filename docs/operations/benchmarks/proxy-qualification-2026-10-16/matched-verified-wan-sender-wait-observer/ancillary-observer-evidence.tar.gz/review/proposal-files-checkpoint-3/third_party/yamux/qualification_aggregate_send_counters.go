//go:build p2pstream_qualification

package yamux

import "time"

const qualificationAggregateSendCountersEnabled = true

type qualificationCreditWaitCause uint8

const (
	qualificationCreditWaitByteZero qualificationCreditWaitCause = iota
	qualificationCreditWaitStreamAllocationZero
	qualificationCreditWaitSessionAllocationZero
	qualificationCreditWaitStreamAndSessionAllocationZero
	qualificationCreditWaitCauseCount
)

type qualificationCreditWaitOutcome uint8

const (
	qualificationCreditWakeByteNotify qualificationCreditWaitOutcome = iota
	qualificationCreditWakeAggregateNotify
	qualificationCreditWakeShutdown
	qualificationCreditWakeTimeout
	qualificationCreditWaitOutcomeCount
)

type qualificationDataEnqueueOutcome uint8

const (
	qualificationDataEnqueueAccepted qualificationDataEnqueueOutcome = iota
	qualificationDataEnqueueShutdown
	qualificationDataEnqueueTimeout
	qualificationDataEnqueueOutcomeCount
)

type qualificationDataCompletionOutcome uint8

const (
	qualificationDataCompletionSuccess qualificationDataCompletionOutcome = iota
	qualificationDataCompletionError
	qualificationDataCompletionShutdown
	qualificationDataCompletionTimeout
	qualificationDataCompletionOutcomeCount
)

type qualificationPhysicalWriteOutcome uint8

const (
	qualificationPhysicalWriteSuccess qualificationPhysicalWriteOutcome = iota
	qualificationPhysicalWriteError
	qualificationPhysicalWriteShort
	qualificationPhysicalWriteOutcomeCount
)

type qualificationDurationBucket struct {
	count uint64
	total uint64
	max   uint64
}

func qualificationAddUint64(target *uint64, value uint64, overflow *bool) {
	if ^uint64(0)-*target < value {
		*overflow = true
		return
	}
	*target += value
}

func qualificationIncrement(target *uint64, overflow *bool) {
	qualificationAddUint64(target, 1, overflow)
}

func (b *qualificationDurationBucket) add(duration time.Duration, overflow *bool) {
	if duration < 0 {
		duration = 0
	}
	nanos := uint64(duration)
	qualificationIncrement(&b.count, overflow)
	qualificationAddUint64(&b.total, nanos, overflow)
	if nanos > b.max {
		b.max = nanos
	}
}

type qualificationAggregateSendWait struct {
	token   uint64
	started time.Time
	cause   qualificationCreditWaitCause
	valid   bool
}

type qualificationDataSendWait struct {
	started      time.Time
	wholeStarted time.Time
	streamID     uint32
	payloadBytes uint64
	wireBytes    uint64
	valid        bool
}

// qualificationAggregateSendCounters is protected by aggregateWindow.mu.
// The ordinary build substitutes an empty type at the existing field.
type qualificationAggregateSendCounters struct {
	reservedDataFrames                   uint64
	reservedPayloadBytes                 uint64
	reservedAllocationChargedBytes       uint64
	activeReservedFrames                 uint64
	activeReservedPayloadBytes           uint64
	activeReservedAllocationChargedBytes uint64
	byteCreditZeroObservations           uint64
	streamAllocationZeroObservations     uint64
	sessionAllocationZeroObservations    uint64

	streamObserved     bool
	streamID           uint32
	multipleStreams    bool
	ambiguous          bool
	overflow           bool
	nextToken          uint64
	firstWaitToken     uint64
	lastWaitToken      uint64
	sendLoopTerminated bool

	pendingCreditDecision bool
	pendingToken          uint64
	pendingStreamID       uint32
	pendingStarted        time.Time
	pendingCause          qualificationCreditWaitCause
	activeCreditWaits     uint64
	creditWaitTotal       qualificationDurationBucket
	creditWaitByCause     [qualificationCreditWaitCauseCount]qualificationDurationBucket
	creditWaitByOutcome   [qualificationCreditWaitOutcomeCount]qualificationDurationBucket

	dataEnqueueTotal        qualificationDurationBucket
	dataEnqueueByOutcome    [qualificationDataEnqueueOutcomeCount]qualificationDurationBucket
	dataCompletionTotal     qualificationDurationBucket
	dataCompletionByOutcome [qualificationDataCompletionOutcomeCount]qualificationDurationBucket
	dataCallTotal           qualificationDurationBucket
	dataCallByOutcome       [qualificationDataCompletionOutcomeCount]qualificationDurationBucket

	dataEnqueuedFrames             uint64
	dataEnqueuedPayloadBytes       uint64
	activeCallerFrames             uint64
	activeCallerPayloadBytes       uint64
	activeEnqueueFrames            uint64
	activeEnqueuePayloadBytes      uint64
	activeQueuedFrames             uint64
	activeQueuedPayloadBytes       uint64
	claimedBeforePublicationFrames uint64
	claimedBeforePublicationBytes  uint64
	enqueuePublicationRaces        uint64
	activePhysicalFrames           uint64
	activePhysicalPayloadBytes     uint64
	dataCompletedFrames            uint64
	dataCompletedPayloadBytes      uint64
	dataGatherErrorFrames          uint64
	dataGatherErrorPayloadBytes    uint64
	dataAbandonedFrames            uint64
	dataAbandonedPayloadBytes      uint64

	physicalWriteTotal            qualificationDurationBucket
	physicalWriteByOutcome        [qualificationPhysicalWriteOutcomeCount]qualificationDurationBucket
	physicalAttemptFrames         uint64
	physicalAttemptPayloadBytes   uint64
	physicalAttemptWireBytes      uint64
	physicalWrittenWireBytes      uint64
	physicalSuccessFrames         uint64
	physicalSuccessPayloadBytes   uint64
	physicalSuccessWireBytes      uint64
	physicalErrorFrames           uint64
	physicalErrorPayloadBytes     uint64
	physicalErrorAttemptWireBytes uint64
	physicalErrorWrittenWireBytes uint64
	physicalShortFrames           uint64
	physicalShortPayloadBytes     uint64
	physicalShortAttemptWireBytes uint64
	physicalShortWrittenWireBytes uint64
}

func (c *qualificationAggregateSendCounters) observeStream(streamID uint32) {
	if !c.streamObserved {
		c.streamObserved, c.streamID = true, streamID
		return
	}
	if c.streamID != streamID {
		c.multipleStreams = true
	}
}

func (c *qualificationAggregateSendCounters) recordReservedData(streamID, payload, charged uint32) {
	c.observeStream(streamID)
	qualificationIncrement(&c.reservedDataFrames, &c.overflow)
	qualificationAddUint64(&c.reservedPayloadBytes, uint64(payload), &c.overflow)
	qualificationAddUint64(&c.reservedAllocationChargedBytes, uint64(charged), &c.overflow)
	qualificationIncrement(&c.activeReservedFrames, &c.overflow)
	qualificationAddUint64(&c.activeReservedPayloadBytes, uint64(payload), &c.overflow)
	qualificationAddUint64(&c.activeReservedAllocationChargedBytes, uint64(charged), &c.overflow)
}

func (c *qualificationAggregateSendCounters) recordAllocationZero(sessionZero, streamZero bool) {
	if sessionZero {
		qualificationIncrement(&c.sessionAllocationZeroObservations, &c.overflow)
	}
	if streamZero {
		qualificationIncrement(&c.streamAllocationZeroObservations, &c.overflow)
	}
}

// recordQualificationByteCreditZero remains for direct qualification fixtures.
// Stream.write uses beginQualificationByteCreditWait so the real wait has one
// entry timestamp and one active owner.
func (s *Session) recordQualificationByteCreditZero() {
	if s == nil || s.aggregate == nil {
		return
	}
	s.aggregate.mu.Lock()
	qualificationIncrement(&s.aggregate.qualification.byteCreditZeroObservations, &s.aggregate.qualification.overflow)
	s.aggregate.mu.Unlock()
}

func (c *qualificationAggregateSendCounters) nextWaitToken() uint64 {
	if c.nextToken == ^uint64(0) {
		c.overflow = true
		return 0
	}
	c.nextToken++
	if c.firstWaitToken == 0 {
		c.firstWaitToken = c.nextToken
	}
	c.lastWaitToken = c.nextToken
	return c.nextToken
}

func (s *Stream) beginQualificationByteCreditWait() qualificationAggregateSendWait {
	if s == nil || s.session == nil || s.session.aggregate == nil {
		return qualificationAggregateSendWait{}
	}
	a := s.session.aggregate
	a.mu.Lock()
	defer a.mu.Unlock()
	c := &a.qualification
	c.observeStream(s.id)
	qualificationIncrement(&c.byteCreditZeroObservations, &c.overflow)
	qualificationIncrement(&c.activeCreditWaits, &c.overflow)
	token := c.nextWaitToken()
	return qualificationAggregateSendWait{token: token, started: time.Now(), cause: qualificationCreditWaitByteZero, valid: token != 0}
}

// recordQualificationAggregateCreditWaitDecision runs with aggregateWindow.mu.
func (c *qualificationAggregateSendCounters) recordQualificationAggregateCreditWaitDecision(streamID uint32, sessionZero, streamZero bool) {
	c.observeStream(streamID)
	if c.pendingCreditDecision {
		c.ambiguous = true
	}
	if !sessionZero && !streamZero {
		c.ambiguous = true
		return
	}
	cause := qualificationCreditWaitSessionAllocationZero
	if streamZero {
		cause = qualificationCreditWaitStreamAllocationZero
	}
	if sessionZero && streamZero {
		cause = qualificationCreditWaitStreamAndSessionAllocationZero
	}
	c.pendingCreditDecision = true
	c.pendingToken = c.nextWaitToken()
	c.pendingStreamID = streamID
	c.pendingStarted = time.Now()
	c.pendingCause = cause
}

func (s *Stream) takeQualificationAggregateCreditWaitDecision() qualificationAggregateSendWait {
	if s == nil || s.session == nil || s.session.aggregate == nil {
		return qualificationAggregateSendWait{}
	}
	a := s.session.aggregate
	a.mu.Lock()
	defer a.mu.Unlock()
	c := &a.qualification
	if !c.pendingCreditDecision || c.pendingStreamID != s.id {
		c.ambiguous = true
		return qualificationAggregateSendWait{}
	}
	wait := qualificationAggregateSendWait{token: c.pendingToken, started: c.pendingStarted, cause: c.pendingCause, valid: true}
	c.pendingCreditDecision = false
	c.pendingToken, c.pendingStreamID = 0, 0
	c.pendingStarted = time.Time{}
	qualificationIncrement(&c.activeCreditWaits, &c.overflow)
	return wait
}

func (s *Stream) finishQualificationCreditWait(wait qualificationAggregateSendWait, outcome qualificationCreditWaitOutcome) {
	if !wait.valid || s == nil || s.session == nil || s.session.aggregate == nil {
		return
	}
	finished := time.Now()
	a := s.session.aggregate
	a.mu.Lock()
	defer a.mu.Unlock()
	c := &a.qualification
	c.observeStream(s.id)
	if wait.token == 0 || wait.cause >= qualificationCreditWaitCauseCount || outcome >= qualificationCreditWaitOutcomeCount || c.activeCreditWaits == 0 {
		c.ambiguous = true
		return
	}
	c.activeCreditWaits--
	duration := finished.Sub(wait.started)
	c.creditWaitTotal.add(duration, &c.overflow)
	c.creditWaitByCause[wait.cause].add(duration, &c.overflow)
	c.creditWaitByOutcome[outcome].add(duration, &c.overflow)
}

func (s *Session) beginQualificationDataEnqueue(streamID uint32, payloadBytes int) qualificationDataSendWait {
	if s == nil || s.aggregate == nil || payloadBytes < 0 || uint64(payloadBytes) > uint64(^uint32(0)) {
		return qualificationDataSendWait{}
	}
	s.aggregate.mu.Lock()
	c := &s.aggregate.qualification
	c.observeStream(streamID)
	payload := uint64(payloadBytes)
	charged := uint64(aggregateDataCharge(uint32(payloadBytes)))
	if c.activeReservedFrames == 0 || c.activeReservedPayloadBytes < payload || c.activeReservedAllocationChargedBytes < charged {
		c.ambiguous = true
		s.aggregate.mu.Unlock()
		return qualificationDataSendWait{}
	}
	c.activeReservedFrames--
	c.activeReservedPayloadBytes -= payload
	c.activeReservedAllocationChargedBytes -= charged
	qualificationIncrement(&c.activeCallerFrames, &c.overflow)
	qualificationAddUint64(&c.activeCallerPayloadBytes, payload, &c.overflow)
	qualificationIncrement(&c.activeEnqueueFrames, &c.overflow)
	qualificationAddUint64(&c.activeEnqueuePayloadBytes, payload, &c.overflow)
	s.aggregate.mu.Unlock()
	started := time.Now()
	return qualificationDataSendWait{started: started, wholeStarted: started, streamID: streamID, payloadBytes: payload, valid: true}
}

func (s *Session) finishQualificationDataEnqueue(wait qualificationDataSendWait, outcome qualificationDataEnqueueOutcome) qualificationDataSendWait {
	if !wait.valid || s == nil || s.aggregate == nil {
		return qualificationDataSendWait{}
	}
	finished := time.Now()
	a := s.aggregate
	a.mu.Lock()
	defer a.mu.Unlock()
	c := &a.qualification
	c.observeStream(wait.streamID)
	if outcome >= qualificationDataEnqueueOutcomeCount {
		c.ambiguous = true
		return qualificationDataSendWait{}
	}
	duration := finished.Sub(wait.started)
	c.dataEnqueueTotal.add(duration, &c.overflow)
	c.dataEnqueueByOutcome[outcome].add(duration, &c.overflow)
	if outcome != qualificationDataEnqueueAccepted {
		if c.activeEnqueueFrames == 0 || c.activeEnqueuePayloadBytes < wait.payloadBytes {
			c.ambiguous = true
			return qualificationDataSendWait{}
		}
		c.activeEnqueueFrames--
		c.activeEnqueuePayloadBytes -= wait.payloadBytes
		if c.activeCallerFrames == 0 || c.activeCallerPayloadBytes < wait.payloadBytes {
			c.ambiguous = true
			return qualificationDataSendWait{}
		}
		c.activeCallerFrames--
		c.activeCallerPayloadBytes -= wait.payloadBytes
		wholeDuration := finished.Sub(wait.wholeStarted)
		wholeOutcome := qualificationDataCompletionShutdown
		if outcome == qualificationDataEnqueueTimeout {
			wholeOutcome = qualificationDataCompletionTimeout
		}
		c.dataCallTotal.add(wholeDuration, &c.overflow)
		c.dataCallByOutcome[wholeOutcome].add(wholeDuration, &c.overflow)
		return qualificationDataSendWait{}
	}
	qualificationIncrement(&c.dataEnqueuedFrames, &c.overflow)
	qualificationAddUint64(&c.dataEnqueuedPayloadBytes, wait.payloadBytes, &c.overflow)
	if c.claimedBeforePublicationFrames != 0 && c.claimedBeforePublicationBytes >= wait.payloadBytes {
		c.claimedBeforePublicationFrames--
		c.claimedBeforePublicationBytes -= wait.payloadBytes
	} else if c.sendLoopTerminated {
		if c.activeEnqueueFrames == 0 || c.activeEnqueuePayloadBytes < wait.payloadBytes {
			c.ambiguous = true
			return qualificationDataSendWait{}
		}
		c.activeEnqueueFrames--
		c.activeEnqueuePayloadBytes -= wait.payloadBytes
		qualificationIncrement(&c.dataAbandonedFrames, &c.overflow)
		qualificationAddUint64(&c.dataAbandonedPayloadBytes, wait.payloadBytes, &c.overflow)
		qualificationIncrement(&c.dataCompletedFrames, &c.overflow)
		qualificationAddUint64(&c.dataCompletedPayloadBytes, wait.payloadBytes, &c.overflow)
	} else {
		if c.activeEnqueueFrames == 0 || c.activeEnqueuePayloadBytes < wait.payloadBytes {
			c.ambiguous = true
			return qualificationDataSendWait{}
		}
		c.activeEnqueueFrames--
		c.activeEnqueuePayloadBytes -= wait.payloadBytes
		qualificationIncrement(&c.activeQueuedFrames, &c.overflow)
		qualificationAddUint64(&c.activeQueuedPayloadBytes, wait.payloadBytes, &c.overflow)
	}
	wait.started = finished
	return wait
}

func (s *Session) finishQualificationDataCompletion(wait qualificationDataSendWait, outcome qualificationDataCompletionOutcome) {
	if !wait.valid || s == nil || s.aggregate == nil {
		return
	}
	finished := time.Now()
	a := s.aggregate
	a.mu.Lock()
	defer a.mu.Unlock()
	c := &a.qualification
	c.observeStream(wait.streamID)
	if outcome >= qualificationDataCompletionOutcomeCount || c.activeCallerFrames == 0 || c.activeCallerPayloadBytes < wait.payloadBytes {
		c.ambiguous = true
		return
	}
	c.activeCallerFrames--
	c.activeCallerPayloadBytes -= wait.payloadBytes
	duration := finished.Sub(wait.started)
	c.dataCompletionTotal.add(duration, &c.overflow)
	c.dataCompletionByOutcome[outcome].add(duration, &c.overflow)
	wholeDuration := finished.Sub(wait.wholeStarted)
	c.dataCallTotal.add(wholeDuration, &c.overflow)
	c.dataCallByOutcome[outcome].add(wholeDuration, &c.overflow)
}
