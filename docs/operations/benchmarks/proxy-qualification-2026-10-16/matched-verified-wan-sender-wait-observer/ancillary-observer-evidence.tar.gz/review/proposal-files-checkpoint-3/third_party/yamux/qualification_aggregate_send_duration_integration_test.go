//go:build p2pstream_qualification

package yamux

import (
	"errors"
	"io"
	"sync/atomic"
	"testing"
	"time"
)

func newQualificationPathSession(conn io.ReadWriteCloser, timeout time.Duration) *Session {
	session := newGatherSendSession(conn, timeout)
	config := smallAggregateTestConfig()
	config.ConnectionWriteTimeout = timeout
	session.config = config
	session.aggregate = newAggregateWindow(config)
	session.recvDoneCh = closedGatherChannel()
	session.pingReplyDoneCh = closedGatherChannel()
	close(session.aggregate.publishDone)
	return session
}

func waitForQualificationState(t *testing.T, session *Session, accept func(*qualificationAggregateSendCounters) bool) {
	t.Helper()
	deadline := time.Now().Add(time.Second)
	for {
		session.aggregate.mu.Lock()
		accepted := accept(&session.aggregate.qualification)
		session.aggregate.mu.Unlock()
		if accepted {
			return
		}
		if time.Now().After(deadline) {
			t.Fatal("qualification state was not reached")
		}
		time.Sleep(time.Millisecond)
	}
}

func requireQualificationSendJoin(t *testing.T, session *Session) {
	t.Helper()
	select {
	case <-session.sendDoneCh:
	case <-time.After(time.Second):
		t.Fatal("tagged send loop did not join")
	}
}

func closeQualificationTestChannel(ch chan struct{}) {
	select {
	case <-ch:
	default:
		close(ch)
	}
}

func registerQualificationSendCleanup(t *testing.T, session *Session, releases ...chan struct{}) {
	t.Helper()
	t.Cleanup(func() {
		for _, release := range releases {
			closeQualificationTestChannel(release)
		}
		closeQualificationTestChannel(session.shutdownCh)
		select {
		case <-session.sendDoneCh:
		case <-time.After(time.Second):
			t.Errorf("cleanup could not join tagged send loop")
		}
	})
}

func TestQualificationSenderDurationActualStreamWriteCreditWakePaths(t *testing.T) {
	tests := []struct {
		name      string
		configure func(*Session, *Stream)
		wake      func(*Session, *Stream)
		cause     qualificationCreditWaitCause
		outcome   qualificationCreditWaitOutcome
	}{
		{
			name: "byte_credit",
			configure: func(_ *Session, stream *Stream) {
				stream.sendWindow = 0
			},
			wake: func(_ *Session, stream *Stream) {
				atomic.StoreUint32(&stream.sendWindow, AggregateWindowUnitSize)
				asyncNotify(stream.sendNotifyCh)
			},
			cause:   qualificationCreditWaitByteZero,
			outcome: qualificationCreditWakeByteNotify,
		},
		{
			name: "stream_allocation",
			configure: func(_ *Session, stream *Stream) {
				stream.allocationSendWindow = 0
			},
			wake: func(session *Session, stream *Stream) {
				session.aggregate.mu.Lock()
				stream.allocationSendWindow = AggregateWindowUnitSize
				session.aggregate.broadcastSendLocked()
				session.aggregate.mu.Unlock()
			},
			cause:   qualificationCreditWaitStreamAllocationZero,
			outcome: qualificationCreditWakeAggregateNotify,
		},
		{
			name: "session_allocation",
			configure: func(session *Session, _ *Stream) {
				session.aggregate.sendWindow = 0
			},
			wake: func(session *Session, _ *Stream) {
				session.aggregate.mu.Lock()
				session.aggregate.sendWindow = AggregateWindowUnitSize
				session.aggregate.broadcastSendLocked()
				session.aggregate.mu.Unlock()
			},
			cause:   qualificationCreditWaitSessionAllocationZero,
			outcome: qualificationCreditWakeAggregateNotify,
		},
		{
			name: "stream_and_session_allocation",
			configure: func(session *Session, stream *Stream) {
				session.aggregate.sendWindow = 0
				stream.allocationSendWindow = 0
			},
			wake: func(session *Session, stream *Stream) {
				session.aggregate.mu.Lock()
				session.aggregate.sendWindow = AggregateWindowUnitSize
				stream.allocationSendWindow = AggregateWindowUnitSize
				session.aggregate.broadcastSendLocked()
				session.aggregate.mu.Unlock()
			},
			cause:   qualificationCreditWaitStreamAndSessionAllocationZero,
			outcome: qualificationCreditWakeAggregateNotify,
		},
	}

	for index, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			conn := newGatherRecordingConn()
			session := newQualificationPathSession(conn, time.Second)
			stream := newStream(session, uint32(41+index), streamEstablished)
			test.configure(session, stream)
			go session.send()
			registerQualificationSendCleanup(t, session)

			payload := make([]byte, 128)
			writeDone := make(chan struct {
				n   int
				err error
			}, 1)
			go func() {
				n, err := stream.write(payload)
				writeDone <- struct {
					n   int
					err error
				}{n: n, err: err}
			}()

			waitForQualificationState(t, session, func(c *qualificationAggregateSendCounters) bool {
				return c.activeCreditWaits == 1
			})
			test.wake(session, stream)
			select {
			case result := <-writeDone:
				if result.n != len(payload) || result.err != nil {
					t.Fatalf("actual Stream.write = (%d, %v), want (%d, nil)", result.n, result.err, len(payload))
				}
			case <-time.After(time.Second):
				t.Fatal("actual Stream.write did not finish")
			}

			close(session.shutdownCh)
			requireQualificationSendJoin(t, session)
			got := session.DrainQualificationAggregateSendCounters()
			if !got.Timing.Complete || !got.Timing.ResetPerformed || got.Timing.Ambiguous ||
				!got.Timing.SendLoopTerminated || got.Timing.CreditWaitTotal.Count != 1 ||
				got.Timing.DataEnqueuedFrames != 1 || got.Timing.DataCompletedFrames != 1 ||
				got.Timing.PhysicalSuccessFrames != 1 || got.Timing.DataCallByOutcome.Success.Count != 1 {
				t.Fatalf("actual credit-wake path accounting = %+v", got.Timing)
			}
			if got.Timing.creditWaitCause(test.cause).Count != 1 || got.Timing.creditWaitOutcome(test.outcome).Count != 1 {
				t.Fatalf("actual credit-wake classification = %+v", got.Timing)
			}
			requirePositiveBucket(t, got.Timing.CreditWaitTotal)
			requirePositiveBucket(t, got.Timing.DataCallByOutcome.Success)
			requirePositiveBucket(t, got.Timing.PhysicalWriteByOutcome.Success)
		})
	}
}

func TestQualificationSenderDurationActualStreamWriteCreditTerminalPaths(t *testing.T) {
	tests := []struct {
		name    string
		prepare func(*Session, *Stream)
		finish  func(*Session, *Stream)
		wantErr error
		outcome qualificationCreditWaitOutcome
	}{
		{
			name: "shutdown",
			prepare: func(_ *Session, stream *Stream) {
				atomic.StoreUint32(&stream.sendWindow, 0)
			},
			finish: func(session *Session, _ *Stream) {
				closeQualificationTestChannel(session.shutdownCh)
			},
			wantErr: ErrSessionShutdown,
			outcome: qualificationCreditWakeShutdown,
		},
		{
			name: "deadline",
			prepare: func(_ *Session, stream *Stream) {
				atomic.StoreUint32(&stream.sendWindow, 0)
				stream.writeDeadline.Store(time.Now().Add(100 * time.Millisecond))
			},
			finish:  func(_ *Session, _ *Stream) {},
			wantErr: ErrTimeout,
			outcome: qualificationCreditWakeTimeout,
		},
	}

	for index, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			session := newQualificationPathSession(newGatherRecordingConn(), time.Second)
			stream := newStream(session, uint32(81+index), streamEstablished)
			test.prepare(session, stream)
			go session.send()
			registerQualificationSendCleanup(t, session)
			writeDone := make(chan error, 1)
			go func() {
				_, err := stream.write([]byte("credit terminal path"))
				writeDone <- err
			}()
			waitForQualificationState(t, session, func(c *qualificationAggregateSendCounters) bool {
				return c.activeCreditWaits == 1
			})
			test.finish(session, stream)
			select {
			case err := <-writeDone:
				if !errors.Is(err, test.wantErr) {
					t.Fatalf("actual Stream.write error = %v, want %v", err, test.wantErr)
				}
			case <-time.After(time.Second):
				t.Fatal("actual Stream.write credit terminal path did not finish")
			}
			closeQualificationTestChannel(session.shutdownCh)
			requireQualificationSendJoin(t, session)
			got := session.DrainQualificationAggregateSendCounters()
			if !got.Timing.Complete || !got.Timing.ResetPerformed || got.Timing.Ambiguous ||
				!got.Timing.SendLoopTerminated || got.Timing.CreditWaitTotal.Count != 1 ||
				got.Timing.CreditWaitByCause.ByteZero.Count != 1 ||
				got.Timing.creditWaitOutcome(test.outcome).Count != 1 ||
				got.ReservedDataFrames != 0 || got.Timing.DataEnqueuedFrames != 0 {
				t.Fatalf("actual credit terminal path accounting = %+v", got)
			}
			requirePositiveBucket(t, got.Timing.CreditWaitTotal)
		})
	}
}

func (timing QualificationAggregateSendTiming) creditWaitCause(cause qualificationCreditWaitCause) QualificationDurationBucket {
	switch cause {
	case qualificationCreditWaitByteZero:
		return timing.CreditWaitByCause.ByteZero
	case qualificationCreditWaitStreamAllocationZero:
		return timing.CreditWaitByCause.StreamAllocationZero
	case qualificationCreditWaitSessionAllocationZero:
		return timing.CreditWaitByCause.SessionAllocationZero
	case qualificationCreditWaitStreamAndSessionAllocationZero:
		return timing.CreditWaitByCause.StreamAndSessionAllocationZero
	default:
		return QualificationDurationBucket{}
	}
}

func (timing QualificationAggregateSendTiming) creditWaitOutcome(outcome qualificationCreditWaitOutcome) QualificationDurationBucket {
	switch outcome {
	case qualificationCreditWakeByteNotify:
		return timing.CreditWaitByOutcome.ByteNotify
	case qualificationCreditWakeAggregateNotify:
		return timing.CreditWaitByOutcome.AggregateNotify
	case qualificationCreditWakeShutdown:
		return timing.CreditWaitByOutcome.Shutdown
	case qualificationCreditWakeTimeout:
		return timing.CreditWaitByOutcome.Timeout
	default:
		return QualificationDurationBucket{}
	}
}

func TestQualificationSenderDurationActualBlockedEnqueueTimeoutJoins(t *testing.T) {
	session := newQualificationPathSession(newGatherRecordingConn(), 20*time.Millisecond)
	stream := newStream(session, 51, streamEstablished)
	for i := 0; i < cap(session.sendCh); i++ {
		session.sendCh <- &sendReady{Hdr: header(make([]byte, headerSize))}
	}
	payload := []byte("blocked enqueue")
	reserved, wake := stream.reserveAggregateSend(uint32(len(payload)))
	if reserved != uint32(len(payload)) || wake != nil {
		t.Fatalf("DATA reservation = (%d, %v)", reserved, wake != nil)
	}
	hdr := header(make([]byte, headerSize))
	hdr.encode(typeData, 0, stream.id, uint32(len(payload)))
	errCh := make(chan error, 1)
	if err := session.waitForSendErr(hdr, payload, errCh); !errors.Is(err, ErrConnectionWriteTimeout) {
		t.Fatalf("blocked enqueue error = %v, want %v", err, ErrConnectionWriteTimeout)
	}

	close(session.shutdownCh)
	go session.send()
	registerQualificationSendCleanup(t, session)
	requireQualificationSendJoin(t, session)
	got := session.DrainQualificationAggregateSendCounters()
	if !got.Timing.Complete || !got.Timing.ResetPerformed || got.Timing.Ambiguous ||
		!got.Timing.SendLoopTerminated || got.Timing.DataEnqueuedFrames != 0 || got.Timing.DataCompletedFrames != 0 ||
		got.Timing.DataEnqueueSelectByOutcome.Timeout.Count != 1 || got.Timing.DataCallByOutcome.Timeout.Count != 1 {
		t.Fatalf("actual blocked enqueue timeout = %+v", got.Timing)
	}
	requirePositiveBucket(t, got.Timing.DataEnqueueSelectByOutcome.Timeout)
	requirePositiveBucket(t, got.Timing.DataCallByOutcome.Timeout)
}

func TestQualificationSenderDurationActualPhysicalWriteOutlivesCallerShutdownAndJoins(t *testing.T) {
	conn := newBlockingGatherConn()
	session := newQualificationPathSession(conn, time.Second)
	stream := newStream(session, 61, streamEstablished)
	payload := []byte("physical write barrier")
	reserved, wake := stream.reserveAggregateSend(uint32(len(payload)))
	if reserved != uint32(len(payload)) || wake != nil {
		t.Fatalf("DATA reservation = (%d, %v)", reserved, wake != nil)
	}
	hdr := header(make([]byte, headerSize))
	hdr.encode(typeData, 0, stream.id, uint32(len(payload)))
	errCh := make(chan error, 1)
	waitDone := make(chan error, 1)
	go session.send()
	registerQualificationSendCleanup(t, session, conn.release)
	go func() { waitDone <- session.waitForSendErr(hdr, payload, errCh) }()

	select {
	case <-conn.started:
	case <-time.After(time.Second):
		t.Fatal("actual physical DATA write did not reach barrier")
	}
	waitForQualificationState(t, session, func(c *qualificationAggregateSendCounters) bool {
		return c.activeCallerFrames == 1 && c.activePhysicalFrames == 1
	})
	close(session.shutdownCh)
	select {
	case err := <-waitDone:
		if !errors.Is(err, ErrSessionShutdown) {
			t.Fatalf("caller result = %v, want %v", err, ErrSessionShutdown)
		}
	case <-time.After(time.Second):
		t.Fatal("caller did not observe shutdown")
	}

	inFlight := session.DrainQualificationAggregateSendCounters()
	if inFlight.Timing.Complete || inFlight.Timing.ResetPerformed ||
		inFlight.Timing.ActiveCallerFrames != 0 || inFlight.Timing.ActivePhysicalFrames != 1 {
		t.Fatalf("physical operation was released with caller = %+v", inFlight.Timing)
	}
	close(conn.release)
	select {
	case <-conn.wrote:
	case <-time.After(time.Second):
		t.Fatal("actual physical DATA write did not leave barrier")
	}
	requireQualificationSendJoin(t, session)
	got := session.DrainQualificationAggregateSendCounters()
	if !got.Timing.Complete || !got.Timing.ResetPerformed || got.Timing.Ambiguous ||
		!got.Timing.SendLoopTerminated || got.Timing.DataCompletedFrames != 1 ||
		got.Timing.PhysicalSuccessFrames != 1 || got.Timing.DataCompletionSelectByOutcome.Shutdown.Count != 1 ||
		got.Timing.DataCallByOutcome.Shutdown.Count != 1 {
		t.Fatalf("actual physical-write shutdown accounting = %+v", got.Timing)
	}
	requirePositiveBucket(t, got.Timing.DataCompletionSelectByOutcome.Shutdown)
	requirePositiveBucket(t, got.Timing.DataCallByOutcome.Shutdown)
	requirePositiveBucket(t, got.Timing.PhysicalWriteByOutcome.Success)
}

func TestQualificationSenderDurationActualSessionClosePublishesTerminalLedger(t *testing.T) {
	session := newQualificationPathSession(newGatherRecordingConn(), time.Second)
	stream := newStream(session, 71, streamEstablished)
	go session.send()
	registerQualificationSendCleanup(t, session)
	payload := []byte("close join")
	if n, err := stream.write(payload); n != len(payload) || err != nil {
		t.Fatalf("actual Stream.write = (%d, %v), want (%d, nil)", n, err, len(payload))
	}
	if err := session.Close(); err != nil {
		t.Fatalf("Session.Close: %v", err)
	}
	select {
	case <-session.sendDoneCh:
	default:
		t.Fatal("Session.Close returned before sendDoneCh joined")
	}
	got := session.DrainQualificationAggregateSendCounters()
	if !got.Timing.Complete || !got.Timing.ResetPerformed || got.Timing.Ambiguous ||
		!got.Timing.SendLoopTerminated || got.Timing.DataEnqueuedFrames != 1 ||
		got.Timing.DataCompletedFrames != 1 || got.Timing.PhysicalSuccessFrames != 1 {
		t.Fatalf("Session.Close did not publish terminal ledger state = %+v", got.Timing)
	}
}
