#!/usr/bin/env python3
"""Mechanically isolate the two tagged observer method bodies.

This generator is source-only. It verifies the cp4 input hashes, extracts the
ordinary bodies from the pinned 8ac4c8d copies and the tagged bodies from cp4,
then removes only those declarations from the shared files.
"""

from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source" / "third_party" / "yamux"
BASELINE = ROOT / "review" / "baseline-files-8ac4c8d" / "third_party" / "yamux"

EXPECTED_CP4 = {
    "session.go": "7dad66495862b2695d16abd13592cd536e0e3e6128406af73d612e8eaf4c64df",
    "stream.go": "b5d7346c704a0fb75da49010fd98aba136ec88251c78718712e5cf07c25974b8",
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def take(text: str, start: str, following: str) -> tuple[str, str]:
    first = text.index(start)
    end = text.index(following, first)
    extracted = text[first:end].rstrip() + "\n"
    remainder = text[:first] + text[end:]
    return extracted, remainder


def write_method_file(path: Path, build: str, imports: tuple[str, ...], body: str) -> None:
    import_block = "import (\n" + "".join(f'\t"{item}"\n' for item in imports) + ")\n\n"
    path.write_text(
        f"//go:build {build}\n\npackage yamux\n\n" + import_block + body,
        encoding="utf-8",
    )


def main() -> None:
    for name, expected in EXPECTED_CP4.items():
        actual = digest(SOURCE / name)
        if actual != expected:
            raise SystemExit(f"cp4 input mismatch for {name}: {actual}")

    baseline_session = (BASELINE / "session.go").read_text(encoding="utf-8")
    tagged_session = (SOURCE / "session.go").read_text(encoding="utf-8")
    ordinary_send, _ = take(
        baseline_session,
        "func (s *Session) sendLoop() error {",
        "// recv is a long running goroutine that accepts new data",
    )
    tagged_send, shared_session = take(
        tagged_session,
        "func (s *Session) sendLoop() error {",
        "// recv is a long running goroutine that accepts new data",
    )
    shared_session = shared_session.replace('\t"bytes"\n', "", 1)
    if '"bytes"' in shared_session:
        raise SystemExit("unexpected remaining bytes import")

    baseline_stream = (BASELINE / "stream.go").read_text(encoding="utf-8")
    tagged_stream = (SOURCE / "stream.go").read_text(encoding="utf-8")
    write_comment = "// write is used to write to the stream, may return on\n// a short write.\n"
    ordinary_write, _ = take(
        baseline_stream,
        write_comment,
        "// sendFlags determines any flags that are appropriate",
    )
    tagged_write, shared_stream = take(
        tagged_stream,
        write_comment,
        "// sendFlags determines any flags that are appropriate",
    )

    (SOURCE / "session.go").write_text(shared_session, encoding="utf-8")
    (SOURCE / "stream.go").write_text(shared_stream, encoding="utf-8")
    write_method_file(
        SOURCE / "session_send_loop_ordinary.go",
        "!p2pstream_qualification",
        ("bytes", "io"),
        ordinary_send,
    )
    write_method_file(
        SOURCE / "session_send_loop_qualification.go",
        "p2pstream_qualification",
        ("bytes", "io"),
        tagged_send,
    )
    write_method_file(
        SOURCE / "stream_write_ordinary.go",
        "!p2pstream_qualification",
        ("errors", "sync/atomic", "time"),
        ordinary_write,
    )
    write_method_file(
        SOURCE / "stream_write_qualification.go",
        "p2pstream_qualification",
        ("errors", "sync/atomic", "time"),
        tagged_write,
    )


if __name__ == "__main__":
    main()
