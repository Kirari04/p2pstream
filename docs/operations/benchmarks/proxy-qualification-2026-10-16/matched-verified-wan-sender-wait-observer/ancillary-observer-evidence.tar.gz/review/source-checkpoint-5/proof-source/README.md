# Ordinary proof source

This source is frozen for review only. It has not been built or executed.

Apply `ordinary_layout_probe_test.go` identically as a validation-only overlay
to fresh pinned baseline and candidate Yamux trees. Run only its exact named
ordinary test and extract the single `QUALIFICATION_LAYOUT_JSON=` payload from
each successful `go test -json` stream into canonical JSON files. The overlay
is not observer production source.

`compare_ordinary_v2.py` consumes bounded regular files for the baseline and
candidate package-archive objdump, compiler `-S` output, compiler `-m=2`
output, and extracted layout JSON. It requires a fresh output directory and
returns nonzero for any code, compiler frame/stack metadata, per-function full
escape/classification, compiler-cost, or four-type layout difference.

The driver that later invokes this comparator must separately bind pinned Go,
source inventories, exact commands, direct tool statuses, parser/comparator
status, source pre/post hashes, and outer shell status. A nonzero producer or
partial input must never reach an accepted report.
