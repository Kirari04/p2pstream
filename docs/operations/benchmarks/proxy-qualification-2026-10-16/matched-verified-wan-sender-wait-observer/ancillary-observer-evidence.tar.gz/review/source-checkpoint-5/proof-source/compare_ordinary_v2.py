#!/usr/bin/env python3
"""Fail-closed baseline/candidate ordinary-code proof.

Only whole-function load addresses and in-function address targets are
normalized for code comparison. Source positions are normalized only for
compiler classification records. All real instruction bytes, operands,
relocations, frames, PCDATA/FUNCDATA stack metadata, compiler costs, escape
details, and complete four-type layout records remain acceptance gates.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import stat
from pathlib import Path


MAX_INPUT = 64 * 1024 * 1024
EXPECTED = (
    "github.com/hashicorp/yamux.(*Stream).reserveAggregateSend",
    "github.com/hashicorp/yamux.(*Session).waitForSendErrCommitOn",
    "github.com/hashicorp/yamux.(*Session).waitForSendErrCommitOn.func1",
    "github.com/hashicorp/yamux.(*Session).waitForSendErrCommitOn.func2",
    "github.com/hashicorp/yamux.(*Session).waitForSendErrCommitOn.func2.deferwrap1",
    "github.com/hashicorp/yamux.(*Session).send",
    "github.com/hashicorp/yamux.(*Session).sendLoop",
    "github.com/hashicorp/yamux.(*Session).sendLoop.deferwrap1",
    "github.com/hashicorp/yamux.(*Stream).write",
)
SHORT = tuple(name.removeprefix("github.com/hashicorp/yamux.") for name in EXPECTED)
TEXT_LINE = re.compile(r"^TEXT (?P<name>\S+)\(SB\)(?: .*)?$")
OBJ_LINE = re.compile(
    r"^\s+(?P<source>\S+:\d+)\s+(?P<addr>0x[0-9a-f]+)\s+"
    r"(?P<bytes>[0-9a-f]+)\s+(?P<asm>.*?)\s*$"
)
HEX_ADDR = re.compile(r"0x[0-9a-f]+")
STEXT_LINE = re.compile(
    r"^(?P<name>\S+) STEXT size=(?P<size>\d+) args=(?P<args>0x[0-9a-f]+) "
    r"locals=(?P<locals>0x[0-9a-f]+) funcid=(?P<funcid>0x[0-9a-f]+) "
    r"align=(?P<align>0x[0-9a-f]+)$"
)
AUX_LINE = re.compile(r"^(?P<name>\S+) SRODATA (?P<header>.*)$")
SOURCE_PARENS = re.compile(r"\s+\(github\.com/hashicorp/yamux/[^:]+:\d+\)")
SOURCE_PREFIX = re.compile(r"^github\.com/hashicorp/yamux/[^:]+:\d+:\d+: ")
SOURCE_SUFFIX = re.compile(r" at github\.com/hashicorp/yamux/[^:]+:\d+:\d+")
LAYOUT_NAMES = ("Stream", "Session", "aggregateWindow", "sendReady")


def read_regular(path: Path) -> tuple[str, str]:
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_INPUT:
        raise ValueError(f"input is not a bounded regular file: {path} size={info.st_size}")
    raw = path.read_bytes()
    return raw.decode("utf-8", errors="strict"), hashlib.sha256(raw).hexdigest()


def parse_objdump(text: str) -> tuple[dict[str, list[dict]], dict[str, list[str]]]:
    raw: dict[str, list[tuple[str, int, str, str]]] = {}
    current: str | None = None
    for line in text.splitlines():
        header = TEXT_LINE.match(line)
        if header:
            current = header.group("name")
            raw[current] = []
            continue
        if current is None:
            continue
        if not line:
            current = None
            continue
        item = OBJ_LINE.match(line)
        if not item:
            raise ValueError(f"unparsed objdump line in {current}: {line!r}")
        raw[current].append(
            (item.group("source"), int(item.group("addr"), 16), item.group("bytes"), item.group("asm"))
        )
    if set(raw) != set(EXPECTED):
        raise ValueError(f"objdump symbols differ: {sorted(raw)}")
    code: dict[str, list[dict]] = {}
    positions: dict[str, list[str]] = {}
    for name, rows in raw.items():
        if not rows:
            raise ValueError(f"empty function: {name}")
        base = rows[0][1]
        end = max(address + len(encoded) // 2 for _, address, encoded, _ in rows)

        def target(match: re.Match[str]) -> str:
            value = int(match.group(0), 16)
            return f"<FUNC+0x{value - base:x}>" if base <= value <= end else match.group(0)

        code[name] = [
            {
                "offset": address - base,
                "bytes": encoded,
                "assembly": HEX_ADDR.sub(target, assembly),
            }
            for _, address, encoded, assembly in rows
        ]
        positions[name] = [source for source, _, _, _ in rows]
    return code, positions


def compiler_functions(text: str) -> tuple[dict[str, dict], dict[str, list[str]], dict[str, list[str]]]:
    lines = text.splitlines()
    records: dict[str, dict] = {}
    source_positions: dict[str, list[str]] = {}
    for index, line in enumerate(lines):
        header = STEXT_LINE.match(line)
        if not header or header.group("name") not in EXPECTED:
            continue
        name = header.group("name")
        metadata: list[str] = []
        positions: list[str] = []
        frame = None
        cursor = index + 1
        while cursor < len(lines):
            candidate = lines[cursor]
            if STEXT_LINE.match(candidate):
                break
            if candidate and not candidate.startswith("\t"):
                break
            stripped = SOURCE_PARENS.sub("", candidate)
            if "\tTEXT\t" in stripped:
                frame = stripped.split("\tTEXT\t", 1)[1]
            if "\tFUNCDATA\t" in stripped or "\tPCDATA\t" in stripped:
                metadata.append(stripped.strip())
            position = SOURCE_PARENS.search(candidate)
            if position:
                positions.append(position.group(0).strip())
            cursor += 1
        if frame is None:
            raise ValueError(f"missing compiler TEXT frame for {name}")
        records[name] = {
            "size": int(header.group("size")),
            "args": header.group("args"),
            "locals": header.group("locals"),
            "funcid": header.group("funcid"),
            "align": header.group("align"),
            "frame": frame,
            "stack_metadata": metadata,
        }
        source_positions[name] = positions
    if set(records) != set(EXPECTED):
        raise ValueError(f"compiler function symbols differ: {sorted(records)}")
    auxiliary: dict[str, list[str]] = {}
    for index, line in enumerate(lines):
        header = AUX_LINE.match(line)
        if not header:
            continue
        name = header.group("name")
        owner = next(
            (
                expected
                for expected in sorted(EXPECTED, key=len, reverse=True)
                if name.startswith(expected + ".")
            ),
            None,
        )
        if owner is None or not name.endswith((".stkobj", ".opendefer", ".arginfo1", ".argliveinfo")):
            continue
        block = [line]
        cursor = index + 1
        while cursor < len(lines) and (not lines[cursor] or lines[cursor].startswith("\t")):
            block.append(lines[cursor])
            cursor += 1
        auxiliary[name] = block
    referenced_aux = {
        token.removesuffix("(SB)")
        for record in records.values()
        for line in record["stack_metadata"]
        for token in line.split()
        if token.endswith((".stkobj(SB)", ".opendefer(SB)", ".arginfo1(SB)", ".argliveinfo(SB)"))
    }
    missing_aux = referenced_aux - set(auxiliary)
    if missing_aux:
        raise ValueError(f"missing referenced stack/argument metadata: {sorted(missing_aux)}")
    return records, source_positions, auxiliary


def function_for_primary(line: str) -> str | None:
    if line[:1].isspace():
        return None
    classifications = (
        "can inline ",
        "cannot inline ",
        "parameter ",
        " escapes to heap in ",
        " does not escape in ",
        " capturing by ",
    )
    if not any(marker in line for marker in classifications):
        return None
    matches = [
        short
        for short in SHORT
        if any(
            re.search(pattern + re.escape(short) + r"(?=\s|:)", line)
            for pattern in (
                r"(?:can|cannot) inline ",
                r"for ",
                r"in ",
            )
        )
        or re.search(re.escape(short) + r" capturing by ", line)
    ]
    if not matches:
        return None
    return max(matches, key=len)


def escape_records(text: str) -> tuple[dict[str, list[list[str]]], dict[str, list[list[str]]]]:
    normalized: dict[str, list[list[str]]] = {name: [] for name in SHORT}
    raw: dict[str, list[list[str]]] = {name: [] for name in SHORT}
    current_norm: list[str] | None = None
    current_raw: list[str] | None = None
    for original in text.splitlines():
        without_prefix = SOURCE_PREFIX.sub("", original)
        if without_prefix == original:
            current_norm = None
            current_raw = None
            continue
        owner = function_for_primary(without_prefix)
        if owner is not None:
            current_norm = [SOURCE_SUFFIX.sub(" at <SOURCE-POSITION>", without_prefix)]
            current_raw = [original]
            normalized[owner].append(current_norm)
            raw[owner].append(current_raw)
            continue
        if without_prefix[:1].isspace() and current_norm is not None and current_raw is not None:
            current_norm.append(SOURCE_SUFFIX.sub(" at <SOURCE-POSITION>", without_prefix))
            current_raw.append(original)
        else:
            current_norm = None
            current_raw = None
    for name in SHORT:
        if not normalized[name]:
            raise ValueError(f"no escape/classification record for {name}")
        normalized[name].sort(key=lambda record: "\n".join(record))
    return normalized, raw


def parse_layout(text: str) -> list[dict]:
    value = json.loads(text)
    if not isinstance(value, list) or [row.get("name") for row in value] != list(LAYOUT_NAMES):
        raise ValueError("layout JSON lacks the exact ordered four-type set")
    for row in value:
        fields = row.get("fields")
        if not isinstance(fields, list) or row.get("field_count") != len(fields):
            raise ValueError(f"invalid field count for {row.get('name')}")
        if [field.get("index") for field in fields] != list(range(len(fields))):
            raise ValueError(f"invalid field order for {row.get('name')}")
        required = {"index", "name", "type", "offset", "size", "align", "anonymous"}
        if any(set(field) != required for field in fields):
            raise ValueError(f"invalid field schema for {row.get('name')}")
    return value


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    for side in ("baseline", "candidate"):
        parser.add_argument(f"--{side}-objdump", required=True, type=Path)
        parser.add_argument(f"--{side}-asm", required=True, type=Path)
        parser.add_argument(f"--{side}-escape", required=True, type=Path)
        parser.add_argument(f"--{side}-layout", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError(f"fresh output required: {args.output}")
    args.output.mkdir(parents=False)

    parsed: dict[str, dict] = {}
    input_hashes: dict[str, str] = {}
    for side in ("baseline", "candidate"):
        values = {}
        for kind in ("objdump", "asm", "escape", "layout"):
            text, digest = read_regular(getattr(args, f"{side}_{kind}"))
            values[kind] = text
            input_hashes[f"{side}_{kind}"] = digest
        code, code_positions = parse_objdump(values["objdump"])
        compiler, compiler_positions, compiler_auxiliary = compiler_functions(values["asm"])
        escape, escape_raw = escape_records(values["escape"])
        parsed[side] = {
            "code": code,
            "compiler": compiler,
            "compiler_auxiliary": compiler_auxiliary,
            "escape": escape,
            "layout": parse_layout(values["layout"]),
        }
        write_json(args.output / f"{side}-source-positions.json", {
            "objdump": code_positions, "compiler": compiler_positions,
        })
        write_json(args.output / f"{side}-escape-raw.json", escape_raw)
        write_json(args.output / f"{side}-canonical.json", parsed[side])

    gates = {
        key: parsed["baseline"][key] == parsed["candidate"][key]
        for key in ("code", "compiler", "compiler_auxiliary", "escape", "layout")
    }
    report = {
        "accepted": all(gates.values()),
        "gates": gates,
        "input_sha256": input_hashes,
        "normalization": {
            "code": "whole-function load addresses and in-function targets only",
            "escape": "source file/line/column positions only; per-function full records sorted",
            "compiler": "source positions excluded; frames and PCDATA/FUNCDATA preserved",
            "layout": "none",
        },
    }
    write_json(args.output / "report.json", report)
    return 0 if report["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
